/* Owner-selected traditional rising-cloud C frame. No raster decoration. */
(() => {
 'use strict';
 const button=document.querySelector('.oracle-button[data-oracle-frame="tengyun-c"]');if(!button)return;
 const svg=button.querySelector('svg'),ns='http://www.w3.org/2000/svg';
 const outline='M6 43C12 36 15 29 13 23C5 26 0 21 3 15C6 10 13 11 15 15C11 6 19 0 27 4C30 -1 39 0 43 6C51 1 62 6 61 15C68 10 77 14 77 22C89 25 100 21 112 13C108 30 91 40 74 36C63 48 43 46 35 38C27 47 15 48 6 43Z';
 const scroll='M15 15C19 19 18 25 13 23M27 4C20 11 25 20 33 19C39 18 40 12 36 10C33 8 30 10 31 13M43 6C38 12 44 22 52 21C57 21 61 18 61 15M35 38C42 30 58 28 74 32C90 36 102 25 112 13M12 40C20 39 25 34 27 28';
 function shape(type,attrs,parent=svg){const node=document.createElementNS(ns,type);for(const [k,v] of Object.entries(attrs))node.setAttribute(k,v);parent.append(node);return node;}
 function draw(){
  const {width:w,height:h}=button.getBoundingClientRect();if(!w||!h)return;
  const label=button.querySelector('.oracle-vector-label');
  const gap=(w-label.getBoundingClientRect().width)/2;
  const scale=matchMedia('(max-width:760px)').matches?Math.min(.52,Math.max(.2,(gap-7)/112)):.52;
  button.dataset.cloudScale=String(scale);
  const tailX=3+112*scale,tailY=1+13*scale,startX=3+6*scale,startY=1+43*scale;
  svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.replaceChildren();
  shape('rect',{x:1.2,y:1.2,width:w-2.4,height:h-2.4,rx:8,fill:'none',stroke:'#e4c47c','stroke-width':1.15});
  for(const transform of [`translate(3 1) scale(${scale})`,`translate(${w-3} ${h-1}) scale(${-scale})`]){
   const g=shape('g',{transform});
   for(const [d,weight] of [[outline,1.05],[scroll,1.05*.83]])shape('path',{d,fill:'none',stroke:'#e4c47c','stroke-width':weight,'stroke-linecap':'round','stroke-linejoin':'round','vector-effect':'non-scaling-stroke'},g);
  }
  for(const d of [`M1.2 24C2 23 4 23 ${startX} ${startY}M${tailX} ${tailY}C79 4 95 4 119 4H${w-13}Q${w-4} 4 ${w-4} 13V${h-30}`,`M${w-1.2} ${h-24}C${w-2} ${h-23} ${w-4} ${h-23} ${w-startX} ${h-startY}M${w-tailX} ${h-tailY}C${w-79} ${h-4} ${w-95} ${h-4} ${w-119} ${h-4}H13Q4 ${h-4} 4 ${h-13}V30`])shape('path',{d,fill:'none',stroke:'#e4c47c','stroke-width':1,'stroke-linecap':'round','stroke-linejoin':'round'});
 }
 draw();if(document.fonts)document.fonts.ready.then(draw);if('ResizeObserver'in window)new ResizeObserver(draw).observe(button);else addEventListener('resize',draw);
})();
