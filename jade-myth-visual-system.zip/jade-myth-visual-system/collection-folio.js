/* Progressive finding aids. All links exist server-side before JavaScript. */
(() => {
 'use strict';
 const creatureRoot=document.querySelector('[data-cf-creatures]');
 if(creatureRoot){
  const cards=[...creatureRoot.querySelectorAll('[data-cf-creature]')], search=creatureRoot.querySelector('[data-cf-creature-search]'), status=creatureRoot.querySelector('[data-cf-creature-status]'), more=creatureRoot.querySelector('[data-cf-show-all]'), buttons=[...creatureRoot.querySelectorAll('[data-cf-group]')];
  let group='all',expanded=false;
  const update=()=>{const q=search.value.toLocaleLowerCase().trim();let found=0,shown=0;cards.forEach(c=>{const match=(!q||c.textContent.toLocaleLowerCase().includes(q))&&(group==='all'||c.dataset.group===group);if(match)found++;c.hidden=!match||(!expanded&&!q&&group==='all'&&shown>=8);if(!c.hidden)shown++;});status.textContent=`Showing ${shown} of ${found} matching creatures.`;more.hidden=shown>=found;};
  search.addEventListener('input',update);more.addEventListener('click',()=>{expanded=true;update();});
  buttons.forEach(b=>b.addEventListener('click',()=>{group=b.dataset.cfGroup;buttons.forEach(n=>n.setAttribute('aria-pressed',String(n===b)));update();}));update();
 }
 document.querySelectorAll('[data-cf-library]').forEach(root=>{const input=root.querySelector('[data-cf-record-search]'),records=[...root.querySelectorAll('[data-cf-record]')],status=root.querySelector('[data-cf-library-status]');input.addEventListener('input',()=>{const q=input.value.toLocaleLowerCase().trim();let count=0;records.forEach(r=>{r.hidden=!r.textContent.toLocaleLowerCase().includes(q);if(!r.hidden)count++;});status.textContent=`${count} matching records.`;});});
 document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',()=>{const target=document.getElementById(a.hash.slice(1));if(target instanceof HTMLDetailsElement)target.open=true;}));
 document.querySelectorAll('[data-cf-subject]').forEach(a=>a.addEventListener('click',()=>{
  const input=document.querySelector('[data-cf-record-search]');
  if(input){input.value=a.dataset.cfSubject==='Archaeology'?'archaeology':a.dataset.cfSubject.replace(' and ',' & ');input.dispatchEvent(new Event('input'));}
 }));
 const initial=document.getElementById(location.hash.slice(1));if(initial instanceof HTMLDetailsElement)initial.open=true;
})();
