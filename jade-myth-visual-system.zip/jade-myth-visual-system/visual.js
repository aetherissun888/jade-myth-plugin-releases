document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('[data-jm-menu-toggle]');
  const menu = document.querySelector('[data-jm-menu]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = menu.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  const creatureIndex = document.querySelector('[data-jm-creature-index]');
  if (creatureIndex) {
    const filter = creatureIndex.querySelector('[data-jm-creature-filter]');
    const clear = creatureIndex.querySelector('[data-jm-creature-clear]');
    const status = creatureIndex.querySelector('[data-jm-creature-status]');
    const empty = creatureIndex.querySelector('[data-jm-creature-empty]');
    const rooms = [...creatureIndex.querySelectorAll('[data-jm-creature-room]')];
    const records = [...creatureIndex.querySelectorAll('[data-jm-creature-record]')];
    const normalize = (value) => String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();

    const applyFilter = () => {
      if (!filter || !status || !empty) return;
      const query = normalize(filter.value);
      let visibleRecords = 0;
      let visibleRooms = 0;

      records.forEach((record) => {
        const match = !query || normalize(record.dataset.search).includes(query);
        record.classList.toggle('is-filtered-out', !match);
        if (match) visibleRecords += 1;
      });

      rooms.forEach((room) => {
        const hasMatch = room.querySelectorAll('[data-jm-creature-record]:not(.is-filtered-out)').length > 0;
        room.classList.toggle('is-filtered-out', !hasMatch);
        if (hasMatch) visibleRooms += 1;
      });

      empty.hidden = visibleRecords > 0;
      if (clear) clear.hidden = !query;
      creatureIndex.classList.toggle('is-filtering', Boolean(query));
      status.textContent = query
        ? `Showing ${visibleRecords} matching ${visibleRecords === 1 ? 'record' : 'records'} in ${visibleRooms} ${visibleRooms === 1 ? 'room' : 'rooms'}.`
        : `Showing ${visibleRecords} reviewed records in ${visibleRooms} rooms.`;
    };

    if (filter) filter.addEventListener('input', applyFilter);
    if (clear && filter) {
      clear.addEventListener('click', () => {
        filter.value = '';
        applyFilter();
        filter.focus();
      });
    }
    applyFilter();
  }

  const newsletterForm = document.querySelector('[data-jm-newsletter-form]');
  if (newsletterForm && window.fetch) {
    newsletterForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const email = newsletterForm.querySelector('input[name="email"]');
      const submit = newsletterForm.querySelector('button[type="submit"]');
      const status = newsletterForm.querySelector('[role="status"]');
      const token = newsletterForm.querySelector('input[name="cf-turnstile-response"]');
      if (!email || !submit || !status) return;

      status.className = 'jm-newsletter-form__status';
      if (!email.checkValidity()) {
        email.reportValidity();
        status.textContent = 'Enter a complete email address.';
        return;
      }
      if (!token || !token.value) {
        status.textContent = 'Complete the verification before continuing.';
        return;
      }

      submit.disabled = true;
      status.textContent = 'Requesting your confirmation email…';
      try {
        const response = await fetch(newsletterForm.dataset.gateway, {
          method: 'POST',
          mode: 'cors',
          credentials: 'omit',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ email: email.value, turnstileToken: token.value }),
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Subscription is temporarily unavailable.');
        newsletterForm.reset();
        status.classList.add('is-success');
        status.textContent = result.message;
      } catch (error) {
        status.classList.add('is-error');
        status.textContent = error instanceof Error ? error.message : 'Subscription is temporarily unavailable.';
      } finally {
        submit.disabled = false;
        if (window.turnstile) window.turnstile.reset();
      }
    });
  }

  const compactMobileTradition = (card) => {
    if (!card.classList.contains('jm-live-almanac--mobile')) return;

    const summaries = [
      card.querySelector('[data-jm-almanac-yi-summary]'),
      card.querySelector('[data-jm-almanac-ji-summary]'),
    ];

    summaries.forEach((summary) => {
      if (!summary) return;
      const prefix = summary.textContent.trim().startsWith('忌') ? '忌' : '宜';
      const value = summary.textContent
        .replace(/^[宜忌]\s*[·/\\-]?\s*/, '')
        .split(/[·/]/)[0]
        .trim();
      summary.textContent = `${prefix} ${value.length > 10 ? `${value.slice(0, 10)}…` : (value || '—')}`;
    });
  };

  const cards = [...document.querySelectorAll('[data-jm-almanac-card]')];
  const referenceAlmanacs = [...document.querySelectorAll('[data-jm-reference-almanac]')];
  cards.forEach(compactMobileTradition);
  if ((!cards.length && !referenceAlmanacs.length) || !window.fetch) return;

  let timezone = '';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch (error) {
    // The server-side card remains a complete, accessible fallback.
  }

  const endpoint = new URL('/wp-json/jade-myth/v1/almanac', window.location.origin);
  if (timezone) endpoint.searchParams.set('timezone', timezone);

  fetch(endpoint.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('Almanac unavailable')))
    .then((data) => {
      cards.forEach((card) => {
        const date = card.querySelector('[data-jm-almanac-date]');
        const season = card.querySelector('[data-jm-almanac-season]');
        const focus = card.querySelector('[data-jm-almanac-focus]');
        const gently = card.querySelector('[data-jm-almanac-gently]');
        const disclaimer = card.querySelector('[data-jm-almanac-disclaimer]');
        const yiSummary = card.querySelector('[data-jm-almanac-yi-summary]');
        const jiSummary = card.querySelector('[data-jm-almanac-ji-summary]');

        if (date && data.civil_date) {
          date.dateTime = data.civil_date;
          date.textContent = data.civil_label;
        }
        if (season && data.solar_term) {
          const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
          season.textContent = `${lunar} · ${data.solar_term.name || 'Seasonal reflection'}`;
        }
        if (focus && data.today_focus) focus.textContent = data.today_focus;
        if (gently && data.go_gently_with) gently.textContent = data.go_gently_with;
        if (disclaimer && data.disclaimer) disclaimer.textContent = data.disclaimer;

        if (data.traditional_record) {
          const summary = (items, prefix) => {
            const label = (items || []).map((item) => item.zh).find(Boolean) || '—';
            return `${prefix} ${label.length > 10 ? `${label.slice(0, 10)}…` : label}`;
          };
          if (yiSummary) yiSummary.textContent = summary(data.traditional_record.suitable, '宜');
          if (jiSummary) jiSummary.textContent = summary(data.traditional_record.discouraged, '忌');
        }

        compactMobileTradition(card);
        card.dataset.jmAlmanacStatus = data.status || 'calculated';
      });

      referenceAlmanacs.forEach((page) => {
        const setText = (selector, value) => {
          if (value === undefined || value === null || value === '') return;
          page.querySelectorAll(selector).forEach((element) => { element.textContent = value; });
        };
        const [year, month, day] = String(data.civil_date || '').split('-').map(Number);
        if (year && month && day) {
          const localDate = new Date(Date.UTC(year, month - 1, day));
          setText('[data-jm-reference-year]', String(year));
          setText('[data-jm-reference-month]', new Intl.DateTimeFormat('en-US', { month: 'long', timeZone: 'UTC' }).format(localDate).toUpperCase());
          setText('[data-jm-reference-day]', String(day));
          setText('[data-jm-reference-weekday]', new Intl.DateTimeFormat('en-US', { weekday: 'long', timeZone: 'UTC' }).format(localDate).toUpperCase());
          page.querySelectorAll('[data-jm-reference-day]').forEach((element) => { element.dateTime = data.civil_date; });
        }
        const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
        const term = data.solar_term ? [data.solar_term.name, data.solar_term.chinese].filter(Boolean).join(' ') : 'Not listed';
        const terms = (items) => (items || [])
          .map((item) => [item.zh, item.en].filter(Boolean).join(' / '))
          .filter(Boolean)
          .join('; ') || 'Not listed';
        setText('[data-jm-reference-lunar], [data-jm-reference-lunar-date]', lunar);
        setText('[data-jm-reference-term]', term);
        if (data.traditional_record) {
          setText('[data-jm-reference-yi]', terms(data.traditional_record.suitable));
          setText('[data-jm-reference-ji]', terms(data.traditional_record.discouraged));
          setText('[data-jm-reference-method]', data.traditional_record.edition || 'Versioned cultural calendar record');
        }
        page.dataset.jmAlmanacStatus = data.status || 'calculated';
      });
    })
    .catch(() => {
      cards.forEach((card) => { card.dataset.jmAlmanacStatus = 'server-fallback'; });
      referenceAlmanacs.forEach((page) => { page.dataset.jmAlmanacStatus = 'server-fallback'; });
    });
});
