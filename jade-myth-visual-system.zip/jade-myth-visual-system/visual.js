document.addEventListener('DOMContentLoaded', () => {
  const PLACEHOLDER_TEXT_PATTERN = /\btrans-[\w._-]+\b/i;

  const hasPlaceholderText = (node) => PLACEHOLDER_TEXT_PATTERN.test(node.textContent || '');

  const isPlaceholderElement = (element) => {
    if (!(element instanceof Element)) {
      return false;
    }

    const href = element.getAttribute('href') || '';
    if (/\btrans-/i.test(href)) {
      return true;
    }

    const className = element.getAttribute('class') || '';
    const id = element.getAttribute('id') || '';
    if (/\btrans-/.test(className) || /\btrans-/.test(id)) {
      return true;
    }

    const text = (element.textContent || '').trim();
    if (!text) {
      return false;
    }

    return PLACEHOLDER_TEXT_PATTERN.test(text) || /trans-contact|trans-social|trans-newsletter|trans-menu|trans-contacts|all-rights-reserved|current-year/i.test(text);
  };

  const removeNodeSafe = (node) => {
    if (!(node && node.parentElement)) {
      return;
    }
    node.remove();
  };

  const normalizeFooter = (root = document) => {
    const placeholders = root.querySelectorAll('*');

    placeholders.forEach((element) => {
      if (!element || element === document.body || element === document.documentElement) {
        return;
      }

      const href = element.getAttribute && element.getAttribute('href');
      const isEmailProtection = href && href.startsWith('/cdn-cgi/l/email-protection');

      if (isEmailProtection || /\btel:trans-/i.test(href || '') || isPlaceholderElement(element)) {
        const anchorHostFooter = element.closest('footer.site-footer, footer.wp-block-template-part, .wp-block-template-part, footer');
        if (anchorHostFooter) {
          removeNodeSafe(anchorHostFooter);
          return;
        }

        const navHost = element.closest('.wp-block-navigation, .wp-block-social-links, .wp-block-column, .wp-block-columns, .wp-block-group, p, li');
        if (navHost) {
          removeNodeSafe(navHost);
          return;
        }

        removeNodeSafe(element);
      }
    });

    const socialWrappers = root.querySelectorAll('.wp-block-social-links, .hostinger-reach-block-subscription-form-wrapper, .hostinger-reach-block-subscription-form, .site-footer');
    socialWrappers.forEach((element) => {
      if (hasPlaceholderText(element) || /trans-/i.test((element.className || '')) || /Hostinger/i.test((element.className || ''))) {
        removeNodeSafe(element);
      }
    });
  };

  const removeLegacyFooterBlocks = () => {
    normalizeFooter(document);

    const duplicatedLegacyFooter = document.querySelector('footer.site-footer.wp-block-template-part, footer.site-footer, footer.wp-block-template-part');
    if (duplicatedLegacyFooter) {
      duplicatedLegacyFooter.remove();
    }
  };

  const compactMobileTradition = (card) => {
    if (!card || !card.classList.contains('jm-live-almanac--mobile')) {
      return;
    }
    const yiSummary = card.querySelector('[data-jm-almanac-yi-summary]');
    const jiSummary = card.querySelector('[data-jm-almanac-ji-summary]');
    if (!yiSummary || !jiSummary) {
      return;
    }
    const yiText = yiSummary.textContent ? yiSummary.textContent.replace(/^宜\\s*[·\\/\\-]?\\s*/, '').trim() : '';
    const jiText = jiSummary.textContent ? jiSummary.textContent.replace(/^忌\\s*[·\\/\\-]?\\s*/, '').trim() : '';
    if (yiText || jiText) {
      yiSummary.textContent = `宜 ${yiText || '—'} / 忌 ${jiText || '—'}`;
      jiSummary.style.display = 'none';
    }
  };

  removeLegacyFooterBlocks();
  const legacyObserver = new MutationObserver(() => {
    removeLegacyFooterBlocks();
  });
  legacyObserver.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => {
    removeLegacyFooterBlocks();
    legacyObserver.disconnect();
  }, 9000);

  const button = document.querySelector('[data-jm-menu-toggle]');
  const menu = document.querySelector('[data-jm-menu]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = menu.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  document.querySelectorAll('[data-jm-newsletter-hold]').forEach((form) => {
    const subscribe = form.querySelector('button');
    const notice = form.querySelector('[role="status"]');
    if (!subscribe || !notice) return;

    subscribe.addEventListener('click', () => {
      const message = 'The mailing list is opening soon. No email address is collected from this form today.';
      notice.textContent = message;

      let visible = form.querySelector('.jm-newsletter-hold__message');
      if (!visible) {
        visible = document.createElement('p');
        visible.className = 'jm-newsletter-hold__message';
        visible.setAttribute('aria-hidden', 'true');
        form.append(visible);
      }
      visible.textContent = message;
    });
  });

  const cards = [...document.querySelectorAll('[data-jm-almanac-card]')];
  cards.forEach(compactMobileTradition);
  if (!cards.length || !window.fetch) return;

  let timezone = '';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch (error) {
    // The server-side card remains a complete, accessible fallback.
  }

  const endpoint = new URL('/wp-json/jade-myth/v1/almanac', window.location.origin);
  if (timezone) endpoint.searchParams.set('timezone', timezone);

  fetch(endpoint.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('Almanac unavailable')))
    .then((data) => {
      cards.forEach((card) => {
        const date = card.querySelector('[data-jm-almanac-date]');
        const season = card.querySelector('[data-jm-almanac-season]');
        const focus = card.querySelector('[data-jm-almanac-focus]');
        const gently = card.querySelector('[data-jm-almanac-gently]');
        const disclaimer = card.querySelector('[data-jm-almanac-disclaimer]');
        const yiSummary = card.querySelector('[data-jm-almanac-yi-summary]');
        const jiSummary = card.querySelector('[data-jm-almanac-ji-summary]');
        if (date && data.civil_date) {
          date.dateTime = data.civil_date;
          date.textContent = data.civil_label;
        }
        if (season && data.solar_term) {
          const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
          season.textContent = `${lunar} · ${data.solar_term.name || 'Seasonal reflection'}`;
        }
        if (focus && data.today_focus) focus.textContent = data.today_focus;
        if (gently && data.go_gently_with) gently.textContent = data.go_gently_with;
        if (disclaimer && data.disclaimer) disclaimer.textContent = data.disclaimer;
        if (data.traditional_record) {
          const summary = (items, prefix) => {
            const labels = (items || []).slice(0, 2).map((item) => item.zh).filter(Boolean);
            return labels.length ? `${prefix} · ${labels.join(' · ')}` : `${prefix} · No recorded labels`;
          };
          if (yiSummary) yiSummary.textContent = summary(data.traditional_record.suitable, '宜');
          if (jiSummary) jiSummary.textContent = summary(data.traditional_record.discouraged, '忌');
        }
        compactMobileTradition(card);
        card.dataset.jmAlmanacStatus = data.status || 'calculated';
      });
    })
    .catch(() => {
      cards.forEach((card) => { card.dataset.jmAlmanacStatus = 'server-fallback'; });
    });
});
