document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('[data-jm-menu-toggle]');
  const menu = document.querySelector('[data-jm-menu]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = menu.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }
});
