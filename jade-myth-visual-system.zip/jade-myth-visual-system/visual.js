document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('[data-jm-menu-toggle]');
  const menu = document.querySelector('[data-jm-menu]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = menu.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  document.querySelectorAll('[data-jm-newsletter-hold]').forEach((form) => {
    const subscribe = form.querySelector('button');
    const notice = form.querySelector('[role="status"]');
    if (!subscribe || !notice) return;

    subscribe.addEventListener('click', () => {
      const message = 'The mailing list is opening soon. No email address is collected from this form today.';
      notice.textContent = message;

      let visible = form.querySelector('.jm-newsletter-hold__message');
      if (!visible) {
        visible = document.createElement('p');
        visible.className = 'jm-newsletter-hold__message';
        visible.setAttribute('aria-hidden', 'true');
        form.append(visible);
      }
      visible.textContent = message;
    });
  });

  const compactMobileTradition = (card) => {
    if (!card.classList.contains('jm-live-almanac--mobile')) return;

    const summaries = [
      card.querySelector('[data-jm-almanac-yi-summary]'),
      card.querySelector('[data-jm-almanac-ji-summary]'),
    ];

    summaries.forEach((summary) => {
      if (!summary) return;
      const prefix = summary.textContent.trim().startsWith('忌') ? '忌' : '宜';
      const value = summary.textContent
        .replace(/^[宜忌]\s*[·/\\-]?\s*/, '')
        .split(/[·/]/)[0]
        .trim();
      summary.textContent = `${prefix} ${value.length > 10 ? `${value.slice(0, 10)}…` : (value || '—')}`;
    });
  };

  const cards = [...document.querySelectorAll('[data-jm-almanac-card]')];
  const referenceAlmanacs = [...document.querySelectorAll('[data-jm-reference-almanac]')];
  cards.forEach(compactMobileTradition);
  if ((!cards.length && !referenceAlmanacs.length) || !window.fetch) return;

  let timezone = '';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch (error) {
    // The server-side card remains a complete, accessible fallback.
  }

  const endpoint = new URL('/wp-json/jade-myth/v1/almanac', window.location.origin);
  if (timezone) endpoint.searchParams.set('timezone', timezone);

  fetch(endpoint.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('Almanac unavailable')))
    .then((data) => {
      cards.forEach((card) => {
        const date = card.querySelector('[data-jm-almanac-date]');
        const season = card.querySelector('[data-jm-almanac-season]');
        const focus = card.querySelector('[data-jm-almanac-focus]');
        const gently = card.querySelector('[data-jm-almanac-gently]');
        const disclaimer = card.querySelector('[data-jm-almanac-disclaimer]');
        const yiSummary = card.querySelector('[data-jm-almanac-yi-summary]');
        const jiSummary = card.querySelector('[data-jm-almanac-ji-summary]');

        if (date && data.civil_date) {
          date.dateTime = data.civil_date;
          date.textContent = data.civil_label;
        }
        if (season && data.solar_term) {
          const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
          season.textContent = `${lunar} · ${data.solar_term.name || 'Seasonal reflection'}`;
        }
        if (focus && data.today_focus) focus.textContent = data.today_focus;
        if (gently && data.go_gently_with) gently.textContent = data.go_gently_with;
        if (disclaimer && data.disclaimer) disclaimer.textContent = data.disclaimer;

        if (data.traditional_record) {
          const summary = (items, prefix) => {
            const label = (items || []).map((item) => item.zh).find(Boolean) || '—';
            return `${prefix} ${label.length > 10 ? `${label.slice(0, 10)}…` : label}`;
          };
          if (yiSummary) yiSummary.textContent = summary(data.traditional_record.suitable, '宜');
          if (jiSummary) jiSummary.textContent = summary(data.traditional_record.discouraged, '忌');
        }

        compactMobileTradition(card);
        card.dataset.jmAlmanacStatus = data.status || 'calculated';
      });

      referenceAlmanacs.forEach((page) => {
        const setText = (selector, value) => {
          if (value === undefined || value === null || value === '') return;
          page.querySelectorAll(selector).forEach((element) => { element.textContent = value; });
        };
        const [year, month, day] = String(data.civil_date || '').split('-').map(Number);
        if (year && month && day) {
          const localDate = new Date(Date.UTC(year, month - 1, day));
          setText('[data-jm-reference-year]', String(year));
          setText('[data-jm-reference-month]', new Intl.DateTimeFormat('en-US', { month: 'long', timeZone: 'UTC' }).format(localDate).toUpperCase());
          setText('[data-jm-reference-day]', String(day));
          setText('[data-jm-reference-weekday]', new Intl.DateTimeFormat('en-US', { weekday: 'long', timeZone: 'UTC' }).format(localDate).toUpperCase());
          page.querySelectorAll('[data-jm-reference-day]').forEach((element) => { element.dateTime = data.civil_date; });
        }
        const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
        const term = data.solar_term ? [data.solar_term.name, data.solar_term.chinese].filter(Boolean).join(' ') : '—';
        const terms = (items) => (items || [])
          .map((item) => [item.zh, item.en].filter(Boolean).join(' — '))
          .filter(Boolean)
          .join(' · ') || '—';
        setText('[data-jm-reference-lunar], [data-jm-reference-lunar-date]', lunar);
        setText('[data-jm-reference-term]', term);
        if (data.traditional_record) {
          setText('[data-jm-reference-yi]', terms(data.traditional_record.suitable));
          setText('[data-jm-reference-ji]', terms(data.traditional_record.discouraged));
          setText('[data-jm-reference-method]', data.traditional_record.edition || 'Versioned cultural calendar record');
        }
        page.dataset.jmAlmanacStatus = data.status || 'calculated';
      });
    })
    .catch(() => {
      cards.forEach((card) => { card.dataset.jmAlmanacStatus = 'server-fallback'; });
      referenceAlmanacs.forEach((page) => { page.dataset.jmAlmanacStatus = 'server-fallback'; });
    });
});
