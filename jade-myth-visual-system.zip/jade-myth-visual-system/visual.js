document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('[data-jm-menu-toggle]');
  const menu = document.querySelector('[data-jm-menu]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = menu.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  const cards = [...document.querySelectorAll('[data-jm-almanac-card]')];
  if (!cards.length || !window.fetch) return;

  let timezone = '';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch (error) {
    // The server-side card remains a complete, accessible fallback.
  }

  const endpoint = new URL('/wp-json/jade-myth/v1/almanac', window.location.origin);
  if (timezone) endpoint.searchParams.set('timezone', timezone);

  fetch(endpoint.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then((response) => response.ok ? response.json() : Promise.reject(new Error('Almanac unavailable')))
    .then((data) => {
      cards.forEach((card) => {
        const date = card.querySelector('[data-jm-almanac-date]');
        const season = card.querySelector('[data-jm-almanac-season]');
        const focus = card.querySelector('[data-jm-almanac-focus]');
        const gently = card.querySelector('[data-jm-almanac-gently]');
        const disclaimer = card.querySelector('[data-jm-almanac-disclaimer]');
        const yiSummary = card.querySelector('[data-jm-almanac-yi-summary]');
        const jiSummary = card.querySelector('[data-jm-almanac-ji-summary]');
        if (date && data.civil_date) {
          date.dateTime = data.civil_date;
          date.textContent = data.civil_label;
        }
        if (season && data.solar_term) {
          const lunar = data.lunar && data.lunar.display ? data.lunar.display : 'Lunar calendar';
          season.textContent = `${lunar} · ${data.solar_term.name || 'Seasonal reflection'}`;
        }
        if (focus && data.today_focus) focus.textContent = data.today_focus;
        if (gently && data.go_gently_with) gently.textContent = data.go_gently_with;
        if (disclaimer && data.disclaimer) disclaimer.textContent = data.disclaimer;
        if (data.traditional_record) {
          const summary = (items, prefix) => {
            const labels = (items || []).slice(0, 2).map((item) => item.zh).filter(Boolean);
            return labels.length ? `${prefix} · ${labels.join(' · ')}` : `${prefix} · No recorded labels`;
          };
          if (yiSummary) yiSummary.textContent = summary(data.traditional_record.suitable, '宜');
          if (jiSummary) jiSummary.textContent = summary(data.traditional_record.discouraged, '忌');
        }
        card.dataset.jmAlmanacStatus = data.status || 'calculated';
      });
    })
    .catch(() => {
      cards.forEach((card) => { card.dataset.jmAlmanacStatus = 'server-fallback'; });
    });
});
