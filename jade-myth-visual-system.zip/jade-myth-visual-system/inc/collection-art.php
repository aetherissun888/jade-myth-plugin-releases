<?php
/** Contemporary E3 artwork, not evidence images or merchandise inventory. */
function jade_myth_collection_art( $key ) {
	$art = array(
		'explore' => array( 'Mountains, seas, and an imagined fox.', 'Modern interpretation inspired by the Shan Hai Jing; not an ancient map.' ),
		'wisdom' => array( 'Scrolls, a brush, an inkstone, and an imagined bronze paperweight.', 'An imagined reading-room still life; not a record of historical objects.' ),
		'daily-almanac' => array( 'Four seasons beneath a gold sun and pale moon.', 'An imagined seasonal landscape; not an astronomical chart.' ),
		'sanctuary' => array( 'A pavilion beside a lake, mountains, pines, and lotus leaves.', 'An imagined landscape; not a photograph of a real place.' ),
		'mysteries' => array( 'An abstract composition of bronze-inspired relief and patina.', 'An imagined material study; not archaeological evidence.' ),
		'shop' => array( 'An ivory art folio, a cloth-bound book, and a silk ribbon.', 'An imagined atelier; these are not products offered for sale.' ),
		'account' => array( 'A closed book and jade-colored bookmark beside a lattice window.', 'An imagined reading corner.' ),
	);
	if ( ! isset( $art[ $key ] ) ) { return ''; }
	$url = JADE_MYTH_VISUAL_URL . 'art/' . $key . '.webp';
	$reuse = home_url( '/ai-disclosure/' );
	$schema = array(
		'@context' => 'https://schema.org', '@type' => 'ImageObject',
		'contentUrl' => $url, 'name' => $art[ $key ][0],
		'creator' => array( '@type' => 'Organization', 'name' => 'Jade & Myth Editorial' ),
		'creditText' => 'Jade & Myth Editorial, original AI-assisted illustration',
		'copyrightNotice' => 'Jade & Myth Editorial — AI-assisted editorial illustration; see reuse terms.',
		'license' => $reuse, 'acquireLicensePage' => $reuse,
		'caption' => $art[ $key ][1] . ' Original AI-assisted editorial illustration.',
	);
	ob_start(); ?>
	<figure class="jm-collection-art jm-collection-art--<?php echo esc_attr( $key ); ?>" data-evidence-class="E3">
		<img src="<?php echo esc_url( $url ); ?>" srcset="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'art/' . $key . '-768.webp' ); ?> 768w, <?php echo esc_url( $url ); ?> 1536w" sizes="(max-width: 900px) 100vw, 55vw" width="1536" height="1024" alt="<?php echo esc_attr( $art[ $key ][0] ); ?>" loading="eager" fetchpriority="high" decoding="async">
		<figcaption><?php echo esc_html( $art[ $key ][1] ); ?> <a href="<?php echo esc_url( $reuse ); ?>">Jade &amp; Myth Editorial · AI-assisted illustration</a></figcaption>
	</figure>
	<script type="application/ld+json"><?php echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?></script>
	<?php return ob_get_clean();
}
