<?php
/**
 * Privacy-first newsletter presentation and activation gates.
 *
 * Subscriber records live with the approved email service provider. WordPress
 * stores only non-secret operational configuration and never receives an email
 * address from this integration.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Jade_Myth_Newsletter {
	const OPTION_KEY      = 'jm_newsletter_configuration';
	const PRIVACY_VERSION = '2026-08-23';

	public static function bootstrap() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function gate_labels() {
		return array(
			'provider_verified'        => 'Provider account verified',
			'dns_authenticated'         => 'DKIM, SPF, and DMARC verified',
			'double_opt_in_verified'    => 'Double opt-in tested',
			'unsubscribe_verified'      => 'One-click unsubscribe tested',
			'suppression_verified'      => 'Suppression and resubscribe tested',
			'privacy_notice_published'  => 'Current privacy notice published',
			'postal_address_configured' => 'Valid postal address configured',
		);
	}

	public static function defaults() {
		return array(
			'provider'       => 'brevo',
			'form_url'       => '',
			'enabled'        => false,
			'privacy_version'=> self::PRIVACY_VERSION,
			'gates'          => array_fill_keys( array_keys( self::gate_labels() ), false ),
			'updated_at'     => '',
			'updated_by'     => 0,
		);
	}

	public static function configuration() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$config          = wp_parse_args( $stored, self::defaults() );
		$config['gates'] = wp_parse_args(
			isset( $stored['gates'] ) && is_array( $stored['gates'] ) ? $stored['gates'] : array(),
			self::defaults()['gates']
		);
		return $config;
	}

	public static function valid_form_url( $url ) {
		$url  = esc_url_raw( $url );
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! $host ) {
			return false;
		}
		return 'sibforms.com' === $host || '.sibforms.com' === substr( $host, -13 );
	}

	public static function ready( $config = null ) {
		$config = is_array( $config ) ? $config : self::configuration();
		if ( empty( $config['enabled'] ) || ! self::valid_form_url( $config['form_url'] ) ) {
			return false;
		}
		foreach ( array_keys( self::gate_labels() ) as $gate ) {
			if ( empty( $config['gates'][ $gate ] ) ) {
				return false;
			}
		}
		return self::PRIVACY_VERSION === $config['privacy_version'];
	}

	public static function public_status() {
		$config = self::configuration();
		$gates  = array();
		foreach ( self::gate_labels() as $key => $label ) {
			$gates[ $key ] = array(
				'label'  => $label,
				'passed' => ! empty( $config['gates'][ $key ] ),
			);
		}
		return array(
			'provider'       => 'Brevo',
			'collecting'     => self::ready( $config ),
			'state'          => self::ready( $config ) ? 'open' : 'closed',
			'privacy_version'=> self::PRIVACY_VERSION,
			'gates'          => $gates,
		);
	}

	public static function register_routes() {
		register_rest_route( 'jade-myth/v1', '/newsletter/status', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => array( __CLASS__, 'public_status' ),
		) );

		register_rest_route( 'jade-myth/v1', '/newsletter/configure', array(
			'methods'             => 'POST',
			'permission_callback' => function () {
				return current_user_can( 'update_plugins' );
			},
			'callback'            => array( __CLASS__, 'configure' ),
		) );
	}

	public static function configure( WP_REST_Request $request ) {
		$current = self::configuration();
		$body    = $request->get_json_params();
		$body    = is_array( $body ) ? $body : array();

		$form_url = isset( $body['form_url'] ) ? esc_url_raw( $body['form_url'] ) : $current['form_url'];
		if ( $form_url && ! self::valid_form_url( $form_url ) ) {
			return new WP_Error( 'jm_newsletter_form_host', 'The hosted form must use an approved Brevo HTTPS address.', array( 'status' => 400 ) );
		}

		$gates = $current['gates'];
		if ( isset( $body['gates'] ) && is_array( $body['gates'] ) ) {
			foreach ( array_keys( self::gate_labels() ) as $gate ) {
				if ( array_key_exists( $gate, $body['gates'] ) ) {
					$gates[ $gate ] = rest_sanitize_boolean( $body['gates'][ $gate ] );
				}
			}
		}

		$requested_enabled = isset( $body['enabled'] ) ? rest_sanitize_boolean( $body['enabled'] ) : false;
		$next              = array(
			'provider'        => 'brevo',
			'form_url'        => $form_url,
			'enabled'         => $requested_enabled,
			'privacy_version' => self::PRIVACY_VERSION,
			'gates'           => $gates,
			'updated_at'      => gmdate( 'c' ),
			'updated_by'      => get_current_user_id(),
		);

		if ( $requested_enabled && ! self::ready( $next ) ) {
			return new WP_Error( 'jm_newsletter_gates', 'Email collection remains closed until every newsletter gate passes.', array( 'status' => 409 ) );
		}

		update_option( self::OPTION_KEY, $next, false );
		return self::public_status();
	}

	public static function compact_control( $context = 'default' ) {
		if ( ! self::ready() ) {
			return '<aside class="jm-newsletter-hold jm-newsletter-hold--' . esc_attr( $context ) . '" aria-label="Newsletter status">'
				. '<strong>The weekly dispatch is being prepared.</strong>'
				. '<span>No email address is collected today.</span>'
				. '<a href="' . esc_url( home_url( '/newsletter/' ) ) . '">See how subscription will work <span aria-hidden="true">→</span></a>'
				. '</aside>';
		}
		return '<a class="jm-newsletter-open" href="' . esc_url( home_url( '/newsletter/' ) ) . '">Join the weekly dispatch <span aria-hidden="true">→</span></a>';
	}

	public static function page() {
		$config = self::configuration();
		$ready  = self::ready( $config );
		ob_start();
		?>
		<main class="jm-newsletter-page alignfull" data-newsletter-state="<?php echo $ready ? 'open' : 'closed'; ?>">
			<header class="jm-newsletter-page__masthead">
				<div class="jm-newsletter-page__intro">
					<p class="jm-newsletter-page__eyebrow">The Jade &amp; Myth weekly dispatch</p>
					<h1>One mystery. One ritual. One object.</h1>
					<p>A carefully sourced letter from the living archive, sent no more than once a week.</p>
				</div>
				<ol class="jm-newsletter-page__sequence" aria-label="Subscription sequence">
					<li><span>01</span><strong>Enter your address</strong><small>Only when registration opens.</small></li>
					<li><span>02</span><strong>Confirm by email</strong><small>No confirmation, no subscription.</small></li>
					<li><span>03</span><strong>Receive the dispatch</strong><small>Leave at any time in one step.</small></li>
				</ol>
			</header>
			<section class="jm-newsletter-page__desk" aria-labelledby="jm-newsletter-desk-title">
				<div class="jm-newsletter-page__record">
					<p>Collection record</p>
					<dl>
						<div><dt>Frequency</dt><dd>Up to one letter per week</dd></div>
						<div><dt>Provider</dt><dd>Brevo</dd></div>
						<div><dt>Consent</dt><dd>Double opt-in</dd></div>
						<div><dt>Data</dt><dd>Email address and consent record</dd></div>
					</dl>
				</div>
				<div class="jm-newsletter-page__form">
					<h2 id="jm-newsletter-desk-title"><?php echo $ready ? 'Join the archive' : 'Registration is not open yet'; ?></h2>
					<?php if ( $ready ) : ?>
						<iframe src="<?php echo esc_url( $config['form_url'] ); ?>" title="Jade &amp; Myth newsletter subscription" loading="eager" referrerpolicy="strict-origin-when-cross-origin"></iframe>
						<p class="jm-newsletter-page__fallback"><a href="<?php echo esc_url( $config['form_url'] ); ?>" rel="external noopener">Open the secure subscription form</a></p>
					<?php else : ?>
						<div class="jm-newsletter-page__closed" role="status">
							<span aria-hidden="true">封</span>
							<p>We are finishing sender authentication, confirmation, unsubscribe, suppression, and privacy checks. No email field is active on this site today.</p>
						</div>
					<?php endif; ?>
					<p class="jm-newsletter-page__privacy">Subscription is optional. We do not sell newsletter addresses. Read the <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a> or contact <a href="mailto:support@jadeandmyth.com">support@jadeandmyth.com</a>.</p>
				</div>
			</section>
		</main>
		<?php
		return ob_get_clean();
	}
}

Jade_Myth_Newsletter::bootstrap();
