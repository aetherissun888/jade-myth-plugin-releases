<?php
if ( ! defined( 'ABSPATH' ) && 'cli' !== PHP_SAPI ) {
	exit;
}

/** Decode and retain the reviewed article figures plus one six-card learning set. */
function jade_myth_inline_image_records( $raw ) {
	$decoded = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
	if ( ! is_array( $decoded ) ) {
		return array();
	}
	$records = array();
	foreach ( array_slice( $decoded, 0, 9 ) as $record ) {
		if ( ! is_array( $record ) ) {
			continue;
		}
		$urls = array( 'content_url', 'license_url', 'acquire_license_url' );
		foreach ( $urls as $key ) {
			if ( empty( $record[ $key ] ) || ! filter_var( $record[ $key ], FILTER_VALIDATE_URL ) || 'https' !== parse_url( $record[ $key ], PHP_URL_SCHEME ) ) {
			continue 2;
			}
		}
		$type = isset( $record['creator_type'] ) ? trim( $record['creator_type'] ) : '';
		if ( ! in_array( $type, array( 'Person', 'Organization' ), true ) ) {
			continue;
		}
		$clean = array();
		foreach ( array( 'alt', 'caption', 'credit', 'rights', 'creator_name' ) as $key ) {
			$clean[ $key ] = isset( $record[ $key ] ) ? trim( strip_tags( (string) $record[ $key ] ) ) : '';
			if ( '' === $clean[ $key ] ) {
				continue 2;
			}
		}
		$clean['content_url'] = $record['content_url'];
		$credit_url = isset( $record['credit_url'] ) ? $record['credit_url'] : '';
		$clean['credit_url'] = filter_var( $credit_url, FILTER_VALIDATE_URL ) && 'https' === parse_url( $credit_url, PHP_URL_SCHEME )
			? $credit_url
			: $record['acquire_license_url'];
		$clean['license_url'] = $record['license_url'];
		$clean['acquire_license_url'] = $record['acquire_license_url'];
		$clean['creator_type'] = $type;
		$clean['width'] = abs( (int) ( $record['width'] ?? 0 ) );
		$clean['height'] = abs( (int) ( $record['height'] ?? 0 ) );
		if ( ! $clean['width'] || ! $clean['height'] ) {
			continue;
		}
		$records[] = $clean;
	}
	return $records;
}

function jade_myth_inline_image_meta_sanitize( $raw ) {
	return json_encode( jade_myth_inline_image_records( $raw ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
}

function jade_myth_inline_image_schema_nodes( $raw, $canonical ) {
	$nodes = array();
	foreach ( jade_myth_inline_image_records( $raw ) as $index => $record ) {
		$nodes[] = array(
			'@type' => 'ImageObject',
			'@id' => $canonical . '#inline-image-' . ( $index + 1 ),
			'contentUrl' => $record['content_url'],
			'url' => $record['content_url'],
			'width' => $record['width'],
			'height' => $record['height'],
			'name' => $record['alt'],
			'caption' => $record['caption'],
			'creditText' => $record['credit'],
			'copyrightNotice' => $record['rights'],
			'license' => $record['license_url'],
			'creator' => array( '@type' => $record['creator_type'], 'name' => $record['creator_name'] ),
			'acquireLicensePage' => $record['acquire_license_url'],
		);
	}
	return $nodes;
}
