<?php
/** Keep an existing first paragraph above the image for the nine reviewed pages. */
function jade_myth_extract_article_intro( $content, $slug ) {
	$targets = array( 'chinese-mythology', 'shan-hai-jing', 'shanhaijing-tiangou', 'sanxingdui', 'guanyin', 'qilin', 'nuwa', 'year-of-the-rooster', 'throw-a-brick-to-draw-out-jade' );
	if ( ! in_array( $slug, $targets, true ) || ! preg_match( '/^\s*(<p\b[^>]*>.*?<\/p>)/s', $content, $match ) ) {
		return array( 'intro' => '', 'content' => $content );
	}
	return array( 'intro' => $match[1], 'content' => substr( $content, strlen( $match[0] ) ) );
}
