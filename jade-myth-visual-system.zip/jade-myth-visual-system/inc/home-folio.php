<?php
/** Owner-approved homepage folio. Real HTML, immutable artwork extracts. */
function jade_myth_home_art( $name, $alt, $width, $height, $priority = false ) {
	$url = JADE_MYTH_VISUAL_URL . 'art/home/' . $name . '.webp';
	$small = JADE_MYTH_VISUAL_URL . 'art/home/' . $name . '-small.webp';
	return '<img src="' . esc_url( $url ) . '" srcset="' . esc_url( $small ) . ' ' . (int) floor( $width / 2 ) . 'w, ' . esc_url( $url ) . ' ' . (int) $width . 'w" sizes="(max-width: 760px) 100vw, ' . ( $priority ? '100vw' : '60vw' ) . '" width="' . (int) $width . '" height="' . (int) $height . '" alt="' . esc_attr( $alt ) . '" decoding="async" loading="' . ( $priority ? 'eager' : 'lazy' ) . '"' . ( $priority ? ' fetchpriority="high"' : '' ) . '>';
}

function jade_myth_homepage() {
	$creatures = array(
		array( 'dragon', 'Chinese Dragon', '/chinese-dragons-explained/', 134, 212 ),
		array( 'fox', 'Nine-Tailed Fox', '/nine-tailed-fox/', 133, 212 ),
		array( 'qilin', 'Qilin', '/qilin/', 134, 212 ),
		array( 'fenghuang', 'Fenghuang', '/fenghuang-explained/', 132, 212 ),
		array( 'bifang', 'Bifang', '/shanhaijing-bifang/', 600, 400 ),
		array( 'kunpeng', 'Kunpeng', '/kunpeng/', 134, 212 ),
	);
	ob_start(); ?>
	<main class="jm-home-folio alignfull" data-jm-home-folio="1">
		<?php echo jade_myth_motion_hero(); ?>
		<section class="jm-folio-gateway" aria-labelledby="jm-folio-gateway-title">
			<?php echo jade_myth_home_art( 'gateway', 'Painted mountains and a river.', 229, 145 ); ?>
			<div><h2 id="jm-folio-gateway-title">Begin with the Shan Hai Jing</h2><p>A guide to the Classic of Mountains and Seas.</p><a href="<?php echo esc_url( home_url( '/shan-hai-jing/' ) ); ?>">Read the guide <span aria-hidden="true">→</span></a></div>
			<form class="jm-folio-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label class="screen-reader-text" for="jm-folio-search">Find a story, creature, or tradition</label>
				<button type="submit" aria-label="Search the archive"><?php echo jade_myth_icon( 'search' ); ?></button>
				<input id="jm-folio-search" type="search" name="s" placeholder="Find a story, creature, or tradition" required>
			</form>
		</section>
		<section class="jm-folio-creatures" aria-labelledby="jm-folio-creatures-title">
			<header><h2 id="jm-folio-creatures-title">Meet the creatures</h2><a href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>">View the collection <span aria-hidden="true">→</span></a></header>
			<div class="jm-folio-creature-grid">
				<?php foreach ( $creatures as $creature ) : ?>
				<a class="jm-folio-creature" href="<?php echo esc_url( home_url( $creature[2] ) ); ?>">
					<?php echo jade_myth_home_art( $creature[0], 'Editorial interpretation of ' . $creature[1] . '.', $creature[3], $creature[4] ); ?>
					<h3><?php echo esc_html( $creature[1] ); ?></h3>
				</a>
				<?php endforeach; ?>
			</div>
		</section>
		<section class="jm-folio-reading" aria-label="Wisdom and evidence">
			<a class="jm-folio-wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>">
				<?php echo jade_myth_home_art( 'wisdom', 'Imagined scrolls, brush and inkstone in a reading room; editorial illustration.', 529, 246 ); ?>
				<div><h2>Wisdom in the texts</h2><span>Explore Wisdom <span aria-hidden="true">→</span></span></div>
			</a>
			<div class="jm-folio-evidence"><h2>Explore the evidence</h2>
				<a href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>"><?php echo jade_myth_home_art( 'sanxingdui', 'Sanxingdui bronze mask, photographed by Gary Todd.', 600, 400 ); ?><span>Sanxingdui</span><b aria-hidden="true">→</b></a>
				<a href="<?php echo esc_url( home_url( '/qin-shi-huang-tomb/' ) ); ?>"><?php echo jade_myth_home_art( 'qin', 'Excavated bronze chariot and horses, photographed by Gary Todd.', 600, 375 ); ?><span>Qin Shi Huang’s Tomb</span><b aria-hidden="true">→</b></a>
				<a href="<?php echo esc_url( home_url( '/thirty-six-stratagems/' ) ); ?>"><?php echo jade_myth_home_art( 'wisdom', 'An imagined reading-room still life, not an ancient manuscript.', 529, 246 ); ?><span>The Thirty-Six Stratagems</span><b aria-hidden="true">→</b></a>
			</div>
		</section>
		<section class="jm-folio-calendar" aria-labelledby="jm-folio-calendar-title">
			<?php echo jade_myth_home_art( 'calendar-master', 'Original decorative gold Bagua, clouds, mountains and plum blossom on dark jade; editorial illustration, not an instructional diagram.', 941, 178 ); ?>
			<div class="jm-folio-calendar__copy"><h2 id="jm-folio-calendar-title">A moment with the calendar</h2><p>Explore the lunar calendar and seasonal traditions.</p><small>Free Daily Almanac</small><a href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Open today’s Almanac <span aria-hidden="true">→</span></a></div>
		</section>
		<section class="jm-folio-newsletter" aria-labelledby="jm-folio-newsletter-title"><div><h2 id="jm-folio-newsletter-title">Keep exploring</h2><p>Culture, stories, and new reading.</p></div><?php echo jade_myth_newsletter_hold( 'jm-folio-email' ); ?></section>
		<footer class="jm-folio-footer"><nav aria-label="Homepage editorial links"><a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Editorial standards</a><a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Sources &amp; methods</a><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy</a><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a></nav><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Jade &amp; Myth</span><p class="jm-folio-credits">Artwork: <a href="<?php echo esc_url( home_url( '/ai-disclosure/' ) ); ?>">Jade &amp; Myth Editorial, AI-assisted interpretations</a>. Object photographs: Gary Todd, CC0. <a href="https://commons.wikimedia.org/wiki/File:Ancient_Bronze_Mask_from_Sanxingdui_12.jpg">Mask source</a> · <a href="https://commons.wikimedia.org/wiki/File:2014_Qin_Shihuang_Bronze_Chariot_Horses.jpg">Chariot source</a>.</p></footer>
	</main>
	<?php
	$images = array();
	foreach ( array( 'gateway','dragon','fox','qilin','fenghuang','bifang','kunpeng','wisdom','calendar-master' ) as $name ) {
		$images[] = array( '@type'=>'ImageObject', 'contentUrl'=>JADE_MYTH_VISUAL_URL . 'art/home/' . $name . '.webp', 'creator'=>array('@type'=>'Organization','name'=>'Jade & Myth Editorial'), 'creditText'=>'Jade & Myth Editorial, AI-assisted editorial illustration', 'copyrightNotice'=>'Jade & Myth Editorial — AI-assisted editorial illustration; see reuse terms.', 'license'=>home_url('/ai-disclosure/'), 'acquireLicensePage'=>home_url('/ai-disclosure/'), 'caption'=>'Modern editorial interpretation, not documentary evidence.' );
	}
	foreach ( array('landscape.webp','dragon.webp','bagua-texture.webp') as $name ) {
		$images[] = array('@type'=>'ImageObject','contentUrl'=>JADE_MYTH_VISUAL_URL . 'art/motion-v1/' . $name,'creator'=>array('@type'=>'Organization','name'=>'Jade & Myth Editorial'),'creditText'=>'Jade & Myth Editorial, AI-assisted editorial illustration','copyrightNotice'=>'Jade & Myth Editorial — AI-assisted editorial illustration; see reuse terms.','license'=>home_url('/ai-disclosure/'),'acquireLicensePage'=>home_url('/ai-disclosure/'),'caption'=>'Modern editorial interpretation, not documentary evidence.');
	}
	foreach ( array( 'sanxingdui'=>'Ancient_Bronze_Mask_from_Sanxingdui_12.jpg', 'qin'=>'2014_Qin_Shihuang_Bronze_Chariot_Horses.jpg' ) as $name=>$file ) {
		$images[] = array( '@type'=>'ImageObject', 'contentUrl'=>JADE_MYTH_VISUAL_URL . 'art/home/' . $name . '.webp', 'creator'=>array('@type'=>'Person','name'=>'Gary Todd'), 'creditText'=>'Gary Todd via Wikimedia Commons', 'copyrightNotice'=>'CC0 public-domain dedication; Gary Todd.', 'license'=>'https://creativecommons.org/publicdomain/zero/1.0/', 'acquireLicensePage'=>'https://commons.wikimedia.org/wiki/File:' . $file, 'caption'=>'Object photograph; CC0 dedication.' );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array('@context'=>'https://schema.org','@graph'=>$images), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
	return ob_get_clean();
}
