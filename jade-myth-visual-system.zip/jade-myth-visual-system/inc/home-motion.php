<?php
/** Owner-approved motion; no Oracle service or route is installed here. */
function jade_myth_motion_hero() { ob_start(); ?>
<section class="jm-motion-hero" id="motion-hero" aria-labelledby="jm-folio-title">
  <img class="landscape" src="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/landscape.webp" alt="" fetchpriority="high" width="1672" height="941">
  <div class="mist mist-one" aria-hidden="true"><svg viewBox="700 95 320 145" xmlns="http://www.w3.org/2000/svg"><image href="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/landscape.webp" width="1672" height="941"/></svg></div><div class="mist mist-two" aria-hidden="true"><svg viewBox="700 95 320 145" xmlns="http://www.w3.org/2000/svg"><image href="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/landscape.webp" width="1672" height="941"/></svg></div>
  <div class="dragon-flight" aria-hidden="true"><canvas id="dragon" width="1024" height="420"></canvas><img id="dragon-fallback" src="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/dragon.webp" alt=""></div>
  <div class="jm-motion-copy">
    <h1 id="jm-folio-title">Chinese myths.<br>A world to explore.</h1>
    <p>Mythical beings, ancient objects, and<br class="jm-folio-desktop-break"> the ideas that shaped Chinese culture.</p>
    <a href="<?php echo esc_url( home_url( "/explore/" ) ); ?>">Explore the archive <span aria-hidden="true">→</span></a>
  </div>
  <div class="oracle-stage">
    <svg id="bagua" viewBox="-256 -256 512 512" role="img" aria-label="Six slowly rotating golden rings, the eight trigrams and a central Taiji" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="gold" x1="0" y1="0" x2=".9" y2="1"><stop stop-color="#80531f"/><stop offset=".24" stop-color="#f9d887"/><stop offset=".52" stop-color="#b68232"/><stop offset=".76" stop-color="#ffdfa0"/><stop offset="1" stop-color="#8e5c23"/></linearGradient>
        <radialGradient id="disc-paper"><stop stop-color="#f8e9c8" stop-opacity=".97"/><stop offset=".65" stop-color="#f7e7c2" stop-opacity=".8"/><stop offset="1" stop-color="#fff5d7" stop-opacity=".12"/></radialGradient>
        <radialGradient id="halo"><stop offset=".7" stop-color="#efc45d" stop-opacity="0"/><stop offset=".87" stop-color="#edbb53" stop-opacity=".21"/><stop offset="1" stop-color="#efd490" stop-opacity="0"/></radialGradient>
        <radialGradient id="glint"><stop stop-color="#fffbe5" stop-opacity=".9"/><stop offset=".2" stop-color="#fff1b0" stop-opacity=".7"/><stop offset="1" stop-color="#f5d87c" stop-opacity="0"/></radialGradient>
        <clipPath id="ornament-band"><path fill-rule="evenodd" d="M224 0A224 224 0 1 0-224 0A224 224 0 1 0 224 0M207 0A207 207 0 1 1-207 0A207 207 0 1 1 207 0"/></clipPath>
        <clipPath id="inner-band"><path fill-rule="evenodd" d="M103 0A103 103 0 1 0-103 0A103 103 0 1 0 103 0M85 0A85 85 0 1 1-85 0A85 85 0 1 1 85 0"/></clipPath>
        <clipPath id="taiji-texture"><circle r="58"/></clipPath>
      </defs>
      <circle r="252" fill="url(#halo)"/>
      <circle r="224" fill="url(#disc-paper)" stroke="#f7d484" stroke-width="1"/>
      <g id="ring-one" class="ring ring-one"><image href="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/bagua-texture.webp" x="-256" y="-256" width="512" height="512" clip-path="url(#ornament-band)"/><circle r="226"/><circle r="207"/></g>
      <g id="ring-two" class="ring ring-two"></g>
      <g id="ring-three" class="ring ring-three"></g>
      <g id="ring-four" class="ring ring-four"></g>
      <g id="ring-five" class="ring ring-five"><image href="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/bagua-texture.webp" x="-256" y="-256" width="512" height="512" clip-path="url(#inner-band)"/><circle r="104"/><circle r="84"/></g>
      <g class="ring ring-six"><circle r="71"/><circle r="64"/><image href="<?php echo esc_url( JADE_MYTH_VISUAL_URL ); ?>art/motion-v1/bagua-texture.webp" x="-256" y="-256" width="512" height="512" clip-path="url(#taiji-texture)"/></g>
      <g id="stardust" aria-hidden="true"></g>
      <g class="sun-glint"><circle cx="-154" cy="-161" r="31" fill="url(#glint)"/><path d="M-175-161h42m-21-21v42" stroke="#ffefb4" stroke-width=".75" opacity=".75"/></g>
    </svg>
    <a class="oracle-button" data-oracle-frame="tengyun-c" href="<?php echo esc_url( home_url( "/divination/" ) ); ?>"><svg class="oracle-vector-frame" viewBox="0 0 390.71875 77.328125" aria-hidden="true" focusable="false"><rect x="1.2" y="1.2" width="388.31875" height="74.928125" rx="8" fill="none" stroke="#e4c47c" stroke-width="1.15"/></svg><span class="oracle-vector-label">Ask the Oracle</span></a>
  </div>
  <span class="screen-reader-text">Original AI-assisted editorial illustration by Jade &amp; Myth Editorial; not a historical landscape record.</span>
  <button class="jm-motion-toggle" id="motion-toggle" type="button" aria-pressed="false">Pause motion</button>
</section>
<?php return ob_get_clean(); }
