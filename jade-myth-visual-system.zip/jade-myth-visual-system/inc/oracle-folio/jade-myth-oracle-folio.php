<?php
/**
 * Plugin Name: Jade & Myth Oracle Folio — Review Candidate
 * Description: Selected Oracle layout and local Four Pillars tool. Review before activation; no accounts or payments.
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
function jm_oracle_folio_request() {
    $request = wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $expected = wp_parse_url(home_url('/divination/'), PHP_URL_PATH);
    return rtrim((string) $request, '/') === rtrim((string) $expected, '/');
}
add_action('template_redirect', function () {
    if (!jm_oracle_folio_request()) { return; }
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($method, array('GET', 'HEAD'), true)) { status_header(405); header('Allow: GET, HEAD'); header('Cache-Control: no-store'); exit; }
    $canonical = home_url('/divination/');
    $request = $_SERVER['REQUEST_URI'] ?? '';
    if (wp_parse_url($request, PHP_URL_PATH) !== wp_parse_url($canonical, PHP_URL_PATH) || wp_parse_url($request, PHP_URL_QUERY) !== null) { wp_safe_redirect($canonical, 301); exit; }
    if (!is_readable(__DIR__ . '/view.html')) { status_header(503); header('Cache-Control: no-store'); exit('The Oracle is temporarily unavailable. Please try again later.'); }
    global $wp_query;
    if (is_object($wp_query)) { $wp_query->is_404 = false; $wp_query->is_home = false; }
    status_header(200); nocache_headers();
    if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    do_action('litespeed_control_set_nocache', 'Oracle folio local birth input');
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Robots-Tag: noindex, follow');
    header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
    header("Content-Security-Policy: default-src 'none'; script-src 'self'; worker-src 'self'; style-src 'self'; font-src 'self'; img-src 'self'; connect-src 'none'; form-action 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'");
    if ($method === 'HEAD') { exit; }
    // Dedicated document: no theme CSS/JS or duplicate theme header/footer.
    $view = file_get_contents(__DIR__ . '/view.html');
    echo str_replace(array('__ORACLE_ASSETS__', '__ORACLE_CANONICAL__'), array(esc_url(plugins_url('assets/oracle-folio-review-v1/', __FILE__)), esc_url($canonical)), $view);
    exit;
}, 0);
add_filter('redirect_canonical', function ($redirect) { return jm_oracle_folio_request() ? false : $redirect; });
