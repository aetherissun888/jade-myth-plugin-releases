# Oracle Folio review candidate — 2026-10-23

Status: prepared locally, not installed or activated on WordPress. This is a separate WordPress plugin ZIP; uploading and activating it would expose the replacement `/divination/` page. Production activation is not authorized.

## Exact scope

Real English HTML controls and results sit over decorative regions of the owner-provided artwork. The existing pinned calendar, time-zone, place-search, interpretation and export modules are reused. The homepage already links to `/divination/`; no homepage, dragon, Bagua, legacy `/divination/bazi/`, database or rewrite rule changes are required by this package. No account, payment, birth-data upload or paid service is added.

Owner approved the appearance, then requested only the desktop upper-right book-edge alignment. That correction is desktop-only. The owner then authorized a separate mobile-only refinement for symmetry, seams and material clarity; it uses two new high-resolution transparent ornaments and keeps desktop frozen. Other desktop suggestions remain deferred under the owner's instruction. This is not a pixel-perfect or complete accessibility claim.

## Build and inspect

From the repository root, use Python 3 (standard library only):

```sh
python3 product/oracle-folio/build_candidate.py --package /tmp/jade-oracle-review
```

The builder first validates the existing 42-source pinned profile. It copies calculation/data modules, maps MJS to JS for conventional host MIME, anchors the local place Worker to its module URL, and substitutes the new single-page presentation adapter. No dependencies are installed. Keep the generated SHA256 receipt with the ZIP; do not modify the extracted assets after review.

## Future staging installation — after approval

1. Take a restorable WordPress database/files backup and record currently active plugins and the existing `/divination/` response.
2. Use a private staging clone with the existing approved theme/plugins and matching PHP. Upload the ZIP through Plugins → Add New → Upload Plugin, then activate it. Activation immediately handles `/divination/`; it has no separate publish button.
3. Check real WordPress routing, permalink/subdirectory behavior, cache/plugin conflicts, asset MIME and CSP in that environment. The local PHP hook fixture used during development is not real WordPress acceptance.
4. Check homepage entry → direct form, date/city selection/time → chart → draft/export; unknown/range input, failure/manual fallback, keyboard and responsive states. Use synthetic data. Birth inputs remain in browser memory and exports are private files. No cloud save is supplied.
5. Review actual device/native date/time and print behavior when devices are available. Complete the independent traditional/English review and remaining method precision gates before treating this structural draft as a full personal reading.
6. This candidate deliberately sends `noindex,nofollow`. Do not activate it on production or silently replace the site's existing index/canonical/sitemap policy. Any public release needs explicit authorization and its own SEO gate, with this candidate policy reconciled first.

## Rollback

Deactivate **Jade & Myth Oracle Folio — Review Candidate**. Its route hook disappears and existing WordPress page rendering resumes. Clear only relevant site/CDN caches through the established release procedure. No page body, rewrite table, order or birth record is created by this plugin; no destructive migration or cleanup is needed. Keep the previous active plugin/theme versions and backup until real staging acceptance is complete.

## Evidence and limitations

Task evidence: `execution/ORACLE-FOLIO/browser/` contains real desktop/mobile captures, known/unknown/range/clear/failed-core/failed-worker observations, one actual JSON export and final desktop input verification. These demonstrate local behavior, not independent predictive accuracy or production safety. The reference art is user-supplied; retain its Library identity/source record and confirm rights before any public release. Engine/data licenses and notices remain in the bundle. Real payment is unavailable.
