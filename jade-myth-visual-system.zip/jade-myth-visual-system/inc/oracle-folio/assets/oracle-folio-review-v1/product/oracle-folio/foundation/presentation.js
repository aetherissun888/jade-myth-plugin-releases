// Versioned presentation projection only. Existing page/CSS/DOM are not modified.
import {prepareLocalReport,exportLocalReport,EXPORT_VERSION} from './export-adapter.js';
import {REPORT_CHAPTER_TITLES,reportChapterIndex as legacyIndex,mobileReportSummary as legacySummary} from '../report-mobile.js';
export {REPORT_CHAPTER_TITLES,releaseMobileReportState} from '../report-mobile.js';
export const PRESENTATION_VERSION='jm-reference-presentation-v1';
const held=new WeakMap();
const groups=Object.freeze({'input-certainty':0,orientation:0,season:1,roots:1,pairs:1,synthesis:1,reflection:2,'method-scope':3,'source-links':3});
const positions=['year','month','day','hour'];
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};

/** Undefined version is the existing legacy call contract. New callers must pass
 * the assembly version; unknown versions/IDs must not silently land in Sources.
 */
export function reportChapterIndex(id='',assemblyVersion){
  if(assemblyVersion===undefined)return legacyIndex(id);
  if(assemblyVersion!==EXPORT_VERSION)fail('PRESENTATION_VERSION_UNSUPPORTED');
  const key=id.startsWith('report-')?id.slice(7):id;
  if(!Object.hasOwn(groups,key))fail('PRESENTATION_SECTION_UNMAPPED');
  return groups[key];
}

export function mobileReportSummary(report){
  if(report?.assemblyVersion!==EXPORT_VERSION){
    if(report?.assemblyVersion?.startsWith('jm-reference-'))fail('PRESENTATION_VERSION_UNSUPPORTED');
    return legacySummary(report);
  }
  const i=report.originalInput,c=report.chart;
  if(!i||!['minute','unknown','range'].includes(i.timePrecision))fail('PRESENTATION_INPUT_MISSING');
  const missing=positions.filter(p=>c.pillars[p]===null);
  const parts=[report.inputNotice];
  if(i.timePrecision==='range')parts.push(`Local range: ${i.range.start}–${i.range.end}. No single birth instant is assigned.`);
  if(i.occurrence)parts.push(`Repeated time: ${i.occurrence} occurrence.`);
  if(missing.length)parts.push(`Unresolved positions: ${missing.join(', ')}.`);
  if(c.yearMonthOptions.length>1)parts.push('Year/month alternatives remain available in the input details.');
  else if(c.nearSolarBoundary)parts.push('Near a calculated solar term; the flag is not an error bound.');
  parts.push('Independent review is pending. Not available to buy.');
  return parts.join(' ');
}

function projectSections(sections){
  return sections.map(s=>({...s,domId:`report-${s.id}`,chapterIndex:reportChapterIndex(s.id,EXPORT_VERSION)}));
}
function chapters(sections){
  return REPORT_CHAPTER_TITLES.map((title,index)=>({index,title,sectionIds:sections.filter(s=>s.chapterIndex===index).map(s=>s.id)})).filter(c=>c.sectionIds.length);
}

/** The input is calculated exactly once by A4. All views and export retain that
 * same frozen report; neither mobile nor free views select another candidate.
 */
export function preparePresentedReport(input,metadata){
  const pack=prepareLocalReport(input,metadata);
  if(!pack.ok)return pack;
  const r=pack.report,s=pack.reference.snapshot;
  const summary=mobileReportSummary(r),sections=projectSections(r.sections);
  if(new Set(sections.map(s=>s.id)).size!==sections.length)fail('PRESENTATION_DUPLICATE_SECTION');
  const declared=['input-certainty',...s.freeSectionIds,'method-scope'];
  if(declared.some(id=>!sections.some(s=>s.id===id)))fail('PRESENTATION_FREE_SECTION_MISSING');
  const freeSections=sections.filter(s=>declared.includes(s.id));
  const certainty=sections.find(s=>s.id==='input-certainty');
  const common={summary,inputNotice:r.inputNotice,completeness:summary,chartCompleteness:summary,
    inputKind:r.originalInput.timePrecision,status:r.chart.status,
    inputSummary:r.inputSummary,normalizedTime:r.normalizedTime,
    pillars:positions.map(position=>({position,value:r.chart.pillars[position],label:r.chart.pillars[position]??'unresolved',
      missingReason:r.chart.pillars[position]!==null?null:
        position==='hour'&&r.originalInput.timePrecision==='unknown'?'Birth time unknown':
        r.originalInput.timePrecision==='range'?'Changes within the supplied time range':'Calculated term boundary alternatives'})),
    // Keep year/month combinations paired; do not form an invented Cartesian product.
    yearMonthOptions:r.chart.yearMonthOptions,candidatePillars:r.chart.candidatePillars??[],
    uncertaintySection:certainty,sourceReportId:r.id,contentVersion:r.contentVersion,
    assemblyVersion:r.assemblyVersion,ruleVersion:r.evidenceSnapshot.ruleVersion,
    purchasable:false,fullPersonalizedReport:false};
  // Existing page uses report- prefixed IDs; offline HTML uses raw IDs. Remap
  // local source anchors for page projection only, leaving frozen exports intact.
  const sources=r.sources.map(x=>({...x,url:x.url==='#method-scope'?'#report-method-scope':x.url}));
  const view=freeze({ok:true,presentationVersion:PRESENTATION_VERSION,
    free:{common,sections:freeSections,chapters:chapters(freeSections)},
    detailed:{common,sections,chapters:chapters(sections)},sources,
    sourceLinksSection:{domId:'report-source-links',chapterIndex:3},
    reviewStatus:r.reviewStatus});
  held.set(view,pack);return view;
}

export function exportPresentedReport(view,format,notes={}){
  const pack=held.get(view);if(!pack)fail('PRESENTED_REPORT_REQUIRED');
  return exportLocalReport(pack,format,notes);
}
