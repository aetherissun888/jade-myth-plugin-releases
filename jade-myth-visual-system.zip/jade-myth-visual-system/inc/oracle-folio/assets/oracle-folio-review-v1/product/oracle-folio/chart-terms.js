/** On-page notation help from the existing frozen facts; no new interpretation. */
export const TERMS_HELP_VERSION='jm-chart-terms-help-v1';
export function chartTerms(report){
 const facts=report?.evidenceSnapshot?.derived?.facts;
 if(!Array.isArray(facts))throw new RangeError('CHART_TERMS_UNAVAILABLE');
 const terms=new Map();
 for(const fact of facts){
  if(!['visible-relationship','hidden-relationship','month-relation'].includes(fact.kind))continue;
  const relation=fact.value.relation||fact.value;
  if(!fact.sourceRefs.includes('S-TEN')||!['label','pinyin','familyLabel','direction'].every(k=>typeof relation[k]==='string'))throw new RangeError('CHART_TERM_BASIS_UNAVAILABLE');
  let term=terms.get(relation.label);
  if(!term){term={label:relation.label,pinyin:relation.pinyin,category:relation.familyLabel,direction:relation.direction,evidenceIds:[],sourceRefs:[],positions:[]};terms.set(relation.label,term);}
  term.evidenceIds.push(fact.factId);
  term.sourceRefs=[...new Set([...term.sourceRefs,...fact.sourceRefs])];
  term.positions=[...new Set([...term.positions,...fact.positions])];
 }
 return Object.freeze([...terms.values()].map(t=>Object.freeze({...t,evidenceIds:Object.freeze(t.evidenceIds),sourceRefs:Object.freeze(t.sourceRefs),positions:Object.freeze(t.positions)})));
}
