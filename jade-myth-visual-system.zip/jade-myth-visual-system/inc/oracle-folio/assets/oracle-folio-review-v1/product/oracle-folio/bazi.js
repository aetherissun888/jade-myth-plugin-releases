import {initMobileFlow} from './oracle-mobile-flow.js';
import {initPlacePicker,resetPlacePicker,showSyntheticPlace} from './place-picker.js';
import {setPresentedState,clearReportUI,showWorkedReport} from './report-ui.js';
import {createReportSession} from './foundation/session.js';
import {CITIES,cityById,formatOffset} from './timezone.js';
import {localUUID} from './local-id.js';
const $=id=>document.getElementById(id),date=$('birth-date'),time=$('birth-time'),city=$('birth-city'),unknown=$('time-unknown'),range=$('time-range'),start=$('time-start'),end=$('time-end'),occurrence=$('occurrence'),status=$('birth-status');
const session=createReportSession({onInternalError:e=>console.error('Local report failed:',e.name)});
const STEMS={甲:['Jia','Wood'],乙:['Yi','Wood'],丙:['Bing','Fire'],丁:['Ding','Fire'],戊:['Wu','Earth'],己:['Ji','Earth'],庚:['Geng','Metal'],辛:['Xin','Metal'],壬:['Ren','Water'],癸:['Gui','Water']};
const BRANCHES={子:'Zi',丑:'Chou',寅:'Yin',卯:'Mao',辰:'Chen',巳:'Si',午:'Wu',未:'Wei',申:'Shen',酉:'You',戌:'Xu',亥:'Hai'};
let synthetic=false;
for(const entry of CITIES){const o=document.createElement('option');o.value=entry.id;o.textContent=entry.label;city.append(o);}
const text=(p,tag,value)=>{const n=document.createElement(tag);n.textContent=value;p.append(n);return n;};
function clearOutput(){clearReportUI();document.querySelector('.chart-summary').setAttribute('aria-labelledby','chart-heading');for(const id of ['calculation-details','pillars'])$(id).replaceChildren();for(const id of ['day-master','mobile-record-summary','mobile-master','chart-version','chart-completeness','boundary-note'])$(id).textContent='';$('boundary-note').hidden=true;$('chart-result').hidden=true;$('chart-empty').hidden=false;}
function resetOccurrence(){$('occurrence-choice').hidden=true;occurrence.replaceChildren();const o=text(occurrence,'option','Choose the recorded occurrence');o.value='';}
function pending(){synthetic=false;session.edit();clearOutput();resetOccurrence();status.classList.remove('error');status.dataset.state='pending';status.textContent='Details changed. Calculate to view this chart.';}
function syncTimeControls(){time.disabled=unknown.checked||range.checked;start.disabled=end.disabled=!range.checked;$('time-range-fields').hidden=$('time-range-help').hidden=!range.checked;}
for(const input of [date,time,city,start,end])input.addEventListener('input',pending);
city.addEventListener('change',()=>{$('zone-label').textContent=city.value?cityById(city.value).zone+' · Historical offsets from IANA 2026e':'Choose the actual birthplace, or use explicit manual confirmation.';});
unknown.addEventListener('change',()=>{if(unknown.checked)range.checked=false;time.value='';start.value=end.value='';syncTimeControls();pending();});
range.addEventListener('change',()=>{if(range.checked)unknown.checked=false;time.value='';start.value=end.value='';syncTimeControls();pending();});
occurrence.addEventListener('change',()=>{session.edit();clearOutput();status.textContent='Occurrence selected. Calculate to view the chart.';});
function render(state){
 if(state.status!=='ready'){
  clearOutput();status.classList.add('error');status.dataset.state='error';
  const resolution=state.resolution;
  if(resolution?.status==='ambiguous-time'){
   resetOccurrence();$('occurrence-choice').hidden=false;
   resolution.candidates.forEach((c,i)=>{const o=text(occurrence,'option',`${i===0?'First':'Second'} · ${formatOffset(c.seconds)} · ${c.abbreviation}`);o.value=i===0?'first':'second';});
   status.textContent='This time occurred twice. Choose the recorded occurrence, then calculate again.';
  }else if(resolution?.status==='nonexistent-time'||resolution?.status==='nonexistent-range')status.textContent='The supplied local time did not exist after a clock change. Check the birth record; no chart is substituted.';
  else if(resolution?.status==='nonexistent-date')status.textContent='This local date was skipped by a civil-clock change. Check the birth record and birthplace.';
  else status.textContent=state.error?.code==='UNSUPPORTED_RANGE'?'Enter a valid earliest and latest time within one date, in that order.':state.error?.message||'The local report could not be prepared. No current chart is available.';
  return;
 }
 const common=state.view.free.common,report=JSON.parse(session.export(state.revision,'json')).report;
 $('chart-empty').hidden=true;$('chart-result').hidden=false;document.querySelector('.chart-summary').setAttribute('aria-labelledby','chart-result-heading');$('pillars').replaceChildren();
 for(const row of common.pillars){const figure=text($('pillars'),'figure','');figure.className='pillar';text(figure,'h3',row.position[0].toUpperCase()+row.position.slice(1));const v=row.value,chars=text(figure,'span',v||'—');chars.className='characters';if(v)chars.lang='zh-Hans';text(figure,'p',v?STEMS[v[0]][0]+' '+BRANCHES[v[1]]:row.missingReason);}
 const stem=report.chart.pillars.day[0],name=STEMS[stem];$('mobile-master').textContent=`${name[0]} (${stem}) · ${name[1]}`;
 $('day-master').textContent=`Your day stem is ${name[0]} (${stem}), called the Day Master. In the five-phase classification used here, it corresponds to ${name[1]}. This identifies a component of the chart; it does not establish your character, compatibility or future.`;
 $('mobile-record-summary').textContent=common.inputSummary;
 $('chart-completeness').textContent=(synthetic?'Synthetic example · ':'')+common.chartCompleteness;
 const alternatives=common.yearMonthOptions.length>1?'Possible year / month pairs: '+common.yearMonthOptions.map(v=>v.year+' / '+v.month).join(' or ')+'. ':'';
 $('boundary-note').hidden=!(report.chart.nearSolarBoundary||alternatives);$('boundary-note').textContent=alternatives+'Solar-term seconds are computational output, not a certified accuracy bound. Retain unresolved positions and alternatives.';
 const details=$('calculation-details');details.replaceChildren();
 for(const [label,value] of [['Birth record',common.inputSummary],['IANA zone',common.normalizedTime.zone],['Resolved instant',common.normalizedTime.instant||'No single instant assigned'],['Clock convention','Local civil clock including historical DST; no true solar time correction'],['Day boundary','Midnight; sect 2 late-Zi hour convention']]){text(details,'dt',label);text(details,'dd',value);}
 $('chart-version').textContent=`${report.chart.engineVersion} · IANA ${report.chart.timeZoneVersion} · ${report.chart.methodVersion}`;
 setPresentedState(state,session,report);status.classList.remove('error');status.dataset.state='success';document.dispatchEvent(new Event('jade-chart-ready'));
 status.textContent='Chart calculated locally. Birth details have not been uploaded or saved by this page.';
}
function calculate(){
 clearOutput();
 const input={date:date.value,cityId:city.value,timePrecision:unknown.checked?'unknown':range.checked?'range':'minute',time:unknown.checked||range.checked?null:time.value,range:range.checked?{start:start.value,end:end.value}:null,occurrence:occurrence.value||null};
 render(session.calculate(input,{id:'local-'+localUUID(),createdAt:new Date().toISOString()}));
}
$('calculate').addEventListener('click',calculate);
$('synthetic').addEventListener('click',()=>{date.value='1986-05-29';city.value='hong-kong';time.value='10:30';unknown.checked=range.checked=false;start.value=end.value='';syncTimeControls();resetOccurrence();$('zone-label').textContent='Asia/Hong_Kong · Synthetic test details, not a real person’s record';showSyntheticPlace();synthetic=true;calculate();});
$('clear').addEventListener('click',()=>{session.clear();date.value=time.value=city.value=start.value=end.value='';unknown.checked=range.checked=false;syncTimeControls();synthetic=false;resetOccurrence();resetPlacePicker();clearOutput();$('zone-label').textContent='Choose the actual birthplace, or use explicit manual confirmation.';status.classList.remove('error');status.dataset.state='cleared';status.textContent='Details and chart cleared from this page.';});
$('worked-report').addEventListener('click',()=>{$('synthetic').click();showWorkedReport();});
initPlacePicker();initMobileFlow();syncTimeControls();
const offer=$('local-offer-preview');offer.textContent='Local development draft · Not for sale. The historical offer remains archived; commercial terms and delivery policies for the upgraded report still require approval.';
