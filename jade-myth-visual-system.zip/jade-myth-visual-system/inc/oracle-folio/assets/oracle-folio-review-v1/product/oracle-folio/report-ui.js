import {chartTerms,TERMS_HELP_VERSION} from './chart-terms.js';
import {prepareReportPrint} from './report-print.js';
import {reportMetadata,NOTE_FIELDS} from './foundation/legacy-export.js';
const $=id=>document.getElementById(id),T=(parent,tag,value)=>{const n=document.createElement(tag);n.textContent=value;parent.append(n);return n;};
let current=null,session=null,restorePrint=null;
function finishPrint(){restorePrint?.();restorePrint=null;}
export function clearReportUI(){
 finishPrint();
 // Release moved mobile nodes before their original containers are emptied.
 document.dispatchEvent(new Event('jade-chart-cleared'));
 current=null;session=null;
 for(const id of ['free-reflection','report-sections','report-notes','report-metadata','report-toc'])$(id).replaceChildren();
 $('full-report').hidden=true;
 for(const id of ['mobile-report-state','report-completeness','report-status'])$(id).textContent='';
 $('generate-report').disabled=true;delete $('report-sections').dataset.reportAssembly;
}
function sectionInto(root,s,terms=[]){
 const node=T(root,'section','');node.id=s.domId;node.tabIndex=-1;node.className='source-note';T(node,'h3',s.title);
 s.paragraphs.forEach(p=>T(node,'p',p));
 if(s.basisNotes||s.fieldDependencies.length||s.sourceRefs.length){
  const detail=T(node,'details','');T(detail,'summary','Text and chart basis');
  if(s.basisNotes)T(detail,'p',s.basisNotes);
  if(s.fieldDependencies.length)T(detail,'p','Fields: '+s.fieldDependencies.join('; '));
  if(s.sourceRefs.length)T(detail,'p','Source references: '+s.sourceRefs.join(', '));
 }
 if(s.id==='method-scope'&&terms.length){
  const help=T(node,'details','');help.id=s.domId+'-terms';help.dataset.helpVersion=TERMS_HELP_VERSION;T(help,'summary','Relationship terms used in this chart');
  T(help,'p','These names describe relationships between stems in the Five Phases model. They are not findings about income, health, employment or another person’s feelings.');
  const list=T(help,'dl','');
  for(const term of terms){const title=T(list,'dt',term.pinyin+' · '),han=T(title,'span',term.label);han.lang='zh-Hans';T(title,'span',' · '+term.category);T(list,'dd',term.direction+'. Compared positions: '+term.positions.join(' / ')+'.');}
  T(help,'p','This help uses only the displayed and hidden stems retained in the current chart. Missing positions are omitted. The accompanying JSON keeps the relationship facts and their source references.');
 }
 return node;
}
export function setPresentedState(state,boundSession,report){
 current={state,report,opened:false,terms:chartTerms(report)};session=boundSession;
 const root=$('free-reflection');root.replaceChildren();
 // Free section IDs are distinct in the DOM; the canonical detailed IDs stay report-*.
 for(const s of state.view.free.sections)sectionInto(root,{...s,domId:'free-'+s.id},current.terms);
 $('generate-report').disabled=false;
 $('report-coverage').textContent='Read the additional structural evidence from this same chart. This local draft is not a full personalized interpretation and is not available to buy.';
}
export function showWorkedReport(){
 if(!current)return;
 if(current.opened){$('full-report').hidden=false;document.dispatchEvent(new Event('jade-report-open'));if(!matchMedia('(max-width:760px)').matches)$('report-title').focus({preventScroll:true});return;}
 const {state,report}=current,view=state.view;
 $('report-title').textContent=report.title;
 $('full-report').querySelector('.notice strong').textContent='Local chart-structure draft · Not available to buy';
 $('mobile-report-state').textContent=view.detailed.common.summary;
 $('report-completeness').textContent=view.detailed.common.completeness;
 const root=$('report-sections'),toc=$('report-toc'),metadata=$('report-metadata');
 root.replaceChildren();toc.replaceChildren();metadata.replaceChildren();root.dataset.reportAssembly=view.detailed.common.assemblyVersion;
 for(const[k,v]of reportMetadata(report)){T(metadata,'dt',k);T(metadata,'dd',v);}
 for(const s of view.detailed.sections){const a=T(toc,'a',s.title);a.href='#'+s.domId;sectionInto(root,s,current.terms);}
 const sources=T(root,'section','');sources.id=view.sourceLinksSection.domId;sources.tabIndex=-1;sources.className='source-note';T(sources,'h3','Open the named sources');
 for(const s of view.sources){const p=T(sources,'p',''),a=T(p,'a',s.id+' · '+s.title);a.href=s.url;a.rel='noreferrer';if(!s.url.startsWith('#'))a.target='_blank';T(p,'span',' · '+s.role);}
 const notes=$('report-notes');notes.replaceChildren();
 for(const[id,label]of NOTE_FIELDS){const wrapper=T(notes,'label','');wrapper.htmlFor='report-note-'+id;T(wrapper,'span',label);const area=T(wrapper,'textarea','');area.id=wrapper.htmlFor;area.dataset.note=id;area.rows=4;area.maxLength=5000;area.autocomplete='off';}
 const revision=state.revision;
 notes.oninput=()=>{try{session?.setNotes(revision,readNotes());}catch{$('report-status').textContent='Details changed. Calculate again before adding notes.';}};
 current.opened=true;$('full-report').hidden=false;$('report-status').dataset.state='ready';
 $('report-status').textContent='Draft generated locally. Reading and downloads use this same versioned chart snapshot.';
 document.dispatchEvent(new Event('jade-report-open'));
 if(!matchMedia('(max-width:760px)').matches){$('report-title').focus({preventScroll:true});$('full-report').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});}
}
const readNotes=()=>Object.fromEntries([...$('report-notes').querySelectorAll('[data-note]')].map(n=>[n.dataset.note,n.value]));
$('generate-report').addEventListener('click',showWorkedReport);
for(const[kind,mime,suffix]of [['html','text/html;charset=utf-8','html'],['text','text/plain;charset=utf-8','txt'],['json','application/json;charset=utf-8','json'],['bundle','application/zip','zip']]){
 $('export-report-'+kind).addEventListener('click',()=>{
  if(!current||!session)return;
  try{
   const revision=current.state.revision;session.setNotes(revision,readNotes());const value=session.export(revision,kind);
   const url=URL.createObjectURL(new Blob([value],{type:mime})),a=document.createElement('a');a.href=url;a.download='Jade-Myth-BaZi-Local-Draft.'+suffix;
   document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
   $('report-status').dataset.state='feedback';$('report-status').textContent='Download requested. Check your browser downloads; the file includes birth details and notes.';
  }catch{$('report-status').textContent='The export could not be prepared. Verify that this chart is still current.';}
 });
}
window.addEventListener('beforeprint',()=>{if(current&&!restorePrint)restorePrint=prepareReportPrint($('full-report'));});
window.addEventListener('afterprint',finishPrint);
$('print-report').addEventListener('click',()=>{if(current)window.print();});
window.addEventListener('pagehide',()=>document.getElementById('clear')?.click());
window.addEventListener('pageshow',event=>{if(event.persisted)document.getElementById('clear')?.click();});
