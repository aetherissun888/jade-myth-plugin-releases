// Browser-compatible synchronous reference. No network, Node APIs or paid models.
import {resolveInput, makeSnapshot, POSITIONS} from './rules.js';
import {relateStems} from '../relationships.js';
import {inputErrorCode} from './input-errors.js';

export const CONTRACT_VERSION = 'jm-foundation-contract-v2';
export const CONTENT_VERSION = 'jm-foundation-en-reference-v2';
const fields = ['date','cityId','timePrecision','time','range','occurrence'];
const terms={'比肩':'Peer','劫财':'Rob Wealth','食神':'Eating God','伤官':'Hurting Officer','偏财':'Indirect Wealth','正财':'Direct Wealth','七杀':'Seven Killings','正官':'Direct Officer','偏印':'Indirect Resource','正印':'Direct Resource'};
const englishLabels=text=>Object.entries(terms).reduce((s,[zh,en])=>s.replaceAll(zh,`${en} (${zh})`),text);
const plain = x => x && Object.getPrototypeOf(x) === Object.prototype;
const error = (code, message) => ({ok:false, contractVersion:CONTRACT_VERSION,
  error:{code,message,retryable:false}});
const deepFreeze = x => {if(x && typeof x === 'object'){Object.values(x).forEach(deepFreeze);Object.freeze(x);}return x;};

export function validateInput(input) {
  if(!plain(input) || Object.keys(input).some(k=>!fields.includes(k)) ||
    typeof input.date !== 'string' || typeof input.cityId !== 'string' ||
    !['minute','range','unknown'].includes(input.timePrecision)) throw new RangeError('INVALID_INPUT');
  if(input.timePrecision === 'range' && (!plain(input.range) ||
    Object.keys(input.range).some(k=>!['start','end'].includes(k)))) throw new RangeError('INVALID_INPUT');
  return {date:input.date,cityId:input.cityId,timePrecision:input.timePrecision,
    time:input.time ?? null,range:input.range ?? null,occurrence:input.occurrence ?? null};
}

function compose(snapshot) {
  const {chart,derived,detail,reconciled} = snapshot;
  const dm = relateStems(derived.dayStem,derived.dayStem);
  const missing = derived.missing;
  const sections = [{id:'orientation',title:'Reading this chart',kind:'calculated',chartFields:POSITIONS.map(p=>`pillars.${p}`),ruleIds:[],evidenceIds:[],
    paragraphs:[`The Day Master is ${dm.dayName} (${derived.dayStem}), classified as ${dm.dayPolarity} ${dm.dayPhase}. It is the reference stem used to name relationships in this chart. These classifications describe a traditional symbolic model, not a tested prediction of personality or events.`,
    `The displayed pillars are ${POSITIONS.map(p=>`${p}: ${chart.pillars[p] ?? 'unresolved'}`).join('; ')}. ${missing.length ? `The ${missing.join(', ')} position(s) remain unresolved; the discussion below uses only the stable positions.` : 'All four positions are available under the stated civil-clock method.'}`]}];
  const groups = [
    ['season','Seasonal context',['R01','R02','R05']],
    ['roots','Roots and stem relationships',['R03','R04','R06','R07']],
    ['pairs','Combinations and clashes',['R08','R09','R10']]
  ];
  for(const [id,title,ids] of groups){
    const entries=detail.filter(e=>ids.includes(e.ruleId));
    const basis=[...new Map(entries.flatMap(e=>e.calculatedBasis).map(b=>[b.factId,b])).values()];
    sections.push({id,title,kind:'rule-evidence',ruleIds:entries.map(e=>e.ruleId),evidenceIds:basis.map(b=>b.factId),
      paragraphs:basis.length?basis.map(b=>englishLabels(b.text)):[
        missing.length?'No positive finding is established here from the available positions. Missing positions prevent a whole-chart absence claim.':'None of the limited rules in this section is triggered. This is a coverage statement, not a favorable or unfavorable verdict.']});
  }
  sections.push({id:'synthesis',title:'Putting the evidence together',kind:'analysis',analysisFields:['reconciled.conflicts','reconciled.strengthConclusion','reconciled.patternConclusion','reconciled.usefulElement','reconciled.annualTiming'],
    ruleIds:[...new Set(reconciled.conflicts.flatMap(c=>c.ruleIds ?? []))],
    evidenceIds:[...new Set(reconciled.conflicts.flatMap(c=>c.evidenceIds ?? []))],
    paragraphs:[reconciled.conflicts.length?
      [reconciled.conflicts.some(c=>c.id==='mixed-relations')?'Both supporting and countervailing relationship categories occur in the displayed positions.':'',
       reconciled.conflicts.some(c=>c.id.startsWith('overlap:'))?'A displayed branch participates in both a combination and a clash; neither label is automatically canceled.':'',
       'These findings are retained together. Counting them into a single score would hide the unresolved interpretation.'].filter(Boolean).join(' '):
      'This limited set of structural rules does not establish a conflict. That does not establish a balanced, strong or favorable chart: those conclusions require additional methods and review.',
      'No final strength, formation, useful-element or annual-timing judgment is supplied. “Resource,” “wealth” and “authority” are traditional relationship names; they are not findings about money, health, employment or another person’s feelings.']});
  sections.push({id:'reflection',title:'An optional reflection',kind:'editorial-exercise',ruleIds:[],evidenceIds:[],
    paragraphs:[reconciled.conflicts.length?
      'As a modern writing exercise, choose one ordinary decision with competing demands. Describe each demand separately and the real-world evidence you would need before acting. This exercise follows the report’s comparison structure; it is not advice inferred from fate.':
      'As a modern writing exercise, choose one ordinary project and separate what is known from what still needs checking. The chart provides a cultural prompt for reflection, not evidence that a particular choice will succeed.']});
  return sections;
}

export function buildReference(input) {
  let validated,chart;
  try {validated=validateInput(input);chart=resolveInput(validated);}
  catch(e){const code=inputErrorCode(e);if(!code) throw e;
    return error(code,
      'Use a supported Gregorian date, confirmed place and valid local time. Ranges must stay within one date.');}
  if(!['calculated','incomplete-time','boundary-minute','range-time'].includes(chart.status))
    return deepFreeze({...error('UNRESOLVED_TIME','Resolve the missing or repeated civil time before interpreting this record.'),
      resolution:{status:chart.status,candidates:chart.candidates ?? [],gapMinutes:chart.gapMinutes ?? null}});
  const snapshot=makeSnapshot(chart);
  const sections=compose(snapshot);
  return deepFreeze({ok:true,contractVersion:CONTRACT_VERSION,validatedInput:validated,
    normalizedTime:{zone:chart.timeZone,instant:chart.instant,offsetSeconds:chart.offsetSeconds ?? null,
      status:chart.status,candidates:chart.timeResolution?.instantCandidates ?? [],
      uncertainty:{missingPositions:snapshot.derived.missing,yearMonthOptions:chart.yearMonthOptions,
        candidatePillars:chart.candidatePillars ?? [],gapMinutes:chart.gapMinutes ?? 0,foldMinutes:chart.foldMinutes ?? 0}},
    snapshot:{...snapshot,contentVersion:CONTENT_VERSION,sections,
      freeSectionIds:['orientation','season'],detailSectionIds:sections.map(s=>s.id)}});
}

export function renderMarkdown(result) {
  if(!result.ok) return `# Input needs attention\n\n${result.error.code}: ${result.error.message}\n`;
  return ['# A reading of the chart structure','','Synthetic foundation sample · English draft awaiting independent review · Not for sale','',
    ...result.snapshot.sections.flatMap(s=>[`## ${s.title}`,'',...s.paragraphs.flatMap(p=>[p,''])]),
    `Method: ${result.snapshot.methodVersion}. Content: ${CONTENT_VERSION}.`,
    'Rule and source identifiers are retained in the accompanying JSON.'].join('\n')+'\n';
}
