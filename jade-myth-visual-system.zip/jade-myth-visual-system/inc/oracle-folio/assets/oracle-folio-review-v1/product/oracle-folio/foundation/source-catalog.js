// Frozen source-ledger projection. No independent human approval implied.
export const SOURCE_CATALOG = [
  {
    "sourceId": "S-HIDDEN",
    "source": "6tail 1.8.6",
    "locator": "src/lib/LunarUtil.ts ZHI_HIDE_GAN; retained dist/index.mjs line 1621; EightChar.get*HideGan",
    "supports": "hidden stems and preserved order",
    "doesNotSupport": "no weights/strength or fate claims",
    "positiveEvidence": "12-branch table fixture",
    "counterexampleOrOmission": "unknown branch omitted",
    "usedBy": "all derived hidden-stem fields",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "S-TEN",
    "source": "6tail 1.8.6 and existing Jade relationships.mjs",
    "locator": "LunarUtil.SHI_SHEN line 1519; relateStems",
    "supports": "relative ten-category names; phase/polarity",
    "doesNotSupport": "labels do not prove wealth, jobs, feelings",
    "positiveEvidence": "100-pair formula comparison",
    "counterexampleOrOmission": "self excluded from visible-other stems",
    "usedBy": "R01 R02 R06 R07",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "S-PAIRS",
    "source": "6tail 1.8.6",
    "locator": "LunarUtil.CHONG line 1400; HE_GAN_5 line 1404; HE_ZHI_6 line 1405",
    "supports": "pair label only",
    "doesNotSupport": "no transformation, strength or event inference",
    "positiveEvidence": "5 stem + 6 combine + 6 clash fixed pairs",
    "counterexampleOrOmission": "unmatched/missing positions not global absence",
    "usedBy": "R08 R09 R10",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "J-ROOT",
    "source": "Jade foundation definition v1",
    "locator": "METHOD-PROFILE.md 新增结构口径",
    "supports": "exact-stem versus same-phase-only presence",
    "doesNotSupport": "not a claimed complete traditional school or final root strength",
    "positiveEvidence": "R03/R04 positive cases",
    "counterexampleOrOmission": "R03/R04 counterexamples + missing",
    "usedBy": "R03 R04",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "J-MONTH",
    "source": "Jade foundation definition v1",
    "locator": "METHOD-PROFILE.md 新增结构口径",
    "supports": "month principal hidden-stem relation as one input",
    "doesNotSupport": "not full seasonal weighting/司令/调候",
    "positiveEvidence": "R01/R02 positive cases",
    "counterexampleOrOmission": "opposite-family example + missing month",
    "usedBy": "R01 R02",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "J-EXPOSURE",
    "source": "Jade foundation definition v1",
    "locator": "METHOD-PROFILE.md 新增结构口径",
    "supports": "month hidden stem visible at non-day position",
    "doesNotSupport": "not formation success; no automatic case classification",
    "positiveEvidence": "R05 positive",
    "counterexampleOrOmission": "R05 negative + missing month",
    "usedBy": "R05",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "T-IANA",
    "source": "IANA tzdata2026e primary release",
    "locator": "evidence/iana/northamerica US rules; australasia LH/Apia; asia PRC",
    "supports": "fixed civil offset/DST transition expectations",
    "doesNotSupport": "historical uncertainty; no claim all597 independently certified",
    "positiveEvidence": "NY/LordHowe/Apia/PRC fixtures",
    "counterexampleOrOmission": "gap/fold explicitly rejected or retained",
    "usedBy": "time resolution",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "T-DAY",
    "source": "Y.T. Liu authored calendar reference",
    "locator": "https://ytliu0.github.io/ChineseCalendar/sexagenary_chinese.html section 干支紀日",
    "supports": "2019-01-27 JiaZi independent anchor",
    "doesNotSupport": "not traditional interpretation approval",
    "positiveEvidence": "anchor plus8 day offsets",
    "counterexampleOrOmission": "declared late-Zi separately regression",
    "usedBy": "day-cycle fixture",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "T-HKO-DAY",
    "source": "Hong Kong Observatory",
    "locator": "business evidence/hko-1986.txt.gz, hko-2023.txt.gz, hko-2024.txt.gz",
    "supports": "3 dated lunar anchors from retained tables",
    "doesNotSupport": "day accuracy only; not seconds",
    "positiveEvidence": "1986-05-29; 2024-02-10; 2023-03-22",
    "counterexampleOrOmission": "not offered as lunar input UI",
    "usedBy": "calendar fixtures",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "T-HKO-MIN",
    "source": "Hong Kong Observatory February2024 PDF",
    "locator": "https://www.hko.gov.hk/en/gts/astron2024/files/2024cal02.pdf page1 indexed text",
    "supports": "2024-02-04 Lichun 16:27 HKT",
    "doesNotSupport": "indexed fact read; local PDF download DNS failed; single minute anchor not seconds certificate",
    "positiveEvidence": "library16:27:07 vs published16:27",
    "counterexampleOrOmission": "all-year error bound still unknown",
    "usedBy": "one term-minute comparison",
    "humanReviewStatus": "pending; internal technical check only"
  },
  {
    "sourceId": "T-YUN",
    "source": "6tail Yun algorithm; Jade UTC adapter proposal",
    "locator": "retained dist/index.mjs lines4655–4730; probe/yun.mjs",
    "supports": "minute arithmetic and alternative start-date observations",
    "doesNotSupport": "same-library comparison not independent traditional endorsement",
    "positiveEvidence": "8 known-time comparisons + calendar clamps",
    "counterexampleOrOmission": "unknown/direction missing rejected; future zone bounds recorded",
    "usedBy": "annual research only",
    "humanReviewStatus": "pending; internal technical check only"
  }
];
