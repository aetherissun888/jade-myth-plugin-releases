// Local reference-to-existing-export adapter. No storage, network, payment or UI.
import {buildReference,CONTRACT_VERSION,CONTENT_VERSION} from './reference-report.js';
import {cityById} from '../timezone.js';
import {SOURCE_CATALOG} from './source-catalog.js';
import {reportText,reportJSON,reportHTML} from './legacy-export.js';
import {reportBundle} from './bundle.js';

export const EXPORT_VERSION='jm-reference-export-v1';
const prepared=new WeakSet();
const clone=x=>JSON.parse(JSON.stringify(x));
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
const pinnedSource='https://github.com/6tail/lunar-typescript/tree/a376ec2b8fd1b3069e24c92801bab8707fccd49d';
const urls={'S-HIDDEN':pinnedSource,'S-TEN':pinnedSource,'S-PAIRS':pinnedSource,
  'J-ROOT':'#method-scope','J-MONTH':'#method-scope','J-EXPOSURE':'#method-scope',
  'T-IANA':'https://www.iana.org/time-zones/releases/2026e'};

function sourcesFor(ids){
  return ids.map(id=>{
    const s=SOURCE_CATALOG.find(s=>s.sourceId===id),url=urls[id];
    if(!s||!url||!(url.startsWith('https://')||url==='#method-scope'))fail('EXPORT_SOURCE_UNAVAILABLE');
    return {id,title:s.source,role:`Supports: ${s.supports}. Does not support: ${s.doesNotSupport}. Locator: ${s.locator}. Review: ${s.humanReviewStatus}.`,url};
  });
}

function uncertaintySection(result){
  const {validatedInput:i,normalizedTime:n,snapshot:s}=result;
  const paragraphs=[];
  if(i.timePrecision==='range')paragraphs.push(`The supplied local time range is ${i.range.start}–${i.range.end}, on one civil date. No single birth instant is assigned. The hour pillar is displayed only if it is stable across the retained candidates.`);
  else if(i.timePrecision==='unknown')paragraphs.push('Birth time was not supplied. No noon or midnight birth instant is substituted. The hour pillar is omitted.');
  else paragraphs.push(`The supplied clock reading has minute precision: ${i.time}. The stored instant is the start of that minute, not a claim that the birth second is known.`);
  if(i.occurrence)paragraphs.push(`This repeated local time uses the explicitly selected ${i.occurrence} occurrence.`);
  paragraphs.push(`Unresolved positions: ${n.uncertainty.missingPositions.join(', ')||'none under the stated input and method'}.`);
  if(n.uncertainty.yearMonthOptions.length>1)paragraphs.push('Retained year/month alternatives: '+n.uncertainty.yearMonthOptions.map(x=>`${x.year} / ${x.month}`).join('; ')+'. No alternative is selected for appeal.');
  if(s.chart.candidatePillars?.length)paragraphs.push('Distinct candidate charts (year / month / day / hour): '+s.chart.candidatePillars.map(p=>['year','month','day','hour'].map(k=>p[k]??'unresolved').join(' / ')).join('; ')+'.');
  if(n.uncertainty.gapMinutes||n.uncertainty.foldMinutes)paragraphs.push(`The range contains ${n.uncertainty.gapMinutes} nonexistent clock minutes and ${n.uncertainty.foldMinutes} repeated clock minutes. Only actual instants are retained; repeated occurrences are kept separately.`);
  if(s.chart.nearSolarBoundary)paragraphs.push('The calculation flags proximity to a solar term. This flag is not a certified error interval. Verify the birth record and retain the displayed alternatives.');
  paragraphs.push('Solar-term seconds are computational output; an independently certified error bound across years is not established. The available checks do not establish that every unflagged birth time is free of astronomical uncertainty. Exact luck-cycle and annual timing remain unavailable.');
  return {id:'input-certainty',title:'Your input and its limits',paragraphs,sourceRefs:['T-IANA'],fieldDependencies:['chart.status','chart.pillars','chart.yearMonthOptions','normalizedTime.uncertainty'],basisNotes:'Input uncertainty is preserved separately from traditional interpretation. A1/A3 independent references cover limited dates; the 2024 June solstice published-minute discrepancy remains unresolved.'};
}

/** Build once and capture place metadata before a registry can be cleared or edited.
 * IDs/timestamps are caller-supplied local metadata, never an order or entitlement.
 * This entry point accepts input, not caller-authored report prose or imported files.
 */
export function prepareLocalReport(input,{id,createdAt}={}){
  if(typeof id!=='string'||!/^local-[a-zA-Z0-9-]{1,70}$/.test(id)||typeof createdAt!=='string'||
    !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(createdAt)||
    !Number.isFinite(Date.parse(createdAt))||new Date(createdAt).toISOString()!==createdAt)fail('INVALID_LOCAL_REPORT_IDENTITY');
  const result=buildReference(input);
  if(!result.ok)return result;
  const s=result.snapshot,i=result.validatedInput,n=result.normalizedTime;
  const birthPlace=clone(cityById(i.cityId));
  if(birthPlace.zone!==n.zone)fail('PLACE_ZONE_DRIFT');
  // Do not depend on mutable registry lookup when exporting an already prepared result.
  birthPlace.source ||= i.cityId.startsWith('manual:')?'User-confirmed manual entry; not independently geocoded':'Curated reference fixture';
  birthPlace.sourceVersion ||= i.cityId.startsWith('manual:')?'manual-user-confirmed-unversioned':'legacy-fixture-v1';
  const facts=new Map(s.derived.facts.map(f=>[f.factId,f]));
  const findings=new Map(s.findings.map(f=>[f.ruleId,f]));
  const sections=s.sections.map(section=>{
    const evidence=section.evidenceIds.map(id=>{const f=facts.get(id);if(!f)fail('EXPORT_EVIDENCE_UNAVAILABLE');return f;});
    const rules=section.ruleIds.map(id=>{const f=findings.get(id);if(!f)fail('EXPORT_RULE_UNAVAILABLE');return f;});
    const sourceRefs=[...new Set([...evidence.flatMap(f=>f.sourceRefs),...rules.flatMap(f=>f.sourceRefs)])];
    const fieldDependencies=[...new Set([...(section.chartFields??[]),...(section.analysisFields??[]),...evidence.flatMap(f=>f.fieldDependencies)])];
    return {id:section.id,title:section.title,paragraphs:[...section.paragraphs],sourceRefs,fieldDependencies,
      basisNotes:`Section type: ${section.kind}. Rules: ${section.ruleIds.join(', ')||'none'}. Evidence IDs: ${section.evidenceIds.join(', ')||'none'}. ${section.kind==='editorial-exercise'?'Original optional reflection; not an inference about fate.':'The accompanying JSON retains the calculated facts and unresolved conflicts.'}`};
  });
  sections.unshift(uncertaintySection(result));
  sections.push({id:'method-scope',title:'Method and source scope',paragraphs:[
    'The retained method uses the recorded historical local civil clock, a midnight day boundary, and the declared late-Zi hour convention. LiChun and Jie boundaries are evaluated using the same instant in UTC+8. No true-solar-time substitution is made.',
    'Jade records exact-stem roots separately from same-phase roots; the month branch’s first listed hidden stem is one input, and exposure means a month hidden stem is visible at a non-day position. These limited structural definitions are not a complete school of interpretation or a final strength, formation or useful-element judgment.',
    'This is an AI-assisted structural reference awaiting independent traditional and English review. Free and detailed sections share the same facts and method; their identifiers are retained in JSON. It is not a full personal reading and cannot be purchased.'
  ],sourceRefs:['S-HIDDEN','S-TEN','S-PAIRS','J-ROOT','J-MONTH','J-EXPOSURE','T-IANA'],fieldDependencies:['methodVersion','ruleVersion','contentVersion'],basisNotes:'Fixed local source-ledger projection; named sources support only their listed roles. No reviewer or prediction claim is implied.'});
  const sourceIds=[...new Set(sections.flatMap(x=>x.sourceRefs))];
  const inputLabel=i.timePrecision==='range'?`${i.range.start}–${i.range.end} (range)`:
    i.timePrecision==='unknown'?'time unknown':`${i.time} (minute precision${i.occurrence?`, ${i.occurrence} occurrence`:''})`;
  const report={schemaVersion:1,id,createdAt,locale:'en-US',title:'A reading of the chart structure',
    contentVersion:CONTENT_VERSION,assemblyVersion:EXPORT_VERSION,reviewStatus:s.reviewStatus,
    purchasable:false,fullPersonalizedReport:false,coverageKind:'chart-structure-draft',
    chart:clone(s.chart),birthPlace,inputSummary:`${i.date} · ${inputLabel} · ${birthPlace.label}`,
    inputNotice:i.timePrecision==='range'?'A supplied time range is retained. Only stable positions are interpreted; candidate charts remain visible.':
      i.timePrecision==='unknown'?'Birth time unknown. The hour pillar and all hour-dependent comparisons are omitted.':
      s.chart.status==='boundary-minute'?'This minute crosses a calculated term boundary. Unresolved positions and alternatives are retained.':
      'Chart-specific structure draft under the stated civil-clock convention; birth seconds are not known.',
    exportMetadata:[['Input status',s.chart.status],['Contract / export',`${CONTRACT_VERSION} / ${EXPORT_VERSION}`],['Rule version',s.ruleVersion],['Unresolved positions',s.derived.missing.join(', ')||'none under the stated method']],
    sections,sources:sourcesFor(sourceIds),
    originalInput:clone(i),normalizedTime:clone(n),evidenceSnapshot:clone(s)};
  const pack=freeze({ok:true,exportVersion:EXPORT_VERSION,reference:result,report});
  prepared.add(pack);return pack;
}

/** Explicit user action is required by the caller; nothing is saved or shared here.
 * This is a local object provenance guard, not authentication or payment security.
 */
export function exportLocalReport(pack,format,notes={}){
  if(!prepared.has(pack))fail('PREPARED_LOCAL_REPORT_REQUIRED');
  if(!['text','json','html','bundle'].includes(format))fail('EXPORT_FORMAT_UNSUPPORTED');
  return ({text:reportText,json:reportJSON,html:reportHTML,bundle:reportBundle})[format](pack.report,notes);
}
