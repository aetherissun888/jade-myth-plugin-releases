// Compatibility adapter for the frozen calendar module's documented input errors.
// Unknown library errors must reach the application error boundary, not blame the user.
const legacyInputErrors=new Set([
  'INVALID_INPUT',
  'Enter a Gregorian date as YYYY-MM-DD.',
  'Use a valid Gregorian date from 1901 to 2026.',
  'Choose a valid repeated-time occurrence.',
  'Enter a local clock time as HH:MM, or select time unknown.',
  'This clock time is not repeated; clear the occurrence selection.',
  'Select the actual birthplace or confirm a manual place and IANA time zone.',
  'Time zone or date outside the pinned data range.',
  'Unsupported IANA time zone.'
]);
export function inputErrorCode(error){
  if(!(error instanceof RangeError))return null;
  if(error.message==='UNSUPPORTED_RANGE')return 'UNSUPPORTED_RANGE';
  return legacyInputErrors.has(error.message)?'INVALID_INPUT':null;
}
