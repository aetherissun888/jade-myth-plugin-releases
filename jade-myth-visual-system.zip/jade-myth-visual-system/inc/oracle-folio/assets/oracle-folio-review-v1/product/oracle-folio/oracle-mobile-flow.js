/** Same single-page task on every width; reuse the existing chart/report events. */
export function initMobileFlow(){
 document.documentElement.removeAttribute('data-mobile-view');
 document.getElementById('mobile-example-report').hidden=true;
 const $=id=>document.getElementById(id);
 const navigation=document.querySelector('.oracle-navigation'),mobile=matchMedia('(max-width:760px)');
 const sync=()=>navigation.open=!mobile.matches;sync();mobile.addEventListener('change',sync);
 const reveal=id=>{const node=$(id);if(!node)return;node.tabIndex=-1;node.focus({preventScroll:true});if(matchMedia('(max-width:760px)').matches)node.scrollIntoView({block:'start',behavior:'instant'});};
 $('manual-shortcut').addEventListener('click',()=>{document.querySelector('.folio-notes').open=true;document.querySelector('.manual-place').open=true;reveal('manual-name');});
 $('mobile-edit').addEventListener('click',()=>reveal('birth-date'));
 $('mobile-report-back').addEventListener('click',()=>reveal('chart-result-heading'));
 document.addEventListener('jade-chart-ready',()=>{ $('mobile-coverage').textContent='A local structure draft is available for review.';reveal('chart-result-heading'); });
 document.addEventListener('jade-report-open',()=>reveal('report-title'));
 document.addEventListener('jade-chart-cleared',()=>{$('mobile-coverage').textContent='';});
}
