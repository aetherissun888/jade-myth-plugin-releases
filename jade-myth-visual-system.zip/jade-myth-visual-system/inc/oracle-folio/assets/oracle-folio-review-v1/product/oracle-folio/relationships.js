/** Original explanation of pinned notation; no prediction or missing-hour inference. */
import {LunarUtil} from './vendor/lunar-typescript-1.8.6/dist/index.js';
export const RELATIONSHIP_VERSION='bazi-visible-stem-relationships-v1';
const STEMS=['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const PINYIN=['Jia','Yi','Bing','Ding','Wu','Ji','Geng','Xin','Ren','Gui'];
const PHASES=['Wood','Fire','Earth','Metal','Water'];
const POSITIONS=[['year','Year'],['month','Month'],['hour','Hour']];
const ROLE_NAMES={'比肩':'Bi Jian','劫财':'Jie Cai','食神':'Shi Shen','伤官':'Shang Guan','偏财':'Pian Cai','正财':'Zheng Cai','七杀':'Qi Sha','正官':'Zheng Guan','偏印':'Pian Yin','正印':'Zheng Yin'};
const FAMILIES=['peer','output','managed','constraint','resource'];
const FAMILY_LABELS={peer:'same phase',output:'produced by the Day Master',managed:'constrained by the Day Master',constraint:'constrains the Day Master',resource:'supports the Day Master'};
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};
export const RELATIONSHIP_SOURCES=freeze([
 {id:'R-TEN',title:'6tail: ten relationship names and stem table',url:'https://6tail.cn/calendar/lunar.shishen.html',role:'Chinese technical labels and their phase/polarity classification. Not evidence of literal wealth, occupation, relationships or outcomes.'},
 {id:'R-TABLE',title:'lunar-typescript: exact retained SHI_SHEN table',url:'https://github.com/6tail/lunar-typescript/blob/a376ec2b8fd1b3069e24c92801bab8707fccd49d/src/lib/LunarUtil.ts',role:'Pinned implementation table used for each displayed stem pair, under the retained MIT notice.'},
 {id:'R-WUXING',title:'Ronnie Littlejohn: Wuxing, Internet Encyclopedia of Philosophy',url:'https://iep.utm.edu/wuxing/',role:'Section 4 describes production and conquest cycles as historical conceptual schemes. It does not validate this report or its modern exercises.'}
]);
export function relateStems(dayStem,otherStem){
 const d=STEMS.indexOf(dayStem),o=STEMS.indexOf(otherStem);if(d<0||o<0)throw new RangeError('A relationship requires two supported Heavenly Stems.');
 const dayPhase=PHASES[Math.floor(d/2)],otherPhase=PHASES[Math.floor(o/2)],delta=(Math.floor(o/2)-Math.floor(d/2)+5)%5;
 const label=LunarUtil.SHI_SHEN[dayStem+otherStem];if(!ROLE_NAMES[label])throw new RangeError('The pinned relationship table has no readable entry.');
 const direction=[`Both stems are classified as ${dayPhase}`,`${dayPhase} generates ${otherPhase}`,`${dayPhase} constrains ${otherPhase}`,`${otherPhase} constrains ${dayPhase}`,`${otherPhase} generates ${dayPhase}`][delta];
 return freeze({dayStem,otherStem,dayName:PINYIN[d],otherName:PINYIN[o],dayPhase,otherPhase,dayPolarity:d%2?'yin':'yang',otherPolarity:o%2?'yin':'yang',samePolarity:d%2===o%2,label,pinyin:ROLE_NAMES[label],family:FAMILIES[delta],familyLabel:FAMILY_LABELS[FAMILIES[delta]],direction});
}
const EXERCISES={
 'peer|resource':['Separate a shared commitment from the support it needs.','Choose a small task you share with someone. Write what each person agreed to do, then one resource the task still needs. Which part is confirmed and which is assumed?'],
 'output|resource':['Separate preparation from a finished result.','Choose a small piece of work. Name the result you want to produce and one input it depends on. What can you finish with the resources already available?'],
 'constraint|resource':['Separate a requirement from the help available.','Choose an ordinary task with a clear requirement. Write the requirement in one line and the support you can actually use in another. What evidence would show that the requirement has been met?'],
 'managed|resource':['Distinguish what you can change from what you need.','Choose one manageable project. Name a choice you control and a resource you depend on. What smaller version could you complete if the resource stays unavailable?'],
 'managed|output':['Keep the scope separate from the result.','Choose a draft, repair or routine. Name what you are trying to finish, then one limit on time or materials. Which reversible change would preserve the purpose with less work?'],
 'output|peer':['Distinguish a shared effort from your contribution.','Choose a task involving another person. Write the shared aim and the part you can finish yourself. What needs agreement before either person proceeds?'],
 'constraint|output':['Make the acceptance condition concrete.','Choose one piece of work. Write what you will produce and the observable condition it must satisfy. How would someone check it without relying on your intention?'],
 'managed|peer':['Separate joint decisions from your own choices.','Choose a low-stakes commitment involving someone else. Mark one decision that needs agreement and one you can make yourself. Which conversation would remove the uncertainty?'],
 'constraint|managed':['Distinguish a fixed condition from an adjustable choice.','Choose an ordinary plan. Write one condition you cannot currently change and one choice you can reverse. What small adjustment is worth trying, and what would make you stop?'],
 'constraint|peer':['Check an agreement against a stated requirement.','Choose a shared task with a practical requirement. Write what was agreed and what the requirement actually says. Is there a difference that needs clarification before you act?'],
 peer:['Check one shared commitment.','Choose an ordinary commitment you share. Write what is agreed and what still needs a direct question. Do not infer the other person’s intentions from a chart label.'],
 resource:['Check one needed resource.','Choose a small plan. Name one input it needs and how you know it is available. What can you do if that assumption is wrong?'],
 output:['Name one finished result.','Choose a small piece of work. Describe what finished would look like, then a step you can complete and inspect.'],
 managed:['Choose one reversible adjustment.','Choose a small part of a routine you can change. Write the possible benefit, the cost and a way to undo the change.'],
 constraint:['Verify one requirement.','Choose an ordinary task. Find the actual instruction or agreement it must satisfy. Write what remains unclear instead of guessing.']
};
/** Caller supplies the same verified chart used by the report assembly. */
export function makeRelationshipSection(chart,{id='relationships'}={}){
 const day=chart?.pillars?.day?.[0];if(!day)throw new RangeError('A stable Day Master is required.');
 const rows=POSITIONS.filter(([key])=>chart.pillars[key]).map(([position,positionLabel])=>({position,positionLabel,...relateStems(day,chart.pillars[position][0])}));
 const omitted=POSITIONS.filter(([key])=>!chart.pillars[key]).map(([position,positionLabel])=>({position,positionLabel,reason:position==='hour'&&chart.time===null?'birth time unknown':'solar-term boundary unresolved'}));
 const anchor=relateStems(day,day),families=[...new Set(rows.map(r=>r.family))];
 const paragraphs=[`The reference stem is ${anchor.dayName} ${day}, classified as ${anchor.dayPhase}, ${anchor.dayPolarity}. Each row below compares a different position with that same reference. The direction and yin/yang pairing determine its traditional ten-relationship label.`];
 for(const row of rows)paragraphs.push(`${row.positionLabel}: ${row.otherName} ${row.otherStem} (${row.otherPhase}, ${row.otherPolarity}) is ${row.pinyin} ${row.label}. Within the five-phase model, ${row.direction.toLowerCase()}; the two stems have ${row.samePolarity?'the same':'opposite'} polarity.`);
 if(omitted.length)paragraphs.push('Not assigned: '+omitted.map(x=>x.positionLabel+' ('+x.reason+')').join('; ')+'. These positions are omitted rather than replaced by a guessed stem.');
 let synthesis;
 if(!rows.length)synthesis='Only the day position is stable in this snapshot. There are no stable non-day stems to compare, so this chapter supplies no relationship pattern or chart-selected exercise.';
 else if(rows.length===1)synthesis=`Only the ${rows[0].positionLabel.toLowerCase()} stem is available for this comparison. Its ${rows[0].pinyin} classification does not establish a pattern across the rest of the chart.`;
 else{
  const first=rows[0],second=rows.find(r=>r.family!==first.family)||rows[1];
  synthesis=first.family===second.family?`The ${first.positionLabel.toLowerCase()} and ${second.positionLabel.toLowerCase()} positions have the same relationship direction relative to the Day Master${first.label===second.label?' and the same technical label':', but their different polarity pairings give different technical labels'}. The similarity belongs to these displayed stems; a count does not measure strength or importance.`:`Compare the ${first.positionLabel.toLowerCase()} and ${second.positionLabel.toLowerCase()} positions: ${first.direction.toLowerCase()}, while ${second.direction.toLowerCase()}. They have different roles relative to the same Day Master. Reducing both to one phase adjective would lose that distinction.`;
 }
 paragraphs.push(synthesis);
 paragraphs.push('These are symbolic classifications within a traditional model. Names associated with wealth or authority are not findings about income, work, other people or future events. This chapter covers visible stems only; it does not weigh hidden stems, seasonal strength or favorable elements.');
 const exerciseKey=families.slice(0,2).sort().join('|'),exercise=EXERCISES[exerciseKey];
 if(exercise)paragraphs.push(`Modern reflection: ${exercise[0]} This exercise is selected from the ${rows.filter(r=>families.slice(0,2).includes(r.family)).map(r=>r.positionLabel.toLowerCase()).join(' and ')} stem relationships above. It is an original planning exercise, not a traditional prescription or a claim about your personality.`);
 return freeze({id,title:'How the other stems relate to your Day Master',paragraphs,prompt:exercise?exercise[1]:null,action:exercise?'Keep your observation in the working notes. Check what happened after a small, reversible step; the chart does not supply the outcome.':null,fieldDependencies:['pillars.day',...rows.map(r=>'pillars.'+r.position),...(omitted.length?['time','yearMonthOptions']:[])],sourceRefs:['S1','S2','R-TEN','R-TABLE','R-WUXING'],claimKind:'traditional-notation-and-original-modern-comparison',basisNotes:'Chinese labels come from the pinned stem-pair table. Phase and polarity explain that classification. The comparison and practical worksheet are original AI-assisted Jade writing, not a translation, professional assessment or independently reviewed forecast.',authorship:'Original English with AI assistance; independent cultural and English review pending.',analysis:{ruleVersion:RELATIONSHIP_VERSION,dayStem:day,rows,omitted,selectedExerciseRule:exercise?exerciseKey:null}});
}
