/** Temporary print projection of the current DOM. No report recalculation/storage. */
export function prepareReportPrint(root){
 const previousFlag=root.dataset.printView;
 const disclosures=[...root.querySelectorAll('details')].map(node=>({node,open:node.open,name:node.getAttribute('name')}));
 const notes=[];let restored=false;
 root.dataset.printView='true';
 // Named disclosure groups otherwise prevent all chapters opening together.
 for(const {node} of disclosures){node.removeAttribute('name');node.open=true;}
 for(const field of root.querySelectorAll('textarea[data-note]')){
  const text=root.ownerDocument.createElement('p');text.dataset.printNote='true';
  text.textContent=field.value||'No note entered.';field.after(text);notes.push(text);
 }
 return ()=>{
  if(restored)return;restored=true;
  for(const text of notes)text.remove();
  for(const {node} of disclosures)node.open=false;
  for(const {node,name} of disclosures){if(name!==null)node.setAttribute('name',name);}
  for(const {node,open} of disclosures)node.open=open;
  if(previousFlag===undefined)delete root.dataset.printView;else root.dataset.printView=previousFlag;
 };
}
