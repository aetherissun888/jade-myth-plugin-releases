/** Keep a failed local module load visible; do not expose raw error/input details. */
import('./bazi.js').then(()=>{
 for(const id of ['calculate','synthetic','worked-report'])document.getElementById(id).disabled=false;
 const status=document.getElementById('birth-status');status.dataset.state='idle';status.textContent='No chart calculated yet.';
}).catch(()=>{
 const $=id=>document.getElementById(id);
 for(const id of ['calculate','synthetic','worked-report','generate-report','export-report-bundle','export-report-html','export-report-text','export-report-json','print-report'])$(id).disabled=true;
 for(const id of ['chart-result','full-report','boundary-note'])$(id).hidden=true;
 for(const id of ['free-reflection','report-sections','report-notes','report-metadata','report-toc'])$(id).replaceChildren();
 $('chart-empty').hidden=false;
 document.documentElement.dataset.mobileView='input';
 $('place-search-status').dataset.state='error';$('place-search-status').textContent='Place search is unavailable until the calculator reloads.';
 const status=$('birth-status');status.dataset.state='error';status.classList.add('error');status.setAttribute('role','alert');
 status.textContent='The local calculator could not load. Reload to try again. No chart or report is available.';
 const retry=document.createElement('button');retry.type='button';retry.className='button secondary';retry.textContent='Reload calculator';
 retry.addEventListener('click',()=>location.reload());status.after(retry);
 // Clear remains useful even if the main module never registered its handler.
 $('clear').addEventListener('click',()=>{
  for(const field of document.querySelectorAll('.birth-input input,.birth-input select')){
   if(field.type==='checkbox')field.checked=false;else field.value='';
  }
  $('place-results').replaceChildren();$('place-selected').textContent='No birthplace selected.';$('place-selected').dataset.selected='false';
  status.textContent='Details cleared. Reload the calculator before trying again.';
 });
 status.tabIndex=-1;status.focus({preventScroll:true});
});
