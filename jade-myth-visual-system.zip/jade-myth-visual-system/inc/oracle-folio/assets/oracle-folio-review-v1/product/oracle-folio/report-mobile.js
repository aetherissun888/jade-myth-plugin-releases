/** Presentation only; no calculation, persistence or browser state. */
export const REPORT_CHAPTER_TITLES=Object.freeze(['1 · Your chart','2 · Reflection and patterns','3 · Choices and review','4 · Sources and limitations']);
export function reportChapterIndex(id=''){
 if(id==='report-relationships')return 0;
 if(/WORKED-CONTEXT|report-structure-(?:record|positions|master|relationships)$/.test(id))return 0;
 if(/GUI-FREE|WORKED-REPEATS|WORKED-HOUR|report-structure-(?:repetition|exercise)$/.test(id))return 1;
 if(/^report-(?:options|review|structure-record-check)$/.test(id))return 2;
 return 3;
}
export function mobileReportSummary(report){
 const chart=report.chart;
 const base=chart.time===null?'Birth time unknown. Hour comparisons are omitted.':report.coverageKind==='chart-structure-draft'?'Chart-structure draft. Independent review is pending.':'Worked draft. Independent review is pending.';
 return base+(chart.yearMonthOptions.length>1?' Year/month have unresolved alternatives.':chart.nearSolarBoundary?' Near a solar-term boundary.':'');
}

export function releaseMobileReportState(moves,wrappers){
 const boxes=wrappers.filter(box=>box.classList.contains('mobile-report-chapter')||box.classList.contains('mobile-report-notes'));
 for(let i=moves.length-1;i>=0;i--){
  const[node,mark]=moves[i];
  if(boxes.some(box=>box.contains(node))){if(mark.parentNode)mark.replaceWith(node);moves.splice(i,1);}
 }
 for(let i=wrappers.length-1;i>=0;i--)if(boxes.includes(wrappers[i])){wrappers[i].remove();wrappers.splice(i,1);}
}
