/** Candidate transitions inside the selected Jia/You branch; no effective rescue verdict. */
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const positions=['year','month','day','hour'];
export const ZP_RESCUE_CONTRACT=freeze({id:'Jade-ZP-JiaYou-RescueCandidates-v1',version:'1.0.0',
 source:{url:'https://www.ncc.com.tw/fate/paleo/bg/bg_032.htm',chapter:'七、論刑沖會合解法',readDate:'2026-10-26',
  layer:'transmitted-main-text',paragraph:61,
  clauses:['有戌，則卯與戌合而不沖','有辰，則酉與辰合而不沖','有亥與未，則卯與亥未會而不沖','有巳與丑，則酉與巳丑會而不沖'],
  limit:'Subsequent main-text counterexamples show that one interaction may reopen another; clauses are not an unconditional whole-chart algorithm.'},
 commentary:{paragraph:62,layer:'Xu commentary, kept separate',use:'position/nature caution only; no numerical distance, strength or root threshold inferred'},
 rules:[{id:'mao-xu',members:['卯','戌'],text:'Mao–Xu pairing route'},
  {id:'you-chen',members:['酉','辰'],text:'You–Chen pairing route'},
  {id:'mao-hai-wei',members:['卯','亥','未'],text:'Hai–Mao–Wei group route'},
  {id:'you-si-chou',members:['酉','巳','丑'],text:'Si–You–Chou group route'}],
 operationalConvention:'Record every complete known member configuration; never rank routes, resolve an opposition or infer effective formation from membership.',
 effectivenessDependencies:['position-and-nature assessment','operative interaction and competing routes','strength/root assessment where required by the claimed effect'],
 excluded:['automatic effective rescue','automatic formation or failure','root/strength scores','life-outcome claims']});
export function reviewZipingRescueCandidates(snapshot,entryStatus){
 const pillars=snapshot.chart.pillars,known=positions.filter(p=>pillars[p]),unknown=positions.filter(p=>!pillars[p]);
 const empty={contractId:ZP_RESCUE_CONTRACT.id,contractVersion:ZP_RESCUE_CONTRACT.version,unknownPositions:unknown,
  rescueEffective:null,patternFormed:null,wholeChartExclusion:false,customerInference:null};
 if(entryStatus!=='entry-established')return freeze({...empty,state:entryStatus==='input-insufficient'?'input-insufficient':'outside-implemented-branch',oppositions:[],routes:[],transition:['entry unavailable','rescue branch not selected']});
 if(!['甲子','甲寅','甲辰','甲午','甲申','甲戌'].includes(pillars.day))throw new RangeError('ZP_RESCUE_INVALID_DAY_PAIR');
 if(pillars.month?.[1]!=='酉')throw new RangeError('ZP_RESCUE_ENTRY_SCOPE_MISMATCH');
 const byId=new Map(snapshot.derived.facts.map(f=>[f.factId,f]));
 for(const p of known)if(byId.get('hidden:'+p)?.value.branch!==pillars[p][1])throw new RangeError('ZP_RESCUE_POSITION_FACT_DRIFT');
 const matches=b=>known.filter(p=>pillars[p][1]===b),mao=matches('卯'),you=matches('酉');
 const oppositions=mao.map(p=>({positions:['month',p],evidenceIds:['hidden:month','hidden:'+p],sourcePaths:['snapshot.chart.pillars.month[1]','snapshot.chart.pillars.'+p+'[1]']}));
 if(!mao.length)return freeze({...empty,state:unknown.length?'no-known-opposition-input-open':'no-listed-opposition',oppositions,routes:[],transition:['stable Jia/You entry','no known Mao; no rescue route inferred']});
 const flags=[];
 if(mao.length>1||you.length>1)flags.push({code:'REPEATED_ENDPOINTS',positions:[...mao,...you],meaning:'Repeated endpoints require separate interaction assessment; one pair is not selected as the effective one.'});
 // Only literal opposing branch pairs in the same four recorded positions. This is a review trigger, not proof of operative force.
 const opposing={'子':'午','丑':'未','寅':'申','卯':'酉','辰':'戌','巳':'亥'};
 for(let i=0;i<known.length;i++)for(let j=i+1;j<known.length;j++){
  const a=known[i],b=known[j],x=pillars[a][1],y=pillars[b][1];
  if((opposing[x]===y||opposing[y]===x)&&!([x,y].includes('卯')&&[x,y].includes('酉')))flags.push({code:'OTHER_OPPOSITION_RECORDED',positions:[a,b],meaning:'Another listed opposition is present; its effect on a candidate route is not determined.'});
 }
 const routes=ZP_RESCUE_CONTRACT.rules.map(rule=>{
  const members=rule.members.map(branch=>({branch,positions:matches(branch)})),missingMembers=members.filter(m=>!m.positions.length).map(m=>m.branch);
  const observedPositions=positions.filter(p=>members.some(m=>m.positions.includes(p))),complete=!missingMembers.length;
  const groupOutsideNatalScope=rule.members.length===3;
  // Jia-day branches have yang parity. Mao/You plus either all-yin three-member group would occupy all four natal slots with yin branches.
  // Preserve the source route, but do not invent an impossible natal birthday or import a transit as a fifth position.
  const canCompleteWithUnknown=missingMembers.length<=unknown.length&&!groupOutsideNatalScope;
  return {id:rule.id,members,missingMembers,patternStatus:groupOutsideNatalScope?'source-route-outside-four-pillar-jia-scope':complete?'complete-known-configuration':canCompleteWithUnknown?'incomplete-known-configuration-input-open':'not-established',
   decision:groupOutsideNatalScope?'OUTSIDE_NATAL_SCOPE':complete?'CANDIDATE_ONLY':canCompleteWithUnknown?'HOLD_INPUT':'NOT_ESTABLISHED',
   scopeLimit:groupOutsideNatalScope?'Mao/You and this complete group require four yin branches; no valid Jia day can occupy a natal slot. No transit/fifth branch has been added.':null,
   evidenceIds:observedPositions.map(p=>'hidden:'+p),sourcePaths:observedPositions.map(p=>'snapshot.chart.pillars.'+p+'[1]'),
   positionOrder:observedPositions,span:observedPositions.length?positions.indexOf(observedPositions.at(-1))-positions.indexOf(observedPositions[0]):null,
   positionMeaning:'Column order/span is recorded for review, not a threshold or priority rule.',
   effective:null,explanation:groupOutsideNatalScope?rule.text+' is retained as a source illustration, not an activated four-pillar Jia-day condition.':complete?rule.text+' has its required members in known positions. This advances to a rescue candidate, not a resolved opposition.':rule.text+' is not established from known positions.',
   pending:complete?[...ZP_RESCUE_CONTRACT.effectivenessDependencies,...(unknown.length?['unresolved birth positions']:[])]:[]};
 });
 const candidates=routes.filter(r=>r.decision==='CANDIDATE_ONLY');
 if(candidates.length>1)flags.push({code:'MULTIPLE_ROUTES_RECORDED',positions:positions.filter(p=>candidates.some(r=>r.positionOrder.includes(p))),meaning:'More than one route shares the recorded opposition; no route wins by array order.'});
 return freeze({...empty,state:candidates.length?'rescue-candidate-requires-assessment':'opposition-without-established-rescue-route',oppositions,routes,reviewFlags:flags,
  transition:['stable Jia/You entry','known Mao/You opposition',candidates.length?'required members establish '+candidates.length+' source-listed candidate route(s)':'no complete source-listed route in known positions','effective rescue remains unassessed'],
  source:ZP_RESCUE_CONTRACT.source,operationalConvention:ZP_RESCUE_CONTRACT.operationalConvention,
  dependencyStatus:{positionAndNature:'unassessed',effectiveInteractions:'unassessed',strengthAndRoots:'unassessed; not replaced by seeing a resource or wealth symbol'}});
}
