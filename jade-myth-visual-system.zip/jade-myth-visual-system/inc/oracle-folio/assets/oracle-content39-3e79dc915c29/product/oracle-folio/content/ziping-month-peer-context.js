/** Bounded same-snapshot structural supplement, not a pattern/strength engine. */
import{assertClaimLedgerSource}from'./claim-ledger.js';
export const MONTH_PEER_CONTEXT_VERSION='Jade-ZP-YinMonthPeer-Conditions-v1';
export const MONTH_PEER_SECTION='reading-month-peer-context';
const unique=a=>[...new Set(a)].sort(),positions=['year','month','day','hour'],entries=new Set(['乙寅','辛申','癸亥']);
const sourceIds=['C-ZP-MONTH-PEER-CONDITIONS'];
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
export function materializeMonthPeerRows(rows,facts){const available=new Set(facts.map(f=>f.factId));return rows.filter(row=>row.requires.every(id=>available.has(id)));}
export function buildMonthPeerContext(snapshot,ledger){
 assertClaimLedgerSource(ledger,snapshot);
 const pillars=snapshot.chart.pillars,day=pillars.day,month=pillars.month,base={ruleId:MONTH_PEER_CONTEXT_VERSION,status:'outside-limited-entry',id:MONTH_PEER_SECTION,title:'Reading these conditions together',sourceRefs:sourceIds,professionalReview:'pending',purchasable:false,newLifeDomain:false,verdicts:{strength:null,formation:null,effectiveMediation:null,effectiveRoot:null,relativeRootSupport:null,usefulElement:null,income:null,careerTalent:null}};
 if(!day||!month)return freeze({...base,status:'input-insufficient'});
 if(!entries.has(day[0]+month[1]))return freeze(base);
 const facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f])),entryIds=['month-relation:principal','hidden:month','hidden-relationship:month:0'];
 if(entryIds.some(id=>!byId.has(id)))return freeze({...base,status:'evidence-incomplete'});
 const principal=byId.get(entryIds[0]),hidden=byId.get(entryIds[1]),first=byId.get(entryIds[2]);
 if(principal.value.relation?.label!=='劫财'||principal.value.relation.dayStem!==day[0]||principal.value.stem!==hidden.value.stems[0]||hidden.value.branch!==month[1]||first.value.stem!==principal.value.stem||first.value.relation.label!=='劫财')throw new RangeError('MONTH_PEER_ENTRY_FACT_DRIFT');
 const inventory=[],missing=[];
 for(const position of positions.filter(p=>pillars[p])){
  const h=byId.get('hidden:'+position);if(!h){missing.push('hidden:'+position);continue;}
  if(h.value.branch!==pillars[position][1])throw new RangeError('MONTH_PEER_HIDDEN_SOURCE_DRIFT');
  if(position!=='day'){
   const id='visible-relationship:'+position,f=byId.get(id);if(!f)missing.push(id);else{
    if(f.value.dayStem!==day[0]||f.value.otherStem!==pillars[position][0])throw new RangeError('MONTH_PEER_VISIBLE_SOURCE_DRIFT');
    inventory.push({factId:id,evidenceIds:[id],position,visibility:'visible',stem:f.value.otherStem,label:f.value.label,family:f.value.family,sourcePaths:['snapshot.chart.pillars.'+position+'[0]','snapshot.derived.facts[factId='+id+'].value']});
   }
  }
  for(let index=0;index<h.value.stems.length;index++){
   const id='hidden-relationship:'+position+':'+index,f=byId.get(id);if(!f){missing.push(id);continue;}
   if(f.value.stem!==h.value.stems[index]||f.value.relation.dayStem!==day[0])throw new RangeError('MONTH_PEER_HIDDEN_SOURCE_DRIFT');
   inventory.push({factId:id,evidenceIds:['hidden:'+position,id],position,visibility:'hidden',stem:f.value.stem,label:f.value.relation.label,family:f.value.relation.family,sourcePaths:['snapshot.derived.facts[factId=hidden:'+position+'].value.stems['+index+']','snapshot.derived.facts[factId='+id+'].value.relation']});
  }
 }
 // Missing facts at known positions cannot become an absence or a replacement interpretation.
 if(missing.length)return freeze({...base,status:'evidence-incomplete',missingFactIds:missing});
 const group=(family,visibility)=>inventory.filter(r=>r.family===family&&r.visibility===visibility),visibleWealth=group('managed','visible'),hiddenWealth=group('managed','hidden'),visibleOutput=group('output','visible'),hiddenOutput=group('output','hidden'),visibleSupport=group('resource','visible'),hiddenSupport=group('resource','hidden');
 const ids=rows=>unique(rows.flatMap(r=>r.evidenceIds)),allInventory=ids(inventory),entry={pair:day[0]+month[1],profileId:'Jade-ZP-MonthPattern-v1',componentVersion:MONTH_PEER_CONTEXT_VERSION,sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.month[1]',...entryIds.map(id=>'snapshot.derived.facts[factId='+id+']')],evidenceIds:entryIds,operation:'limited three yin-day/month pairs only; not a universal rule for month peers, establishment or blades'};
 const unknown=positions.filter(p=>!pillars[p]),rows=[];
 const placementNote='In this traditional chart, symbols may be shown directly or contained within other symbols; that describes their position, not real-world strength.';
 const add=(id,text,requires,projection='detailed')=>rows.push({id,projection,text:(id==='entry'||id==='free'?placementNote+' ':'')+text,layer:'structural-context',requires:unique([...entryIds,...requires]),sourceRefs:sourceIds});
 add('entry','The selected Zi Ping approach starts with the birth month and asks how the rest of the chart fits with it. In this limited reading, material-resources symbols and expression symbols need to be considered together; their presence alone does not settle the interpretation.',entryIds);
 let free,comparison,comparisonIds;
 const bothWealth=['正财','偏财'].every(label=>visibleWealth.some(r=>r.label===label));
 if(unknown.length&&!visibleWealth.length&&hiddenWealth.length&&hiddenOutput.length){
  free='Material-resources symbols and expression symbols are present within other symbols in the known chart. Your birth time is unknown, so no directly shown symbol or interaction is assigned to the missing hour. This incomplete record does not establish whether the full chart has additional directly shown material-resources symbols.';
  comparison='The known chart retains material-resources symbols and expression symbols within other symbols. No symbol or interaction has been supplied for the missing birth hour. This supports a partial comparison while leaving room for relationships that more complete birth information could reveal.';comparisonIds=allInventory;
 }else if(visibleSupport.length&&!visibleWealth.length&&!visibleOutput.length&&hiddenWealth.length&&hiddenOutput.length){
  free='Support symbols appear directly more than once. Material-resources symbols and expression symbols are contained within other symbols. Reading those groups together keeps the interpretation from treating the contained symbols as absent.';
  comparison='Support symbols appear directly more than once in the known chart. Material-resources symbols and expression symbols are contained within other symbols, so they also belong in the comparison. Their positions give the reading something to examine; they do not establish that any one group is powerful or effective.';comparisonIds=allInventory;
 }else if(bothWealth&&hiddenOutput.length&&!visibleOutput.length){
  free='Two different types of material-resources symbols are shown directly, while expression symbols occur within other symbols. This differs from the source’s narrower example of one unmixed type. The reading therefore compares their conditions rather than borrowing that example’s conclusion.';
  comparison='The month and hour each show a different type of material-resources symbol. Expression symbols are contained within other symbols. The source’s narrower exception for one unmixed type cannot simply be transferred to this arrangement. How the parts work together still requires a fuller assessment.';comparisonIds=allInventory;
 }else if(visibleWealth.length&&hiddenOutput.length&&!visibleOutput.length){
  free='A material-resources symbol is shown directly, while expression symbols are contained within other symbols. The selected method compares the conditions around them before drawing a conclusion about their relationship.';
  comparison='A material-resources symbol is shown directly, while expression symbols are contained within other symbols. This differs from a chart where both groups are shown directly. Neither position alone establishes that the connection between expression and material resources is effective.';comparisonIds=allInventory;
 }else return freeze({...base,status:'entry-without-this-comparison',entry,inventory,unknownPositions:unknown});
 if(snapshot.chart.status!=='incomplete-time')free=free.replace('Your birth time is unknown','The birth hour is unresolved');
 if(unknown.length&&!free.includes('birth time'))free+=' The unresolved birth information may add conditions that change this comparison.';
 add('free',free,comparisonIds,'free');add('observed-layers',comparison,comparisonIds);
 const interactions=facts.filter(f=>['stem-combination','branch-clash'].includes(f.kind)).map(f=>({factId:f.factId,kind:f.kind,positions:[...f.positions],value:f.value,sourcePath:'snapshot.derived.facts[factId='+f.factId+']',effective:null}));
 const link=byId.get('stem-combination:month:hour'),clash=byId.get('branch-clash:day:hour');
 if(entry.pair==='辛申'&&pillars.hour?.[0]==='乙'&&pillars.day?.[1]==='丑'&&pillars.hour?.[1]==='未'){
  if(link&&(!link.value.includes('庚')||!link.value.includes('乙'))||clash&&(!clash.value.includes('丑')||!clash.value.includes('未')))throw new RangeError('MONTH_PEER_INTERACTION_DRIFT');
  if(!link||!clash)return freeze({...base,status:'evidence-incomplete',entry,missingInteractionContext:true});
  add('interactions','That directly shown material-resources symbol is part of a recorded pairing, and the same position is involved in a separate opposition. Both relationships need to be considered. The pairing has not been treated as removing or transforming the symbol, and the opposition is not a prediction that a plan or relationship will fail.',['visible-relationship:hour','visible-relationship:month',link.factId,clash.factId]);
 }
 add('source-route','The source usually considers expression symbols alongside material-resources symbols. It also discusses a separate case where expression symbols are not shown directly. That exception has its own conditions, so this comparison keeps both routes open rather than treating the presence of two groups as a favorable verdict.',comparisonIds);
 add('boundary','What remains open is the balance between the different parts and how their recorded relationships operate. This supplement does not settle overall strength, effective mediation, a completed pattern or a favorable-element choice. These are comparisons within a traditional symbolic framework, not measures of your income or career ability or a new interpretation of a life topic.',comparisonIds);
 const rendered=materializeMonthPeerRows(rows,facts),freeRows=rendered.filter(r=>r.projection==='free'),detailRows=rendered.filter(r=>r.projection==='detailed');
 return freeze({...base,status:'supported-structural-context',entry,inventory,partition:{visibleWealth,hiddenWealth,visibleOutput,hiddenOutput,visibleSupport,hiddenSupport},unknownPositions:unknown,interactions,rows:rendered,freeRows,detailRows,evidenceIds:unique(rendered.flatMap(r=>r.requires)),basis:'This supplement follows the selected month-led framework. Material-resources symbols, support symbols and expression symbols are identified separately, with their recorded positions. The source’s usual route and conditional exception are both retained; symbol placement and repetition are not treated as proof of effective strength or transformation.',basisSources:[{title:'Zi Ping Zhen Quan — 四十五、論建祿月劫',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_035.htm'}],scopeNotice:'Chart context — A limited comparison of the available relationships is included. This does not add a work or money topic or complete a pattern analysis.'});
}

/** Root-approved NQ1–NQ5: one bounded reading over the original month-peer facts. */
export const N10_QUALITATIVE_RULE='Jade-ZP-N10-AimsMeans-v1';
export function buildN10QualitativeReading(snapshot,context,ledger){
 assertClaimLedgerSource(ledger,snapshot);
 const absent=reason=>({ruleId:N10_QUALITATIVE_RULE,status:'not-established',reason});
 const p=snapshot.chart.pillars,unknown=snapshot.chart.status==='incomplete-time'&&p.hour==null;
 if(context.status!=='supported-structural-context'||context.entry?.pair!=='癸亥'||snapshot.chart.nearSolarBoundary||p.year!=='庚午'||p.month!=='丁亥'||p.day!=='癸未'||(unknown?false:p.hour!=='丙辰')||(!unknown&&snapshot.chart.status!=='calculated'))return absent('outside-reviewed-N10-configuration');
 const facts=new Map(snapshot.derived.facts.map(f=>[f.factId,f]));
 const roles=[['visible-relationship:year','庚','正印'],['visible-relationship:month','丁','偏财'],['hidden-relationship:year:0','丁','偏财'],['hidden-relationship:year:1','己','七杀'],['hidden-relationship:month:0','壬','劫财'],['hidden-relationship:month:1','甲','伤官'],['hidden-relationship:day:0','己','七杀'],['hidden-relationship:day:1','丁','偏财'],['hidden-relationship:day:2','乙','食神'],...(!unknown?[['visible-relationship:hour','丙','正财'],['hidden-relationship:hour:0','戊','正官'],['hidden-relationship:hour:1','乙','食神'],['hidden-relationship:hour:2','癸','比肩']]:[])];
 for(const[id,stem,label]of roles){const f=facts.get(id);if(!f)return absent('required-known-role-missing');const visible=f.kind==='visible-relationship',r=visible?f.value:f.value.relation,position=id.split(':')[1];
  if((visible?f.value.otherStem:f.value.stem)!==stem||r.dayStem!=='癸'||r.label!==label||f.positions.join(':')!=='day:'+position)throw new RangeError('N10_QUALITATIVE_ROLE_SOURCE_DRIFT');
 }
 const required=[...context.entry.evidenceIds,...context.evidenceIds,'phase-root:month','branch-combination:year:day',...roles.map(r=>r[0]),...(!unknown?['exact-root:hour']:[])];
 if(required.some(id=>!facts.has(id)))return absent('required-known-context-missing');
 const pair=facts.get('branch-combination:year:day'),root=facts.get('phase-root:month');
 if(pair.kind!=='branch-combination'||pair.positions.join(':')!=='year:day'||pair.value.join('')!=='午未'||root.kind!=='phase-root'||root.positions.join(':')!=='day:month'||root.value.stem!=='壬'||root.value.branch!=='亥'||root.value.index!==0)throw new RangeError('N10_QUALITATIVE_CONTEXT_SOURCE_DRIFT');
 if(!unknown&&(facts.get('exact-root:hour').kind!=='exact-root'||facts.get('exact-root:hour').positions.join(':')!=='day:hour'||facts.get('exact-root:hour').value.stem!=='癸'||facts.get('exact-root:hour').value.branch!=='辰'||facts.get('exact-root:hour').value.index!==2))throw new RangeError('N10_QUALITATIVE_HOUR_SOURCE_DRIFT');
 if(context.partition.visibleOutput.length)return absent('visible-output-requires-another-reading');
 const evidenceIds=unique(required),qualifiers=roles.filter(([, ,label])=>['正印','正官','七杀'].includes(label)).map(r=>r[0]).concat(pair.factId);
 const conditions={contractId:'Jade-ZP-N10-Qualitative-v1',decisionIds:['NQ1','NQ2','NQ3','NQ4','NQ5'],decisionOrigin:'root-approved qualitative product interpretation, not a classical personality quotation',entryPair:'癸亥',interpretationStatus:unknown?'provisional-known-positions':'bounded-resources-theme',sourcePaths:evidenceIds.map(id=>'snapshot.derived.facts[factId='+id+']'),qualifyingFactIds:unique(qualifiers),unknownPositions:unknown?['hour']:[],wholeChartExclusionMade:false,narrowExceptionApplied:false,hiddenExpressionMeansLackOfAbility:false,rootEffectiveness:null,effectiveMediation:null,overallStrength:null,formedPattern:null,usefulElement:null};
 const kind=unknown?'provisional-n10-aims-means':'n10-aims-means';
 const notice=unknown?'Traditional chart interpretation — A provisional aims-and-means theme is included from the known parts. It does not complete a personal resources chapter.':'Traditional chart interpretation — A limited resources-and-action reading is included. It does not establish effective mediation, a completed pattern or income.';
 return {id:MONTH_PEER_SECTION,ruleId:N10_QUALITATIVE_RULE,status:'supported-cultural-structure',kind,domain:unknown?null:'money',title:unknown?'A possible link between goals and what you can offer':'Linking what you want with what you can offer',evidenceIds,counterEvidenceIds:unique(qualifiers),sourceRefs:sourceIds,conditions,
  overview:unknown?'A provisional theme is linking a useful result with what you can make, explain or offer toward it. The missing birth time may change the emphasis.':'This Zi Ping cultural reading explores how a result that appeals to you might connect with something you can actually make, explain or offer.',
  freeLayers:['modern-reflection','traditional-cultural-interpretation'],freeParagraphs:unknown?[
   'With your birth time unknown, this Zi Ping cultural reading offers a possible theme: linking a useful result with what you can make, explain or offer toward it.',
   'That connection is present in the known parts of your chart, but the missing time could change what else needs to be considered. Keep this reading provisional rather than treating it as your chart’s settled emphasis.'
  ]:[
   'You may be drawn to a worthwhile result before you have decided what you could actually bring to it. The tension in this reading is between seeing a possibility and finding a workable way to take part.',
   'This theme is selected because the chart combines roles associated with a result and with making or explaining something. Jade reads their connection as something to develop, rather than treating the desired result as proof that the means are already in place.'
  ],
  detailedLayers:unknown?['traditional-cultural-interpretation','modern-reflection','modern-reflection','structural-context']:['traditional-cultural-interpretation','modern-reflection','modern-reflection','modern-reflection','structural-context'],
  detailedParagraphs:unknown?[
   'The known parts of your chart give a reason to consider a useful result alongside the way you make or express something. In the selected Zi Ping approach, those are read together rather than assuming that wanting a result supplies the means. Your birth time is unknown, so this is a possible reading direction, not the full known-time comparison.',
   'Jade’s contemporary application is to distinguish an attractive goal from a clear way to take part in it. You may find the theme useful when a result matters to you but what you can actually do toward it is still taking shape.',
   'Two situations remain different. If you are drawn to a goal before the task is clear, defining one useful part to take on can help you assess it. If you already have something useful to offer, deciding where it belongs is a separate choice; more possible uses need not all claim the same time or resources.',
   'The missing hour could change the emphasis of the reading, including how resources are considered. It has not been filled in or used to rule out further conditions. The theme remains conditional and does not settle an income outcome or complete the traditional assessment.'
  ]:[
   'You may see a worthwhile possibility before it is clear what you would actually offer toward it. This theme comes from the chart’s combination of result-seeking and expression symbols; Jade reads their link as something to develop, rather than an ability already proved.',
   'Imagine wanting to grow vegetables because you like the idea of a useful garden. Deciding what you can care for with the time and help available is different from picturing the finished garden. Taking responsibility for one manageable part can show what the larger idea would ask of you.',
   'A finished piece of writing presents a different choice: it could become a personal essay, a club handout or a talk. Choosing an audience changes what is useful to explain, even when the underlying material stays the same. That is a question of fit, rather than a signal that you need more ability.',
   'A promising result and a workable way to carry it out are different things. This reading distinguishes finding a way to contribute from deciding where an existing contribution belongs. More possible uses need not all claim the same time or resources.',
   'Help, preparation and other requirements still matter. The examples show two ways to explore the theme; the chart does not establish which situation is actually happening in your life.'
  ],previewParagraphIndex:1,
  previewScope:unknown?'Also included: a provisional goals-and-means theme using only the known chart. It cannot supply the missing birth time or complete a personal resources assessment.':'Also included: one limited resources-and-action theme explaining why a desired result and a workable way to reach it are not the same thing.',
  basis:unknown?'The known Gui day and Hai month retain Ren as a same-phase role, month Ding as a material-resource role, and Jia/Yi expression symbols within the positions. Geng support, the known Ji requirement roles and the Wu/Wei pair remain in view. Nothing is supplied for the missing hour. One known resource category does not establish that it is the only one in the full chart. Jade’s aims-and-means theme is provisional; how these roles actually work together and any income outcome remain unassessed.':'For the Gui day and Hai month, month Ding and hour Bing are two different material-resource roles; Jia/Yi expression symbols occur within the chart positions. Year Geng support, the contained Ji/Wu requirement roles and the year Wu/day Wei pair stay in the comparison. No pair is assumed to remove or transform a role. The source considers expression alongside resources and gives a narrower exception that is not assumed to apply here. Jade’s aims-and-means emphasis is a chosen qualitative interpretation; chart placement is not a measure of strength or ability.',
  coverageNotice:notice,reportScope:{status:conditions.interpretationStatus,bodyNotice:unknown?'A provisional aims-and-means theme is included from the known positions. The unknown time prevents a complete resources chapter; it is not supplied by more detailed wording.':'One bounded resources-and-action theme is included. Other life topics, effective strength, completed formation and income outcomes have not been supplied.',coverageNotice:notice}};
}
