import {readingInputLimit} from '../content/evidence-report-plan.js';
import {ZP_PROFILE_SOURCE_URLS} from '../content/ziping-profile-sources.js';
import {readingDeliveryScope} from '../content/reading-deliverability.js';
// Additive export view, not a calculation/recovery snapshot or an anonymity guarantee.
import{reportHTML,reportText,reportJSON,cleanNotes,NOTE_FIELDS,escapeHTML as E}from'./legacy-export.js';
import{reportBundle,bundleTextFiles}from'./bundle.js';
export const ANNUAL_PRIVACY_VERSION='jm-annual-export-privacy-v1';
export const STRUCTURAL_PRIVACY_VERSION='jm-structural-export-privacy-v1';
const allowedSections=new Set(['input-certainty','orientation','season','roots','pairs','synthesis','reflection','method-scope','cycle-direction','annual-calendar','luck-cycles','luck-method-scope']);
const structuralSections=new Set(['input-certainty','orientation','season','roots','pairs','synthesis','reflection','method-scope']);
const profiles={annual:{version:ANNUAL_PRIVACY_VERSION,assembly:'jm-annual-facts-report-v2',sections:allowedSections},structural:{version:STRUCTURAL_PRIVACY_VERSION,assembly:'jm-reference-export-v2',sections:structuralSections}};
const omittedSections=new Set(['input-certainty','luck-cycles']);
const clone=x=>JSON.parse(JSON.stringify(x));
const fail=code=>{throw new RangeError(code);};
export function privacyOptions(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['omitBirthDetails','includeNotes'].includes(k))||typeof value.omitBirthDetails!=='boolean'||typeof value.includeNotes!=='boolean')fail('EXPLICIT_EXPORT_PRIVACY_REQUIRED');
 return{omitBirthDetails:value.omitBirthDetails,includeNotes:value.includeNotes};
}
function readingView(profile,report,notes,options){
 const choice=privacyOptions(options);
 if(!choice.omitBirthDetails)fail('OMITTED_BIRTH_DETAILS_VIEW_REQUIRED');
 if(report.assemblyVersion!==profile.assembly||report.sections.some(s=>!profile.sections.has(s.id)))fail('PRIVACY_PROJECTION_REVIEW_REQUIRED');
 const sections=report.sections.filter(s=>!omittedSections.has(s.id)).map(s=>({id:s.id,title:s.title,paragraphs:[...s.paragraphs],sourceRefs:[...s.sourceRefs],fieldDependencies:[...s.fieldDependencies],basisNotes:s.basisNotes.replace('The accompanying JSON retains the calculated facts and unresolved conflicts.','This reduced JSON retains reading sections and chart alternatives, not the full calculation evidence.')}));
 const c=report.chart;
 const document={schemaVersion:profile.version,sourceAssemblyVersion:report.assemblyVersion,contentVersion:report.contentVersion,createdAt:report.createdAt,title:'Chart reading — birth details omitted',reviewStatus:report.reviewStatus,purchasable:false,fullPersonalizedReport:false,
  privacy:{...choice,anonymous:false,restorable:false,notice:profile===profiles.annual?'Birth date, recorded time/range, birthplace, birth timezone, raw input, normalized instants, full evidence and personal cycle dates are omitted. Pillars, reading text and the selected shared calendar/display zone remain personal information and may reveal birth details. This is not an anonymous or public-sharing file.':'Birth date, recorded time/range, birthplace, birth timezone, raw input, normalized instants and full evidence are omitted. Pillars and reading text remain personal information and may reveal birth details. This is not an anonymous or public-sharing file.',notesNotice:choice.includeNotes?'You explicitly included notes. They may reintroduce any details you typed.':'Personal notes are excluded.',evidenceNotice:'This is a reading copy, not a complete calculation or recovery snapshot. Keep a full private export if you need the underlying evidence.'},
  chart:{methodVersion:c.methodVersion,engineVersion:c.engineVersion,timeZoneVersion:c.timeZoneVersion,status:c.status,complete:c.complete,pillars:clone(c.pillars),yearMonthOptions:clone(c.yearMonthOptions),nearSolarBoundary:c.nearSolarBoundary},
  inputLimits:{timePrecision:report.originalInput.timePrecision,unresolvedPositions:Object.entries(c.pillars).filter(([,v])=>v===null).map(([k])=>k),personalCycleTiming:profile===profiles.annual?'Omitted from this reading copy; this does not change the source report.':'Personal cycle timing is not provided by this structural report.'},
  sections,sources:clone(report.sources)};
 if(choice.includeNotes)document.notes=cleanNotes(notes);
 return document;
}
function paragraphs(d){return[d.title,'LOCAL DRAFT / INDEPENDENT HUMAN REVIEW PENDING',d.privacy.notice,d.privacy.notesNotice,d.privacy.evidenceNotice,
 `Export view: ${d.schemaVersion}. Source assembly: ${d.sourceAssemblyVersion}. Content: ${d.contentVersion}.`,
 `Method: ${d.chart.methodVersion}; ${d.chart.engineVersion}; IANA ${d.chart.timeZoneVersion}.`,
 `Input precision: ${d.inputLimits.timePrecision}. Status: ${d.chart.status}. Unresolved positions: ${d.inputLimits.unresolvedPositions.join(', ')||'none under the stated method'}. Near solar boundary: ${d.chart.nearSolarBoundary}.`,
 `Pillars: ${Object.values(d.chart.pillars).map(x=>x??'unresolved').join(' / ')}.`,
 `Year/month alternatives: ${d.chart.yearMonthOptions.map(x=>`${x.year} / ${x.month}`).join('; ')}. No candidate is selected by this export.`,
 d.inputLimits.personalCycleTiming,...d.sections.flatMap(s=>[s.title,...s.paragraphs,'Basis: '+s.basisNotes,'Fields: '+s.fieldDependencies.join('; '),'Sources: '+s.sourceRefs.join(', ')]),
 ...(d.notes?['Explicitly included notes',...Object.entries(d.notes).filter(([,v])=>v).map(([k,v])=>k+': '+v)]:[]),
 'Named sources',...d.sources.map(s=>`${s.id} · ${s.title} · ${s.role} · ${s.url}`)];}
function renderHTML(d){return`<!doctype html><html lang="en-US"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${E(d.title)}</title><style>body{max-width:850px;margin:auto;padding:32px;color:#173d32;background:#faf6e9;font:19px/1.65 Georgia,serif}p{overflow-wrap:anywhere;white-space:pre-wrap}h1{font-weight:500;font-size:36px}@media print{body{background:white}}</style></head><body><h1>${E(d.title)}</h1>${paragraphs(d).slice(1).map(p=>'<p>'+E(p)+'</p>').join('')}</body></html>`;}
function exportWithProfile(profile,report,format,notes,options){
 const choice=privacyOptions(options);
 if(!['html','text','json','bundle'].includes(format))fail('EXPORT_FORMAT_UNSUPPORTED');
 if(!choice.omitBirthDetails)return({html:reportHTML,text:reportText,json:reportJSON,bundle:reportBundle})[format](report,choice.includeNotes?notes:{});
 const view=readingView(profile,report,notes,choice);
 if(format==='json')return JSON.stringify(view,null,2);
 if(format==='text')return paragraphs(view).join('\n\n');
 if(format==='html')return renderHTML(view);
 return bundleTextFiles([['Jade-Myth-Reading.html',renderHTML(view)],['Jade-Myth-Reading.txt',paragraphs(view).join('\n\n')],['Jade-Myth-Reading.json',JSON.stringify(view,null,2)]],view.createdAt);
}

// Separate explicit assembly gates; the common omission/notes/rendering policy stays shared.
export const annualReadingView=(report,notes,options)=>readingView(profiles.annual,report,notes,options);
export const exportAnnualWithPrivacy=(report,format,notes,options)=>exportWithProfile(profiles.annual,report,format,notes,options);
export function exportStructuralWithPrivacy(report,format,notes,options){
 if(report.assemblyVersion!==profiles.structural.assembly||report.sections.some(s=>!structuralSections.has(s.id)))fail('PRIVACY_PROJECTION_REVIEW_REQUIRED');
 return exportWithProfile(profiles.structural,report,format,notes,options);
}

// New explicit customer-copy profile. Historical structural/annual exports above
// keep their old schemas and guards. Technical evidence stays in the raw pack.
export const CUSTOMER_PRIVACY_VERSION='jm-customer-reading-privacy-v2.1';
export function customerReadingView(report,notes,options,tier='detailed',timing=null){
 const choice=privacyOptions(options),r=report.reading;
 const profiles={'jm-personal-reading-v2':['jm-personal-reading-en-v2','jm-symbolic-theme-composition-v2','jm-customer-reading-privacy-v2'],'jm-personal-reading-v2.1':['jm-personal-reading-en-v2.1','jm-symbolic-theme-composition-v2.1',CUSTOMER_PRIVACY_VERSION]};
 const profile=profiles[r?.schemaVersion];
 if(report.assemblyVersion!=='jm-reference-export-v2'||!profile||!(r.contentVersion===profile[0]||(r.schemaVersion==='jm-personal-reading-v2.1'&&['jm-personal-reading-en-v2.1.1','jm-personal-reading-en-v2.1.2','jm-personal-reading-en-v2.1.3','jm-personal-reading-en-v2.1.4','jm-personal-reading-en-v2.1.5','jm-personal-reading-en-v2.1.6','jm-personal-reading-en-v2.1.7','jm-personal-reading-en-v2.1.8','jm-personal-reading-en-v2.1.9','jm-personal-reading-en-v2.1.10','jm-personal-reading-en-v2.1.11','jm-personal-reading-en-v2.1.12','jm-personal-reading-en-v2.1.13','jm-personal-reading-en-v2.1.14','jm-personal-reading-en-v2.1.15','jm-personal-reading-en-v2.1.16','jm-personal-reading-en-v2.1.17','jm-personal-reading-en-v2.1.18','jm-personal-reading-en-v2.1.19','jm-personal-reading-en-v2.1.20','jm-personal-reading-en-v2.1.21','jm-personal-reading-en-v2.1.22','jm-personal-reading-en-v2.1.23','jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion)))||r.ruleVersion!==profile[1]||!['free','detailed'].includes(tier))fail('CUSTOMER_READING_REVIEW_REQUIRED');
 const revised=['jm-personal-reading-en-v2.1.3','jm-personal-reading-en-v2.1.4','jm-personal-reading-en-v2.1.5','jm-personal-reading-en-v2.1.6','jm-personal-reading-en-v2.1.7','jm-personal-reading-en-v2.1.8','jm-personal-reading-en-v2.1.9','jm-personal-reading-en-v2.1.10','jm-personal-reading-en-v2.1.11','jm-personal-reading-en-v2.1.12','jm-personal-reading-en-v2.1.13','jm-personal-reading-en-v2.1.14','jm-personal-reading-en-v2.1.15','jm-personal-reading-en-v2.1.16','jm-personal-reading-en-v2.1.17','jm-personal-reading-en-v2.1.18','jm-personal-reading-en-v2.1.19','jm-personal-reading-en-v2.1.20','jm-personal-reading-en-v2.1.21','jm-personal-reading-en-v2.1.22','jm-personal-reading-en-v2.1.23','jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion);
 const ids=new Set(['reading-overview','reading-craft','reading-patient-craft','reading-learning','reading-shared-money','reading-care-boundaries','reading-equal-voice','reading-ideas-value','reading-supported-authority','reading-mutual-space','reading-together','reading-limits']);
 if(r.schemaVersion==='jm-personal-reading-v2.1')for(const id of ['reading-money-exchange','reading-relationship-both','reading-work-both','reading-action'])ids.add(id);
 if(revised)ids.add('reading-coverage');
 if(['jm-personal-reading-en-v2.1.14','jm-personal-reading-en-v2.1.15','jm-personal-reading-en-v2.1.16','jm-personal-reading-en-v2.1.17','jm-personal-reading-en-v2.1.18','jm-personal-reading-en-v2.1.19','jm-personal-reading-en-v2.1.20','jm-personal-reading-en-v2.1.21','jm-personal-reading-en-v2.1.22','jm-personal-reading-en-v2.1.23','jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion))ids.add('reading-month-support');
 if(['jm-personal-reading-en-v2.1.17','jm-personal-reading-en-v2.1.18','jm-personal-reading-en-v2.1.19','jm-personal-reading-en-v2.1.20','jm-personal-reading-en-v2.1.21','jm-personal-reading-en-v2.1.22','jm-personal-reading-en-v2.1.23','jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion))ids.add('reading-yi-root-context');
 if(['jm-personal-reading-en-v2.1.22','jm-personal-reading-en-v2.1.23','jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion))ids.add('reading-month-peer-context');
 if(['jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion))ids.add('reading-rooted-expression');
 if(r.contentVersion==='jm-personal-reading-en-v2.1.39')ids.add('reading-yi-support');
 for(const sections of [r.freeSections,r.detailedSections])if(!Array.isArray(sections)||new Set(sections.map(s=>s.id)).size!==sections.length||sections.some(s=>!ids.has(s.id)||typeof s.title!=='string'||!Array.isArray(s.paragraphs)||s.paragraphs.some(p=>typeof p!=='string')))fail('CUSTOMER_READING_REVIEW_REQUIRED');
 const deliveryScope=['jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(r.contentVersion)?readingDeliveryScope(r):null;
 const d={schemaVersion:deliveryScope?'jm-customer-reading-privacy-v2.4':revised?'jm-customer-reading-privacy-v2.3':profile[2],contentVersion:r.contentVersion,compositionVersion:r.ruleVersion,createdAt:report.createdAt,title:tier==='free'?'Your BaZi reading: the essentials':'Your BaZi reading: a closer look',tier,reviewStatus:'Independent review pending',purchasable:deliveryScope?.availableToBuy??false,
  privacy:{...choice,anonymous:false,notice:choice.omitBirthDetails?'Birth details are omitted. The reading and chart symbols still contain personal information; keep this file private.':'You chose to include birth details. Keep this file private.',notesNotice:choice.includeNotes?'Your optional notes are included and may contain identifying details.':'Your optional notes are excluded.'},
  inputLimit:readingInputLimit(report.chart),
  chart:{pillars:clone(report.chart.pillars),alternatives:clone(report.chart.candidatePillars??[]),yearMonthOptions:clone(report.chart.yearMonthOptions)},
  sections:clone(tier==='free'?r.freeSections:r.detailedSections).map(({id,title,paragraphs,chartBasis})=>{
   if(chartBasis&&(Object.keys(chartBasis).some(k=>!['title','paragraphs','sources'].includes(k))||!['Why this topic appears','How this reading uses the tradition'].includes(chartBasis.title)||!Array.isArray(chartBasis.paragraphs)||chartBasis.paragraphs.some(p=>typeof p!=='string')||
    (chartBasis.sources&&(!Array.isArray(chartBasis.sources)||chartBasis.sources.some(s=>typeof s.title!=='string'||(!/^https:\/\/zh\.wikisource\.org\/w\/index\.php\?title=[^&]+&oldid=\d+$/.test(s.url)&&!ZP_PROFILE_SOURCE_URLS.includes(s.url)))))))fail('CUSTOMER_CHART_BASIS_INVALID');
   return {id,title,paragraphs,...(chartBasis?{chartBasis}:{} )};
  }),
  preview:tier==='free'?clone(r.preview):null};
 if(deliveryScope)d.deliveryScope=clone(deliveryScope);
 if(revised){
  d.coverage=clone(r.coverage.domains).map(({domain,status,sectionId,detail,partialNotice})=>({domain,status,sectionId,detail,...(partialNotice?{partialNotice}:{})}));
  d.appendices=[];
  const about=d.sections.find(s=>s.id==='reading-limits');
  // A compact About keeps the same canonical input limit in its visible basis.
  // Preserve older body layouts; do not reinsert it only in exports/Review.
  if(!(about.paragraphs.length===1&&about.chartBasis?.paragraphs.includes(d.inputLimit)))about.paragraphs.splice(1,1,d.inputLimit);
 }
 if(timing){
  const allowedTiming=new Set(['timing-year-reflection','timing-personal-cycles','timing-seasonal-calendar','timing-reading-scope']);
  if(timing.schemaVersion!=='jm-customer-timing-reading-v1'||!['jm-timing-en-cultural-v1','jm-timing-en-cultural-v1.0.1','jm-timing-en-cultural-v1.1','jm-timing-en-cultural-v1.2'].includes(timing.contentVersion)||timing.sourceReportId!==report.id||timing.sourceReadingContentVersion!==r.contentVersion||timing.sourceReadingCompositionVersion!==r.ruleVersion||[timing.freeSections,timing.detailedSections].some(a=>!Array.isArray(a)||new Set(a.map(s=>s.id)).size!==a.length||a.some(s=>!allowedTiming.has(s.id)||typeof s.title!=='string'||!Array.isArray(s.paragraphs)||s.paragraphs.some(p=>typeof p!=='string'))))fail('CUSTOMER_TIMING_REVIEW_REQUIRED');
  d.schemaVersion=deliveryScope?'jm-customer-reading-privacy-v2.4':revised?'jm-customer-reading-privacy-v2.3':'jm-customer-reading-privacy-v2.2';
  d.timing={contentVersion:timing.contentVersion,targetYear:timing.targetYear,calendarDisplayZone:timing.calendarDisplayZone,directionSelection:clone(timing.directionSelection),personalInterpretation:'limited cultural prompts only; not a complete forecast'};
  const extra=(tier==='free'?timing.freeSections:timing.detailedSections).filter(s=>!choice.omitBirthDetails||s.privacyClass!=='birth-derived-dates');
  for(const s of extra){
   const section={id:s.id,title:s.title,paragraphs:[...s.paragraphs]};
   if(revised&&s.role==='shared-calendar-reference')d.appendices.push({...section,optional:true,role:s.role});else d.sections.push(section);
  }
  if(choice.omitBirthDetails)d.privacy.notice+=' Calculated personal cycle dates are excluded; the selected shared calendar timezone remains.';
 }
 if(!choice.omitBirthDetails)d.birthDetails={summary:report.inputSummary};
 if(choice.includeNotes)d.notes=cleanNotes(notes);
 return d;
}
const SHARED_CALENDAR_NOTICE='Shared reference only. This optional appendix is not personal analysis.';
function customerParagraphs(d){return[d.title,'Private review draft · Not for sale',d.privacy.notice,d.privacy.notesNotice,
 ...(!d.appendices?[d.inputLimit]:[]),...(!d.appendices&&d.birthDetails?[d.birthDetails.summary]:[]),...d.sections.flatMap(s=>[s.title,...s.paragraphs]),
 ...(d.appendices&&d.birthDetails?['Your supplied birth details',d.birthDetails.summary]:[]),
 ...(d.preview?[d.preview.title,d.preview.paragraph,d.preview.description]:[]),
 ...(d.notes?['Your notes',...NOTE_FIELDS.filter(([id])=>d.notes[id]).flatMap(([id,label])=>[label,d.notes[id]])]:[]),
 ...(d.sections.some(s=>s.chartBasis)?['Optional chart connections',...d.sections.filter(s=>s.chartBasis).flatMap(s=>[s.title,...s.chartBasis.paragraphs,...(s.chartBasis.sources??[]).map(r=>r.title+' — '+r.url)])]:[]),
 ...(d.appendices??[]).flatMap(s=>[s.title,SHARED_CALENDAR_NOTICE,...s.paragraphs])];}
function customerHTML(d){
 const appendix=s=>'<details><summary>'+E(s.title)+'</summary><p>'+E(SHARED_CALENDAR_NOTICE)+'</p>'+s.paragraphs.map(p=>'<p>'+E(p)+'</p>').join('')+'</details>';
 const section=s=>'<section><h2>'+E(s.title)+'</h2>'+s.paragraphs.map(p=>'<p>'+E(p)+'</p>').join('')+(s.chartBasis?'<details><summary>'+E(s.chartBasis.title)+'</summary>'+s.chartBasis.paragraphs.map(p=>'<p>'+E(p)+'</p>').join('')+(s.chartBasis.sources??[]).map(r=>'<p><a href="'+E(r.url)+'" rel="noreferrer noopener">'+E(r.title)+'</a></p>').join('')+'</details>':'')+'</section>';
 return `<!doctype html><html lang="en-US"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${E(d.title)}</title><style>body{max-width:48rem;margin:auto;padding:2rem;color:#173d32;background:#faf6e9;font:19px/1.65 Georgia,serif}p{overflow-wrap:anywhere;white-space:pre-wrap}h1,h2{font-weight:500;line-height:1.2}section{margin:2rem 0}@media print{body{background:white}}</style></head><body><h1>${E(d.title)}</h1><p>Private review draft · Not for sale</p><p>${E(d.privacy.notice)}</p><p>${E(d.privacy.notesNotice)}</p>${!d.appendices?'<p>'+E(d.inputLimit)+'</p>':''}${!d.appendices&&d.birthDetails?'<p>'+E(d.birthDetails.summary)+'</p>':''}${d.sections.map(section).join('')}${d.appendices&&d.birthDetails?section({title:'Your supplied birth details',paragraphs:[d.birthDetails.summary]}):''}${d.preview?section({title:d.preview.title,paragraphs:[d.preview.paragraph,d.preview.description]}):''}${d.notes?section({title:'Your notes',paragraphs:NOTE_FIELDS.filter(([id])=>d.notes[id]).flatMap(([id,label])=>[label,d.notes[id]])}):''}${(d.appendices??[]).map(appendix).join('')}</body></html>`;
}
export function exportCustomerReadingWithPrivacy(report,format,notes,options,tier='detailed',timing=null){
 if(!['text','html','json','bundle'].includes(format))fail('EXPORT_FORMAT_UNSUPPORTED');
 const d=customerReadingView(report,notes,options,tier,timing),text=customerParagraphs(d).join('\n\n'),json=JSON.stringify(d,null,2);
 if(format==='text')return text;if(format==='json')return json;
 const html=customerHTML(d);if(format==='html')return html;
 return bundleTextFiles([['Jade-Myth-Reading.html',html],['Jade-Myth-Reading.txt',text],['Jade-Myth-Reading.json',json]],d.createdAt);
}
