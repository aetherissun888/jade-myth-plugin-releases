// Calendar facts only. Does not enable an annual interpretation or change birth methods.
import{Solar}from'../vendor/lunar-typescript-1.8.6/dist/index.js';
import{ALL_TIMEZONES,offsetAt,TIMEZONE_VERSION}from'../timezone.js';
export const ANNUAL_FACTS_METHOD='jm-lichun-jie-calendar-facts-v1';
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const keys=['立春','惊蛰','清明','立夏','芒种','小暑','立秋','白露','寒露','立冬','大雪','XIAO_HAN','LI_CHUN'];
const names=['立春','惊蛰','清明','立夏','芒种','小暑','立秋','白露','寒露','立冬','大雪','小寒','立春'];
const iso=ms=>new Date(ms).toISOString();
const parts=ms=>{const d=new Date(ms);return[d.getUTCFullYear(),d.getUTCMonth()+1,d.getUTCDate(),d.getUTCHours(),d.getUTCMinutes(),d.getUTCSeconds()];};
const solarMs=s=>Date.UTC(s.getYear(),s.getMonth()-1,s.getDay(),s.getHour(),s.getMinute(),s.getSecond())-28800000;
const ecAt=ms=>Solar.fromYmdHms(...parts(ms+28800000)).getLunar().getEightChar();
const made=new WeakSet();
export function buildAnnualFacts(targetYear,displayZone){
 if(!Number.isInteger(targetYear)||targetYear<1901||targetYear>2026)throw new RangeError('UNSUPPORTED_TARGET_YEAR');
 if(!ALL_TIMEZONES.includes(displayZone))throw new RangeError('EXPLICIT_DISPLAY_ZONE_REQUIRED');
 const table=Solar.fromYmd(targetYear,6,1).getLunar().getJieQiTable();
 const boundaries=keys.map((key,i)=>{const s=table[key];if(!s||s.getYear()!==targetYear+(i>=11?1:0))throw new RangeError('ANNUAL_TERM_TABLE_DRIFT');const ms=solarMs(s),o=offsetAt(ms,displayZone);return{term:names[i],instantUTC:iso(ms),displayLocal:iso(ms+o.seconds*1000).slice(0,-1),displayZone,offsetSeconds:o.seconds,daylightSaving:o.daylightSaving,precision:'model-second; independently certified error bound unavailable'};});
 const times=boundaries.map(b=>Date.parse(b.instantUTC));if(times.some((x,i)=>i&&x<=times[i-1]))throw new RangeError('ANNUAL_TERM_ORDER');
 const yearGanZhi=ecAt((times[0]+times[1])/2).getYear();
 const months=times.slice(0,-1).map((start,i)=>{const e=ecAt(Math.floor((start+times[i+1])/2));if(e.getYear()!==yearGanZhi)throw new RangeError('ANNUAL_YEAR_LABEL_DRIFT');return{id:`${targetYear}-jie-${i+1}`,number:i+1,ganZhi:e.getMonth(),start:boundaries[i],endExclusive:boundaries[i+1],interval:'[start,end)',meaning:'solar Jie month; not a Gregorian or lunar month'};});
 const facts=freeze({schemaVersion:'jm-annual-calendar-facts-v1',methodVersion:ANNUAL_FACTS_METHOD,engineVersion:'lunar-typescript-1.8.6',timeZoneVersion:TIMEZONE_VERSION,targetYear,displayZone,yearGanZhi,start:boundaries[0],endExclusive:boundaries[12],months,
  sourceRefs:['S-LUNAR-1.8.6','T-HKO-JIE','T-JPL-2024','T-IANA'],uncertainty:{modelSeconds:true,certifiedAllYearsErrorBound:false,boundaryGuardMilliseconds:120000,guardIsHeuristic:true},
  personalization:{status:'not-provided',birthTimeRequiredForCalendarFacts:false,annualInterpretation:false},eligibleForPublic:false,reviewStatus:'local calendar candidate; not professional approval'});
 made.add(facts);return facts;
}
export function locateAnnualWindow(facts,windowUTC){
 if(!made.has(facts))throw new RangeError('PREPARED_ANNUAL_FACTS_REQUIRED');
 if(!Array.isArray(windowUTC)||windowUTC.length!==2||windowUTC.some(x=>typeof x!=='string'||!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(x)))throw new RangeError('INVALID_CALENDAR_WINDOW');
 const [lo,hi]=windowUTC.map(Date.parse);if(!Number.isFinite(lo)||!Number.isFinite(hi)||lo>hi||[lo,hi].some((ms,i)=>iso(ms)!==windowUTC[i]))throw new RangeError('INVALID_CALENDAR_WINDOW');
 const guard=facts.uncertainty.boundaryGuardMilliseconds,start=Date.parse(facts.start.instantUTC),end=Date.parse(facts.endExclusive.instantUTC);
 const nominal=facts.months.filter(m=>lo<Date.parse(m.endExclusive.instantUTC)&&hi>=Date.parse(m.start.instantUTC));
 const guarded=facts.months.filter(m=>lo<Date.parse(m.endExclusive.instantUTC)+guard&&hi>=Date.parse(m.start.instantUTC)-guard);
 return freeze({methodVersion:facts.methodVersion,windowUTC:[...windowUTC],nominalPeriodIds:nominal.map(m=>m.id),candidatePeriodIds:guarded.map(m=>m.id),nearBoundary:guarded.length!==nominal.length||facts.months.some(m=>lo<=Date.parse(m.start.instantUTC)+guard&&hi>=Date.parse(m.start.instantUTC)-guard),outsideTargetYear:{before:lo<start,after:hi>=end},guardMayReachOutsideYear:{before:lo-guard<start,after:hi+guard>=end},warning:'Nominal membership uses model half-open boundaries. Guarded candidates are precautionary, not a certified astronomical confidence interval.'});
}
export function annualFactsSection(facts){
 if(!made.has(facts))throw new RangeError('PREPARED_ANNUAL_FACTS_REQUIRED');
 return {id:'annual-calendar',title:'Solar-year calendar facts',paragraphs:[
  `Target solar year ${facts.targetYear}: ${facts.yearGanZhi}. It runs from LiChun ${facts.start.instantUTC} inclusive to ${facts.endExclusive.instantUTC} exclusive. It does not start on January 1 or Lunar New Year.`,
  `Display zone: ${facts.displayZone}. The table below contains twelve Jie months, not Gregorian or lunar months. All timestamps are calculated model output, not certified event predictions.`,
  ...facts.months.map(m=>`Jie month ${m.number}: ${m.ganZhi}; ${m.start.term} inclusive to ${m.endExclusive.term} exclusive. UTC: ${m.start.instantUTC} to ${m.endExclusive.instantUTC}. Local display: ${m.start.displayLocal} (offset ${m.start.offsetSeconds}s) to ${m.endExclusive.displayLocal} (offset ${m.endExclusive.offsetSeconds}s).`),
  'These shared calendar facts remain available when birth time is unknown. They do not establish the natal chart, active luck cycle or a personal annual outcome.',
  'A two-minute boundary guard can retain neighboring calendar periods; it is a heuristic. Two independent 2024 astronomical anchors do not certify every term or year. No favorable/unfavorable, wealth, health or relationship judgment is generated.'
 ],sourceRefs:[...facts.sourceRefs],fieldDependencies:['extensions.annualFacts'],basisNotes:`Method ${facts.methodVersion}; engine ${facts.engineVersion}; IANA ${facts.timeZoneVersion}. Target-year/calendar facts are separate from annual interpretation.`};
}
