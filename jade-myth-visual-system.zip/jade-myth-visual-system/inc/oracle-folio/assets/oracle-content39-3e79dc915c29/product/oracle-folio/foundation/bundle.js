import {reportHTML,reportText,reportJSON} from './legacy-export.js';
const encoder=new TextEncoder();
function crc32(bytes){let crc=0xffffffff;for(const value of bytes){crc^=value;for(let b=0;b<8;b++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
const join=chunks=>{const out=new Uint8Array(chunks.reduce((n,c)=>n+c.length,0));let pos=0;for(const c of chunks){out.set(c,pos);pos+=c.length;}return out;};
// Standard ZIP stored entries: no third-party service, compression or archive code.
export function reportBundle(report,notes={},paper=''){
 const entries=[['Jade-Myth-BaZi-Report.html',reportHTML(report,notes,paper)],['Jade-Myth-BaZi-Report.txt',reportText(report,notes)],['Jade-Myth-BaZi-Report.json',reportJSON(report,notes)]];
 return bundleTextFiles(entries,report.createdAt);
}
// Shared stored-ZIP writer; existing report entry names and bytes are preserved.
export function bundleTextFiles(entries,createdAt){
 const local=[],central=[];let offset=0;const created=new Date(createdAt),year=Math.max(1980,Math.min(2107,created.getUTCFullYear())),dosDate=((year-1980)<<9)|((created.getUTCMonth()+1)<<5)|created.getUTCDate(),dosTime=(created.getUTCHours()<<11)|(created.getUTCMinutes()<<5)|Math.floor(created.getUTCSeconds()/2);
 for(const[name,body]of entries){const n=encoder.encode(name),data=encoder.encode(body),crc=crc32(data),header=new Uint8Array(30),h=new DataView(header.buffer);h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(10,dosTime,true);h.setUint16(12,dosDate,true);h.setUint32(14,crc,true);h.setUint32(18,data.length,true);h.setUint32(22,data.length,true);h.setUint16(26,n.length,true);local.push(header,n,data);
  const index=new Uint8Array(46),v=new DataView(index.buffer);v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint16(8,0x0800,true);v.setUint16(12,dosTime,true);v.setUint16(14,dosDate,true);v.setUint32(16,crc,true);v.setUint32(20,data.length,true);v.setUint32(24,data.length,true);v.setUint16(28,n.length,true);v.setUint32(42,offset,true);central.push(index,n);offset+=header.length+n.length+data.length;
 }
 const directory=join(central),end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,entries.length,true);v.setUint16(10,entries.length,true);v.setUint32(12,directory.length,true);v.setUint32(16,offset,true);return join([...local,directory,end]);
}
