/** Internal typed evidence ledger over the original snapshot; never calculates a chart. */
import {readingSelectorMatches} from './reading-selection.js';
import {assertRootAdmissibilitySource} from './ziping-root-admissibility.js';
import {assertOfficerChainSource} from './ziping-officer-chain.js';
import {assertLifeRouteSource} from './ziping-life-route-review.js';
import {SOURCE_CATALOG} from '../foundation/source-catalog.js';
import {DOMAIN_RESEARCH_SOURCES} from './domain-sources.js';
import {ORDINARY_SOURCES,ORDINARY_REVIEW_CARDS} from './ordinary-method-definitions.js';
import {METHOD_CONTEXT_SOURCES} from './method-context.js';
import {ZP_PROFILE_ID,ZP_PROFILE_VERSION,ZP_BRANCH_IDS,ZP_BRANCH_ID,ZP_YI_BRANCH_ID,ZP_JIA_YIN_BRANCH_ID,ZP_PROFILE_SOURCES} from './ziping-profile-sources.js';
export const CLAIM_LEDGER_VERSION='jm-evidence-claim-ledger-v1';
const bound=new WeakMap(),positions=['year','month','day','hour'];
const fail=code=>{throw new RangeError(code);};
const unique=a=>[...new Set(a)].sort();
const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const privateOnly=()=>({scope:'private-candidate-only',eligibleForPublic:false,purchasable:false,professionalReview:'pending'});
const sources=new Map([...SOURCE_CATALOG.map(s=>[s.sourceId,{id:s.sourceId,source:s.source??s.title,url:s.url??null,locator:s.locator,supports:s.supports,doesNotSupport:s.doesNotSupport,reviewStatus:s.humanReviewStatus}]),...DOMAIN_RESEARCH_SOURCES.map(s=>[s.sourceId,{id:s.sourceId,source:s.source??s.title,url:s.url??null,locator:s.locator,supports:s.supports,doesNotSupport:s.doesNotSupport,reviewStatus:s.humanReviewStatus}]),...ORDINARY_SOURCES.map(s=>[s.id,{id:s.id,url:s.url,locator:s.locator,supports:s.scope,doesNotSupport:s.status,reviewStatus:'pending'}])]);
for(const s of METHOD_CONTEXT_SOURCES)sources.set(s.id,s);
for(const s of ZP_PROFILE_SOURCES)sources.set(s.id,s);
const origin=f=>/^(?:visible|hidden)-relationship:(year|month|day|hour)(?::\d+)?$/.exec(f.factId)?.[1]??(['exact-root','phase-root','hidden','month-exposure'].includes(f.kind)?f.factId.split(':')[1]:f.kind==='month-relation'?'month':null);
const origins=f=>origin(f)?[origin(f)]:unique(f.positions);
function context(snapshot){
 if(snapshot?.schemaVersion!=='jm-foundation-schema-v1'||!snapshot.chart?.pillars||!Array.isArray(snapshot.derived?.facts)||!Array.isArray(snapshot.findings))fail('CLAIM_SNAPSHOT_REQUIRED');
 const facts=[...snapshot.derived.facts].sort((a,b)=>a.factId.localeCompare(b.factId,'en'));
 if(new Set(facts.map(f=>f.factId)).size!==facts.length)fail('CLAIM_DUPLICATE_FACT');
 for(const f of facts)if(!Array.isArray(f.positions)||f.positions.some(p=>!positions.includes(p)||snapshot.chart.pillars[p]==null)||!Array.isArray(f.sourceRefs)||!f.sourceRefs.length||f.sourceRefs.some(s=>!sources.has(s)))fail('CLAIM_FACT_BASIS_INVALID');
 return {facts,byId:new Map(facts.map(f=>[f.factId,f])),missing:positions.filter(p=>snapshot.chart.pillars[p]==null)};
}
const sourceRecords=ids=>unique(ids).map(id=>{const s=sources.get(id);if(!s)fail('CLAIM_SOURCE_UNKNOWN');return {...s};});
function assess(c,{requires,excludes=[]}){
 if(!Array.isArray(requires)||!requires.length||!Array.isArray(excludes))fail('CLAIM_CONDITIONS_REQUIRED');
 const rows=groups=>groups.map(group=>{
  if(!Array.isArray(group.anyOf)||!group.anyOf.length||group.anyOf.some(q=>!['visible-relationship','hidden-relationship'].includes(q.kind)||!['peer','resource','output','managed','constraint'].includes(q.family)||Object.keys(q).some(k=>!['kind','family','label','position'].includes(k))||(q.position&&!positions.includes(q.position))))fail('CLAIM_SELECTOR_UNSUPPORTED');
  return {anyOf:group.anyOf,factIds:c.facts.filter(f=>group.anyOf.some(q=>readingSelectorMatches(f,q))).map(f=>f.factId)};
 });
 const required=rows(requires),excluded=rows(excludes),evidence=unique(required.flatMap(r=>r.factIds)),counter=unique(excluded.flatMap(r=>r.factIds));
 const status=counter.length?'suppressed-by-counterevidence':required.some(r=>!r.factIds.length)?c.missing.length?'input-insufficient':'not-established':excludes.length&&c.missing.length?'input-insufficient':'supported-in-stable-scope';
 return {status,requires:required,excludes:excluded,evidenceIds:evidence,counterEvidenceIds:counter,missingPositions:c.missing,scope:'stable-retained-positions; not a strength or life-outcome judgment'};
}
export function assessEvidenceConditions(snapshot,conditions){return freeze(assess(context(snapshot),conditions));}
const roles={
 craft:['expression-and-standards','demonstrated-alternative','work-setting-conditions','preserve-requirement'],
 learning:['receiving-to-making','explanation-gap','forms-of-help','learning-loop'],
 'shared-money':['shared-ownership','agreement-before-sharing','bounded-contribution','actual-financial-boundary'],
 'care-boundaries':['care-and-duty','silent-task-allocation','reciprocal-request','other-person-boundary'],
 'equal-voice':['voice-and-accountability','decision-rights','identify-the-request','reversible-group-trial'],
 'ideas-value':['contribution-and-cost','correction-versus-new-request','exchange-terms','when-exchange-is-relevant'],
 'patient-craft':['production-and-standards','repeatable-task','routine-counterexample','teach-versus-judge'],
 'supported-authority':['responsibility-and-support','authority-gap','preparation-context','missing-resource-question'],
 'mutual-space':['independence-and-closeness','invitation-not-test','shared-versus-separate','other-person-boundary']
};
export function buildClaimLedger(snapshot,reading,definitions,compositions){
 if(reading.rootSupportAssessment)assertRootAdmissibilitySource(reading.rootSupportAssessment,snapshot);
 if(reading.officerChain)assertOfficerChainSource(reading.officerChain,snapshot);
 if(reading.lifeRouteReview)assertLifeRouteSource(reading.lifeRouteReview,snapshot);
 const c=context(snapshot),cards=new Map(definitions.map(d=>[d.id,d])),claims=[],gates=[];
 const add=r=>{claims.push({...r,publication:privateOnly()});return r.claimId;};
 const factRefs=ids=>unique(ids).map(id=>{const f=c.byId.get(id);if(!f)fail('CLAIM_FACT_UNKNOWN');return {factId:id,originPosition:origin(f),originPositions:origins(f),comparisonDependencies:unique(f.positions),sourceRefs:unique(f.sourceRefs)};});
 const refSources=ids=>sourceRecords(ids.flatMap(id=>{const f=c.byId.get(id);if(!f)fail('CLAIM_FACT_UNKNOWN');return f.sourceRefs;}));
 const probes=[...snapshot.findings].sort((a,b)=>a.ruleId.localeCompare(b.ruleId,'en'));
 for(const f of c.facts)add({claimId:'fact.'+f.factId,layer:'calculated-fact',status:'established-in-declared-model',factRefs:factRefs([f.factId]),sources:sourceRecords(f.sourceRefs),value:f.value,conditions:{requiredStablePositions:unique(f.positions)},counterEvidenceIds:[],unknown:c.missing,limitation:'Table/position fact only; no personal domain inference.'});
 for(const p of probes)add({claimId:'observation.'+p.ruleId,layer:'structural-observation',status:p.status,evidenceIds:unique(p.evidenceIds),factRefs:factRefs(p.evidenceIds),sources:sourceRecords(p.sourceRefs),conditions:{missingDependencies:unique(p.missingDependencies??[])},counterEvidenceIds:[],unknown:c.missing,rawProbeSignal:p.signal,limitation:'Existing probe classification, not whole-chart strength, formation or practical effect.'});
 for(const conflict of [...snapshot.reconciled.conflicts].sort((a,b)=>a.id.localeCompare(b.id,'en'))){
  const ids=unique([...(conflict.evidenceIds??[]),...(conflict.ruleIds??[]).flatMap(id=>{const p=probes.find(p=>p.ruleId===id);if(!p)fail('CLAIM_PROBE_UNKNOWN');return p.evidenceIds;})]);
  add({claimId:'context.conflict.'+conflict.id,layer:'structural-context',status:'contested',evidenceIds:ids,factRefs:factRefs(ids),sources:refSources(ids),conditions:{probeIds:unique(conflict.ruleIds??[])},counterEvidenceIds:ids,unknown:c.missing,resolution:conflict.resolution});
 }
 // An actual exclusion, deliberately limited to the visible category set.
 // Hidden/month factors can still oppose it: this is never a strength verdict.
 const unopposed=assess(c,{requires:[{anyOf:['peer','resource'].map(family=>({kind:'visible-relationship',family}))}],excludes:[{anyOf:['output','managed','constraint'].map(family=>({kind:'visible-relationship',family}))}]});
 add({claimId:'observation.visible-peer-resource-without-other-categories',layer:'structural-observation',...unopposed,conditions:{requires:unopposed.requires,excludes:unopposed.excludes},unknown:c.missing,factRefs:factRefs([...unopposed.evidenceIds,...unopposed.counterEvidenceIds]),sources:refSources([...unopposed.evidenceIds,...unopposed.counterEvidenceIds]),limitation:'Only the observed visible stem categories; not unopposed whole-chart support or strong Day Master.'});
 for(const d of ORDINARY_REVIEW_CARDS){const ids=c.facts.filter(f=>d.factKinds.includes(f.kind)).map(f=>f.factId);
  add({claimId:'method.'+d.id,layer:'traditional-method-interpretation',status:'HOLD',reason:'UNREVIEWED_METHOD_CONDITIONS',factRefs:factRefs(ids),sources:sourceRecords(d.sourceIds),conditions:{availableFactKinds:d.factKinds,unresolvedDecisions:d.decisions},counterEvidenceIds:[],counterConditions:d.counterconditions,unknown:c.missing,existingConflictIds:unique(snapshot.reconciled.conflicts.map(f=>f.id)),customerInference:null});
 }
 for(const t of [...reading.themes].sort((a,b)=>a.entryId.localeCompare(b.entryId,'en'))){
  const d=cards.get(t.entryId);if(!d||!roles[d.id]||roles[d.id].length!==d.paragraphs.length)fail('CLAIM_CARD_ROLES_REQUIRED');
  const conditions=assess(c,{requires:d.selectors.map(q=>({anyOf:[q]}))});
  const counters=unique(t.counterEvidenceIds),matched=t.status==='private-editorial-candidate';
  if(matched&&conditions.status!=='supported-in-stable-scope')fail('CLAIM_TEMPLATE_PREMISE_DRIFT');
  const evidence=unique(t.evidenceIds);factRefs([...evidence,...counters]);
  const gate={cardId:d.id,legacyStatus:t.status,legacyTemplateMatched:matched,decision:matched?counters.length?'qualified-modern-candidate':'matched-modern-candidate':t.status==='not-established-from-stable-input'?'HOLD_INPUT':'NOT_ESTABLISHED',traditionalDomainInference:'HOLD',reason:'CATEGORY_NAMES_DO_NOT_ESTABLISH_DOMAIN_INTERPRETATION',conditions,retainedCandidateCheck:t.retainedCandidateCheck??null,qualifyingCounterFactIds:counters,qualifyingCounterCondition:d.counterCondition};gates.push(gate);
  const common={layer:'modern-reflection',status:gate.decision,cardId:d.id,conditions,qualifyingCounterEvidenceIds:counters,counterCondition:d.counterCondition,unknown:c.missing,
   sourceExplanation:{tableFacts:refSources([...evidence,...counters]),namingReference:sourceRecords(['C-SM-V5-NAMES']),interpretationBridge:d.bridge,traditionalDomainInference:'HOLD'},factRefs:factRefs(evidence),counterFactRefs:factRefs(counters),legacyRendered:matched};
  d.paragraphs.forEach((text,i)=>add({claimId:'application.'+d.id+'.'+roles[d.id][i],...common,text}));
  add({claimId:'application.'+d.id+'.qualification',...common,role:'qualification-not-logical-exclusion',legacyRendered:matched&&counters.length>0,text:d.counterParagraph});
 }
 for(const descriptor of reading.reportPlan?.claimDescriptors??[]){
  add({...descriptor,status:descriptor.status??'private-source-bounded-candidate',sources:sourceRecords(descriptor.sourceRefs??[]),factRefs:factRefs(descriptor.evidenceIds),counterFactRefs:factRefs(descriptor.counterEvidenceIds),unknown:c.missing,
   sourceExplanation:{...descriptor.sourceExplanation,tableFacts:refSources([...descriptor.evidenceIds,...descriptor.counterEvidenceIds])},traditionalDomainInference:descriptor.layer==='traditional-cultural-interpretation'?'bounded-cultural-interpretation-only':'HOLD'});
 }
 const paragraphLinks=[],used=new Set();
 for(const section of reading.detailedSections){
  const planned=reading.reportPlan?.detailLinks[section.id];
  if(planned){
   if(planned.length!==section.paragraphs.length||planned.some((id,i)=>claims.find(c=>c.claimId===id)?.text!==section.paragraphs[i]))fail('CLAIM_PLAN_PARAGRAPH_DRIFT');
   planned.forEach(id=>used.add(id));paragraphLinks.push({sectionId:section.id,paragraphs:planned.map((id,i)=>({paragraph:i+1,claimIds:[id]})),reason:'source-bounded-report-plan',traditionalImportance:false});continue;
  }
  const selected=reading.selectionLedger.find(l=>'reading-'+l.outputId===section.id);
  if(selected){
   let ids=[];
   if(selected.selected.length===1){const id=selected.selected[0],d=cards.get(id);ids=roles[id].map(role=>'application.'+id+'.'+role);if(reading.themes.find(t=>t.entryId===id).counterEvidenceIds.length)ids.push('application.'+id+'.qualification');}
   else{
    const recipe=compositions.find(r=>r.id===selected.outputId&&r.members.length===selected.selected.length&&r.members.every(id=>selected.selected.includes(id)));if(!recipe)fail('CLAIM_COMPOSITION_REQUIRED');
    const members=selected.selected.map(id=>reading.themes.find(t=>t.entryId===id)),evidence=unique(members.flatMap(t=>t.evidenceIds)),counter=unique(members.flatMap(t=>t.counterEvidenceIds));
    const id=add({claimId:'composition.'+recipe.id+'.lead',layer:'modern-composition',status:'existing-private-copy',text:recipe.lead,conditions:{members:unique(selected.selected)},factRefs:factRefs(evidence),counterFactRefs:factRefs(counter),sources:refSources([...evidence,...counter]),unknown:c.missing,traditionalDomainInference:'HOLD',limitation:recipe.rationale});
    ids=[id,...recipe.fragments.flatMap(f=>f.counter?(reading.themes.find(t=>t.entryId===f.member).counterEvidenceIds.length?['application.'+f.member+'.qualification']:[]):['application.'+f.member+'.'+roles[f.member][f.index]])];
   }
   if(ids.length!==section.paragraphs.length||ids.some((id,i)=>claims.find(c=>c.claimId===id)?.text!==section.paragraphs[i]))fail('CLAIM_PARAGRAPH_LINK_DRIFT');
   ids.forEach(id=>used.add(id));paragraphLinks.push({sectionId:section.id,paragraphs:ids.map((id,i)=>({paragraph:i+1,claimIds:[id]})),selectedCardIds:unique(selected.selected),reason:selected.reason,traditionalImportance:false});
  }else{
   const sectionRoles={'reading-overview':['summary'],'reading-together':['integration','observe-and-revise'],'reading-action':['action'],'reading-coverage':['work','learning','money','relationships','collaboration','month-cultural-interpretation'],'reading-limits':['culture-review','input-precision','timing-scope','traditional-entry-scope']}[section.id];
   if(section.id==='reading-coverage'&&reading.reportPlan?.monthPeerContext?.status==='supported-structural-context')sectionRoles[5]='month-peer-structural-supplement';
   if(!sectionRoles||sectionRoles.length<section.paragraphs.length)fail('CLAIM_PRESENTATION_ROLE_MISSING');
   const basis=section.id==='reading-action'?reading.actionBasis:reading.synthesisBasis,refs=unique(basis?.evidenceIds??[]);
   const ids=section.paragraphs.map((text,i)=>add({claimId:'presentation.'+section.id+'.'+sectionRoles[i],layer:section.id==='reading-coverage'||section.id==='reading-limits'?'coverage-or-education':'editorial-synthesis',status:'existing-private-copy',text,conditions:{selectedCardIds:unique(reading.selectionLedger.flatMap(l=>l.selected))},factRefs:section.id==='reading-coverage'||section.id==='reading-limits'?[]:factRefs(refs),sources:[],counterEvidenceIds:[],unknown:c.missing,traditionalImportance:false,limitation:'Legacy selected context only; exact synthesis justification is HOLD for stage3. No new traditional inference.'}));
   ids.forEach(id=>used.add(id));paragraphLinks.push({sectionId:section.id,paragraphs:ids.map((id,i)=>({paragraph:i+1,claimIds:[id]})),reason:'existing-presentation-only',traditionalImportance:false});
  }
 }
 for(const claim of claims)if(claim.layer==='modern-reflection')claim.legacyRendered=used.has(claim.claimId);
 const freeParagraphLinks=reading.freeSections.map(s=>{
  const planned=reading.reportPlan?.freeLinks[s.id];
  if(planned){if(planned.length!==s.paragraphs.length||planned.some((id,i)=>claims.find(c=>c.claimId===id)?.text!==s.paragraphs[i]))fail('CLAIM_PLAN_FREE_DRIFT');return {sectionId:s.id,paragraphs:planned.map((id,i)=>({paragraph:i+1,claimIds:[id]}))};}
  const detail=reading.detailedSections.find(d=>d.id===s.id),link=paragraphLinks.find(l=>l.sectionId===s.id);if(!detail||!link)fail('CLAIM_FREE_SECTION_DRIFT');
  return {sectionId:s.id,paragraphs:s.paragraphs.map((p,i)=>{const index=detail.paragraphs.indexOf(p);if(index<0)fail('CLAIM_FREE_PARAGRAPH_DRIFT');return {paragraph:i+1,claimIds:link.paragraphs[index].claimIds};})};
 });
 let previewClaimIds=[];
 if(reading.preview){const detail=reading.detailedSections.find(s=>s.id===reading.preview.sectionId),index=detail?.paragraphs.indexOf(reading.preview.paragraph);if(index===undefined||index<0)fail('CLAIM_PREVIEW_DRIFT');previewClaimIds=paragraphLinks.find(s=>s.sectionId===detail.id).paragraphs[index].claimIds;}
 const ids=claims.map(c=>c.claimId);if(new Set(ids).size!==ids.length)fail('CLAIM_ID_DUPLICATE');
 const basisParagraphLinks=Object.entries(reading.reportPlan?.basisLinks??{}).map(([sectionId,claimIds])=>{
  const section=reading.detailedSections.find(s=>s.id===sectionId);
  if(!section?.chartBasis||claimIds.length!==section.chartBasis.paragraphs.length||claimIds.some((id,i)=>claims.find(c=>c.claimId===id)?.text!==section.chartBasis.paragraphs[i]))fail('CLAIM_BASIS_PARAGRAPH_DRIFT');
  return {sectionId,paragraphs:claimIds.map((id,i)=>({paragraph:i+1,claimIds:[id]}))};
 });
 const ledger={schemaVersion:CLAIM_LEDGER_VERSION,status:reading.reportPlan?'internal-contract-active; source-bounded-projection':'internal-contract-active; customer-prose-unchanged',snapshotRef:{schemaVersion:snapshot.schemaVersion,ruleVersion:snapshot.ruleVersion,methodVersion:snapshot.methodVersion,engineVersion:snapshot.engineVersion,timeZoneVersion:snapshot.timeZoneVersion,chart:JSON.parse(JSON.stringify(snapshot.chart))},
  facts:c.facts.map(f=>({factId:f.factId,originPosition:origin(f),originPositions:origins(f),comparisonDependencies:unique(f.positions),sourceRefs:unique(f.sourceRefs)})),claims:claims.sort((a,b)=>a.claimId.localeCompare(b.claimId,'en')),cardGates:gates,paragraphLinks,freeParagraphLinks,basisParagraphLinks,previewClaimIds,
  context:{probeClaimIds:probes.map(p=>'observation.'+p.ruleId),methodClaimIds:ORDINARY_REVIEW_CARDS.map(d=>'method.'+d.id),conflictIds:unique(snapshot.reconciled.conflicts.map(f=>f.id)),formalVerdicts:{strength:null,formation:null,usefulElement:null},traditionalPrecedence:'not-established; no scores or inferred ranking',
   selectedInterpretationProfile:reading.interpretationProfile?{id:reading.interpretationProfile.profileId,version:reading.interpretationProfile.profileVersion,branchId:reading.interpretationProfile.branchId,status:reading.interpretationProfile.status}:null,
   ...(reading.reportPlan?.sourceBoundedDomainDecisions?.length?{sourceBoundedDomainDecisions:reading.reportPlan.sourceBoundedDomainDecisions}:{}),
   ...(reading.rootSupportAssessment?{rootSupportAssessment:reading.rootSupportAssessment}:{}),
   ...(reading.officerChain?{officerChain:reading.officerChain}:{}),
   ...(reading.lifeRouteReview?{lifeRouteReview:reading.lifeRouteReview}:{}),
   culturalReading:reading.reportPlan?.culturalReading?{ruleId:reading.reportPlan.culturalReading.ruleId,status:reading.reportPlan.culturalReading.status}:null},
  decisionLedger:reading.selectionLedger.map(l=>({domain:l.domain,selected:unique(l.selected),reason:l.reason,importanceRanking:false})),customerInferenceChanged:!!reading.reportPlan,
  traditionalInferenceActivated:reading.interpretationProfile?.status==='entry-established',traditionalInferenceScope:reading.interpretationProfile?.status==='entry-established'?(reading.reportPlan?.culturalReading?.status==='supported-cultural-structure'?'declared-entry-and-bounded-cultural-reading':'declared-month-pattern-entry-only'):null,
  reportPlanVersion:reading.reportPlan?.version??null,customerProjectionChanged:!!reading.reportPlan};
 validateClaimLedger(ledger);bound.set(ledger,snapshot);return freeze(ledger);
}
export function assertClaimLedgerSource(ledger,snapshot){if(bound.get(ledger)!==snapshot)fail('CLAIM_LEDGER_SOURCE_MISMATCH');return true;}
export function claimLedgerReplayText(ledger){return canonical(ledger);}
export function validateClaimLedger(ledger){
 if(ledger?.schemaVersion!==CLAIM_LEDGER_VERSION||!Array.isArray(ledger.claims)||!Array.isArray(ledger.facts))fail('CLAIM_LEDGER_REQUIRED');
 const facts=new Map(ledger.facts.map(f=>[f.factId,f])),ids=new Set(ledger.claims.map(c=>c.claimId));
 if(facts.size!==ledger.facts.length||ids.size!==ledger.claims.length)fail('CLAIM_ID_DUPLICATE');
 const profile=ledger.context?.selectedInterpretationProfile;
 if(profile&&(profile.id!==ZP_PROFILE_ID||profile.version!==ZP_PROFILE_VERSION||!ZP_BRANCH_IDS.includes(profile.branchId)||!['entry-established','input-insufficient','outside-implemented-branch'].includes(profile.status)))fail('CLAIM_PROFILE_UNSUPPORTED');
 if(profile?.status==='entry-established'&&(ledger.snapshotRef.chart.pillars.month?.[1]!==({[ZP_BRANCH_ID]:'酉',[ZP_YI_BRANCH_ID]:'酉',[ZP_JIA_YIN_BRANCH_ID]:'寅'}[profile.branchId])||ledger.snapshotRef.chart.pillars.day?.[0]!==({[ZP_BRANCH_ID]:'甲',[ZP_YI_BRANCH_ID]:'乙',[ZP_JIA_YIN_BRANCH_ID]:'甲'}[profile.branchId])))fail('CLAIM_PROFILE_BRANCH_DRIFT');
 if(Boolean(ledger.traditionalInferenceActivated)!==(profile?.status==='entry-established'))fail('CLAIM_PROFILE_ACTIVATION_SCOPE');
 const activeCultural=ledger.context?.culturalReading?.status==='supported-cultural-structure';
 const culturalContracts={'Jade-ZP-YiYou-ConditionalSupport-v1':{branch:ZP_YI_BRANCH_ID,source:'ZP-YI-RESOURCE-ROUTE'},'Jade-ZP-N10-AimsMeans-v1':{componentContract:'Jade-ZP-N10-Qualitative-v1',source:'C-ZP-MONTH-PEER-CONDITIONS'},'Jade-ZP-JiaYou-CombineRival-v1':{branch:ZP_BRANCH_ID,source:'ZP-OFFICER-CLEARING-PAIR',requiresOfficerChain:true},'Jade-ZP-JiaYin-CompetingRootContext-v1':{branch:ZP_JIA_YIN_BRANCH_ID,source:'ZP-JIA-YIN-EXPRESSION',requiresOriginalRouteWithheld:true},'Jade-ZP-JiaYin-RootedExpression-v1':{branch:ZP_JIA_YIN_BRANCH_ID,source:'ZP-JIA-YIN-EXPRESSION'},'Jade-ZP-two-supports-cultural-reading-v1':{branch:ZP_BRANCH_ID,source:'ZP-OFFICER-TWO-SUPPORTS'},'Jade-ZP-Yi-ObservedRootContext-v1':{branch:ZP_YI_BRANCH_ID,source:'ZP-ROOT-VS-PEERS'},'Jade-ZP-Yi-ObservedRootContext-v2':{branch:ZP_YI_BRANCH_ID,source:'ZP-ROOT-VS-PEERS'}};
 const culturalContract=culturalContracts[ledger.context?.culturalReading?.ruleId];
 const chart=ledger.snapshotRef.chart,p=chart.pillars;
 // This bounded component is not a spoofed Jia/You month-profile activation.
 const n10Scope=culturalContract?.componentContract==='Jade-ZP-N10-Qualitative-v1'&&p.year==='庚午'&&p.month==='丁亥'&&p.day==='癸未'&&!chart.nearSolarBoundary&&((p.hour==='丙辰'&&chart.status==='calculated')||(p.hour==null&&chart.status==='incomplete-time'))&&ledger.context.sourceBoundedDomainDecisions?.some(d=>d.ruleId==='Jade-ZP-N10-AimsMeans-v1'&&d.domain==='money'&&d.traditionalFormation===false&&d.incomePrediction===false);
 if(activeCultural&&(!culturalContract||(culturalContract.componentContract?!n10Scope:profile?.branchId!==culturalContract.branch)))fail('CLAIM_CULTURAL_SCOPE_INVALID');
 if(ledger.traditionalInferenceActivated&&(!profile||profile.status!=='entry-established'||ledger.traditionalInferenceScope!==(activeCultural?'declared-entry-and-bounded-cultural-reading':'declared-month-pattern-entry-only')))fail('CLAIM_PROFILE_ACTIVATION_SCOPE');
 const layers=new Set(['calculated-fact','structural-observation','structural-context','traditional-method-interpretation','traditional-cultural-interpretation','modern-reflection','modern-composition','editorial-synthesis','coverage-or-education']);
 for(const claim of ledger.claims){
  if(typeof claim.claimId!=='string'||!claim.claimId||!layers.has(claim.layer)||typeof claim.status!=='string'||!claim.conditions||!Array.isArray(claim.unknown)||claim.unknown.some(p=>!positions.includes(p))||!Array.isArray(claim.factRefs)||(!Array.isArray(claim.sources)&&!claim.sourceExplanation))fail('CLAIM_RECORD_INVALID');
  if(claim.publication?.eligibleForPublic!==false||claim.publication?.purchasable!==false||claim.publication?.professionalReview!=='pending'||(claim.layer==='traditional-method-interpretation'&&claim.status!=='HOLD'))fail('CLAIM_UNREVIEWED_ACTIVATION');
  if(claim.layer==='traditional-cultural-interpretation'&&(!activeCultural||(profile?.status!=='entry-established'&&!n10Scope)||claim.status!=='private-source-bounded-cultural-interpretation'||claim.conditions.formalVerdict!==false||!claim.sources.some(s=>s.id===culturalContract?.source)))fail('CLAIM_CULTURAL_SCOPE_INVALID');
  if(claim.claimId.startsWith('culture.Jade-ZP-YiYou-ConditionalSupport-v1.')&&(p.year!=='己亥'||p.month!=='癸酉'||p.day!=='乙亥'||!((p.hour==='戊寅'&&chart.status==='calculated')||(p.hour==null&&chart.status==='incomplete-time'))||claim.conditions.contractId!=='Jade-ZP-YiYou-ConditionalSupport-v1'||claim.conditions.wholeChartExclusion!==false||claim.conditions.sourceExampleSharedMonthEstablished!==false||claim.conditions.effectiveSupport!==null||claim.conditions.formation!==null||claim.conditions.overallStrength!==null))fail('CLAIM_YI_SUPPORT_QUALITATIVE_SCOPE');
  if(n10Scope&&claim.claimId.startsWith('culture.Jade-ZP-N10-AimsMeans-v1.')&&(claim.conditions.contractId!=='Jade-ZP-N10-Qualitative-v1'||canonical(claim.conditions.decisionIds)!==canonical(['NQ1','NQ2','NQ3','NQ4','NQ5'])||claim.conditions.wholeChartExclusionMade!==false||claim.conditions.narrowExceptionApplied!==false||claim.conditions.hiddenExpressionMeansLackOfAbility!==false||claim.conditions.effectiveMediation!==null||claim.conditions.formedPattern!==null||claim.conditions.overallStrength!==null))fail('CLAIM_N10_QUALITATIVE_SCOPE');
  if(claim.conditions.applicationVersion==='Jade-ZP-N03-LearningThreeWay-v1'&&(p.year!=='癸亥'||p.month!=='乙卯'||p.day!=='丙午'||p.hour!=='戊戌'||chart.status!=='calculated'||chart.nearSolarBoundary||claim.conditions.qualitativeContract!=='Jade-ZP-N03-LearningQualitative-v1'||claim.conditions.traditionalInferenceApproved!==false||['formalPrintRoute','overallStrength','effectiveCombination','academicOutcome'].some(k=>claim.conditions[k]!==null)||!['modern-reflection','structural-observation','editorial-synthesis'].includes(claim.layer)||!claim.sources.some(s=>s.id==='C-ZP-PRINT-LEARNING-CONTEXT')))fail('CLAIM_N03_QUALITATIVE_SCOPE');
  if(claim.layer==='traditional-cultural-interpretation'&&culturalContract?.requiresOriginalRouteWithheld&&claim.conditions.originalExpressionRoute!=='withheld-known-context')fail('CLAIM_CULTURAL_ORIGINAL_ROUTE_SCOPE');
  if(claim.layer==='traditional-cultural-interpretation'&&culturalContract?.requiresOfficerChain&&(!ledger.context.officerChain?.roleLinks||claim.conditions.localChainState!==ledger.context.officerChain.state||claim.conditions.sourceListedLocalRoleOnly!==true||claim.conditions.formation!==null||claim.conditions.wholeChartCleared!==false||canonical(claim.conditions.openContext)!==canonical(ledger.context.officerChain.openContext)))fail('CLAIM_OFFICER_CHAIN_SCOPE_INVALID');
  for(const ref of [...(claim.factRefs??[]),...(claim.counterFactRefs??[])]){const fact=facts.get(ref.factId);if(!fact||fact.originPosition!==ref.originPosition||canonical(fact.originPositions)!==canonical(ref.originPositions)||canonical(fact.comparisonDependencies)!==canonical(ref.comparisonDependencies)||canonical(fact.sourceRefs)!==canonical(ref.sourceRefs))fail('CLAIM_FACT_REFERENCE_DRIFT');}
 }
 for(const rows of [ledger.paragraphLinks,ledger.freeParagraphLinks,ledger.basisParagraphLinks]){
  const primary=new Set();for(const row of rows??[])for(const p of row.paragraphs)for(const id of p.claimIds){if(!ids.has(id))fail('CLAIM_PARAGRAPH_REFERENCE_UNKNOWN');if(p.use!=='reference'){if(primary.has(id))fail('CLAIM_DUPLICATE_PRIMARY');primary.add(id);}}
 }
 if((ledger.previewClaimIds??[]).some(id=>!ids.has(id)))fail('CLAIM_PREVIEW_REFERENCE_UNKNOWN');return true;
}
