/** Declared bounded month-pattern entries over one bound snapshot. No calendar calls. */
import {evaluateJiaYinEntry} from './ziping-jia-yin-core.js';
import {evaluateYiYouEntry} from './ziping-yi-you-entry.js';
import {reviewZipingRescueCandidates} from './ziping-rescue-review.js';
import {assertClaimLedgerSource} from './claim-ledger.js';
import {ZP_PROFILE_ID,ZP_PROFILE_VERSION,ZP_BRANCH_ID,ZP_YI_BRANCH_ID} from './ziping-profile-sources.js';
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const unique=a=>[...new Set(a)].sort(),positions=['year','month','day','hour'];
const englishList=a=>a.length<2?a[0]??'':a.length===2?a.join(' and '):a.slice(0,-1).join(', ')+', and '+a.at(-1);
const fail=code=>{throw new RangeError(code);};
const profileSources=new WeakMap();
export function assertZipingProfileSource(profile,snapshot){if(profileSources.get(profile)!==snapshot)fail('ZP_PROFILE_SOURCE_IDENTITY_MISMATCH');}
export const ZP_METHOD_PROFILE=freeze({id:ZP_PROFILE_ID,version:ZP_PROFILE_VERSION,branchId:ZP_BRANCH_ID,
 priority:['approved main-text whitelist','main-text cross-chapter comparison','separate Xu commentary','declared product conventions'],
 calculationCompatibility:{methodVersion:'civil-clock-sect2-utc8-terms-v1',engineVersion:'lunar-typescript-1.8.6',timeZoneVersion:'2026e',ruleVersion:'jm-foundation-probe-v2'},
 scope:'stable Jia/You, Yi/You and declared Jia/Yin rooted-expression entries; no complete formation verdict',
 branches:[{id:ZP_BRANCH_ID,dayStem:'甲',monthBranch:'酉',category:'正官'},{id:ZP_YI_BRANCH_ID,dayStem:'乙',monthBranch:'酉',category:'七杀'},{id:'Jia-Yin-rooted-expression-entry-v1',dayStem:'甲',monthBranch:'寅',category:'建禄'}],
 operationalScreens:{gengDing:'known visible and hidden stems, separately identified',bingXin:'existing visible-stem pair facts only',
  youMonthPairs:{'卯':'opposition-review','辰':'combination-review','酉':'repetition-punishment-review','子':'break-review-convention','戌':'harm-review-convention'},
  meetingMembers:'known Si/You/Chou members only, following the selected chapter usage; no seasonal directional-group system added; membership never proves formation/transformation',
  origin:'conservative product screen, not an exhaustive quoted classical rule'},
 excludes:['automatic formation/damage/rescue','strength scores','favorable-element supplementation','personality/relationship/wealth events','calendar-policy changes'],
 commentaryPolicy:'contrast record only; no commentary rule merged into the entry',sourceVariantPolicy:'retain 戊甲/戊申; 戊申 is a parallel-passage reading candidate, not a birth gold standard',
 transmissionVariants:{rawChapter31:['壬戌','丁未','戊甲','乙卯'],parallelChapter32:['壬戌','丁未','戊申','乙卯'],normalizationApproved:false,birthGoldStandard:false}});
const origin=f=>/^(?:visible|hidden)-relationship:(year|month|day|hour)(?::\d+)?$/.exec(f.factId)?.[1];
export function evaluateZipingMonthProfile(snapshot,ledger){
 assertClaimLedgerSource(ledger,snapshot);
 for(const[k,v]of Object.entries(ZP_METHOD_PROFILE.calculationCompatibility))if(snapshot[k]!==v||(k!=='ruleVersion'&&snapshot.chart[k]!==v))fail('ZP_PROFILE_CALCULATION_POLICY_MISMATCH');
 const chart=snapshot.chart,pillars=chart.pillars,facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f]));
 const missing=positions.filter(p=>pillars[p]==null),knownExposurePositions=['year','month','hour'].filter(p=>pillars[p]),day=pillars.day?.[0],month=pillars.month?.[1];
 if(day==='甲'&&month==='寅'){const result=freeze(evaluateJiaYinEntry(snapshot,ZP_METHOD_PROFILE));profileSources.set(result,snapshot);return result;}
 if(day==='乙'&&month==='酉'){const result=freeze(evaluateYiYouEntry(snapshot,ledger,ZP_METHOD_PROFILE));profileSources.set(result,snapshot);return result;}
 const status=!day||!month?'input-insufficient':day==='甲'&&month==='酉'?'entry-established':'outside-implemented-branch';
 const paragraphs=[],visibleXin=[],contexts=[];
 const add=(id,text,evidenceIds=[],sourceRefs=['ZP-MONTH-START'],kind='framework-scope')=>paragraphs.push({id,text,evidenceIds:unique(evidenceIds),sourceRefs:unique(sourceRefs),kind});
 add('framework','The traditional structure check follows the approach in Zi Ping Zhen Quan that starts with the birth month. Source-bounded cultural interpretations and modern editorial reflections are identified separately; this limited check does not establish a complete pattern.');
 let entry=null;
 if(status==='input-insufficient')add('unresolved','The day or month reference is unresolved, so this branch has not been selected from one of the possible charts. No missing reference has been filled in.');
 else if(status==='outside-implemented-branch')add('outside','The day/month starting check described here covers Jia or Yi day references in a You month. This chart is outside that check; any separately supported supplement is identified in its own section. No pattern or favorable element has been substituted.');
 else{
  const hidden=byId.get('hidden:month'),relationship=byId.get('hidden-relationship:month:0'),principal=byId.get('month-relation:principal');
  if(hidden?.value.branch!=='酉'||hidden.value.stems.length!==1||hidden.value.stems[0]!=='辛'||relationship?.value.stem!=='辛'||relationship.value.relation.label!=='正官'||principal?.value.stem!=='辛'||principal.value.relation.label!=='正官')fail('ZP_PROFILE_MONTH_FACT_DRIFT');
  const entryFacts=[hidden.factId,relationship.factId,principal.factId];
  entry={status:'supported-entry-in-declared-framework',dayStem:'甲',monthBranch:'酉',monthHiddenStem:'辛',category:'正官',evidenceIds:entryFacts,
   sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.month[1]','snapshot.derived.facts[factId=hidden:month].value.stems[0]'],
   patternReferenceMeaning:'month-led category to examine, not an element to supplement',formedPattern:null};
  add('entry','In this month-led reading, the chart begins with Zheng Guan, the traditional category concerned with order and responsibility. This sets a starting point for analysis; it does not establish a complete or successful pattern, or a personal trait.',entryFacts,['ZP-MONTH-START','ZP-JIA-YOU-ENTRY'],'declared-framework-entry');
  add('entry-basis','The recorded day and month establish this starting point. The rule compares the month’s underlying symbol with the day reference; it does not choose a category by counting elements.',entryFacts,['ZP-JIA-YOU-ENTRY','S-HIDDEN','S-TEN'],'calculated-fact-context');
  for(const p of knownExposurePositions){
   const f=byId.get('visible-relationship:'+p);
   if(pillars[p][0]==='辛'){
    const exposure=byId.get('month-exposure:'+p);if(f?.value.otherStem!=='辛'||f.value.label!=='正官'||exposure?.value.stem!=='辛')fail('ZP_PROFILE_EXPOSURE_DRIFT');
    visibleXin.push({position:p,evidenceIds:[f.factId,exposure.factId],sourcePaths:['snapshot.chart.pillars.'+p+'[0]','snapshot.derived.facts[factId='+f.factId+']']});
   }
  }
  if(visibleXin.length)add('exposure','The same reference is visible in the '+englishList(visibleXin.map(x=>x.position))+' part'+(visibleXin.length===1?'':'s')+' of the chart. '+(visibleXin.length===1?'This is an additional recorded appearance':'These are additional recorded appearances')+', not proof of overall strength or a successful pattern.',visibleXin.flatMap(x=>x.evidenceIds),['ZP-EXPOSED-CONTEXT','S-TEN'],'calculated-fact-context');
  else add('exposure','No separate appearance of that reference is shown in the known '+englishList(knownExposurePositions)+' parts of the chart. '+(missing.length?'The unresolved parts have not been treated as absences.':'This is a check of the visible symbols, not a judgment of the whole chart.'),[],['ZP-EXPOSED-CONTEXT'],'known-position-scope');
  const relationFacts=facts.filter(f=>['visible-relationship','hidden-relationship'].includes(f.kind)).sort((a,b)=>a.factId.localeCompare(b.factId,'en'));
  for(const f of relationFacts){const stem=f.kind==='hidden-relationship'?f.value.stem:f.value.otherStem;if(!['庚','丁'].includes(stem))continue;
   const p=origin(f),visibility=f.kind==='hidden-relationship'?'hidden':'visible';if(!p||!pillars[p])fail('ZP_PROFILE_SOURCE_POSITION_DRIFT');
   contexts.push({id:'stem:'+f.factId,kind:stem==='庚'?'geng-review':'ding-review',positions:[p],visibility,stem,evidenceIds:[f.factId],
    sourcePaths:['snapshot.derived.facts[factId='+f.factId+']'],text:(stem==='庚'?'Geng':'Ding')+' is '+visibility+' in the '+p+' position.'});
  }
  for(const f of facts.filter(f=>f.kind==='stem-combination'&&f.value.includes('丙')&&f.value.includes('辛')).sort((a,b)=>a.factId.localeCompare(b.factId,'en')))
   contexts.push({id:f.factId,kind:'bing-xin-pair-review',positions:f.positions,evidenceIds:[f.factId],sourcePaths:['snapshot.derived.facts[factId='+f.factId+']'],text:'A Bing–Xin table pair is recorded between the '+f.positions.join(' and ')+' positions.'});
  for(const p of ['year','day','hour'].filter(p=>pillars[p])){
   const other=pillars[p][1],kind=ZP_METHOD_PROFILE.operationalScreens.youMonthPairs[other];if(!kind)continue;
   const wording={卯:'Mao (卯), the listed opposition partner of You',辰:'Chen (辰), the listed pairing partner of You',酉:'You (酉), repeating the month branch',子:'Zi (子), retained in the conservative additional-context check',戌:'Xu (戌), retained in the conservative additional-context check'};
   contexts.push({id:'month-context:'+p,kind,positions:['month',p],evidenceIds:['hidden:month','hidden:'+p],sourcePaths:['snapshot.chart.pillars.month[1]','snapshot.chart.pillars.'+p+'[1]'],
    text:'The '+p+' branch is '+wording[other]+'.'});
  }
  const members=['year','day','hour'].filter(p=>pillars[p]&&['巳','丑'].includes(pillars[p][1]));
  if(members.length)contexts.push({id:'month-group-members',kind:'si-you-chou-members-review',positions:['month',...members],
   evidenceIds:['hidden:month',...members.map(p=>'hidden:'+p)],sourcePaths:['month',...members].map(p=>'snapshot.chart.pillars.'+p+'[1]'),
   completeMemberSet:members.some(p=>pillars[p][1]==='巳')&&members.some(p=>pillars[p][1]==='丑'),text:'Known branches contain Si/You/Chou group members. Membership is not a formed group or transformation.'});
  const contextReader=[];
  for(const[k,label]of [['geng-review','Another authority-related symbol'],['ding-review','An expression-related symbol']]){
   const matched=contexts.filter(c=>c.kind===k),where=positions.filter(p=>matched.some(c=>c.positions.includes(p)));
   if(where.length)contextReader.push(label+' is recorded in the known '+englishList(where)+' part'+(where.length===1?'':'s')+' of the chart.');
  }
  for(const c of contexts.filter(c=>c.kind==='bing-xin-pair-review'))contextReader.push('A recorded pairing involving the starting reference connects the '+englishList(c.positions)+' parts.');
  const branchContexts=contexts.filter(c=>c.id.startsWith('month-context:'));
  if(branchContexts.length)contextReader.push('The month also has listed branch relationships with the '+englishList(positions.filter(p=>p!=='month'&&branchContexts.some(c=>c.positions.includes(p))))+' part'+(branchContexts.length===1?'':'s')+' of the chart.');
  if(contexts.some(c=>c.kind==='si-you-chou-members-review'))contextReader.push('Some known branches are also checked together as members of a traditional group; their presence alone does not establish a working group or transformation.');
  if(contexts.length)add('context',contextReader.join(' ')+' These observations require context. They are not automatically read as a conflict, a damaged pattern or a transformation.',contexts.flatMap(c=>c.evidenceIds),['ZP-OPS-CONTEXT-v1',...(contexts.some(c=>c.kind==='opposition-review')?['ZP-YOU-CLASH']:[])],'product-context-observation');
  else if(!missing.length)add('context','None of the listed review conditions appears in the four recorded positions. This limited check does not establish that the whole chart is pure or free of other conditions.',facts.filter(f=>['hidden','visible-relationship'].includes(f.kind)).map(f=>f.factId),['ZP-OPS-CONTEXT-v1'],'product-scope-exclusion');
  else add('context','No listed review condition is shown in the known positions checked here. Unresolved positions remain open, so no whole-chart exclusion is made.',[],['ZP-OPS-CONTEXT-v1'],'incomplete-input-scope');
  if(missing.length)add('partial','The '+missing.join(' and ')+' position is unresolved. The stable day/month entry and known appearances remain available; the missing information may add context and is not guessed.',entryFacts,['ZP-OPS-CONTEXT-v1'],'incomplete-input-scope');
 }
 add('limits','In this branch, pattern formation, strength, climate adjustment and a favorable-element recommendation remain undetermined. A pattern reference is not an instruction to add an element, and it does not predict a career, relationship or financial outcome.',[],['ZP-OFFICER-CONDITIONS'],'framework-limit');
 const result=freeze({profileId:ZP_PROFILE_ID,profileVersion:ZP_METHOD_PROFILE.version,branchId:ZP_METHOD_PROFILE.branchId,status,
  calculationPolicy:{...ZP_METHOD_PROFILE.calculationCompatibility},missingPositions:missing,knownExposurePositions,entry,visibleXin,contexts,paragraphs,
  operationalScreens:ZP_METHOD_PROFILE.operationalScreens,rescueReview:reviewZipingRescueCandidates(snapshot,status),wholeChartExclusionMade:false,
  verdicts:{formation:null,strength:null,usefulElement:null,climate:null},eligibleForPublic:false,purchasable:false,
  review:'owner-selected limited framework; internal verification, no external master certification or scientific prediction claim'});
 profileSources.set(result,snapshot);return result;
}
