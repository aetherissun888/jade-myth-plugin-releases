/** Editorial selection over already-matched facts, never a strength calculation.
 * Implements original plan §5: explicit conditions first; preserve unresolved
 * differences. Source order, counts, hashes and numerical weights select nothing.
 */
export const SELECTION_VERSION='jm-reading-selection-v1';
const fail=code=>{throw new RangeError(code);};
const sorted=a=>[...a].sort((x,y)=>x.entryId.localeCompare(y.entryId,'en'));
// positions contains dependencies, including the reference day. A positional
// predicate must inspect the fact's source position, not any dependency.
export function readingSelectorMatches(f,q){
 if(f.kind!==q.kind)return false;
 const relation=f.kind==='hidden-relationship'?f.value.relation:f.value;
 const origin=/^(?:visible|hidden)-relationship:(year|month|day|hour)(?::\d+)?$/.exec(f.factId)?.[1];
 return relation?.family===q.family&&(!q.label||relation?.label===q.label)&&(!q.position||origin===q.position);
}
// A implies B only if every predicate required by B is entailed by a predicate
// in A. Label/position restrictions refine a selector; another family does not.
export function selectorsImply(a,b){
 return b.every(q=>a.some(p=>p.kind===q.kind&&p.family===q.family&&(!q.label||p.label===q.label)&&(!q.position||p.position===q.position)));
}
export function selectReadingThemes(entries,definitions,compositions){
 const defs=new Map(definitions.map(d=>[d.id,d])),ledger=[],selected=[];
 if(defs.size!==definitions.length||new Set(entries.map(e=>e.entryId)).size!==entries.length)fail('DUPLICATE_SELECTION_ENTRY');
 const order=['work','learning','money','relationships','collaboration'];
 if(entries.some(e=>!defs.has(e.entryId)||!order.includes(e.domain)))fail('UNDEFINED_SELECTION_ENTRY');
 for(const domain of order){
  const eligible=sorted(entries.filter(e=>e.domain===domain&&e.status==='private-editorial-candidate'));
  const record={domain,matched:eligible.map(e=>e.entryId),superseded:[],selected:[],reason:'no-supported-card',policyVersion:SELECTION_VERSION,importanceRanking:false};
  let remaining=eligible.filter(b=>{
   const override=eligible.find(a=>a!==b&&defs.get(a.entryId).refines?.includes(b.entryId));
   if(!override)return true;
   const ad=defs.get(override.entryId),bd=defs.get(b.entryId);
   if(!ad.question||ad.question!==bd.question||!selectorsImply(override.selectors,b.selectors)||selectorsImply(b.selectors,override.selectors))fail('UNPROVEN_PRECEDENCE');
   record.superseded.push({entryId:b.entryId,by:override.entryId,reason:'declared-same-question-strict-predicate-refinement'});return false;
  });
  const contradictory=remaining.flatMap(a=>remaining.filter(b=>a.entryId<b.entryId&&(defs.get(a.entryId).conflictsWith?.includes(b.entryId)||defs.get(b.entryId).conflictsWith?.includes(a.entryId))).map(b=>[a.entryId,b.entryId]));
  if(contradictory.length){record.reason='unresolved-explicit-conflict';record.conflicts=contradictory;ledger.push(record);continue;}
  if(remaining.length===1){record.selected=[remaining[0].entryId];record.outputId=remaining[0].entryId;record.reason=record.superseded.length?'proven-specificity':'only-supported-question';selected.push({...remaining[0],memberIds:record.selected});}
  else if(remaining.length>1){
   const ids=remaining.map(e=>e.entryId);
   // Exact declared sets only. An unhandled combination stays unresolved; do
   // not manufacture a winner from declaration order or print every paragraph.
   const matches=compositions.filter(c=>c.domain===domain&&c.members.length===ids.length&&c.members.every(id=>ids.includes(id)));
   if(matches.length!==1){record.reason='unreviewed-composition';record.pendingCombination=ids;ledger.push(record);continue;}
   const recipe=matches[0],byId=new Map(remaining.map(e=>[e.entryId,e]));
   const rendered=recipe.fragments.flatMap(({member,index,counter})=>{const entry=byId.get(member);if(counter){return entry?.counterEvidenceIds.length?[entry.paragraphs.at(-1)]:[];}const p=entry?.paragraphs[index];if(typeof p!=='string')fail('COMPOSITION_FRAGMENT_UNAVAILABLE');return [p];});
   const combine=key=>[...new Set(remaining.flatMap(e=>e[key]??[]))];
   selected.push({entryId:recipe.id,domain,title:recipe.title,memberIds:ids,paragraphs:[recipe.lead,...rendered],selectors:remaining.flatMap(e=>e.selectors),evidenceIds:combine('evidenceIds'),counterEvidenceIds:combine('counterEvidenceIds'),fieldDependencies:combine('fieldDependencies'),sourceRefs:combine('sourceRefs'),counterConditions:remaining.map(e=>e.counterCondition),interpretationBoundary:recipe.rationale,reviewStatus:'pending',status:'private-editorial-candidate'});
   record.selected=ids;record.outputId=recipe.id;record.reason='declared-compatible-questions';record.compositionId=recipe.id;record.compatibilityRationale=recipe.rationale;record.fragments=recipe.fragments;
  }
  ledger.push(record);
 }
 return {policyVersion:SELECTION_VERSION,selected,ledger};
}
