/** One declared Zi Ping route over retained facts; no calendar or strength engine. */
export const JIA_YIN_BRANCH='Jia-Yin-rooted-expression-entry-v1';
export const JIA_YIN_RULE='Jade-ZP-JiaYin-RootedExpression-v1';
export const JIA_YIN_SECTION='reading-rooted-expression';
const positions=['year','month','day','hour'],unique=a=>[...new Set(a)].sort();
const sourceRefs=['ZP-JIA-YIN-EXPRESSION','ZP-MONTH-START'];
export function evaluateJiaYinEntry(snapshot,common){
 const chart=snapshot.chart,p=chart.pillars,facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f]));
 const missing=positions.filter(k=>!p[k]),entryIds=['hidden:month','hidden-relationship:month:0','month-relation:principal'];
 const entry={status:'supported-entry-in-declared-framework',dayStem:'甲',monthBranch:'寅',monthHiddenStem:'甲',category:'建禄',evidenceIds:entryIds,sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.month[1]',...entryIds.map(id=>'snapshot.derived.facts[factId='+id+']')],formedPattern:null,patternReferenceMeaning:'month-led starting point; no formation or strength verdict'};
 const base={profileId:common.id,profileVersion:common.version,branchId:JIA_YIN_BRANCH,status:'entry-established',calculationPolicy:{...common.calculationCompatibility},missingPositions:missing,knownExposurePositions:positions.filter(k=>k!=='day'&&p[k]),entry,visibleXin:[],contexts:[],verdicts:{formation:null,strength:null,usefulElement:null,climate:null},wholeChartExclusionMade:false,eligibleForPublic:false,purchasable:false};
 const paragraphs=[{id:'framework',text:'This part of the selected Zi Ping method considers how a springtime foundation connects with outward expression. It is a particular route through the chart, not a complete assessment of every pattern.',evidenceIds:entryIds,sourceRefs,kind:'declared-framework-entry'}];
 const finish=(status,requires=[],counterEvidenceIds=[],reason=null)=>({...base,paragraphs,coreRoute:{ruleId:JIA_YIN_RULE,status,evidenceIds:unique(requires),counterEvidenceIds:unique(counterEvidenceIds),reason,sourceRefs,methodBoundary:'declared source-bounded cultural route, not sufficient conditions for a formed pattern',effectiveRoots:null,overallStrength:null,formedPattern:null},reportScope:{status,bodyNotice:status==='supported-cultural-structure'?'This cultural reading connects an observed foundation with expression. It does not settle overall strength, a completed pattern, favorable elements or a destined occupation.':'The starting point is known, but this particular traditional expression route has not been established from the available conditions.',coverageNotice:'Traditional chart interpretation — A springtime starting point is identified; the expression route is included only when its declared conditions are established.'}});
 if(p.day?.[0]!=='甲'||p.month?.[1]!=='寅')throw new RangeError('JIA_YIN_ENTRY_MISMATCH');
 if(entryIds.some(id=>!byId.has(id)))return finish('evidence-incomplete',[],[],'entry-fact-missing');
 if(byId.get('hidden:month').value.stems[0]!=='甲'||byId.get('month-relation:principal').value.relation?.label!=='比肩')throw new RangeError('JIA_YIN_MONTH_FACT_DRIFT');
 if(missing.length||chart.nearSolarBoundary)return finish('input-insufficient',entryIds,[],missing.length?'unresolved-position':'near-solar-boundary');
 if(p.month[0]!=='丙'||p.hour!=='丙寅')return finish('not-established',entryIds,[],'declared-visible-route-not-present');
 // Every known source position must be intact before any absence is used.
 const inventory=[],needed=[...entryIds,'exact-root:month','exact-root:hour','month-exposure:month','month-exposure:hour'];
 for(const k of positions){
  const h=byId.get('hidden:'+k);needed.push('hidden:'+k);
  if(!h)return finish('evidence-incomplete',entryIds,[],'known-hidden-inventory-missing');
  if(h.value.branch!==p[k][1])throw new RangeError('JIA_YIN_SOURCE_POSITION_DRIFT');
  if(k!=='day'){
   const id='visible-relationship:'+k,f=byId.get(id);needed.push(id);
   if(f&&(f.value.dayStem!=='甲'||f.value.otherStem!==p[k][0]))throw new RangeError('JIA_YIN_VISIBLE_SOURCE_DRIFT');
  }
  for(let i=0;i<h.value.stems.length;i++){
   const id='hidden-relationship:'+k+':'+i,f=byId.get(id);needed.push(id);
   if(f&&(f.value.stem!==h.value.stems[i]||f.value.relation.dayStem!=='甲'))throw new RangeError('JIA_YIN_HIDDEN_SOURCE_DRIFT');
  }
 }
 if(needed.some(id=>!byId.has(id)))return finish('evidence-incomplete',entryIds,[],'required-source-fact-missing');
 for(const id of unique(needed)){const f=byId.get(id);if(['visible-relationship','hidden-relationship'].includes(f.kind))inventory.push(f);}
 const visible=inventory.filter(f=>f.kind==='visible-relationship'),hidden=inventory.filter(f=>f.kind==='hidden-relationship'),relation=f=>f.value.relation??f.value;
 const expression=visible.filter(f=>f.value.otherStem==='丙'&&f.value.label==='食神');
 const support=hidden.filter(f=>f.value.relation.family==='resource');
 const declaredCounter=inventory.filter(f=>relation(f).family==='constraint'||(f.kind==='visible-relationship'&&['managed','resource'].includes(relation(f).family))||(f.kind==='visible-relationship'&&relation(f).family==='output'&&f.value.otherStem!=='丙'));
 const rootPositions=positions.filter(k=>p[k][1]==='寅');
 const interactions=facts.filter(f=>(['branch-clash','branch-combination'].includes(f.kind)&&f.positions.some(k=>rootPositions.includes(k)))||(f.kind==='stem-combination'&&f.value.includes('丙')));
 const reviewPositions=positions.filter(k=>['巳','申'].includes(p[k][1]));
 if(declaredCounter.length||interactions.length||reviewPositions.length)return finish('withheld-known-context',needed,[...declaredCounter,...interactions].map(f=>f.factId).concat(reviewPositions.map(k=>'hidden:'+k)),'outside-reviewed-route-conditions');
 if(p.month[0]!=='丙'||p.hour!=='丙寅'||expression.length<2||!support.length)return finish('not-established',needed,[],'required-visible-expression-or-hidden-support-not-established');
 const monthRoot=byId.get('exact-root:month'),hourRoot=byId.get('exact-root:hour');
 if(monthRoot.value.stem!=='甲'||hourRoot.value.stem!=='甲'||byId.get('month-exposure:month').value.stem!=='丙'||byId.get('month-exposure:hour').value.stem!=='丙')throw new RangeError('JIA_YIN_ROOT_EXPOSURE_DRIFT');
 const containedWealth=hidden.filter(f=>f.value.relation.family==='managed');
 paragraphs.push({id:'route',text:'The known chart connects a same-character monthly foothold, openly repeated expression and retained support. These observations select a limited cultural interpretation of rooted expression; they are not a strength score or proof of talent.',evidenceIds:unique(needed),sourceRefs,kind:'calculated-fact-context'});
 const result=finish('supported-cultural-structure',needed);result.coreRoute.conditions={completeRecordedPositions:true,monthRootFact:monthRoot.factId,hourRootFact:hourRoot.factId,visibleExpression:expression.map(f=>f.factId),hiddenSupport:support.map(f=>f.factId),containedMaterialResources:containedWealth.map(f=>f.factId),hiddenWealthTreatedAsAbsent:false,universalNoConflictClaim:false,operationalGuard:'visible wealth/support/other expression or authority at any visibility, root interactions and Si/Shen require separate review; this is a conservative product scope, not a classical necessary-and-sufficient theorem'};return result;
}

// P1–P5 are approved product interpretation decisions, not classical quotations.
export const JIA_YIN_QUALITATIVE_CONTRACT='Jade-ZP-JiaYin-Qualitative-v1';
const decisions={P1:'source-example-bounded-cultural-reading',P2:'local-expression-emphasis-not-global-strength',P3:'retain-hidden-material-resources-not-income',P4:'attributed-conditional-modern-application',P5:'known-scope-provisional-when-hour-unknown'};
function provisionalKnownRoute(snapshot,profile){
 const c=snapshot?.chart,p=c?.pillars;
 if(!p||c.status!=='incomplete-time'||c.nearSolarBoundary||p.hour!=null||!p.year||!p.day||p.day[0]!=='甲'||p.month!=='丙寅'||profile.coreRoute?.status!=='input-insufficient')return null;
 const facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f])),known=positions.filter(k=>p[k]);
 const ids=['hidden:month','hidden-relationship:month:0','month-relation:principal','exact-root:month','month-exposure:month'],inventory=[];
 for(const k of known){
  const h=byId.get('hidden:'+k);if(!h)return null;
  if(h.kind!=='hidden'||h.value.branch!==p[k][1]||h.positions.length!==1||h.positions[0]!==k)throw new RangeError('JIA_YIN_PROVISIONAL_SOURCE_DRIFT');
  ids.push(h.factId);
  for(let i=0;i<h.value.stems.length;i++){
   const f=byId.get('hidden-relationship:'+k+':'+i);if(!f)return null;
   if(f.value.stem!==h.value.stems[i]||f.value.relation.dayStem!=='甲')throw new RangeError('JIA_YIN_PROVISIONAL_RELATION_DRIFT');
   inventory.push(f);ids.push(f.factId);
  }
  if(k!=='day'){
   const f=byId.get('visible-relationship:'+k);if(!f)return null;
   if(f.value.dayStem!=='甲'||f.value.otherStem!==p[k][0])throw new RangeError('JIA_YIN_PROVISIONAL_VISIBLE_DRIFT');
   inventory.push(f);ids.push(f.factId);
  }
 }
 if(ids.some(id=>!byId.has(id)))return null;
 const root=byId.get('exact-root:month'),exposure=byId.get('month-exposure:month');
 if(root.value.stem!=='甲'||root.value.branch!=='寅'||root.value.index!==0||exposure.value.stem!=='丙'||exposure.value.monthBranch!=='寅')throw new RangeError('JIA_YIN_PROVISIONAL_ROOT_DRIFT');
 const family=f=>(f.value.relation??f.value).family;
 if(inventory.some(f=>family(f)==='constraint'||(f.kind==='visible-relationship'&&(['managed','resource'].includes(family(f))||(family(f)==='output'&&f.value.otherStem!=='丙')))))return null;
 if(known.some(k=>['巳','申'].includes(p[k][1]))||facts.some(f=>(['branch-clash','branch-combination'].includes(f.kind)&&f.positions.includes('month'))||(f.kind==='stem-combination'&&f.value.includes('丙'))))return null;
 return {evidenceIds:unique(ids),conditions:{qualitativeContract:JIA_YIN_QUALITATIVE_CONTRACT,interpretationDecisions:decisions,interpretationStatus:'provisional-known-positions',missingPositions:['hour'],wholeChartExclusionMade:false,sourcePaths:unique(ids).map(id=>'snapshot.derived.facts[factId='+id+']'),formalVerdict:false}};
}
export function jiaYinCulturalReading(profile,snapshot){
 const route=profile.coreRoute,provisional=route?.status==='input-insufficient'?provisionalKnownRoute(snapshot,profile):null;
 if(route?.status!=='supported-cultural-structure'&&!provisional)return {ruleId:JIA_YIN_RULE,status:route?.status??'not-established',id:JIA_YIN_SECTION};
 if(provisional)return {id:JIA_YIN_SECTION,ruleId:JIA_YIN_RULE,status:'supported-cultural-structure',kind:'provisional-known-foundation',title:'A possible emphasis on expression',domain:null,
  evidenceIds:provisional.evidenceIds,counterEvidenceIds:[],sourceRefs,conditions:provisional.conditions,
  overview:'A provisional theme in this reading is giving what you understand a form others can see or respond to. Your birth time could change how strongly this theme should guide the reading.',
  freeLayers:['modern-reflection','traditional-cultural-interpretation'],freeParagraphs:[
   'With your birth time unknown, this Zi Ping cultural reading offers a provisional theme: you may find it useful to give what you understand a clear form, through making, explaining or sharing.',
   'The known part of your chart connects a springtime starting point with expression. This supports a possible direction for the reading, but the missing time could add relationships that change its emphasis.'
  ],
  detailedLayers:['traditional-cultural-interpretation','modern-reflection','modern-reflection','structural-context'],detailedParagraphs:[
   'The known part of your chart connects a springtime starting point with expression. In the selected Zi Ping approach, that gives a reason to explore how what has developed can take a clear form. It does not establish the full arrangement in the source example, because your birth time is unknown.',
   'Jade’s modern symbolic application is to distinguish developing an understanding from making it available to others. You may find this theme useful when you know what you mean but have not yet found a form in which to make, explain or share it. The connection is provisional; it is not a finding about your abilities or history.',
   'Two situations call for different responses. If you understand a task but others cannot see the result, a small demonstration can make the idea available for feedback. If the result is already clear but permission, usable resources or agreement is missing, producing more will not settle that obstacle. These are conditional applications of the theme, not circumstances inferred about your life.',
   'The missing birth time may add support or competing relationships that change the emphasis. It does not erase the connection in the known parts, and it does not allow this reading to exclude further conditions. Keep this theme provisional rather than treating it as the chart’s settled direction; overall strength, a completed pattern and future outcomes are not determined here.'
  ],previewParagraphIndex:1,
  previewScope:'Also included: a provisional expression theme based on the known parts of your chart. The detailed view explains its basis and compares two conditional situations; it cannot supply the missing birth time or complete the traditional assessment.',
  basis:'The known Jia day and Bing/Yin month retain a monthly Jia root observation and visible Bing expression. Only recorded year, month and day facts are used. No hour root, repeated hour expression or whole-chart absence is inferred. Jade uses those known connections for a provisional cultural theme; its everyday applications are modern interpretations, not quoted personality findings.',
  reportScope:{status:'provisional-known-positions',bodyNotice:'A possible expression theme is included from the known parts. The unknown birth time may change its emphasis; the complete connected-expression work reading is not established.',coverageNotice:'Traditional chart interpretation — A provisional theme is included. A complete personal work interpretation remains limited by the unknown birth time.'}};
 return {id:JIA_YIN_SECTION,ruleId:JIA_YIN_RULE,status:'supported-cultural-structure',kind:'qualitative-rooted-expression',title:'Turning understanding into expression',domain:'work',evidenceIds:route.evidenceIds,counterEvidenceIds:route.counterEvidenceIds,sourceRefs:route.sourceRefs,
  conditions:{...route.conditions,qualitativeContract:JIA_YIN_QUALITATIVE_CONTRACT,interpretationDecisions:decisions,interpretationStatus:'source-example-bounded',sourcePaths:route.evidenceIds.map(id=>'snapshot.derived.facts[factId='+id+']')},
  overview:'This reading explores how what you have developed can take a form others can see or understand. It gives expression a particular place without treating it as a promise of talent or success.',
  freeLayers:['modern-reflection','traditional-cultural-interpretation'],freeParagraphs:[
   'In this Zi Ping cultural reading, you may feel more engaged when what you understand becomes something you make, explain or share. The central theme is bringing an idea into a clear form, rather than assuming that more preparation is always what it needs.',
   'This emphasis comes from a specific connection in your chart: a rooted springtime image is linked with repeated expression. Jade reads those together as a direction for development, rather than treating each symbol as a separate talent or a promise about your work.'
  ],
  detailedLayers:['traditional-cultural-interpretation','modern-reflection','modern-reflection','modern-reflection','structural-context'],detailedParagraphs:[
   'The selected Zi Ping passage reads this arrangement through the image of spring growth becoming clear through expression. That is why this part of your reading gives priority to making, explaining or sharing what has developed, rather than adding support without asking what it is for. This is the emphasis of this particular reading, not a claim that every part of your life has one purpose.',
   'The relationships are complementary, but they are not interchangeable. What helps something develop is different from what lets it take a form outside yourself. Here, Jade’s modern symbolic interpretation is that understanding can stay private unless it becomes a result, a clear explanation or something another person can respond to. That is a tension between keeping something in reserve and bringing it into view, not a diagnosis that you are hesitant or unproductive.',
   'If you understand a task but others cannot see the result, a small demonstration can be more informative than another round of preparation. A worked example lets you discover whether the idea is clear enough to use. Where the knowledge itself is missing, preparation still matters; the reading does not turn producing more into the answer to every problem.',
   'A different situation arises when you can already show the result but lack permission, usable resources or agreement about what happens next. More output will not settle those conditions. This distinction also keeps expression separate from earning: your chart’s material-resources symbols have not disappeared, but their presence does not establish an income outcome.',
   'The reading changes when another known relationship challenges the same starting point or redirects its expression. An unknown birth time leaves further conditions open. This is a bounded traditional interpretation with an attributed modern application, not a settled judgment of overall strength, a completed pattern or your future.'
  ],previewParagraphIndex:1,
  previewScope:'Also included: an explanation of why this reading emphasizes expression, how its relationships differ, and two conditional situations. It does not supply a completed pattern judgment or an income forecast.',
  basis:'The Jia day and Bing/Yin month/hour match the selected primary passage’s example. Known Jia root observations and Bing expression select this bounded reading; hidden Gui support and Wu material resources remain recorded. The local reading emphasis is Jade’s explicit interpretation choice, not a numerical strength result or whole-chart useful element. Jade’s everyday applications are modern symbolic translations.',
  coverageNotice:'Traditional chart interpretation — A bounded expression-led cultural reading is included. Modern applications are attributed; whole-chart strength, formation and life outcomes remain unassessed.'};
}
