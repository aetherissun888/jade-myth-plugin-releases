/** Second bounded entry in the same month-led profile. Facts only; no calendar or Jia rescue transfer. */
import{assertClaimLedgerSource}from'./claim-ledger.js';
import{ZP_PROFILE_ID,ZP_PROFILE_VERSION,ZP_YI_BRANCH_ID,ZP_BRANCH_ID}from'./ziping-profile-sources.js';
const positions=['year','month','day','hour'],unique=a=>[...new Set(a)].sort();
const list=a=>a.length<2?a[0]??'':a.length===2?a.join(' and '):a.slice(0,-1).join(', ')+', and '+a.at(-1);
const fail=c=>{throw new RangeError(c);};
const origin=f=>/^(?:visible|hidden)-relationship:(year|month|day|hour)(?::\d+)?$/.exec(f.factId)?.[1];
export function evaluateYiYouEntry(snapshot,ledger,common){
 assertClaimLedgerSource(ledger,snapshot);
 const pillars=snapshot.chart.pillars;if(pillars.day?.[0]!=='乙'||pillars.month?.[1]!=='酉')fail('YI_YOU_ENTRY_OUTSIDE_SCOPE');
 const facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f])),h=byId.get('hidden:month'),r=byId.get('hidden-relationship:month:0'),m=byId.get('month-relation:principal');
 if(h?.value.branch!=='酉'||h.value.stems.length!==1||h.value.stems[0]!=='辛'||r?.value.stem!=='辛'||r.value.relation.label!=='七杀'||r.value.relation.family!=='constraint'||m?.value.stem!=='辛'||m.value.relation.label!=='七杀'||m.value.relation.family!=='constraint')fail('YI_YOU_MONTH_FACT_DRIFT');
 const missing=positions.filter(p=>!pillars[p]),knownExposurePositions=['year','month','hour'].filter(p=>pillars[p]),evidenceIds=[h.factId,r.factId,m.factId];
 const observations=facts.filter(f=>['visible-relationship','hidden-relationship'].includes(f.kind)).sort((a,b)=>a.factId.localeCompare(b.factId,'en')).map(f=>{
  const relation=f.value.relation??f.value,p=origin(f),stem=f.kind==='hidden-relationship'?f.value.stem:f.value.otherStem;
  if(!p||!pillars[p]||relation.dayStem!=='乙')fail('YI_YOU_ROLE_SOURCE_DRIFT');
  const expected={辛:'七杀',庚:'正官',丁:'食神'}[stem];if(expected&&relation.label!==expected)fail('YI_YOU_ROLE_SOURCE_DRIFT');
  return{position:p,visibility:f.kind==='hidden-relationship'?'hidden':'visible',stem,label:relation.label,family:relation.family,evidenceIds:[f.factId],sourcePaths:['snapshot.derived.facts[factId='+f.factId+']']};
 });
 const visibleXin=knownExposurePositions.filter(p=>pillars[p][0]==='辛').map(p=>{
  const f=byId.get('visible-relationship:'+p),x=byId.get('month-exposure:'+p);if(f?.value.label!=='七杀'||x?.value.stem!=='辛')fail('YI_YOU_EXPOSURE_DRIFT');
  return{position:p,evidenceIds:[f.factId,x.factId],sourcePaths:['snapshot.chart.pillars.'+p+'[0]','snapshot.derived.facts[factId='+f.factId+']']};
 });
 const visible=label=>observations.filter(o=>o.visibility==='visible'&&label(o));
 const food=visible(o=>o.stem==='丁'&&o.label==='食神'),resources=visible(o=>o.family==='resource'),wealth=visible(o=>o.family==='managed'),properOfficer=observations.filter(o=>o.stem==='庚'&&o.label==='正官');
 const route=(id,observed,required,sourceRefs)=>({id,status:observed.length?'premises-observed-not-effective':missing.length?'not-observed-in-known-positions-input-open':'not-established-from-visible-positions',
  evidenceIds:unique(observed.flatMap(x=>x.evidenceIds)),positions:positions.filter(p=>observed.some(o=>o.position===p)),effective:null,requiredBeforeConclusion:required,sourceRefs});
 const methodRoutes=[route('yi-food-restraint',food,['assessed demand strength','assessed expression strength','assessed capacity of the day reference','effective positions and counterinteractions'],['ZP-YI-YOU-ENTRY','ZP-YI-FOOD-REQUIREMENTS']),
  route('yi-resource-mediation',resources,['effective mediation rather than mere resource occurrence','assessed relative roles/roots and capacity','position and wealth/output counterconditions'],['ZP-YI-RESOURCE-ROUTE'])];
 const contexts=[...wealth.map(o=>({...o,kind:'yi-wealth-context-not-verdict'})),...properOfficer.map(o=>({...o,kind:'yi-proper-officer-context-not-mixing-verdict'}))];
 for(const f of facts.filter(f=>f.kind==='stem-combination').sort((a,b)=>a.factId.localeCompare(b.factId,'en')))
  contexts.push({kind:'yi-pair-context-no-operative-verdict',positions:f.positions,stems:f.value,dayReferenceInPair:f.positions.includes('day'),evidenceIds:[f.factId],sourcePaths:['snapshot.derived.facts[factId='+f.factId+']']});
 for(const f of facts.filter(f=>f.kind==='branch-clash'&&f.positions.includes('month')).sort((a,b)=>a.factId.localeCompare(b.factId,'en')))
  contexts.push({kind:'yi-month-clash-context-not-damage',positions:f.positions,branches:f.value,evidenceIds:[f.factId],sourcePaths:['snapshot.derived.facts[factId='+f.factId+']']});
 const paragraphs=[],add=(id,text,ids=[],sources=['ZP-YI-YOU-ENTRY'],kind='declared-profile-context')=>paragraphs.push({id,text,evidenceIds:unique(ids),sourceRefs:sources,kind});
 add('framework','The traditional structure check follows the approach in Zi Ping Zhen Quan that starts with the birth month. Source-bounded cultural interpretations and modern editorial reflections are identified separately; this limited check does not establish a complete pattern.',[],['ZP-MONTH-START'],'framework-scope');
 add('entry','This chart starts with the category often called indirect authority in Zi Ping. The source examines how its demanding side is handled or moderated. This identifies an analytical starting point; individual temperament and life events have not been assessed.',evidenceIds,['ZP-YI-YOU-ENTRY','ZP-YI-CONDITIONAL-HANDLING'],'declared-framework-entry');
 add('entry-basis','The day reference and the month’s recorded symbol establish this particular starting point. The result is tied to this chart rather than chosen from a list of personality descriptions.',evidenceIds,['ZP-MONTH-START','ZP-YI-YOU-ENTRY','S-TEN'],'calculated-fact-context');
 add('exposure',visibleXin.length?'The month reference is also visible in the '+list(visibleXin.map(o=>o.position))+' part'+(visibleXin.length===1?'':'s')+' of the chart. Appearance alone is not a measure of overall strength.':'No separate appearance of the month reference is recorded in the known '+list(knownExposurePositions)+' parts. Unresolved positions are not treated as absences.',visibleXin.flatMap(o=>o.evidenceIds),['ZP-YI-YOU-ENTRY'],'known-position-scope');
 add('route-scope',food.length?'The source’s particular expression role is visible in the '+list(food.map(o=>o.position))+' part'+(food.length===1?'':'s')+'. Its appearance opens an assessment route; the required strength and capacity conditions have not been established.':'The source’s particular restraining expression role is not visible in the known positions. A hidden or unresolved appearance has not been promoted to a visible one.',food.flatMap(o=>o.evidenceIds),['ZP-YI-FOOD-REQUIREMENTS'],'product-scope-observation');
 if(resources.length)add('resource-context','A support-related role is visible in the '+list(resources.map(o=>o.position))+' part'+(resources.length===1?'':'s')+'. This is retained as a different assessment route, not proof that the demanding influence has been successfully redirected.',resources.flatMap(o=>o.evidenceIds),['ZP-YI-RESOURCE-ROUTE'],'product-scope-observation');
 if(contexts.length)add('context','Other recorded categories, pairings or branch relationships require separate assessment. They are not automatically read as a mixed, damaged or rescued pattern.',contexts.flatMap(o=>o.evidenceIds),['ZP-YI-YOU-ENTRY','S-TEN','S-PAIRS'],'product-context-observation');
 if(missing.length)add('partial','The birth hour is unresolved. The stable day/month entry and known facts remain available, but the missing information may add conditions that change the interpretation.',evidenceIds,['ZP-YI-YOU-ENTRY'],'incomplete-input-scope');
 add('limits','The full source example requires more than a category or a visible symbol. Overall strength, effective restraint or mediation, pattern formation and a favorable-element recommendation remain unassessed. This entry does not provide a completed personal interpretation.',evidenceIds,['ZP-YI-FOOD-REQUIREMENTS'],'framework-limit');
 return{profileId:ZP_PROFILE_ID,profileVersion:ZP_PROFILE_VERSION,branchId:ZP_YI_BRANCH_ID,status:'entry-established',calculationPolicy:{...common.calculationCompatibility},missingPositions:missing,knownExposurePositions,
  entry:{status:'supported-entry-in-declared-framework',dayStem:'乙',monthBranch:'酉',monthHiddenStem:'辛',category:'七杀',evidenceIds,sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.month[1]','snapshot.derived.facts[factId=hidden:month].value.stems[0]'],formedPattern:null,patternReferenceMeaning:'starting category only; not a danger or personality label'},
  visibleXin,contexts,observations,methodRoutes,paragraphs,wholeChartExclusionMade:false,
  operationalScreens:{appliesTo:ZP_YI_BRANCH_ID,origin:'declared known-position observations only; not effective classical judgments',dingFood:'visible Ding only; hidden Ding is not exposed',wealthOfficerPairs:'retained as context, no automatic damage, mixing or cancellation'},
  rescueReview:{state:'outside-implemented-jia-rescue-branch',excludedBranch:ZP_BRANCH_ID,routes:[],rescueEffective:null,patternFormed:null},
  reportScope:{status:'entry-only',bodyNotice:'The traditional starting point has been identified for this chart, but this draft does not include a completed personal interpretation of how that structure works. Choosing the detailed view does not remove this limit.',coverageNotice:'Traditional chart interpretation — Starting point identified only; a completed personal interpretation of this structure is not included.',previewNotice:'The traditional starting category is identified only. The detailed draft does not supply a completed personal interpretation of that structure.'},
  sourceDisagreement:{mainText:'food-control example expressly requires assessed demand/expression/capacity',commentary:'yin-stem exception remains a separately recorded comparison, not a waiver',priority:'selected main-text prerequisites retained'},
  verdicts:{formation:null,strength:null,usefulElement:null,climate:null},eligibleForPublic:false,purchasable:false,review:'internal source/entry verification only; no external certification or predictive validation'};
}
