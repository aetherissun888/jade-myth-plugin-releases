/** Source-example root admission, not effective-root/strength calculation. */
export const ROOT_ADMISSIBILITY_VERSION='Jade-ZP-RootAdmissibility-v1';
const held=new WeakMap(),positions=['year','month','day','hour'];
const admitted=new Set(['甲未','丙戌','乙辰','丁未']);
const excluded=new Set(['乙戌','丁丑']);
const disputed=new Set(['乙午','丁酉','甲子']);
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
export function assessRootAdmissibility(snapshot){
 if(snapshot?.schemaVersion!=='jm-foundation-schema-v1'||!snapshot.chart?.pillars||!Array.isArray(snapshot.derived?.facts))fail('ROOT_ADMISSION_SNAPSHOT_REQUIRED');
 const p=snapshot.chart.pillars,facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f]));
 if(byId.size!==facts.length)fail('ROOT_ADMISSION_DUPLICATE_FACT');
 const missing=positions.filter(k=>!p[k]),day=p.day?.[0],rows=[];
 if(day)for(const position of positions.filter(k=>p[k])){
  const branch=p[position][1],key=day+branch,h=byId.get('hidden:'+position);
  const row={position,dayStem:day,branch,status:'outside-reviewed-examples',evidenceIds:[],sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.'+position+'[1]'],
   listedInteractions:[],effectiveness:'unassessed',otherInteractionsAssessed:false,rootOpeningRequired:null};
  if(!h){row.status='input-evidence-incomplete';rows.push(row);continue;}
  if(h.kind!=='hidden'||h.value.branch!==branch||!Array.isArray(h.value.stems)||h.positions.length!==1||h.positions[0]!==position)fail('ROOT_ADMISSION_HIDDEN_SOURCE_DRIFT');
  row.evidenceIds=[h.factId];row.sourcePaths.push('snapshot.derived.facts[factId='+h.factId+']');
  const roots=facts.filter(f=>['exact-root','phase-root'].includes(f.kind)&&f.factId===f.kind+':'+position);
  for(const f of roots){
   const i=f.value.index,r=byId.get('hidden-relationship:'+position+':'+i);
   if(f.value.branch!==branch||h.value.stems[i]!==f.value.stem||r?.value.stem!==f.value.stem||r.value.index!==i||r.value.relation.dayStem!==day||r.value.relation.family!=='peer'||
    f.positions?.length!==2||f.positions[0]!=='day'||f.positions[1]!==position||r.positions?.length!==2||r.positions[0]!=='day'||r.positions[1]!==position||
    (f.kind==='exact-root')!==(f.value.stem===day))fail('ROOT_ADMISSION_SUPPORT_SOURCE_DRIFT');
  }
  row.listedInteractions=facts.filter(f=>['branch-clash','branch-combination'].includes(f.kind)&&f.positions.includes(position)).sort((a,b)=>a.factId.localeCompare(b.factId,'en')).map(f=>({factId:f.factId,kind:f.kind,positions:[...f.positions],effective:null}));
  if(admitted.has(key)){
   row.status=roots.length?'recognized-root-basis':'input-evidence-incomplete';
   row.evidenceIds.push(...roots.flatMap(f=>[f.factId,'hidden-relationship:'+position+':'+f.value.index]));
   row.sourcePaths.push(...roots.flatMap(f=>['snapshot.derived.facts[factId='+f.factId+']','snapshot.derived.facts[factId=hidden-relationship:'+position+':'+f.value.index+']']));
   row.rootKind=roots.map(f=>f.kind).sort();row.rootOpeningRequired=false;
   row.rootOpeningRuleOrigin='declared admission rule for these source examples; not a verdict about effective root under interaction';
   row.effectReview=roots.length?(row.listedInteractions.length?'listed-interaction-requires-assessment':'whole-chart-assessment-still-required'):'required-support-fact-missing';
  }else if(excluded.has(key)){
   if(roots.length)fail('ROOT_ADMISSION_PRIMARY_EXCLUSION_CONTRADICTION');
   row.status='rejected-at-this-position';row.rejectionScope='the named source example only; not absence of roots elsewhere';
  }else if(disputed.has(key)){
   row.status='textual-method-dispute';row.dispute=key==='甲子'?'transmitted-list-includes-Zi-without-hidden-Wood; no silent emendation':'main-text-yin-lifecycle-wording-and-separate-commentary-diverge';
  }
  row.evidenceIds=[...new Set(row.evidenceIds)].sort();rows.push(row);
 }
 const result=freeze({version:ROOT_ADMISSIBILITY_VERSION,methodProfile:'Jade-ZP-MonthPattern-v1',status:day?'bounded-root-admission-assessed':'day-reference-unresolved',
  sourceRefs:['ZP-ROOT-VS-PEERS','ZP-ROOT-NOT-SEASON-ONLY'],sourceLocator:'selected NCC bg_032 chapter六 main-text paragraph49; separate commentary paragraph50 not merged',
  sourceParagraphSHA256:'014ca608a0697e7385997dcf73b8cddbc5c48b5214e23153af84c52816d181ea',
  rows,missingPositions:missing,knownPositionScopeOnly:missing.length>0,wholeChartRootAbsenceAssessed:false,
  effectiveRoots:null,overallStrength:null,formation:null,usefulElement:null,
  inferenceBoundary:'Recognized hidden root basis is a traditional observation, not proof of effective support or capacity. Listed pair presence/absence neither removes nor certifies a root. No visible-peer count becomes root weight.',
  eligibleForPublic:false,purchasable:false});
 held.set(result,snapshot);return result;
}
export function assertRootAdmissibilitySource(result,snapshot){if(held.get(result)!==snapshot)fail('ROOT_ADMISSION_SOURCE_IDENTITY_MISMATCH');return true;}
