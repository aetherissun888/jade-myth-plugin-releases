/** Source-bounded presentation plan over the existing compiler ledger.
 * Fact connections are observations. Domain questions remain modern applications.
 * Editorial reading order is never a traditional importance ranking. */
import {assertClaimLedgerSource} from './claim-ledger.js';
import {buildMethodContext} from './method-context.js';
import {ZP_PROFILE_SOURCES} from './ziping-profile-sources.js';
import {buildZipingCulturalReading} from './ziping-cultural-reading.js';
import {buildYiRootContext,buildYiConditionalSupport} from './ziping-yi-root-context.js';
import{buildMonthPeerContext,buildN10QualitativeReading,MONTH_PEER_SECTION}from'./ziping-month-peer-context.js';
import{applyMonthPeerApplication}from'./ziping-month-peer-application.js';
import{jiaYinCulturalReading,JIA_YIN_BRANCH,JIA_YIN_SECTION}from'./ziping-jia-yin-core.js';
import{buildJiaYinRoleContrast}from'./ziping-jia-yin-role-contrast.js';
import{officerChainCulturalReading}from'./ziping-officer-chain.js';
export const REPORT_PLAN_VERSION='jm-evidence-report-plan-v2.3';
/** One scope-copy source for the actual preview and detailed-page introduction. */
export function readingValueScope(coverage,sections,freeSections=[]){
 const has=(items,id)=>items.some(section=>section.id===id&&Array.isArray(section.paragraphs)&&section.paragraphs.some(p=>typeof p==='string'&&p.trim()));
 const included=(coverage?.domains??[]).filter(domain=>domain.status==='interpreted'&&has(sections,domain.sectionId));
 const rootOnly=has(sections,'reading-yi-root-context')&&!included.length;
 const delivery=coverage?.culturalInterpretation?.deliveryCapabilities;
 const deliveredRole=role=>[...new Set((delivery?.paragraphs??[]).filter(row=>row.role===role&&Number.isInteger(row.index)&&sections.some(section=>section.id===delivery.sectionId&&typeof section.paragraphs?.[row.index]==='string'&&section.paragraphs[row.index].trim())).map(row=>row.index))];
 const examples=deliveredRole('example'),exercises=deliveredRole('exercise');
 const expandedYi=has(sections,'reading-yi-root-context')&&delivery?.ruleId==='Jade-ZP-Yi-ObservedRootContext-v2';
 if(expandedYi&&(examples.length!==2||exercises.length!==1||new Set([...examples,...exercises]).size!==3))throw new RangeError('READING_DELIVERY_CAPABILITY_DRIFT');
 const action=sections.find(s=>s.id==='reading-action'),freeAction=freeSections.find(s=>s.id==='reading-action');
 const sharedPrompt=!!action&&!!freeAction&&JSON.stringify(action.paragraphs)===JSON.stringify(freeAction.paragraphs);
 const topicExercises=expandedYi||!!action&&freeSections.length>0&&!sharedPrompt;
 const addedTopics=freeSections.length?included.filter(d=>!has(freeSections,d.sectionId)):[];
 // The existing, source-bounded Jia section already includes its own examples and reflection.
 const fullCulturalSection=has(sections,'reading-month-support');
 const supplement=has(sections,'reading-month-peer-context');
 const application=supplement&&coverage?.structuralSupplement?.kind==='support-outlet-application';
 const contextOnly=supplement&&!included.length&&coverage.structuralSupplement?.entryPair==='乙寅';
 const n10Kind=coverage?.culturalInterpretation?.kind;
 const expansion=['conditional-yi-support','provisional-yi-support'].includes(n10Kind)?'The detailed view explains the same theme through two contrasting situations: clear guidance, and help that comes with additional obligations. It does not add a complete life-topic assessment or a separate exercise.': ['n10-aims-means','provisional-n10-aims-means'].includes(n10Kind)
  ?(n10Kind==='n10-aims-means'?'The same resources-and-action theme is explained in more detail, with two contrasting everyday situations.':'The detailed view explains the same provisional theme through two conditional situations. Missing birth time still limits that reading.')
  :contextOnly
  ?application?'The detailed view adds an explanation of the shared chart conditions and one contemporary learning example. It does not provide full work, learning, money, relationship or collaboration chapters.':'The detailed view adds a partial chart comparison. It does not provide full work, learning, money, relationship or collaboration chapters, and a more precise time would not guarantee them.'
  :application
  ?'The detailed view explains the supporting observation, the shared conditions and what remains unestablished, with one contemporary learning example. It does not complete a personal topic chapter or add practical exercises.'
  :coverage?.culturalInterpretation?.kind==='officer-corrective-chain'
  ?'The detailed chapter explains the corrective relationship, which demand it addresses and what remains open, with one contemporary illustration. It does not establish a completed pattern or a complete personal forecast.'
  :coverage?.culturalInterpretation?.kind==='conditional-root-role-contrast'
  ?'The detailed reading explains how a supporting foundation and a competing relationship meet in this chart, with one contemporary illustration. It does not settle effective strength, resolve the opposition or add a complete personal forecast.'
  :coverage?.culturalInterpretation?.kind==='provisional-known-foundation'
  ?'The detailed view explains the provisional theme from the known parts and compares two conditional situations. It cannot supply the missing time or complete the traditional assessment.'
  :has(sections,JIA_YIN_SECTION)
  ?'The detailed reading explains the connected structure and two different work situations. These work applications are Jade’s contemporary interpretation, not additional predictions or a completed pattern judgment.'
  :expandedYi
  ?'This detailed chapter adds an explanation of how the supported themes fit together, two contemporary examples and one short reflection. It remains a limited cultural reading, not a complete personal analysis.'
  :supplement&&!included.length
  ?'The detailed view compares the chart’s available roles and the source’s conditional routes. This is a structural supplement, not additional work or money topics or a complete personal interpretation.'
  :rootOnly
  ?'The detailed draft contains a short explanation of the support relationship and a conditional contemporary symbolic interpretation. It does not include topic exercises or a complete personal analysis.'
  :included.length||fullCulturalSection
   ?'The detailed view adds explanations, contrasting situations and trade-offs for the supported themes.'+(addedTopics.length?' Compared with the free view, '+list(addedTopics.map(d=>d.label.toLowerCase()))+(addedTopics.length===1?' is an additional chapter.':' are additional chapters.'):'')+(sharedPrompt?' The reflection prompt is already in the free view; it is not an additional exercise.':topicExercises?' A separate reflection is included.':'')
   :'This detailed candidate shows the available chart context and the limits of the current reading method. It does not supply a personal interpretation or topic exercises.';
 const freePrompt=has(freeSections,'reading-action');
 const freeMain=(coverage?.domains??[]).some(domain=>has(freeSections,domain.sectionId))||has(freeSections,'reading-month-support')||has(freeSections,'reading-yi-root-context')||has(freeSections,'reading-yi-support');
 const freeIntro=['conditional-yi-support','provisional-yi-support','n10-aims-means','provisional-n10-aims-means'].includes(n10Kind)?'The free view includes the core cultural theme and a short reason for this reading.':application?'The free view includes the core comparison and an attributed contemporary application.':supplement&&!included.length?'The free view includes the available chart context.':freePrompt?'The free reading includes supported themes and a practical prompt.':freeMain?'The free reading includes the supported core interpretation.':'The free view presents the chart and its input and method limits.';
 return{expansion,detailIntroduction:freeIntro+' '+expansion+(contextOnly?' This limited draft is not for sale.':' Topics left open are listed explicitly; a complete personal forecast is not supplied.'),freePrompt,topicExercises,sharedPrompt,additionalTopicIds:addedTopics.map(d=>d.sectionId)};
}
export function readingInputLimit(chart){
 if(chart.status==='incomplete-time')return 'Birth time is unknown. Only stable chart information is used.';
 if(chart.status==='range-time')return 'A range of birth times was supplied. Only chart information shared across the retained possibilities is used.';
 if(chart.status==='boundary-minute')return 'This birth minute crosses a calculated calendar boundary. Only stable chart information is used.';
 if(chart.nearSolarBoundary)return 'This birth time is near a calculated calendar boundary. The calculation flag has no independently certified error bound.';
 return 'The recorded birth time has minute precision; the birth second is not known.';
}
const unique=a=>[...new Set(a)].sort();
const list=a=>a.length<2?a[0]??'':a.length===2?a.join(' and '):a.slice(0,-1).join(', ')+', and '+a.at(-1);
export function readingPreviewDescription(chart,coverage,sections,freeSections=[]){
 const domains=coverage?.domains,byId=new Map(sections.map(s=>[s.id,s]));
 if(!Array.isArray(domains)||byId.size!==sections.length||domains.some(d=>!['interpreted','input-insufficient','method-not-supported'].includes(d.status)))throw new RangeError('PREVIEW_COVERAGE_REQUIRED');
 const included=domains.filter(d=>d.status==='interpreted'),used=new Set();
 for(const d of included){const s=byId.get(d.sectionId);
  if(!s||used.has(s.id)||!s.title||!Array.isArray(s.paragraphs)||!s.paragraphs.length||s.paragraphs.some(p=>!p.trim()))throw new RangeError('PREVIEW_SECTION_UNAVAILABLE');
  used.add(s.id);
 }
 const structuralSection=byId.get(coverage.structuralSupplement?.sectionId);
 const culturalSection=byId.get(coverage.culturalInterpretation?.sectionId??'reading-month-support');
 if(!included.length&&!culturalSection&&!structuralSection)throw new RangeError('PREVIEW_SECTION_UNAVAILABLE');
 if(culturalSection&&(!culturalSection.paragraphs?.length||culturalSection.paragraphs.some(p=>!p.trim())))throw new RangeError('PREVIEW_SECTION_UNAVAILABLE');
 if(!included.length&&structuralSection&&coverage.structuralSupplement?.entryPair==='乙寅')return readingValueScope(coverage,sections,freeSections).expansion+' '+(['incomplete-time','range-time','boundary-minute'].includes(chart.status)?readingInputLimit(chart)+' ':'')+'This is an actual excerpt, not a prediction. This limited draft is not a complete personal reading and is not for sale.';
 const labels=rows=>list(rows.map(d=>d.label.toLowerCase()));
 const oneN10Theme=coverage.culturalInterpretation?.kind==='n10-aims-means'&&included.length===1&&included[0].sectionId===culturalSection?.id;
 const sentences=oneN10Theme?['This detailed view covers one limited resources-and-action theme.']:included.length?['Included in this detailed draft: '+labels(included)+'.']:[];
 const unavailable=domains.filter(d=>d.status==='method-not-supported'),unresolved=domains.filter(d=>d.status==='input-insufficient');
 if(unavailable.length)sentences.push((coverage.structuralSupplement?.kind==='support-outlet-application'?'Full personal-topic chapters not included under the current reading method: ':'Not included under the current reading method: ')+labels(unavailable)+'.');
 if(unresolved.length)sentences.push('Left open because the birth information is uncertain: '+labels(unresolved)+'.');
 if(['incomplete-time','range-time','boundary-minute'].includes(chart.status))sentences.push(readingInputLimit(chart));
 for(const d of included.filter(d=>d.partialNotice))sentences.push('For '+d.label.toLowerCase()+', only “'+byId.get(d.sectionId).title+'” is included; other themes depend on unresolved birth information.');
 if(culturalSection&&!included.some(d=>d.sectionId===culturalSection.id))sentences.push(coverage.culturalInterpretation?.previewScope??'Also included: a traditional interpretation of how practical results and preparation can support or constrain one another.');
 if(structuralSection)sentences.push(coverage.structuralSupplement?.kind==='support-outlet-application'?'Also included: a limited support-and-outlet comparison with a contemporary learning illustration. This is distinct from a complete learning chapter.':'Also included: a limited comparison of the available chart relationships and the source’s conditional routes. This supplement does not add work or money topics or settle effective mediation.');
 if(coverage.traditionalEntry?.previewNotice)sentences.push(coverage.traditionalEntry.previewNotice);
 const {expansion}=readingValueScope(coverage,sections,freeSections);
 sentences.push(expansion+' The excerpt is taken from that reading.');
 return sentences.join(' ');
}
const scopes={
 "craft": "This angle matters when you can influence how a result is produced. A settled instruction with no room for a trial calls for a different response.",
 "patient-craft": "This angle is most useful in familiar work. When the assignment has changed, test the approach before repeating the routine.",
 "supported-authority": "If an obligation is already within your authority and has adequate support, this tension may play little part in your present work.",
 "learning": "A practical attempt can guide the next round of learning; it still needs to respect the essential instructions for the task.",
 "shared-money": "A gift, a loan and a jointly owned commitment have different terms. Financial decisions still depend on your actual finances and agreements.",
 "ideas-value": "This matters when extra work consumes resources promised elsewhere. An open-ended hobby or a freely chosen gift may not need a stopping rule; financial decisions require actual costs and agreements.",
 "care-boundaries": "This angle fits an actual pattern of unspoken practical expectations. It does not establish what another person feels or intends.",
 "mutual-space": "This angle matters when separate interests and shared time are both wanted. It is not a test of another person’s affection.",
 "equal-voice": "If decision rights are already clear and trusted, this tension may play little role in the group’s current work."
};
// Original modern applications of the selected symbolic pairings. These do not
// claim a classical formation, diagnosed trait or event in the reader's life.
const prose={
 craft:{brief:"In this reading, you may feel more engaged when there is a clear standard to meet and room to improve how the work gets done. A small working alternative gives your ideas something concrete to stand on.",detail:"The central distinction is between the requirement and the method used to meet it. You can respect the first while questioning the second. A proposed change becomes easier to evaluate when you can show what it preserves and what it improves; criticism alone leaves both points unsettled.",qualifier:'Where guidance is actually available, review can strengthen an independent proposal. Accepting a useful correction need not mean handing over the decision.'},
 'patient-craft':{brief:"You may get more satisfaction from work whose quality you can repeat and improve. A dependable process can free your attention for the part that still needs judgment.",detail:"Dependable craft involves deciding which choices can become repeatable and which still deserve attention each time. A routine can hold the settled steps so you have room to notice an exception. The useful measure is whether the result improves, rather than how faithfully every step is followed.",qualifier:'Where there is room for independent initiative, a review point keeps a dependable process open to improvement. Reliability does not require keeping every step forever.'},
 'supported-authority':{brief:"You may find responsibility easier to carry when your knowledge, permission and practical support match what is expected of you. Being accountable for a result and being able to influence it need to belong together.",detail:"An obligation becomes more workable when you can distinguish its demands from the resources available to meet them. Recognition alone does not provide permission, information or time. In this interpretation, the important balance is between what you are answerable for and what the arrangement actually lets you control.",qualifier:'Where independent choices are possible, support can leave room for a concrete improvement proposal. Carrying an obligation does not require accepting every existing method.'},
 learning:{brief:"You may understand an idea more clearly once you have explained it or tried making something with it. Preparation and a first attempt can take turns, with each showing you what the other still needs.",detail:"Feeling familiar with an explanation is different from being able to use it. A first attempt can reveal a gap that another round of general reading would leave hidden. The learning theme here favors moving between receiving information and making it your own, rather than treating preparation as a stage that must become perfect before you begin.",qualifier:'When another person depends on the result, a usable first version and a later revision may matter more than waiting for complete confidence.'},
 'shared-money':{brief:"In shared commitments, you may value generosity while still wanting a clear sense of what belongs to whom. Contributing willingly does not settle who can decide, who benefits or how the arrangement can change.",detail:"A shared contribution has two boundaries: what you agree to give and what responsibility follows from giving it. The amount can be clear while ownership or decision rights remain unsettled. Separating those issues leaves room to help without making every contribution an open-ended promise.",qualifier:'Where help is freely offered, not every exchange needs to become a transaction. Distinguishing a gift from a loan or a shared commitment protects that difference.'},
 'ideas-value':{brief:"You may enjoy making a contribution while still needing to protect the resources that sustain it. A worthwhile result can need a smaller scope; enthusiasm alone does not settle what another revision should cost.",detail:"Improving a result and enlarging a commitment can look similar from the outside. A correction fulfills the existing agreement; a new request changes what is being promised. The distinction matters when extra work draws on time, money or materials you have already set aside for something else.",qualifier:'If someone else also owns the result, the stopping point needs shared acceptance. An individual sense of completion may not describe the whole agreement.'},
 'care-boundaries':{brief:"You may express care through being dependable while also needing room to ask for something yourself. Practical help works better when preferences and limits can be spoken, rather than inferred from who has always handled a task.",detail:"Willingly helping can gradually become an unspoken role. The distinction is between a task you choose to take on and an expectation that no one remembers agreeing to. Making that difference visible gives both people something specific to discuss without deciding in advance who cares more.",qualifier:'Where independent interests and direct expression are already welcome, they can keep care from becoming a person’s entire role. Reliability and a preference of one’s own can coexist.'},
 'mutual-space':{brief:"You may want closeness without needing to share every interest or activity. Separate space can belong within a relationship when the shared commitments remain clear to both people.",detail:"Wanting an interest understood is different from requiring the other person to take part in it. A clear invitation leaves room for an honest response; an unspoken test asks for proof of affection without stating what is wanted. The distinction allows room for both company and separate pursuits.",qualifier:'Where real care responsibilities exist, separate time sits alongside those commitments. Making the shared work visible keeps personal space from creating an unnoticed extra burden.'},
 'equal-voice':{brief:"You may care about having a meaningful say while also wanting a group to reach a decision. Equal input and clear final responsibility can coexist; fairness does not require reopening every choice.",detail:"Being heard, being consulted and making the final decision are different roles. A group can respect participation without requiring consensus on every detail. Clarity about those roles makes disagreement easier to address as a decision about the task, rather than a struggle over everyone’s standing.",qualifier:'Where trusted advice is available, it can test an assumption without taking over the decision. Advice and final authority remain different forms of involvement.'}
};
const exampleRoles={
 craft:['demonstrated-alternative','work-setting-conditions'],
 'patient-craft':['repeatable-task','teach-versus-judge'],
 'supported-authority':['authority-gap','preparation-context'],
 learning:['explanation-gap','forms-of-help'],
 'shared-money':['agreement-before-sharing','bounded-contribution'],
 'ideas-value':['correction-versus-new-request','exchange-terms'],
 'care-boundaries':['silent-task-allocation','reciprocal-request'],
 'mutual-space':['invitation-not-test','shared-versus-separate'],
 'equal-voice':['decision-rights','identify-the-request']
};
const groupingBasis={
 craft:'The chart contains the expression category traditionally called Shang Guan together with responsibility-related categories. That is the grouping used here for improving an approach against a standard. The other expression category, Shi Shen, selects the repeatable-craft theme instead; the broad label “expression” alone does not explain that choice.',
 'patient-craft':'The expression category here is traditionally called Shi Shen, paired with responsibility-related categories. This selects the repeatable-craft theme. The idea-testing theme uses Shang Guan, a different expression category, so these two readings are not selected from the broad label “expression” alone.',
 'supported-authority':'Responsibility-related categories appear openly while support-related categories occur within the chart. The tool groups that pairing into a theme about carrying an obligation with adequate support.',
 learning:'Support-related categories occur within the chart alongside openly expressed making-related categories. The tool groups that pairing into a theme about taking something in and putting it to use.',
 'shared-money':'Peer-related symbols appear openly alongside resource-management symbols within the chart. That grouping selects shared ownership here; it does not establish that an actual dispute or joint venture exists.',
 'ideas-value':'Expression-related symbols occur alongside resource-management symbols. That grouping selects contribution and cost. The separate grouping about shared ownership does not appear in the chart information available here, so this chapter stays with contribution and cost.',
 'care-boundaries':'The care theme comes from support and responsibility symbols in particular parts of the chart, including the birth-time position. This grouping is used to explore giving and receiving care; it does not assess a partner or a couple’s compatibility.',
 'mutual-space':'Peer-related symbols and inner expression-related symbols select the separate-interests theme. The care-and-duty theme has different requirements, so one chapter is not a substitute for the other.',
 'equal-voice':'Peer-related symbols appear openly alongside responsibility-related categories within the chart. The tool groups that pairing into participation and decision rights, rather than treating it as evidence that colleagues are competitive.'
};
function coalesceTopic(row,members,cards){
 const ids=members.map(m=>m.entryId),has=id=>ids.includes(id);
 const examples=(chosen,firstOnly=false)=>chosen.flatMap(id=>(firstOnly?exampleRoles[id].slice(0,1):exampleRoles[id]).map(role=>'application.'+id+'.'+role));
 if(ids.length===1){const id=ids[0];return {...prose[id],scope:scopes[id],basis:groupingBasis[id]+(id==='mutual-space'&&cards.get('care-boundaries').status==='not-established-from-stable-input'?' The care grouping depends on unresolved birth information and is withheld; this separate-interests grouping remains stable.':''),examples:examples(ids)};}
 if(row.outputId==='money-exchange')return {
  brief:'You may enjoy contributing to a shared effort while still wanting its promises to stay clear. The central theme is keeping useful work sustainable; shared ownership adds a need to agree who can decide and when the commitment changes.',
  detail:'A shared project can become harder in two different ways: the result keeps growing, or the agreement about ownership stays vague. More effort cannot settle both. A correction may belong within the original promise, while a new feature changes its scope; neither decision answers who owns the result or has the final say.',
  qualifier:'Help can still be freely given. Naming a gift as a gift, and a joint commitment as something both people can revisit, keeps clear terms from turning every relationship into a transaction.',
  scope:'This angle matters when a result or a commitment is actually shared. An individual hobby does not need an ownership agreement, and financial choices still require your real costs, resources and terms.',
  basis:'Both combinations are present: expression with resource-management symbols selects contribution and cost; openly expressed peer symbols with resource-management symbols adds shared ownership. That second grouping is why this chapter includes ownership as well as scope. These are the tool’s cultural groupings, not a completed pattern analysis.',
  examples:examples(['ideas-value','shared-money'],true)};
 if(row.outputId==='relationship-both')return {
  brief:'You may want to be someone others can rely on without letting that role take up all the space in a relationship. Here, practical care and separate interests belong in the same conversation: being close can leave room to remain yourself.',
  detail:'Dependability can narrow your room in a relationship if practical tasks become automatic; a wish for closeness can narrow it in another way if every interest is expected to be shared. These are different pressures. Making a task visible helps with the first, while a clear invitation leaves the other person room to respond to the second.',
  qualifier:'Where needs and preferences are already spoken openly, these tensions may be mild. Keep that existing arrangement in view before treating the reading as a problem to solve.',
  scope:'This angle fits real decisions about shared care and separate time. It does not tell you what another person feels, or turn a preference for company or space into a test of love.',
  basis:'Two combinations support this chapter: support and responsibility symbols lead to the theme of giving and receiving care; peer and expression symbols lead to separate interests. Because both combinations are present, the chapter brings the two themes together. The care theme is included only when the birth-time information it needs is available.',
  examples:examples(['care-boundaries','mutual-space'],true)};
 if(row.outputId==='work-both'&&ids.every(id=>['craft','patient-craft','supported-authority'].includes(id))){
  const approaches=ids.map(id=>({craft:'testing an improvement','patient-craft':'making quality repeatable','supported-authority':'matching responsibility with practical support'})[id]);
  const distinctions=ids.map(id=>({craft:'A proposed improvement needs a fair test against the requirement.','patient-craft':'Variable quality in familiar work calls for a process you can check.','supported-authority':'An obligation you cannot influence calls for the missing permission, information or help to be identified.'})[id]);
  return {
   brief:'You may bring more than one approach to work: '+list(approaches)+'. The useful distinction is which part of a task needs attention, rather than treating one approach as your fixed style.',
   detail:distinctions.join(' ')+' Adding effort to the wrong part can leave the real difficulty untouched. Separating these situations lets you choose a response without changing the whole arrangement at once.',
   qualifier:'If the arrangement already leaves room for judgment and useful feedback, these tensions may be small. Preserve what works rather than looking for hidden conflict.',
   scope:'Apply these angles to the actual task and authority you have. Their coexistence does not require you to fit every description or select a destined career.',
   basis:'The combinations present in this chart lead to '+list(approaches)+'. '+(has('craft')&&has('patient-craft')?'Both traditional expression categories are present, so neither work theme is chosen merely from the broad expression label. ':'')+(has('supported-authority')?'The responsibility-and-support pairing adds an angle distinct from the expression-based work themes. ':'')+'These themes can be read together; none is treated as your dominant personality trait.',
   examples:examples(ids,true)};
 }
 throw new RangeError('UNREVIEWED_EDITORIAL_COALESCENCE');
}
const N03_LEARNING_RULE='Jade-ZP-N03-LearningThreeWay-v1';
// One root-approved qualitative bridge. It does not decide the formal print route.
function n03LearningContext(snapshot,facts){
 const p=snapshot.chart.pillars;
 if(snapshot.chart.status!=='calculated'||snapshot.chart.nearSolarBoundary||p.year!=='癸亥'||p.month!=='乙卯'||p.day!=='丙午'||p.hour!=='戊戌')return null;
 const roles=[['visible-relationship:year','癸','正官'],['visible-relationship:month','乙','正印'],['visible-relationship:hour','戊','食神'],['hidden-relationship:year:0','壬','七杀'],['hidden-relationship:year:1','甲','偏印'],['hidden-relationship:month:0','乙','正印'],['hidden-relationship:day:0','丁','劫财'],['hidden-relationship:day:1','己','伤官'],['hidden-relationship:hour:0','戊','食神'],['hidden-relationship:hour:1','辛','正财'],['hidden-relationship:hour:2','丁','劫财']];
 const required=[...roles.map(r=>r[0]),'hidden:month','month-relation:principal','month-exposure:month','phase-root:day','phase-root:hour','stem-combination:year:hour','branch-combination:month:hour'];
 if(required.some(id=>!facts.has(id)))return null;
 for(const[id,stem,label]of roles){const f=facts.get(id),visible=id.startsWith('visible-'),r=visible?f.value:f.value.relation,position=id.split(':')[1];if(f.kind!==(visible?'visible-relationship':'hidden-relationship')||(visible?f.value.otherStem:f.value.stem)!==stem||r.dayStem!=='丙'||r.label!==label||f.positions.join(':')!=='day:'+position)throw new RangeError('N03_LEARNING_ROLE_SOURCE_DRIFT');}
 const month=facts.get('hidden:month'),principal=facts.get('month-relation:principal'),exposure=facts.get('month-exposure:month');
 if(month.kind!=='hidden'||month.positions.join(':')!=='month'||month.value.branch!=='卯'||month.value.stems.join('')!=='乙'||principal.kind!=='month-relation'||principal.positions.join(':')!=='day:month'||principal.value.relation.dayStem!=='丙'||principal.value.stem!=='乙'||principal.value.relation.label!=='正印'||exposure.kind!=='month-exposure'||exposure.positions.join(':')!=='month:month'||exposure.value.stem!=='乙'||exposure.value.monthBranch!=='卯')throw new RangeError('N03_LEARNING_MONTH_SOURCE_DRIFT');
 for(const[id,kind,positions,value]of[['stem-combination:year:hour','stem-combination','year:hour','癸戊'],['branch-combination:month:hour','branch-combination','month:hour','卯戌']]){const f=facts.get(id);if(f.kind!==kind||f.positions.join(':')!==positions||f.value.join('')!==value)throw new RangeError('N03_LEARNING_PAIR_SOURCE_DRIFT');}
 for(const[id,branch,index]of[['phase-root:day','午',0],['phase-root:hour','戌',2]]){const f=facts.get(id);if(f.kind!=='phase-root'||f.positions.join(':')!=='day:'+id.split(':')[1]||f.value.stem!=='丁'||f.value.branch!==branch||f.value.index!==index)throw new RangeError('N03_LEARNING_SUPPORT_SOURCE_DRIFT');}
 return{factIds:unique(required),qualifyingFactIds:unique(['hidden-relationship:year:0','hidden-relationship:year:1','hidden-relationship:day:1','hidden-relationship:hour:1','stem-combination:year:hour','branch-combination:month:hour']),conditions:{applicationVersion:N03_LEARNING_RULE,qualitativeContract:'Jade-ZP-N03-LearningQualitative-v1',decisionOrigin:'root-approved Jade qualitative symbolic application, not a classical psychological finding',classicalContextSourceRefs:['C-ZP-PRINT-LEARNING-CONTEXT'],sourcePaths:unique(required).map(id=>'snapshot.derived.facts[factId='+id+']'),traditionalInferenceApproved:false,formalPrintRoute:null,overallStrength:null,effectiveCombination:null,academicOutcome:null}};
}
const firstSentence=text=>text.match(/^.*?[.!?](?=\s|$)/)?.[0]??text;
const topicReason={
 craft:'Jade selects this theme where the chart brings expressing an alternative together with answering to a requirement.',
 'patient-craft':'This theme comes from the chart’s pairing of steady making with meeting a requirement.',
 'supported-authority':'The chart pairs responsibility with receiving support, which is why Jade reads what is expected alongside what helps you carry it.',
 learning:'The chart’s pairing of receiving guidance and expressing something is why this reading connects understanding with use.',
 'shared-money':'The chart brings participation and shared resources together, so this reading distinguishes giving something from agreeing what follows.',
 'ideas-value':'Jade selects this theme where making a contribution meets the question of what it takes to sustain it.',
 'care-boundaries':'This chart brings support and responsibility together in the care-related pairing, which is why this reading considers both helping and being able to ask.',
 'mutual-space':'The chart’s individuality-and-expression pairing is why Jade keeps shared time and separate interests in view together.',
 'equal-voice':'Jade selects this theme where the chart brings participation and responsibility together.'
};
function reasonForTopic(row){
 if(row.outputId==='money-exchange')return 'This chart combines making a contribution with sharing resources, so Jade reads both the size of a promise and the agreement behind it.';
 if(row.outputId==='relationship-both')return 'Both the care-and-responsibility and separate-interests pairings are present, so this reading keeps those two needs in the same conversation.';
 if(row.outputId==='work-both')return 'More than one work pairing is present here: '+list(row.selected.map(id=>({craft:'expressing an alternative against a requirement','patient-craft':'making quality dependable','supported-authority':'carrying responsibility with support'})[id]))+'. Jade keeps their different questions visible rather than choosing a dominant trait.';
 return topicReason[row.outputId];
}
const family=f=>(f.value.relation??f.value).family;
export function buildEvidenceReportPlan(snapshot,reading,ledger){
 assertClaimLedgerSource(ledger,snapshot);
 const facts=new Map(snapshot.derived.facts.map(f=>[f.factId,f]));
 const selected=reading.selectionLedger.filter(l=>l.selected.length);
 const cards=new Map(reading.themes.map(t=>[t.entryId,t]));
 const claimDescriptors=[],detailLinks={},freeLinks={},basisLinks={};
 const jiaCultural=buildZipingCulturalReading(snapshot,reading.interpretationProfile,ledger),yiRootContext=buildYiRootContext(snapshot,reading.interpretationProfile,ledger);
 let cultural=reading.interpretationProfile.branchId===JIA_YIN_BRANCH?jiaYinCulturalReading(reading.interpretationProfile,snapshot):yiRootContext.status==='supported-cultural-structure'?yiRootContext:jiaCultural;
 if(reading.interpretationProfile.branchId===JIA_YIN_BRANCH&&cultural.status!=='supported-cultural-structure'){
  const contrast=buildJiaYinRoleContrast(snapshot,reading.interpretationProfile,ledger);if(contrast.status==='supported-cultural-structure')cultural=contrast;
 }
 if(reading.interpretationProfile.branchId==='Jia-You-ZhengGuan-entry-v1'&&cultural.status!=='supported-cultural-structure'){
  const officer=officerChainCulturalReading(reading.officerChain);if(officer.status==='supported-cultural-structure')cultural=officer;
 }
 if(cultural.status!=='supported-cultural-structure'){const support=buildYiConditionalSupport(snapshot,reading.interpretationProfile,ledger,yiRootContext);if(support.status==='supported-cultural-structure')cultural=support;}
 const monthPeerContext=applyMonthPeerApplication(snapshot,reading.lifeRouteReview,buildMonthPeerContext(snapshot,ledger));
 const n10=buildN10QualitativeReading(snapshot,monthPeerContext,ledger);if(n10.status==='supported-cultural-structure')cultural=n10;
 // A source-bound work application is separate from the legacy category cards.
 // It must have a real rendered section; a month-pattern entry alone adds none.
 const sourceBoundedDomainDecisions=[];
 if(reading.interpretationProfile.branchId===JIA_YIN_BRANCH){
  const work=reading.coverage.domains.find(d=>d.domain==='work');
  if(work.status!=='interpreted'&&cultural.status==='supported-cultural-structure'&&cultural.domain==='work'){
   Object.assign(work,{status:'interpreted',sectionId:cultural.id,pendingEntryIds:[],detail:'Included: '+cultural.title+' — a contemporary work application of the stated traditional structure.'});
   delete work.partialNotice;
   reading.coverage.includedDomains=unique([...reading.coverage.includedDomains,'work']);
   reading.coverage.unavailableDomains=reading.coverage.unavailableDomains.filter(id=>id!=='work');
   sourceBoundedDomainDecisions.push({domain:'work',sectionId:cultural.id,ruleId:cultural.ruleId,decision:'included-source-bounded-work-application',evidenceIds:cultural.evidenceIds,traditionalFormation:false,personalityDiagnosis:false});
  }else if(work.status!=='interpreted'&&reading.interpretationProfile.coreRoute.status==='input-insufficient'){
   Object.assign(work,{status:'input-insufficient',sectionId:null,detail:cultural.kind==='provisional-known-foundation'?'A provisional expression theme is included separately, but the unknown birth time limits a complete personal work interpretation. More precise input would not guarantee one.':'Not interpreted: unresolved birth information prevents the declared connected-expression work reading. More precise input would not guarantee it.'});
   sourceBoundedDomainDecisions.push({domain:'work',sectionId:null,ruleId:reading.interpretationProfile.coreRoute.ruleId,decision:'withheld-input-insufficient',traditionalFormation:false});
  }
 }
 if(cultural.ruleId===n10.ruleId&&cultural.status==='supported-cultural-structure'){
  const money=reading.coverage.domains.find(d=>d.domain==='money');
  if(cultural.domain==='money'){Object.assign(money,{status:'interpreted',sectionId:cultural.id,pendingEntryIds:[],detail:'Included: '+cultural.title+' — one limited Zi Ping cultural theme, not a financial forecast.'});delete money.partialNotice;reading.coverage.includedDomains=unique([...reading.coverage.includedDomains,'money']);reading.coverage.unavailableDomains=reading.coverage.unavailableDomains.filter(id=>id!=='money');}
  else Object.assign(money,{status:'input-insufficient',sectionId:null,detail:'A provisional goals-and-means theme is included separately. The unknown time leaves a complete resources chapter open.'});
  sourceBoundedDomainDecisions.push({domain:'money',sectionId:cultural.domain?cultural.id:null,ruleId:cultural.ruleId,decision:cultural.domain?'included-bounded-resources-cultural-theme':'provisional-theme-not-complete-topic',evidenceIds:cultural.evidenceIds,traditionalFormation:false,personalityDiagnosis:false,incomePrediction:false});
 }
 const entryScope=cultural.reportScope??yiRootContext.reportScope??reading.interpretationProfile.reportScope;
 if(entryScope)reading.coverage.traditionalEntry={...entryScope};
 const claim=(id,text,layer,ids=[],counterIds=[],condition={})=>{
  if([...ids,...counterIds].some(id=>!facts.has(id)))throw new RangeError('REPORT_PLAN_FACT_UNKNOWN');
  claimDescriptors.push({claimId:'plan.'+id,text,layer,evidenceIds:unique(ids),counterEvidenceIds:unique(counterIds),conditions:condition,
   ...(condition.classicalContextSourceRefs?{sourceRefs:condition.classicalContextSourceRefs}:{}),
   sourceExplanation:{kind:layer==='structural-observation'?'calculated-category-and-position':'original-modern-application',traditionalDomainInference:'HOLD',boundary:'Category placement supports the stated chart connection, not a personality or life-outcome inference.',...(condition.qualitativeContract?{qualitativeContract:condition.qualitativeContract,primary:'chapter35 distinguishes officer-present and expression-using routes; formal strength conditions are not presumed',commentary:'Xu comparison retained separately, not an exception waiver',modernBridge:'Jade interpretation of guidance, own explanation and a stated requirement; not a historical personality quotation'}:{})}});
  return 'plan.'+id;
 };
 const links=(store,id,descriptors)=>{store[id]=descriptors;return descriptors.map(id=>claimDescriptors.find(c=>c.claimId===id)?.text??ledger.claims.find(c=>c.claimId===id)?.text);};
 const sections=[],freeSections=[];
 const learningContext=selected.some(r=>r.outputId==='learning')?n03LearningContext(snapshot,facts):null;
 for(const row of selected){
  const id='reading-'+row.outputId,original=reading.detailedSections.find(s=>s.id===id);
  const members=row.selected.map(id=>cards.get(id)),evidence=unique(members.flatMap(c=>c.evidenceIds)),counters=unique(members.flatMap(c=>c.counterEvidenceIds));
  const editorial=coalesceTopic(row,members,cards);
  // Refine this existing modern application only. An openly recorded peer
  // category is not a stronger role, an effective combination or a real coworker.
  // Hidden peer symbols alone do not satisfy this declared editorial condition.
  const peerContext=row.outputId==='supported-authority'?counters.filter(id=>{
   const f=facts.get(id),position=/^visible-relationship:(year|month|hour)$/.exec(id)?.[1];
   return position&&snapshot.chart.pillars[position]!=null&&f?.kind==='visible-relationship'&&family(f)==='peer';
  }).sort():[];
  const application=peerContext.length?{applicationVersion:'jm-authority-peer-context-v1',contextFactIds:peerContext,traditionalInferenceApproved:false}:{};
  if(peerContext.length){
   evidence.push(...peerContext);
   editorial.brief='You may find a shared responsibility easier to carry when other people’s contributions are agreed as clearly as your own. This reading brings responsibility, support and shared participation together: being answerable for the result is different from being able to supply every part yourself.';
   editorial.detail='Here the responsibility-and-support theme is joined by a shared-participation theme. Jade’s contemporary application is to distinguish help you can arrange from work another person must agree to deliver. In a joint task, doing more yourself can keep things moving briefly while leaving the handoff unresolved.';
   editorial.qualifier='A delayed contribution may reflect a missing agreement, a competing priority or a genuine obstacle. Check what happened before treating it as unwillingness to help. The chart does not tell you which explanation is true.';
   editorial.scope='Use this angle when a result really depends on shared inputs. If you already have the support and authority you need and can complete the task yourself, the shared-participation question may add little.';
   const columns=unique(peerContext.map(id=>id.split(':')[1]));
   editorial.basis=groupingBasis['supported-authority']+' A peer-related symbol is also shown directly in the '+list(columns)+' '+(columns.length===1?'column':'columns')+'. Jade uses that additional category for the shared-participation application in this work chapter. Direct and hidden describe chart placement, not stronger or weaker influence; this grouping does not establish a real coworker or an actual dependency.';
   editorial.examples=[
    claim('supported-authority.peer-handoff','If you are preparing a client presentation and a colleague supplies the figures, separate the review you own from the accuracy they need to confirm. Agree when those figures will be ready and what you will do if they arrive late. Quietly absorbing their part may finish the slides while leaving the same handoff unclear next time.','modern-reflection',evidence,peerContext,application),
    claim('supported-authority.peer-priority','Suppose two people need the same person’s help at once. Asking that person to work harder does not settle which commitment should come first. Take the competing deadlines to whoever can set the priority, then check whether responsibility should move with the revised plan. This calls for resolving the commitment, rather than simply adding another reminder.','modern-reflection',evidence,peerContext,application)
   ];
   if(reading.preview?.sectionId===id){
    reading.preview.paragraph=claimDescriptors.find(c=>c.claimId===editorial.examples[0]).text;
    reading.previewSelection={...reading.previewSelection,evidenceIds:unique(evidence),reason:'actual responsibility-support application with stable visible-peer context'};
   }
  }
  const learning=row.outputId==='learning'?learningContext:null;
  if(learning){
   evidence.push(...learning.factIds);counters.push(...learning.qualifyingFactIds);Object.assign(application,learning.conditions);
   editorial.brief='You may want to understand a method well enough to explain it in your own words, while still wanting your answer to meet a clear standard. In this reading, learning is about deciding what needs to stay faithful to the method and where your own reasoning can take the lead.';
   editorial.detail='In Jade’s reading of this traditional combination, learning involves three different kinds of progress: following a method, explaining why it works, and answering what was actually asked. None automatically supplies the other two. The distinction is whether the task calls for a faithful demonstration or a reasoned revision.';
   editorial.qualifier='A method can give your thinking a starting point without supplying your final explanation. An explanation that feels convincing to you can also leave the requirement unanswered. Reading these together keeps the theme from becoming either “trust the instructions” or “always do it your way.”';
   editorial.scope='This angle concerns the choice between demonstrating a method and questioning its fit. When the basic steps are still unfamiliar, understanding them comes first; the chart does not establish your level of knowledge.';
   editorial.basis='Month Yi in Mao is the chart’s receiving-and-support role; year Gui is a requirement role, and hour Wu is an expression role. Jade reads those three together for this limited learning interpretation. It is a declared contemporary application, not a completed traditional pattern that uses expression to balance support.';
   editorial.examples=[
    claim('learning.faithful-method','If a course asks you to demonstrate a named technique, explain why each step matters while keeping the technique intact. An original shortcut might produce a good answer yet fail to show the particular understanding being assessed. Here, keeping the method is part of showing your judgment, rather than evidence that you lack it.','modern-reflection',evidence,counters,application),
    claim('learning.reasoned-revision','An open-ended investigation asks for a different decision. If the usual method leaves part of the question unexplained, make that limit explicit and show what your alternative accounts for. Repeating the method more accurately would not answer that criticism. In this situation, the explanation can change while the standard—making a clear, checkable case—remains.','modern-reflection',evidence,counters,application)
   ];
   if(reading.preview?.sectionId===id){reading.preview.paragraph=claimDescriptors.find(c=>c.claimId===editorial.examples[0]).text;reading.previewSelection={...reading.previewSelection,evidenceIds:unique(evidence),reason:'actual limited N03 guidance-expression-requirement interpretation'};}
  }
  const why=learning?'Jade selects this theme because this chart brings receiving guidance, expressing your reasoning and answering to a requirement together.':reasonForTopic(row);
  if(!why)throw new RangeError('READING_PLAIN_REASON_MISSING');
  const connection=claim(row.outputId+'.connection',editorial.basis,'structural-observation',evidence,[],{memberIds:row.selected,stablePositionsOnly:true,classificationExplanation:true,...application});
  const question=claim(row.outputId+'.questions',editorial.detail,'modern-reflection',evidence,counters,{memberIds:row.selected,traditionalInferenceApproved:false,coalescer:'jm-topic-coalescer-v1',...application});
  const opening=claim(row.outputId+'.opening',firstSentence(editorial.brief)+' '+why,'modern-reflection',evidence,counters,{memberIds:row.selected,meaningFirst:true,classificationExplanation:true,...application});
  const retained=editorial.examples;
  const qualifierIds=counters.length?[claim(row.outputId+'.qualifying-question',editorial.qualifier,'modern-reflection',evidence,counters,{memberIds:row.selected,qualifierOnly:true,notTraditionalCancellation:true,...(learning?application:{})})]:[];
  const boundary=claim(row.outputId+'.scope',editorial.scope,'modern-reflection',evidence,counters,{memberIds:row.selected,scopeOnly:true,...(learning?application:{})});
  const basis=[connection,...qualifierIds,...(learning?[claim('learning.method-context','Year Gui/hour Wu and month Mao/hour Xu are recorded pairs. Neither is assumed to remove or transform a role. The primary source distinguishes an officer-present route from an expression-using route, with strength conditions for the latter that are not established here. Other known hidden support, constraint and resource roles remain in context; this comparison does not decide overall strength or a favorable element.','structural-observation',evidence,counters,application)]:[])];
  basisLinks[id]=basis;
  const chartBasis={title:'Why this topic appears',paragraphs:basis.map(id=>claimDescriptors.find(c=>c.claimId===id).text),...(learning?{sources:[{title:'Zi Ping Zhen Quan — 三十五、論印綬 (primary and Xu commentary distinguished)',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_034.htm'}]}:{})};
  sections.push({...original,paragraphs:links(detailLinks,id,[opening,...retained,question,boundary]),chartBasis});
  const freeCore=claim(row.outputId+'.free-core',editorial.brief+' '+why,'modern-reflection',evidence,[],{memberIds:row.selected,projection:'free-core',sourceClaimIds:[connection,question],coalescer:'jm-topic-coalescer-v1',...application});
  const glimpse=retained.length?claim(row.outputId+'.free-situation',firstSentence(claimDescriptors.find(c=>c.claimId===retained[0])?.text??ledger.claims.find(c=>c.claimId===retained[0]).text)+' '+editorial.scope,'modern-reflection',evidence,counters,{memberIds:row.selected,projection:'free-situation',scopeOnly:true,...application}):boundary;
  freeSections.push({...original,paragraphs:links(freeLinks,id,[freeCore,glimpse]),chartBasis});
 }
 // Shared evidence is one connection, not multiple independent validations.
 const connections=[];
 for(const name of ['output','resource','peer','managed','constraint']){
  const shared=[...facts.values()].filter(f=>family(f)===name&&selected.filter(r=>r.selected.some(id=>cards.get(id).evidenceIds.includes(f.factId))).length>1);
  if(!shared.length)continue;
  const factIds=shared.map(f=>f.factId).sort();
  const memberIds=unique(selected.flatMap(r=>r.selected.filter(id=>cards.get(id).evidenceIds.some(fid=>factIds.includes(fid)))));
  connections.push({family:name,domains:unique(selected.filter(r=>r.selected.some(id=>memberIds.includes(id))).map(r=>r.domain)),memberIds,factIds});
 }
 // One connecting thread keeps the overview readable. This explicit editorial
 // order is not a strength score or a claim of traditional importance.
 const focus=connections[0];
 const overviewText=focus?'This reading brings together '+list(focus.memberIds.map(id=>({craft:'room to improve an approach',learning:learningContext?'understanding a method for yourself':'learning you can put to use','ideas-value':'giving without losing sight of your limits','shared-money':'clear shared commitments','patient-craft':'care in familiar work','supported-authority':'responsibility you can genuinely carry','care-boundaries':'care that leaves room for your own needs','mutual-space':'closeness with individual space','equal-voice':'a voice in shared decisions'})[id]))+'. These are connected tensions to explore, rather than a single description of who you are.':
  selected.length?'The available symbols support the questions listed below. Each chapter identifies its own chart connection; none is declared your dominant trait.':'The stable chart information does not establish a supported pairing for these topics. No personality profile is substituted.';
 const overview={id:'reading-overview',title:'Your reading at a glance',chapterIndex:0,paragraphs:links(detailLinks,'reading-overview',[claim('overview.connections',overviewText,'editorial-synthesis',focus?.factIds??[],[],{sharedConnections:focus?[focus]:[],importanceRanking:false})])};
 freeLinks[overview.id]=detailLinks[overview.id];
 let culturalFree=null,culturalDetail=null;
 if(cultural.status==='supported-cultural-structure'){
  const culturalClaim=(name,text,layer='traditional-cultural-interpretation',ids=cultural.evidenceIds)=>{
   const id='culture.'+cultural.ruleId+'.'+name;
   claimDescriptors.push({claimId:id,text,status:layer==='traditional-cultural-interpretation'?'private-source-bounded-cultural-interpretation':layer==='modern-reflection'?'private-modern-application':'declared-conditional-structure',layer,sourceRefs:cultural.sourceRefs,
    evidenceIds:ids,counterEvidenceIds:cultural.counterEvidenceIds??[],conditions:{...cultural.conditions,formalVerdict:false},
   sourceExplanation:{kind:layer==='modern-reflection'?'original-everyday-application':layer==='structural-context'?'conditional-structure-or-limit':'original-cultural-translation-of-conditional-structure',traditionalDomainInference:layer==='traditional-cultural-interpretation'?'bounded-cultural-interpretation-only':'not-a-personal-method-verdict',professionalApproval:false,...(cultural.id==='reading-yi-root-context'?{effectiveRootUnderInteraction:'unassessed'}:cultural.id===JIA_YIN_SECTION?{effectiveRootSupport:'unassessed',workApplication:'contemporary'}:{operativeNoninterference:'unassessed'})}});
   return id;
  };
  overview.paragraphs=links(detailLinks,overview.id,[culturalClaim('overview',cultural.overview+(sections.length?' The other topic chapters explore everyday applications.':''),'traditional-cultural-interpretation',cultural.overviewEvidenceIds??cultural.evidenceIds)]);
  freeLinks[overview.id]=detailLinks[overview.id];
  const basisParagraphs=cultural.basisParagraphs??[cultural.basis];
  basisLinks[cultural.id]=basisParagraphs.map((text,i)=>culturalClaim(i?'basis-'+i:'basis',text,'structural-context',cultural.basisParagraphEvidenceIds?.[i]??cultural.evidenceIds));
  const chartBasis={title:'Why this topic appears',paragraphs:basisParagraphs,...(cultural.basisSources?{sources:cultural.basisSources}:{})};
  reading.coverage.culturalInterpretation={sectionId:cultural.id,...(cultural.kind?{kind:cultural.kind}:{}),...(cultural.previewScope?{previewScope:cultural.previewScope}:{}),...(cultural.deliveryCapabilities?{deliveryCapabilities:cultural.deliveryCapabilities}:{})};
  culturalFree={id:cultural.id,title:cultural.title,chapterIndex:0,paragraphs:links(freeLinks,cultural.id,cultural.freeParagraphs.map((text,i)=>culturalClaim('free-'+i,text,cultural.freeLayers[i],cultural.freeParagraphEvidenceIds?.[i]??cultural.evidenceIds))),chartBasis};
  culturalDetail={id:cultural.id,title:cultural.title,chapterIndex:0,paragraphs:links(detailLinks,cultural.id,cultural.detailedParagraphs.map((text,i)=>culturalClaim('detail-'+i,text,cultural.detailedLayers[i],cultural.detailedParagraphEvidenceIds?.[i]??cultural.evidenceIds))),chartBasis};
  {const previewIndex=cultural.previewParagraphIndex??1;if(!Number.isInteger(previewIndex)||!cultural.detailedParagraphs[previewIndex]?.trim())throw new RangeError('PREVIEW_SECTION_UNAVAILABLE');reading.preview={title:'A closer look inside the detailed reading',...reading.preview,sectionId:cultural.id,paragraph:cultural.detailedParagraphs[previewIndex]};reading.previewSelection={policyVersion:'jm-source-bounded-cultural-preview-v1',outputEntryId:cultural.id,sourceEntryId:cultural.ruleId,evidenceIds:cultural.evidenceIds,reason:'actual structural explanation from included cultural chapter',uniqueAcrossChartsRequired:false};}
 }
 if(entryScope&&!selected.length&&cultural.status!=='supported-cultural-structure'){const id=claim('entry-only-overview','A traditional starting category can be identified from the stable day and month. This draft has not established the additional conditions needed for its individual interpretation, and the available input does not support the everyday topic chapters. No personality profile has been substituted.','coverage-or-education',reading.interpretationProfile.entry.evidenceIds,[],{branchId:reading.interpretationProfile.branchId,startingCategoryOnly:true});overview.paragraphs=links(detailLinks,overview.id,[id]);freeLinks[overview.id]=detailLinks[overview.id];}
 const distinctions={craft:'A proposed improvement needs a test against the actual requirement',learning:'A gap in understanding needs a first attempt and useful feedback','ideas-value':'A changed request needs a decision about scope and resources','shared-money':'Shared ownership needs an agreement about contributions and decisions','patient-craft':'Inconsistent quality in familiar work needs a process you can check','supported-authority':'A responsibility you cannot carry needs the missing permission, knowledge or help identified','care-boundaries':'Uneven practical care needs a request that both people can discuss','mutual-space':'Separate interests need room alongside visible shared commitments','equal-voice':'A joint task needs clear decision rights'};
 if(learningContext)distinctions.learning='The learning question is whether the task calls for demonstrating a method or explaining why it needs revision';
 // One declared cross-theme application, not another traditional verdict.
 // Both shared connections and the actually selected chapters are required:
 // a useful trial is not automatically a promise to supply shared resources.
 const trialMembers=['craft','learning','ideas-value'],jointMembers=['shared-money','equal-voice'];
 const trialConnection=connections.find(c=>c.family==='output'&&trialMembers.every(id=>c.memberIds.includes(id)));
 const jointConnection=connections.find(c=>c.family==='peer'&&jointMembers.every(id=>c.memberIds.includes(id)));
 const trialBridge=selected.some(r=>r.outputId==='money-exchange')&&selected.some(r=>r.outputId==='learning')&&selected.some(r=>r.outputId==='equal-voice')&&selected.some(r=>r.domain==='work'&&r.selected.includes('craft'))&&trialConnection&&jointConnection;
 const integrationDecision=trialBridge?{ruleId:'jm-cross-theme-trial-commitment-v1',layer:'original-modern-editorial-synthesis',traditionalInferenceApproved:false,
  memberIds:[...trialMembers,...jointMembers],sharedFactIds:unique([...trialConnection.factIds,...jointConnection.factIds]).sort(),
  factIds:unique([...trialMembers,...jointMembers].flatMap(id=>cards.get(id).evidenceIds)).sort(),
  requiredSections:selected.filter(r=>r.domain==='work'||['learning','money-exchange','equal-voice'].includes(r.outputId)).map(r=>'reading-'+r.outputId)}:null;
 const togetherText=integrationDecision?['A first version can teach you something without being ready for someone else to rely on. In this combination, feedback and commitment need separate boundaries. A change may improve the result while also requiring more time, materials or approval from people who share the work. That improvement does not automatically expand their agreement. An experiment can be ready for review while a shared task is not ready to grow. This is the tension linking the work, learning and shared-resource themes: making the work better and deciding what everyone has promised are related decisions, but one cannot stand in for the other.']:
  focus?[focus.memberIds.map(id=>distinctions[id]+'.').join(' ')+' These are different responses. Before adding effort, check which situation is actually present; the shared chart connection does not make one response suitable for all of them.']:[];
 const together=reading.detailedSections.find(s=>s.id==='reading-together');
 const learningIntegration=learningContext&&!integrationDecision&&focus?.memberIds.includes('learning')?learningContext:null;
 const combined=together&&togetherText.length?{...together,title:'How these questions connect',paragraphs:links(detailLinks,together.id,togetherText.map((text,i)=>claim('integration.'+i,text,'editorial-synthesis',learningIntegration?unique([...focus.factIds,...learningIntegration.factIds]):integrationDecision?.factIds??focus.factIds,learningIntegration?.qualifyingFactIds??[],{sharedConnection:focus,importanceRanking:false,...(integrationDecision?{integrationDecision}: {}),...(learningIntegration?learningIntegration.conditions:{})})))}:null;
 // Preserve older supplementary notes internally; the selected ZP profile,
 // not these notes, supplies the reader-facing method explanation below.
 const methodContext=buildMethodContext(snapshot);
 const contextId='plan.method-context.M-CONTEXT-01',guardId='plan.method-guard.M-GUARD-01';
 const methodClaim=(id,text,status,sourceId,ids,conditions)=>claimDescriptors.push({claimId:id,text,status,layer:'structural-context',sourceRefs:[sourceId],
  evidenceIds:unique(ids),counterEvidenceIds:[],conditions,sourceExplanation:{kind:'draft-source-specific-traditional-context',professionalApproval:false,sourceClass:methodContext.sourceClass}});
 methodClaim(contextId,methodContext.text,methodContext.status,methodContext.sourceId,methodContext.matches.flatMap(m=>m.evidenceIds),{
  methodId:methodContext.methodId,exactCharacterOnly:true,matches:methodContext.matches,missingPositions:methodContext.missingPositions,dayStemPolicy:methodContext.dayStemPolicy});
 methodClaim(guardId,methodContext.guard.text,'active-limitation',methodContext.guard.sourceId,
  snapshot.derived.facts.filter(f=>['month-relation','exact-root','phase-root'].includes(f.kind)).map(f=>f.factId),
  {methodId:methodContext.guard.methodId,overallStrength:'unassessed',requiredBeforeConclusion:methodContext.guard.requiredBeforeConclusion});
 const profile=reading.interpretationProfile;if(!profile)throw new RangeError('SELECTED_INTERPRETATION_PROFILE_REQUIRED');
 const profileIds=profile.paragraphs.map(p=>{const id='profile.'+profile.profileId+'.'+p.id;
  claimDescriptors.push({claimId:id,text:p.text,status:p.kind==='declared-framework-entry'?'source-supported-limited-entry':'declared-profile-context',layer:'structural-context',
   sourceRefs:p.sourceRefs,evidenceIds:p.evidenceIds,counterEvidenceIds:[],conditions:{profileId:profile.profileId,profileVersion:profile.profileVersion,branchId:profile.branchId,branchStatus:profile.status,claimKind:p.kind,scope:'entry-and-context-only',formalVerdict:false},
   sourceExplanation:{kind:p.kind,primaryMethod:'Zi Ping Zhen Quan month-led profile',commentary:'separate comparison only',professionalApproval:false}});return id;});
 const sourceIds=new Set(profile.paragraphs.flatMap(p=>p.sourceRefs));
 const methodSources=[...new Map(ZP_PROFILE_SOURCES.filter(s=>s.url&&sourceIds.has(s.id)).map(({source,url})=>[source+'|'+url,{title:source,url}])).values()];
 let monthPeerFree=null,monthPeerDetail=null;
 if(monthPeerContext.status==='supported-structural-context'&&!(cultural.ruleId===n10.ruleId&&cultural.status==='supported-cultural-structure')){
  const descriptor=row=>{const id='structure.'+monthPeerContext.ruleId+'.'+row.id;claimDescriptors.push({claimId:id,text:row.text,layer:row.layer??'structural-context',status:row.layer==='modern-reflection'?'private-modern-application':'declared-conditional-structure',sourceRefs:monthPeerContext.sourceRefs,evidenceIds:row.requires,counterEvidenceIds:[],conditions:{entryPair:monthPeerContext.entry.pair,componentVersion:monthPeerContext.ruleId,formalVerdict:false,sourcePaths:[...monthPeerContext.entry.sourcePaths,...row.requires.map(id=>'snapshot.derived.facts[factId='+id+']')],notANewLifeDomain:true},sourceExplanation:{kind:row.layer==='modern-reflection'?'attributed-contemporary-learning-analogy':'bounded-original-English-structural-comparison',primary:'chapter45 primary regular route and conditional exception; root and capacity remain distinct',commentary:'not merged into rule',effectiveMediation:'unassessed',professionalApproval:false}});return id;};
  const basisId=descriptor({id:'basis',text:monthPeerContext.basis,requires:monthPeerContext.application?.evidenceIds??monthPeerContext.entry.evidenceIds});basisLinks[monthPeerContext.id]=[basisId];
  const chartBasis={title:'Why this topic appears',paragraphs:[monthPeerContext.basis],sources:monthPeerContext.basisSources};
  monthPeerFree={id:monthPeerContext.id,title:monthPeerContext.title,chapterIndex:0,paragraphs:links(freeLinks,monthPeerContext.id,monthPeerContext.freeRows.map(descriptor)),chartBasis};
  monthPeerDetail={id:monthPeerContext.id,title:monthPeerContext.title,chapterIndex:0,paragraphs:links(detailLinks,monthPeerContext.id,monthPeerContext.detailRows.map(descriptor)),chartBasis};
  reading.coverage.structuralSupplement={sectionId:monthPeerContext.id,ruleId:monthPeerContext.ruleId,entryPair:monthPeerContext.entry.pair,newLifeDomain:false,...(monthPeerContext.application?{kind:monthPeerContext.application.kind}: {})};
  if(monthPeerContext.application)reading.coverage.domains.find(d=>d.domain==='learning').detail='No complete personal learning chapter is supported by the current method. A limited contemporary learning illustration is included in the chart-context interpretation.';
  if(!selected.length){const id=descriptor({id:'overview',text:monthPeerContext.overview??'This reading offers a limited comparison of the roles recorded in your chart and explains which conditions are still open. It does not replace the missing life-topic chapters with a personality profile.',requires:monthPeerContext.application?.evidenceIds??monthPeerContext.entry.evidenceIds});overview.paragraphs=links(detailLinks,overview.id,[id]);freeLinks[overview.id]=detailLinks[overview.id];}
  if(!reading.preview){const row=monthPeerContext.detailRows.find(r=>r.id===(monthPeerContext.application?'source-route':'observed-layers'));reading.preview={title:'A closer look inside the detailed reading',sectionId:monthPeerContext.id,paragraph:row.text};reading.previewSelection={policyVersion:'jm-structural-context-preview-v1',outputEntryId:monthPeerContext.id,sourceEntryId:monthPeerContext.ruleId,evidenceIds:row.requires,reason:'actual conditional comparison, not a new life topic',uniqueAcrossChartsRequired:false};}
 }
 const withheldJiaYin=profile.branchId===JIA_YIN_BRANCH&&profile.coreRoute.status!=='supported-cultural-structure';
 const entryBodyNotice=entryScope?entryScope.bodyNotice+(withheldJiaYin?(reading.coverage.domains.find(d=>d.domain==='work')?.status==='interpreted'?' The work chapter in this report is a separate contemporary reflection; it does not establish or replace the withheld traditional interpretation.':' No separate contemporary work chapter is included in this report.'):''):null;
 const includedRows=reading.coverage.domains.filter(d=>d.status==='interpreted'),unsupportedRows=reading.coverage.domains.filter(d=>d.status==='method-not-supported'),uncertainRows=reading.coverage.domains.filter(d=>d.status==='input-insufficient');
 const coverageCopy=[...includedRows.map(d=>d.label+' — '+(cultural.kind==='n10-aims-means'&&d.sectionId===cultural.id?'One limited theme: ':'')+reading.detailedSections.concat(sections,culturalDetail?[culturalDetail]:[]).find(s=>s.id===d.sectionId)?.title+(d.partialNotice?' '+d.partialNotice:'')),...(unsupportedRows.length?['Not covered by this reading: '+list(unsupportedRows.map(d=>d.label.toLowerCase()))+'.']:[]),...(uncertainRows.length?['Left open because birth information is uncertain: '+list(uncertainRows.map(d=>d.label.toLowerCase()))+'. More precise input would not guarantee those chapters.']:[])];
 const meta=reading.detailedSections.filter(s=>['reading-coverage','reading-limits'].includes(s.id)).map(s=>s.id==='reading-coverage'?{...s,title:'Topics covered in this report',paragraphs:coverageCopy}:s.id==='reading-limits'?{...s,paragraphs:['BaZi is a traditional Chinese cultural framework. This reading is for cultural reflection and entertainment, not a scientific assessment or prediction. Whole-chart strength, a completed traditional pattern and favorable-element choices have not been established. Independent review is pending; this private draft is not for sale.',readingInputLimit(snapshot.chart),'Optional timing material separates a selected-year reflection, estimated cycle starts where supported, and a shared seasonal calendar.',...(withheldJiaYin?[entryBodyNotice]:[])],chartBasis:{
  title:'How this reading uses the tradition',paragraphs:profile.paragraphs.map(p=>p.text),
  sources:methodSources
 }}:s);
 basisLinks['reading-limits']=profileIds;
 if(entryScope&&cultural.status!=='supported-cultural-structure')for(const s of meta)if(s.id==='reading-coverage')s.paragraphs=[...s.paragraphs,entryScope.coverageNotice];
 const freeIds=reading.freeSections.map(s=>s.id);
 const freeMeta=meta.map(s=>s.id==='reading-coverage'?{...s,title:'Topics available in the detailed reading'}:s);
 if(culturalDetail&&!includedRows.some(d=>d.sectionId===culturalDetail.id))for(const s of [...meta,...freeMeta])if(s.id==='reading-coverage')s.paragraphs=[...s.paragraphs,cultural.coverageNotice??cultural.reportScope?.coverageNotice??('Traditional chart interpretation — Included: '+cultural.title+'. Effective pattern formation and priority between the two supports remain unassessed.')];
 if(cultural.status==='withheld-known-context'&&cultural.ruleId==='Jade-ZP-two-supports-cultural-reading-v1')for(const s of [...meta,...freeMeta])if(s.id==='reading-coverage')s.paragraphs=[...s.paragraphs,'Traditional chart interpretation — Left open: other relationships in the known chart need assessment before this particular two-support interpretation can be offered. The everyday topic chapters remain separate.'];
 if(monthPeerDetail)for(const s of [...meta,...freeMeta])if(s.id==='reading-coverage')s.paragraphs=[...s.paragraphs,monthPeerContext.scopeNotice];
 const contextOnly=monthPeerDetail&&monthPeerContext.entry.pair==='乙寅'&&reading.coverage.domains.every(d=>d.status!=='interpreted');
 if(contextOnly){
  const domains=reading.coverage.domains,allInput=domains.every(d=>d.status==='input-insufficient'),someInput=domains.some(d=>d.status==='input-insufficient');
  const summary=allInput?(snapshot.chart.status==='incomplete-time'?'Birth time is unknown.':'Some birth information remains uncertain.')+' This report provides a partial chart comparison, not personal-topic chapters. A more precise time would not guarantee those chapters.':someInput?'Some personal-topic chapters depend on unresolved birth information; others are not supported by the current method. Only a limited chart-context comparison is available.':monthPeerContext.application?'Only a limited chart-context explanation and one contemporary learning example are available. Complete personal-topic chapters are not supported for this chart.':'Only a limited chart-context comparison is available. The current method does not support complete personal-topic chapters for this chart.';
  const coverageParagraphs=[summary,...domains.map(d=>d.label+' — '+(d.status==='input-insufficient'?'Unresolved.':d.domain==='learning'&&monthPeerContext.application?'Example only; no full chapter.':'Not included.'))];
  const coverageIds=coverageParagraphs.map((text,i)=>claim('scope.compact-coverage-'+i,text,'coverage-or-education',[],[],{domainStatuses:domains.map(d=>({domain:d.domain,status:d.status})),newLifeDomain:false}));
  detailLinks['reading-coverage']=coverageIds;freeLinks['reading-coverage']=coverageIds;
  const about='BaZi is a traditional Chinese cultural framework, not a scientific assessment or prediction. This private draft is not for sale and still requires independent traditional review.';
  detailLinks['reading-limits']=[claim('scope.compact-about',about,'coverage-or-education')];freeLinks['reading-limits']=detailLinks['reading-limits'];
  const policyNotes=reading.detailedSections.find(s=>s.id==='reading-limits').paragraphs.slice(1),noteIds=policyNotes.map((text,i)=>claim('scope.input-method-note-'+i,text,'coverage-or-education',[],[],{inputStatus:snapshot.chart.status}));
  basisLinks['reading-limits']=[...profileIds,...noteIds];
  for(const s of new Set([...meta,...freeMeta]))if(s.id==='reading-coverage'){s.title='What this reading covers';s.paragraphs=coverageParagraphs;}else if(s.id==='reading-limits'){s.paragraphs=[about];s.chartBasis={...s.chartBasis,paragraphs:[...s.chartBasis.paragraphs,...policyNotes]};}
 }
 const free= [overview,...(culturalFree?[culturalFree]:[]),...(monthPeerFree?[monthPeerFree]:[]),...freeSections.filter(s=>freeIds.includes(s.id)),...reading.freeSections.filter(s=>s.id==='reading-action'),...freeMeta];
 const detail=[overview,...(culturalDetail?[culturalDetail]:[]),...(monthPeerDetail?[monthPeerDetail]:[]),...sections,...(combined?[combined]:[]),...reading.detailedSections.filter(s=>s.id==='reading-action'),...meta];
 return {version:REPORT_PLAN_VERSION,claimDescriptors,detailLinks,freeLinks,basisLinks,methodContext,culturalReading:cultural,yiRootContext,monthPeerContext,entryScope,sourceBoundedDomainDecisions,sharedConnections:connections,displayedConnection:cultural.status==='supported-cultural-structure'?{kind:cultural.id===MONTH_PEER_SECTION?'source-bounded-N10-resources':cultural.id==='reading-yi-root-context'?'source-bounded-yi-root-context':cultural.id===JIA_YIN_SECTION?'source-bounded-rooted-expression':'source-bounded-month-support',ruleId:cultural.ruleId,factIds:cultural.evidenceIds}:focus??null,displayPolicy:'bounded month-led interpretation when supported; other topics in editorial order, not a strength ranking',formalVerdicts:ledger.context.formalVerdicts,
  traditionalMethods:ledger.context.methodClaimIds.map(id=>({id,status:ledger.claims.find(c=>c.claimId===id).status})),editorialOrder:'existing domain reading order; no traditional importance ranking',freeSections:free,detailedSections:detail};
}
