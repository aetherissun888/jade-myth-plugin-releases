import {buildClaimLedger} from './claim-ledger.js';
import {buildReadingDeliverability} from './reading-deliverability.js';
import {assessRootAdmissibility} from './ziping-root-admissibility.js';
import {assessOfficerChain} from './ziping-officer-chain.js';
import {assessLifeRoutePremises} from './ziping-life-route-review.js';
import {buildEvidenceReportPlan,readingInputLimit,readingPreviewDescription} from './evidence-report-plan.js';
import {evaluateZipingMonthProfile} from './ziping-month-profile.js';
import {selectReadingThemes,readingSelectorMatches} from './reading-selection.js';
import {READING_CARDS,READING_COMPOSITIONS,READING_ACTIONS,READING_CONTENT_VERSION,READING_RULE_VERSION} from './reading-cards.js';
/** Versioned editorial composition over the existing chart evidence.
 * All output remains unreviewed/unpublishable; author JSON cannot approve itself.
 */
import {SOURCE_CATALOG} from '../foundation/source-catalog.js';
import {RULES,derive} from '../foundation/rules.js';
import {DOMAIN_RESEARCH_SOURCES} from './domain-sources.js';
export const DOMAIN_DRAFT_VERSION='jm-domain-review-pipeline-v1';
const domains=['relationships','career','resources'],positions=['year','month','day','hour'];
const families=['peer','resource','output','managed','constraint'];
const ruleIds=new Set(RULES.map(r=>r.id)),sourceIds=new Set([...SOURCE_CATALOG,...DOMAIN_RESEARCH_SOURCES].map(s=>s.sourceId));
const fields=['schemaVersion','id','domain','kind','requires','counterRuleIds','counterConditions','exclusions','sourceRefs','sourceLocator','methodProfile','body','reflection','reviewStatus'];
const tokens=['position','label','pinyin','direction'];
const plain=o=>o&&Object.getPrototypeOf(o)===Object.prototype;
const fail=code=>{throw new RangeError(code);};
const strings=a=>Array.isArray(a)&&a.every(x=>typeof x==='string')&&new Set(a).size===a.length;
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
function checkTemplate(text){
 if(typeof text!=='string'||!text.trim()||text.length>2000)fail('INVALID_DRAFT_TEXT');
 const found=[...text.matchAll(/\{([^{}]+)\}/g)].map(x=>x[1]);
 if(found.some(x=>!tokens.includes(x))||/[{}]/.test(text.replace(/\{[^{}]+\}/g,'')))fail('UNSUPPORTED_TEMPLATE_FIELD');
}
export function validateDomainEntry(e){
 if(!plain(e)||Object.keys(e).some(k=>!fields.includes(k))||fields.some(k=>!Object.hasOwn(e,k))||e.schemaVersion!=='jm-domain-entry-v1'||!/^draft-[a-z0-9-]+$/.test(e.id)||!domains.includes(e.domain)||!['reflection-prompt','traditional-interpretation'].includes(e.kind))fail('INVALID_DOMAIN_ENTRY');
 if(e.reviewStatus!=='pending')fail('UNVERIFIED_REVIEW_STATUS');
 if(!strings(e.counterConditions)||!strings(e.counterRuleIds)||e.counterRuleIds.some(x=>!ruleIds.has(x))||!strings(e.exclusions)||e.exclusions.some(x=>x!=='unstable-required-position')||!strings(e.sourceRefs)||e.sourceRefs.some(x=>!sourceIds.has(x)))fail('INVALID_DRAFT_BASIS');
 const r=e.requires;
 if(!plain(r)||Object.keys(r).some(k=>!['stablePositions','fact','ruleIds'].includes(k))||!strings(r.stablePositions)||!r.stablePositions.includes('day')||r.stablePositions.some(p=>!positions.includes(p))||!strings(r.ruleIds)||r.ruleIds.some(x=>!ruleIds.has(x)))fail('INVALID_DRAFT_REQUIREMENTS');
 const f=r.fact;
 if(!plain(f)||Object.keys(f).some(k=>!['kind','position','family'].includes(k))||f.kind!=='visible-relationship'||!['year','month','hour'].includes(f.position)||!r.stablePositions.includes(f.position)||!families.includes(f.family))fail('UNSUPPORTED_FACT_SELECTOR');
 if(!e.sourceRefs.includes('S-TEN')||typeof e.sourceLocator!=='string'||!e.sourceLocator.trim()||typeof e.methodProfile!=='string'||!e.methodProfile.trim())fail('MISSING_SOURCE_OR_METHOD');
 checkTemplate(e.body);if(e.reflection!==null)checkTemplate(e.reflection);return e;
}
export function compileDomainDrafts(entries,snapshot){
 if(!Array.isArray(entries)||entries.length>100||!snapshot||snapshot.schemaVersion!=='jm-foundation-schema-v1'||snapshot.ruleVersion!=='jm-foundation-probe-v2'||!Array.isArray(snapshot.derived?.facts)||!Array.isArray(snapshot.findings)||!snapshot.chart?.pillars)fail('UNSUPPORTED_DRAFT_CONTEXT');
 entries.forEach(validateDomainEntry);if(new Set(entries.map(e=>e.id)).size!==entries.length)fail('DUPLICATE_DRAFT_ID');
 const findings=new Map(snapshot.findings.map(f=>[f.ruleId,f]));
 const output=entries.map(e=>{
  const base={entryId:e.id,domain:e.domain,kind:e.kind,reviewStatus:'pending',eligibleForPublic:false};
  // A numerical table source is not permission/evidence for a life-domain claim.
  if(e.kind==='traditional-interpretation')return {...base,status:'blocked-method-review',paragraphs:[],evidenceIds:[],draftForReview:{body:e.body,sourceRefs:e.sourceRefs,sourceLocator:e.sourceLocator,methodProfile:e.methodProfile,requires:e.requires,counterConditions:e.counterConditions},requiredNext:['source-specific-method-and-conditions','counterconditions-and-independent-review','approved-domain-text']};
  const missing=e.requires.stablePositions.filter(p=>snapshot.chart.pillars[p]==null);
  if(missing.length)return {...base,status:'insufficient-input',missingPositions:missing,paragraphs:[],evidenceIds:[]};
  const required=e.requires.ruleIds.map(id=>findings.get(id));
  if(required.some(f=>!f||f.status==='insufficient'))return {...base,status:'insufficient-evidence',paragraphs:[],evidenceIds:[]};
  const selector=e.requires.fact,facts=snapshot.derived.facts.filter(f=>f.kind===selector.kind&&f.positions.includes(selector.position)&&f.value.family===selector.family);
  if(required.some(f=>f.status!=='supported')||!facts.length)return {...base,status:'not-applicable',paragraphs:[],evidenceIds:[]};
  const fact=facts[0],r=fact.value;
  if(facts.length!==1||!fact.sourceRefs.includes('S-TEN')||!['label','pinyin','direction'].every(k=>typeof r[k]==='string')||!required.some(f=>f.evidenceIds.includes(fact.factId)))fail('INVALID_FACT_BASIS');
  const context={position:selector.position,label:r.label,pinyin:r.pinyin,direction:r.direction};
  const render=text=>text.replace(/\{([^{}]+)\}/g,(_,k)=>context[k]);
  const counters=e.counterRuleIds.flatMap(id=>{const f=findings.get(id);return f?.status==='supported'?f.evidenceIds:[];});
  return {...base,status:'internal-draft',personalization:'calculated fact context only; shared editorial prompt',paragraphs:[render(e.body),...(e.reflection?[render(e.reflection)]:[])],evidenceIds:[fact.factId],fieldDependencies:fact.fieldDependencies,sourceRefs:fact.sourceRefs,sourceLocator:e.sourceLocator,methodProfile:e.methodProfile,counterEvidenceIds:[...new Set(counters)],counterConditions:e.counterConditions,counterHandling:'retain-for-review; no automatic cancellation or outcome verdict',unresolvedCounterRules:e.counterRuleIds.filter(id=>findings.get(id)?.status==='insufficient')};
 });
 return freeze({pipelineVersion:DOMAIN_DRAFT_VERSION,status:'internal-review-only',eligibleForPublic:false,ruleVersion:snapshot.ruleVersion,contentVersion:snapshot.contentVersion,entries:output});
}

/** Private customer-reading candidate, not an approval of traditional judgments.
 * Uses only facts in the captured snapshot. Positive matches are required;
 * missing positions never become absence or an inferred birth time. */
export function compileReadingThemes(snapshot){
 if(snapshot?.schemaVersion!=='jm-foundation-schema-v1'||snapshot.ruleVersion!=='jm-foundation-probe-v2'||!snapshot.chart?.pillars||!Array.isArray(snapshot.derived?.facts)||!Array.isArray(snapshot.findings))fail('UNSUPPORTED_READING_CONTEXT');
 const facts=snapshot.derived.facts.filter(f=>f.positions.every(p=>snapshot.chart.pillars[p]!=null));
 const relation=f=>f.kind==='hidden-relationship'?f.value.relation:f.value;
 // A range/term minute already retains exhaustive paired chart alternatives.
 // Derive table facts from those retained symbols only: no calendar/time lookup,
 // guessed hour, crossed year/month combinations or new interpretation rule.
 const chart=snapshot.chart;
 const retained=chart.status==='range-time'?chart.candidatePillars:
  chart.status==='boundary-minute'?chart.yearMonthOptions?.map(ym=>({...chart.pillars,...ym})):null;
 const candidateFacts=retained?.length?retained.map(pillars=>{
  if(['year','month','day','hour'].some(k=>typeof pillars[k]!=='string'||(chart.pillars[k]!=null&&chart.pillars[k]!==pillars[k])))fail('RETAINED_READING_CANDIDATE_DRIFT');
  return derive({...chart,pillars}).facts;
 }):null;
 const selections=READING_CARDS.map(card=>{
  const matched=card.selectors.map(selector=>facts.filter(f=>readingSelectorMatches(f,selector)));
  const base={entryId:card.id,domain:card.domain,selectors:card.selectors,reviewStatus:'pending',sourceRefs:['S-HIDDEN','S-TEN','C-SM-V5-NAMES'],sourceLocator:'San Ming Tong Hui vol.5, naming analogies only; original modern English editorial application',methodProfile:READING_RULE_VERSION,interpretationBoundary:card.bridge,counterCondition:card.counterCondition};
  if(matched.some(a=>!a.length)){
   // Exhaustive alternatives must satisfy all predicates within one chart.
   // Any possible match stays withheld under the stable-facts-only policy,
   // including matches in every candidate. Unknown time has no exhaustive
   // list. One unknown position can supply several absent predicates together,
   // even with no prior match. This fallback stays conservatively unresolved;
   // it does not prove a feasible completion or promote an interpretation.
   const absent=card.selectors.filter((_,i)=>!matched[i].length);
   const compatible=candidateFacts?.map((list,index)=>({index,matches:card.selectors.every(q=>list.some(f=>readingSelectorMatches(f,q)))}));
   const inputCouldChange=compatible?compatible.some(c=>c.matches):absent.every(q=>snapshot.derived.missing.some(p=>!q.position||q.position===p));
   return {...base,status:inputCouldChange?'not-established-from-stable-input':'not-applicable',evidenceIds:[],counterEvidenceIds:[],
    ...(compatible?{retainedCandidateCheck:{policy:'all-predicates-within-one-retained-chart-v1',candidates:compatible.length,satisfyingCandidates:compatible.filter(c=>c.matches).map(c=>c.index),interpretationPromoted:false}}:{})};
  }
  const supporting=[...new Map(matched.flat().map(f=>[f.factId,f])).values()];
  if(supporting.some(f=>!f.sourceRefs?.includes('S-TEN')||(f.kind==='hidden-relationship'&&!f.sourceRefs.includes('S-HIDDEN'))))fail('READING_SOURCE_BASIS_MISSING');
  const counters=facts.filter(f=>['visible-relationship','hidden-relationship'].includes(f.kind)&&card.counterFamilies.includes(relation(f)?.family));
  return {...base,status:'private-editorial-candidate',title:card.title,paragraphs:[...card.paragraphs,...(counters.length?[card.counterParagraph]:[])],evidenceIds:supporting.map(f=>f.factId),counterEvidenceIds:counters.map(f=>f.factId),fieldDependencies:[...new Set(supporting.flatMap(f=>f.fieldDependencies))],conflictHandling:'Retain counterevidence and scope limitation; no automatic cancellation, strength score or verdict.',unresolvedPositions:[...snapshot.derived.missing]};
 });
 const selection=selectReadingThemes(selections,READING_CARDS,READING_COMPOSITIONS);
 const themes=selection.selected,chosen=new Map(themes.map(t=>[t.domain,t]));
 const freeThemes=['work','money','relationships'].map(d=>chosen.get(d)).filter(Boolean);
 for(const theme of themes)if(freeThemes.length<3&&!freeThemes.includes(theme))freeThemes.push(theme);
 // The source-bounded plan below replaces the former four editorial summary branches.
 const tradeoff=null;
 const synthesisBasis=tradeoff?{themeIds:themes.map(t=>t.entryId),evidenceIds:[...new Set(themes.flatMap(t=>t.evidenceIds))],counterEvidenceIds:[...new Set(themes.flatMap(t=>t.counterEvidenceIds))],kind:'original-modern-cross-theme-reflection',formalMethodVerdict:false}:null;
 const summary={id:'reading-overview',title:'Your reading at a glance',chapterIndex:0,paragraphs:[
  tradeoff?tradeoff[0]:themes.length?`This reading connects ${themes.slice(0,3).map(t=>t.title.toLowerCase()).join('; ')}. The sections explore different questions raised by those combinations, rather than treating one symbol as your whole personality.`:'The available chart does not establish a supported combination for these reading topics. No personality profile has been filled in to replace missing evidence.'
 ]};
 const domainNames={work:'Work',learning:'Learning',money:'Money and resources',relationships:'Close relationships',collaboration:'Collaboration'};
 const domains=Object.entries(domainNames).map(([domain,label])=>{
  const selected=chosen.get(domain),pending=selections.filter(t=>t.domain===domain&&t.status==='not-established-from-stable-input');
  const status=selected?'interpreted':pending.length?'input-insufficient':'method-not-supported';
  const detail=selected?`Included: ${selected.title}.`:
   status==='input-insufficient'?'Not interpreted: unresolved birth information may affect the conditions used for this topic. More precise input would not guarantee a reading.':'Not interpreted: the current reading method does not support a chapter for the available chart. This says nothing about whether this part of your life matters.';
  return {domain,label,status,sectionId:selected?'reading-'+selected.entryId:null,pendingEntryIds:pending.map(t=>t.entryId),detail,
   ...(selected&&pending.length?{partialNotice:'Only the supported theme is included; additional themes that depend on unresolved birth information are withheld.'}:{})};
 });
 const coverageSection={id:'reading-coverage',title:'Topics available in the detailed reading',chapterIndex:3,paragraphs:domains.map(d=>`${d.label} — ${d.detail}${d.partialNotice?' '+d.partialNotice:''}`)};
 const limits={id:'reading-limits',title:'About this reading',chapterIndex:3,paragraphs:[
  'BaZi is a traditional Chinese symbolic framework. These original cultural reflections are not a scientific assessment or a prediction. Independent traditional and English-language review is pending; this private candidate is not for sale.',
  readingInputLimit(snapshot.chart),
  'The optional timing view offers a selected-year reflection and, when the input supports it, estimated cycle starts. The shared seasonal calendar is a separate optional reference appendix. None supplies a completed personal forecast.'
 ]};
 const section=t=>({id:'reading-'+t.entryId,title:t.title,chapterIndex:['work','learning','collaboration'].includes(t.domain)?1:2,paragraphs:[...t.paragraphs]});
 const detailed=[summary,...themes.map(section)];
 if(themes.length>1)detailed.push({id:'reading-together',title:'Putting the themes to work',chapterIndex:2,paragraphs:tradeoff?[tradeoff[1]]:[
  `Start with the question in “${themes[0].title},” then compare it with “${themes[1].title}.” They need not describe the same part of your life. One may fit a current situation while the other offers little insight. Use that difference to focus the reading instead of stretching every paragraph to fit.`,
  'Choose one situation you can actually observe. Write down what happened, which part of the reading helped you understand it, and one alternative explanation. Then choose a small, reversible action. That keeps reflection connected to your experience rather than turning the chart into a fixed identity.'
 ]});
 const actionTheme=chosen.get('money')??chosen.get('work')??themes[0];
 const action=actionTheme?{id:'reading-action',title:'One thing to try',chapterIndex:2,paragraphs:[READING_ACTIONS[actionTheme.entryId]]}:null;
 if(action){if(typeof action.paragraphs[0]!=='string')fail('READING_ACTION_UNAVAILABLE');detailed.push(action);}
 detailed.push(coverageSection,limits);
 const free=[summary,...freeThemes.map(t=>({...section(t),paragraphs:[t.paragraphs[0]]})),...(action?[action]:[]),coverageSection,limits];
 const deeper=themes.find(t=>t.domain==='money')??themes[0];
 // Choose an excerpt that represents an actually supported question. The
 // combined money chapter has an ownership question absent from ideas-only
 // charts; source order/hash/chart identity do not create fake uniqueness.
 const excerptSource=deeper?.entryId==='money-exchange'?selections.find(t=>t.entryId==='shared-money'):deeper;
 const excerpt=excerptSource?.paragraphs[1];
 if(deeper&&(!excerpt||!deeper.paragraphs.includes(excerpt)))fail('READING_PREVIEW_BASIS_UNAVAILABLE');
 const previewSelection=deeper?{policyVersion:'jm-representative-preview-v1',outputEntryId:deeper.entryId,sourceEntryId:excerptSource.entryId,evidenceIds:excerptSource.evidenceIds,reason:deeper.entryId==='money-exchange'?'represent-supported-ownership-question-in-compatible-money-chapter':'represent-actual-supported-question',uniqueAcrossChartsRequired:false}:null;
 const preview=deeper?{title:'A closer look inside the detailed reading',sectionId:'reading-'+deeper.entryId,paragraph:excerpt}:null;
 const reading={schemaVersion:'jm-personal-reading-v2.1',contentVersion:READING_CONTENT_VERSION,ruleVersion:READING_RULE_VERSION,sourceRuleVersion:snapshot.ruleVersion,status:'private-review-candidate',eligibleForPublic:false,purchasable:false,professionalReview:'pending',synthesisBasis,previewSelection,selectionLedger:selection.ledger,selectionPolicyVersion:selection.policyVersion,actionBasis:actionTheme?{selectedEntryId:actionTheme.entryId,memberIds:actionTheme.memberIds,evidenceIds:actionTheme.evidenceIds}:null,themes:selections,freeSections:free,detailedSections:detailed,preview,coverage:{domains,includedDomains:themes.map(t=>t.domain),unresolvedCompositionDomains:selection.ledger.filter(l=>['unresolved-explicit-conflict','unreviewed-composition'].includes(l.reason)).map(l=>l.domain),unavailableDomains:['work','learning','money','relationships','collaboration'].filter(d=>!chosen.has(d)),timing:'not-in-this-reading; retained luck/annual reference modules require explicit integration and review',formalStrengthAndPattern:'withheld; no approved final judgment'}};
 const ledger=buildClaimLedger(snapshot,reading,READING_CARDS,READING_COMPOSITIONS);
 reading.rootSupportAssessment=assessRootAdmissibility(snapshot);
 reading.interpretationProfile=evaluateZipingMonthProfile(snapshot,ledger);
 reading.officerChain=assessOfficerChain(snapshot);
 reading.lifeRouteReview=assessLifeRoutePremises(snapshot);
 reading.reportPlan=buildEvidenceReportPlan(snapshot,reading,ledger);
 reading.freeSections=reading.reportPlan.freeSections;
 reading.detailedSections=reading.reportPlan.detailedSections;
 if(reading.preview)reading.preview.description=readingPreviewDescription(snapshot.chart,reading.coverage,reading.detailedSections,reading.freeSections);
 reading.synthesisBasis={kind:'source-bounded-shared-evidence',formalMethodVerdict:false,
  evidenceIds:[...new Set(reading.reportPlan.sharedConnections.flatMap(c=>c.factIds))],connections:reading.reportPlan.sharedConnections};
 reading.claimLedger=buildClaimLedger(snapshot,reading,READING_CARDS,READING_COMPOSITIONS);
 reading.deliveryCapabilities=buildReadingDeliverability(snapshot,reading);
 return freeze(reading);
}
