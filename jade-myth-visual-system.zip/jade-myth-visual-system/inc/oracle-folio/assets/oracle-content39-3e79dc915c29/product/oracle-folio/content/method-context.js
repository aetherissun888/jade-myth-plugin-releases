/** Narrow draft traditional context authorized by parent source review.
 * No chart calculation, commander-day table, formation or strength classifier. */
export const METHOD_CONTEXT_VERSION='jm-draft-method-context-v1';
export const METHOD_CONTEXT_SOURCES=Object.freeze([
 {id:'C-DTS-06-844363',source:'Di Tian Sui, formation chapter, commentary rather than original verse',url:'https://zh.wikisource.org/w/index.php?title=滴天髓/06&oldid=844363',locator:'格局注文：月支之神，透於天干也',supports:'draft exact-character correspondence context only',doesNotSupport:'commander day, effective root, formed pattern, strength, personality or life outcome',reviewStatus:'parent primary-method check supplied; this task web retrieval unavailable; digital transcription not facsimile collation'},
 {id:'C-DTSCW-2600158',source:'Di Tian Sui Chan Wei, prosperity/decline, Ren commentary',url:'https://zh.wikisource.org/w/index.php?title=滴天髓闡微&oldid=2600158',locator:'衰旺，任氏曰：rejects treating all timely charts as strong and all untimely charts as weak',supports:'guard against a season-only strength conclusion',doesNotSupport:'complete qualitative support rubric, balancing recommendation or a middle/default strength',reviewStatus:'parent primary-method check supplied; this task web retrieval unavailable; original verse/commentary/modern explanation kept distinct'}
].map(Object.freeze));
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
export function buildMethodContext(snapshot){
 if(snapshot?.schemaVersion!=='jm-foundation-schema-v1'||!snapshot.chart?.pillars||!Array.isArray(snapshot.derived?.facts))fail('METHOD_CONTEXT_SNAPSHOT_REQUIRED');
 const byId=new Map(snapshot.derived.facts.map(f=>[f.factId,f])),month=snapshot.chart.pillars.month;
 const known=['year','month','hour'].filter(p=>snapshot.chart.pillars[p]!=null),missing=['year','month','hour'].filter(p=>snapshot.chart.pillars[p]==null),matches=[];
 const hidden=byId.get('hidden:month');
 if(month){
  if(!hidden||hidden.value.branch!==month[1]||!Array.isArray(hidden.value.stems)||new Set(hidden.value.stems).size!==hidden.value.stems.length)fail('METHOD_CONTEXT_MONTH_FACT_DRIFT');
  for(const position of known){
   const stem=snapshot.chart.pillars[position][0],index=hidden.value.stems.indexOf(stem),exposure=byId.get('month-exposure:'+position);
   if(index<0){if(exposure)fail('METHOD_CONTEXT_EXPOSURE_DRIFT');continue;}
   if(!exposure||exposure.value.stem!==stem||exposure.value.monthBranch!==month[1])fail('METHOD_CONTEXT_EXPOSURE_DRIFT');
   matches.push({position,stem,monthHiddenIndex:index,evidenceIds:['hidden:month',exposure.factId],
    sourcePaths:['snapshot.derived.facts[factId=hidden:month].value.stems['+index+']','snapshot.chart.pillars.'+position+'[0]'],
    comparison:'exact-character-equality',effectiveTransformationAssessed:false});
  }
 }
 const status=!month?'input-insufficient':missing.length?'partial-known-positions':'observed-known-positions';
 const contextText=!month?'The recorded birth information leaves the month position unsettled, so this piece of traditional context is not included.':
  matches.length?'The cited commentary describes a month’s hidden stem appearing openly in the chart. Here, that correspondence occurs in '+matches.map(m=>'the '+m.position+' position').join(' and ')+'. It is one part of the traditional discussion of a pattern, rather than a completed pattern reading.':
  'The correspondence described in the cited commentary is not established in the recorded positions used here. That result does not rule out other traditional ways of reading the chart.';
 return freeze({version:METHOD_CONTEXT_VERSION,methodId:'M-CONTEXT-01',status,matches,missingPositions:missing,
  dayStemPolicy:'excluded only by the scope of this draft card; not a claimed prohibition in the historical text',
  monthBoundaryPolicy:'withhold when the month pillar is unresolved',
  unknownPolicy:'known year/month matches may remain; missing hour prevents a full-chart uniqueness or absence assertion',
  sourceId:'C-DTS-06-844363',sourceClass:'commentary; digital transcription; not the original verse',
  text:contextText+(month&&missing.length?' The unknown birth time may add further context.':''),
  guard:{methodId:'M-GUARD-01',status:'active-limitation',overallStrength:'unassessed',sourceId:'C-DTSCW-2600158',
   text:'Season and roots are parts of a larger traditional reading. They are not enough on their own to settle a chart’s balance, so this report does not give a final strength judgment.',
   requiredBeforeConclusion:['complete support/output/constraint evidence','effective-root conditions','position and competing interactions','explicit method and counterexamples']},
  commanderDayPolicy:'not implemented; hidden-stem ordering is not a commander-days table',
  knownSourceDisagreement:{sanMingTongHuiVolume2Oldid2292392:'Yin: earth5, Bing5, Jia20',diTianSuiMonthOldid844366:'Yin: earth1–7, Bing8–14, Jia15 onward',resolution:'retain separately; neither table selected or merged'},
  formalJudgments:{strength:null,formation:null,usefulElement:null},eligibleForPublic:false,purchasable:false});
}
