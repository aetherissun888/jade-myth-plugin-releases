/** A conditional cultural contrast, not activation of the rejected expression route. */
import{assertClaimLedgerSource}from'./claim-ledger.js';
import{assertZipingProfileSource}from'./ziping-month-profile.js';
import{JIA_YIN_BRANCH,JIA_YIN_SECTION}from'./ziping-jia-yin-core.js';
export const JIA_YIN_ROLE_CONTRAST='Jade-ZP-JiaYin-CompetingRootContext-v1';
const positions=['year','month','day','hour'],unique=a=>[...new Set(a)].sort();
export function buildJiaYinRoleContrast(snapshot,profile,ledger){
 assertClaimLedgerSource(ledger,snapshot);assertZipingProfileSource(profile,snapshot);
 const absent=reason=>({ruleId:JIA_YIN_ROLE_CONTRAST,status:'not-established',reason});
 const p=snapshot.chart.pillars,route=profile.coreRoute,facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f]));
 if(profile.branchId!==JIA_YIN_BRANCH||route?.status!=='withheld-known-context'||positions.some(k=>!p[k])||snapshot.chart.nearSolarBoundary)return absent('not-the-stable-declared-counter-route');
 if(p.month!=='丙寅'||p.hour!=='丙寅'||p.day[0]!=='甲')return absent('declared-rooted-expression-prerequisites-unavailable');
 const roots=['month','hour'],opponents=positions.filter(k=>p[k][1]==='申');
 if(!opponents.length)return absent('no-recorded-Shen-endpoint');
 for(const k of roots){const root=byId.get('exact-root:'+k),exposure=byId.get('month-exposure:'+k);
  if(!root||!exposure)return absent('required-root-or-exposure-fact-missing');
  if(root.value.stem!=='甲'||root.value.branch!=='寅'||root.value.index!==0||exposure.value.stem!=='丙'||exposure.value.monthBranch!=='寅')throw new RangeError('JIA_YIN_CONTRAST_SOURCE_DRIFT');
 }
 const clashes=[];for(const a of roots)for(const b of opponents){const pair=[a,b].sort((x,y)=>positions.indexOf(x)-positions.indexOf(y)),f=byId.get('branch-clash:'+pair.join(':'));
  if(!f)return absent('required-opposition-fact-missing');
  if(f.kind!=='branch-clash'||f.positions.join(':')!==pair.join(':')||!f.value.includes('寅')||!f.value.includes('申'))throw new RangeError('JIA_YIN_CONTRAST_OPPOSITION_SOURCE_DRIFT');clashes.push(f.factId);
 }
 const allowed=new Set(clashes),authority=[];
 for(const k of opponents){const h=byId.get('hidden:'+k);if(!h||h.value.branch!=='申')return absent('opponent-inventory-missing');allowed.add(h.factId);
  const i=h.value.stems.indexOf('庚'),f=byId.get('hidden-relationship:'+k+':'+i);if(i<0||!f)return absent('opponent-relationship-missing');
  if(f.value.stem!=='庚'||f.value.relation.dayStem!=='甲'||f.value.relation.family!=='constraint')throw new RangeError('JIA_YIN_CONTRAST_RELATION_SOURCE_DRIFT');allowed.add(f.factId);authority.push(f.factId);
 }
 if(!route.counterEvidenceIds.length||route.counterEvidenceIds.some(id=>!allowed.has(id))||route.evidenceIds.some(id=>!byId.has(id)))return absent('additional-or-incomplete-counterconditions-require-review');
 const evidenceIds=unique([...route.evidenceIds,...clashes,...authority]);
 return {ruleId:JIA_YIN_ROLE_CONTRAST,id:JIA_YIN_SECTION,status:'supported-cultural-structure',kind:'conditional-root-role-contrast',domain:null,
  title:'A foundation under competing demands',evidenceIds,counterEvidenceIds:unique([...clashes,...authority]),sourceRefs:['ZP-JIA-YIN-EXPRESSION','ZP-ROOT-NOT-SEASON-ONLY','ZP-ROOT-VS-PEERS'],
  conditions:{originalExpressionRoute:'withheld-known-context',rootPositions:roots,oppositionPositions:opponents,rootEffectiveness:null,overallStrength:null,formedPattern:null,sourcePaths:evidenceIds.map(id=>'snapshot.derived.facts[factId='+id+']'),operationalScope:'full declared Bing/Yin month/hour route; only listed Yin/Shen root opposition and its hidden Geng context, not an exhaustive efficacy theorem',newLifeDomain:false},
  overview:'This part of your reading centers on a foundation and an outlet that cannot be considered in isolation. A competing relationship reaches the same supporting positions, so the interpretation keeps both the possibility of expression and the conditions around it in view.',
  freeLayers:['traditional-cultural-interpretation','modern-reflection'],
  freeParagraphs:[
   'There is a push and pull in this part of your chart. A foundation and a repeated outlet for expression appear together, while that same foundation also takes part in an opposing relationship. In the selected Zi Ping approach, support cannot simply be counted and assumed to work without interference. The point is to read the base and the competing connection together, rather than call the whole chart strong or weak from either one.',
   'Jade’s contemporary symbolic application is to distinguish having something worth expressing from having conditions that let it work as intended. If your own experience fits that tension, an existing skill or idea may still be useful while a conflicting requirement needs attention. This is an application of the chart relationship, not evidence about your abilities, history or workplace.'
  ],
  detailedLayers:['traditional-cultural-interpretation','traditional-cultural-interpretation','structural-context','modern-reflection','structural-context'],
  detailedParagraphs:[
   'The earlier starting point in this method connects a springtime foundation with outward expression. Your chart retains that connection, but it also records an opposition involving the positions that provide the foundation. This changes the question: expression is present, yet we cannot treat its supporting base as an independent advantage untouched by the rest of the chart.',
   'A supporting point being present and being usable are different judgments. The opposition does not erase the recorded foundation. Equally, seeing a foundation does not settle how freely it can support expression when another relationship reaches the same place. This reading therefore holds a tension between support and constraint, rather than choosing a confident label and overlooking the competing condition.',
   'The same opposing part of the chart also carries a role associated, in this tradition, with limits and obligation. That gives a second reason to keep the interaction in view, but it does not prove that constraint is stronger than support. The selected text cautions against deciding capacity from the season alone; no numerical balance or completed pattern is substituted here.',
   'Jade’s contemporary symbolic application is about the conditions of use. Imagine a familiar way of doing something meeting a requirement that it does not yet satisfy. The useful distinction is between improving the work itself and resolving the conflicting requirement. More effort in the old form may not address that conflict; abandoning the useful part may be unnecessary too. This example applies only where such a conflict actually exists in your experience, and is not a prediction that you face one.',
   'The distinction here is between a foundation and the conditions under which it can be used. This chapter keeps both sides visible while their effective balance remains open. It does not establish a completed pattern, a career path or an income outcome.'
  ],
  previewParagraphIndex:1,previewScope:'Also included: a limited interpretation of a supporting foundation and an opposing connection involving the same positions. Its effective balance remains open.',
  basis:'The known Jia/Yin starting point retains exact-character Jia root facts and Bing expression in the month and hour. A Shen position forms recorded oppositions with those Yin positions and contains a Geng constraint relationship. The original expression route remains withheld; Jade reads these connected observations as a bounded cultural contrast, not a measured loss of root support. The everyday illustration is a modern application.',
  coverageNotice:'Traditional chart interpretation — A limited foundation-and-opposition contrast is included. This adds no new life-topic coverage or settled strength, formation or income judgment.'};
}
