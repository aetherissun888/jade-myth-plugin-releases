import {readingValueScope} from './content/evidence-report-plan.js';
import {installTimingControls} from './timing-controls.js';
import {TIMED_PRESENTATION_VERSION,reportChapterIndex} from './foundation/presentation.js';
import {installReportJump} from './report-navigation.js';
import {chartTerms,TERMS_HELP_VERSION} from './chart-terms.js';
import {prepareReportPrint} from './report-print.js';
import {NOTE_FIELDS} from './foundation/legacy-export.js';
const $=id=>document.getElementById(id),T=(parent,tag,value)=>{const n=document.createElement(tag);n.textContent=value;parent.append(n);return n;};
let current=null,session=null,restorePrint=null,reviewed=null,removeReportJump=null,removeTimingControls=null;
const exportURLs=new Set(),exportKinds=['html','text','json','bundle'];
const exportChoice=()=>({omitBirthDetails:$('report-omit-birth').checked,includeNotes:$('report-include-notes').checked});
const exportKey=()=>JSON.stringify([current?.state.revision,current?.report.assemblyVersion,current?.report.contentVersion,current?.state.view.customerReadingVersion,current?.state.view.customerDetailed?.common.contentVersion,session?.read().timingRevision,exportChoice(),readNotes()]);
function resetExportReview(message){
 reviewed=null;for(const url of exportURLs)URL.revokeObjectURL(url);exportURLs.clear();$('report-export-preview').value='';
 for(const kind of exportKinds)$('export-report-'+kind).disabled=true;
 if(message){$('report-status').dataset.state='pending';$('report-status').textContent=message;}
}
function resetExportChoices(){resetExportReview();$('report-omit-birth').checked=true;$('report-include-notes').checked=false;$('review-report-export').disabled=true;}

function finishPrint(){restorePrint?.();restorePrint=null;}
export function clearReportUI(){
 finishPrint();resetExportChoices();removeReportJump?.();removeReportJump=null;removeTimingControls?.();removeTimingControls=null;
 // Release moved mobile nodes before their original containers are emptied.
 document.dispatchEvent(new Event('jade-chart-cleared'));
 current=null;session=null;
 for(const id of ['free-reflection','report-sections','report-notes','report-metadata','report-toc'])$(id).replaceChildren();
 $('full-report').hidden=true;
 for(const id of ['mobile-report-state','report-completeness','report-status'])$(id).textContent='';
 $('generate-report').disabled=true;delete $('report-sections').dataset.reportAssembly;
}
function sectionInto(root,s,terms=[]){
 const node=T(root,'section','');node.id=s.domId;node.tabIndex=-1;node.className='source-note';T(node,'h3',s.title);
 const body=s.optional?T(node,'details',''):node;if(s.optional)T(body,'summary','Open shared calendar reference');
 s.paragraphs.forEach(p=>T(body,'p',p));
 if(s.chartBasis){const basis=T(node,'details','');T(basis,'summary',s.chartBasis.title);s.chartBasis.paragraphs.forEach(p=>T(basis,'p',p));for(const source of s.chartBasis.sources??[]){const a=T(T(basis,'p',''),'a',source.title);a.href=source.url;a.rel='noreferrer noopener';}}
 if(s.basisNotes||s.fieldDependencies.length||s.sourceRefs.length){
  const detail=T(node,'details','');T(detail,'summary','Text and chart basis');
  if(s.basisNotes)T(detail,'p',s.basisNotes);
  if(s.fieldDependencies.length)T(detail,'p','Fields: '+s.fieldDependencies.join('; '));
  if(s.sourceRefs.length)T(detail,'p','Source references: '+s.sourceRefs.join(', '));
 }
 if(s.id==='method-scope'&&terms.length){
  const help=T(node,'details','');help.id=s.domId+'-terms';help.dataset.helpVersion=TERMS_HELP_VERSION;T(help,'summary','Relationship terms used in this chart');
  T(help,'p','These names describe relationships between stems in the Five Phases model. They are not findings about income, health, employment or another person’s feelings.');
  const list=T(help,'dl','');
  for(const term of terms){const title=T(list,'dt',term.pinyin+' · '),han=T(title,'span',term.label);han.lang='zh-Hans';T(title,'span',' · '+term.category);T(list,'dd',term.direction+'. Compared positions: '+term.positions.join(' / ')+'.');}
  T(help,'p','This help uses only the displayed and hidden stems retained in the current chart. Missing positions are omitted. The accompanying JSON keeps the relationship facts and their source references.');
 }
 return node;
}
export function setPresentedState(state,boundSession,report){
 resetExportChoices();current={state,report,opened:false,timingReading:null,timingRoots:null,terms:chartTerms(report)};session=boundSession;
 const root=$('free-reflection');root.replaceChildren();
 // Free section IDs are distinct in the DOM; the canonical detailed IDs stay report-*.
 for(const s of state.view.customerFree.sections)sectionInto(root,{...s,domId:'free-'+s.id},current.terms);
 $('generate-report').disabled=false;
 const preview=state.view.customerFree.preview;
 if(preview){const box=T(root,'section','');box.className='source-note';box.dataset.readingUpgrade='true';T(box,'h3',preview.title);T(box,'p',preview.paragraph);T(box,'p',preview.description);}
 $('report-coverage').textContent=state.view.customerDetailed.common.readingCoverageNotice;
}
export function showWorkedReport(){
 if(!current)return;
 if(current.opened){$('full-report').hidden=false;document.dispatchEvent(new Event('jade-report-open'));if(!matchMedia('(max-width:760px)').matches)$('report-title').focus({preventScroll:true});return;}
 const {state,report}=current,view=state.view;
 $('report-title').textContent=view.customerDetailed.common.readingTitle;
 const explanation=$('full-report').querySelector('.report-value-long');
 if(explanation)explanation.textContent=readingValueScope(view.customerDetailed.common.readingCoverage,view.customerDetailed.sections,view.customerFree.sections).detailIntroduction;
 $('full-report').querySelector('.notice strong').textContent='Private reading candidate · Independent review pending · Not for sale';
 $('mobile-report-state').textContent=view.detailed.common.summary;
 $('report-completeness').textContent=view.detailed.common.completeness;
 const root=$('report-sections'),toc=$('report-toc'),metadata=$('report-metadata');
 root.replaceChildren();toc.replaceChildren();metadata.replaceChildren();root.dataset.reportAssembly=view.customerDetailed.common.assemblyVersion;
 // Keep calculation/debug metadata internal. Input summary remains in the chart.
 for(const[k,v]of [['Reading','Traditional symbolic reflection'],['Review','Independent review pending']]){T(metadata,'dt',k);T(metadata,'dd',v);}
 for(const s of view.customerDetailed.sections){const a=T(toc,'a',s.title);a.href='#'+s.domId;sectionInto(root,s,current.terms);}
 refreshReportNavigation();
 const notes=$('report-notes');notes.replaceChildren();
 for(const[id,label]of NOTE_FIELDS){const wrapper=T(notes,'label','');wrapper.htmlFor='report-note-'+id;T(wrapper,'span',label);const area=T(wrapper,'textarea','');area.id=wrapper.htmlFor;area.dataset.note=id;area.rows=4;area.maxLength=5000;area.autocomplete='off';}
 const revision=state.revision;
 notes.oninput=()=>{try{session.setNotes(revision,readNotes());resetExportReview('Notes changed. Review export contents again before saving.');}catch{resetExportReview('Details changed. Calculate again before adding notes.');}};
 installCurrentTimingControls();
 current.opened=true;$('full-report').hidden=false;$('review-report-export').disabled=false;$('report-status').dataset.state='ready';
 $('report-status').textContent='Draft generated locally. Review export contents before saving; each format uses this same chart snapshot.';
 document.dispatchEvent(new Event('jade-report-open'));
 if(!matchMedia('(max-width:760px)').matches){$('report-title').focus({preventScroll:true});$('full-report').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});}
}
const currentReportReady=()=>Boolean(current&&session&&session.read().revision===current.state.revision&&session.read().status==='ready');
function timingSections(tier){
 return (current?.timingReading?.[tier==='free'?'freeSections':'detailedSections']??[]).map(s=>({...s,domId:'report-'+s.id,chapterIndex:reportChapterIndex(s.id,TIMED_PRESENTATION_VERSION),sourceRefs:[],fieldDependencies:[],basisNotes:''}));
}
function refreshReportNavigation(){
 if(!current)return;const view=current.state.view,toc=$('report-toc');
 const sections=[...view.customerDetailed.sections,...timingSections('detailed')];
 $('report-sections').dataset.reportAssembly=current.timingReading?TIMED_PRESENTATION_VERSION:view.customerDetailed.common.assemblyVersion;
 toc.replaceChildren();for(const s of sections){const a=T(toc,'a',s.title);a.href='#'+s.domId;}
 removeReportJump?.();const revision=current.state.revision;
 removeReportJump=installReportJump($('full-report'),toc,sections,()=>currentReportReady()&&current.state.revision===revision);
}
function renderTimingSections(){
 if(!current?.timingRoots)return;
 for(const [tier,root]of Object.entries(current.timingRoots)){
  root.replaceChildren();const sections=timingSections(tier);root.hidden=!sections.length;
  for(const section of sections)sectionInto(root,{...section,domId:tier==='free'?'free-'+section.id:section.domId});
 }
 refreshReportNavigation();
}
function installCurrentTimingControls(){
 const printWarning=$('full-report').querySelector('.report-export-review p:last-child');
 if(printWarning)printWarning.textContent='File choices do not hide the report on screen. Printing includes displayed birth details, cycle estimates and notes; it does not use these export choices.';
 const revision=current.state.revision;
 const freeRoot=T($('free-reflection'),'div',''),detailRoot=T($('report-sections'),'div','');freeRoot.className='report-timing-reading';detailRoot.className='report-timing-reading';freeRoot.hidden=true;detailRoot.hidden=true;
 const preview=$('free-reflection').querySelector('[data-reading-upgrade]');if(preview)preview.before(freeRoot);
 current.timingRoots={free:freeRoot,detailed:detailRoot};
 const invalidate=message=>{session.clearTiming(revision);current.timingReading=null;renderTimingSections();resetExportReview(message);};
 removeTimingControls?.();
 removeTimingControls=installTimingControls($('full-report'),$('report-toc'),{
  birthZone:current.report.chart.timeZone,isCurrent:()=>currentReportReady()&&current.state.revision===revision,
  onChange:()=>invalidate('Timing options changed. Review export contents again before saving.'),
  onRemove:()=>invalidate('Timing view removed. Review the base reading again before saving.'),
  onApply:options=>{
   current.timingReading=null;renderTimingSections();resetExportReview('Timing contents changed. Review export contents again before saving.');
   const result=session.prepareTiming(revision,options);current.timingReading=result.ok?session.readTimingReading(revision):null;renderTimingSections();
   if(!result.ok)return {ok:false,message:result.error.code==='INVALID_DIRECTION'?'Choose a known direction or leave it unknown.':'Choose a whole year from 1901 to 2026 and a listed calendar timezone.'};
   return {ok:true,message:`Your ${options.targetYear} timing view is ready to read. ${result.luckCycle.status==='blocked'?'Personal cycle dates remain unavailable under the supplied information.':'Cycle dates are estimates under the explicitly chosen convention.'}`};
  }
 });
}
const readNotes=()=>Object.fromEntries([...$('report-notes').querySelectorAll('[data-note]')].map(n=>[n.dataset.note,n.value]));
$('generate-report').addEventListener('click',showWorkedReport);
for(const id of ['report-omit-birth','report-include-notes'])$(id).addEventListener('change',()=>resetExportReview('Export choices changed. Review export contents again before saving.'));
$('review-report-export').addEventListener('click',()=>{
 if(!current?.opened||!session)return;
 try{const revision=current.state.revision;session.setNotes(revision,readNotes());$('report-export-preview').value=session.exportReading(revision,'text',exportChoice());reviewed=exportKey();for(const kind of exportKinds)$('export-report-'+kind).disabled=false;$('report-status').dataset.state='ready';$('report-status').textContent='Export contents ready to review. No download has been requested.';}
 catch{resetExportReview('Export review unavailable. Calculate the current chart and review again.');}
});

for(const[kind,mime,suffix,label]of [['html','text/html;charset=utf-8','html','Save reading as HTML'],['text','text/plain;charset=utf-8','txt','Save reading as text'],['json','application/json;charset=utf-8','json','Save reading as JSON'],['bundle','application/zip','zip','Save reading bundle']]){
 $('export-report-'+kind).textContent=label;
 $('export-report-'+kind).addEventListener('click',()=>{
  if(!current?.opened||!session)return;
  try{
   if(reviewed!==exportKey())throw new RangeError('EXPORT_REVIEW_REQUIRED');
   const revision=current.state.revision;session.setNotes(revision,readNotes());const value=session.exportReading(revision,kind,exportChoice());
   const url=URL.createObjectURL(new Blob([value],{type:mime})),a=document.createElement('a');a.href=url;exportURLs.add(url);a.download='Jade-Myth-BaZi-Reading-v2'+(exportChoice().omitBirthDetails?'-Birth-Details-Omitted':'')+'.'+suffix;
   document.body.append(a);a.click();a.remove();setTimeout(()=>{URL.revokeObjectURL(url);exportURLs.delete(url);},30000);
   $('report-status').dataset.state='feedback';$('report-status').textContent='Download requested; saving is not confirmed. Check browser downloads. The private file uses the reviewed choices.';
  }catch{resetExportReview('The export is no longer ready. Review the current contents before saving.');}
 });
}
window.addEventListener('beforeprint',()=>{if(current&&!restorePrint)restorePrint=prepareReportPrint($('full-report'));});
window.addEventListener('afterprint',finishPrint);
$('print-report').addEventListener('click',()=>{if(current)window.print();});
window.addEventListener('pagehide',()=>document.getElementById('clear')?.click());
window.addEventListener('pageshow',event=>{if(event.persisted)document.getElementById('clear')?.click();});
