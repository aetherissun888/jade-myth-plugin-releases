/** Narrow support/interaction observation; not an effective-root or strength engine. */
import{assertClaimLedgerSource}from'./claim-ledger.js';import{assertZipingProfileSource}from'./ziping-month-profile.js';import{ZP_YI_BRANCH_ID}from'./ziping-profile-sources.js';
const positions=['year','month','day','hour'],unique=a=>[...new Set(a)].sort();
export const YI_ROOT_CONTEXT_RULE='Jade-ZP-Yi-ObservedRootContext-v1';
export function buildYiRootContext(snapshot,profile,ledger){
 assertClaimLedgerSource(ledger,snapshot);assertZipingProfileSource(profile,snapshot);
 const base={ruleId:YI_ROOT_CONTEXT_RULE,status:'outside-this-root-context',evidenceIds:[],counterEvidenceIds:[],sourceRefs:['ZP-ROOT-NOT-SEASON-ONLY','ZP-ROOT-VS-PEERS'],
  formation:null,overallStrength:null,rootEffectiveness:null,restraintOrMediation:null,rootAbsenceClaim:false,unknownPositions:profile.missingPositions};
 if(profile.branchId!==ZP_YI_BRANCH_ID||profile.status!=='entry-established')return base;
 const facts=[...snapshot.derived.facts].sort((a,b)=>a.factId.localeCompare(b.factId,'en')),byId=new Map(facts.map(f=>[f.factId,f])),pillars=snapshot.chart.pillars;
 const rootRows=facts.filter(f=>['exact-root','phase-root'].includes(f.kind)).map(f=>{
  const position=f.factId.split(':')[1],h=byId.get('hidden:'+position),r=byId.get('hidden-relationship:'+position+':'+f.value.index);
  if(!positions.includes(position)||!pillars[position]||h?.value.branch!==pillars[position][1]||f.value.branch!==h.value.branch||h.value.stems[f.value.index]!==f.value.stem||r?.value.stem!==f.value.stem||r.value.relation.dayStem!=='乙')throw new RangeError('YI_ROOT_SOURCE_DRIFT');
  if(f.kind==='exact-root'&&f.value.stem!=='乙'||f.kind==='phase-root'&&(r.value.relation.family!=='peer'||f.value.stem==='乙'))throw new RangeError('YI_ROOT_KIND_DRIFT');
  return{position,kind:f.kind==='exact-root'?'same-character-hidden-support':'same-phase-support-candidate',stem:f.value.stem,branch:f.value.branch,index:f.value.index,
   factId:f.factId,evidenceIds:[f.factId,h.factId,r.factId],sourcePaths:['snapshot.derived.facts[factId='+f.factId+']','snapshot.derived.facts[factId='+h.factId+'].value.stems['+f.value.index+']'],effective:null};
 });
 const exact=rootRows.filter(r=>r.kind==='same-character-hidden-support'),phase=rootRows.filter(r=>r.kind==='same-phase-support-candidate');
 const additionalPeers=facts.filter(f=>f.kind==='visible-relationship'&&f.value.family==='peer').map(f=>({position:f.factId.split(':')[1],stem:f.value.otherStem,factId:f.factId,notConvertedToRoot:true}));
 const interactions=facts.filter(f=>['branch-clash','branch-combination'].includes(f.kind)&&f.positions.some(p=>rootRows.some(r=>r.position===p))).map(f=>({factId:f.factId,kind:f.kind,positions:f.positions,value:f.value,sourcePath:'snapshot.derived.facts[factId='+f.factId+']',effective:null}));
 const matched=exact.filter(r=>interactions.some(f=>f.kind==='branch-clash'&&f.positions.includes(r.position))),clashes=interactions.filter(f=>f.kind==='branch-clash'&&matched.some(r=>f.positions.includes(r.position)));
 const observation={sameCharacterHiddenSupport:exact,samePhaseCandidates:phase,additionalVisiblePeers:additionalPeers,dayReferenceIsNotExtraExposure:true,
  knownSupportInteractions:interactions,matchedSupportPositions:matched.map(r=>r.position),scope:'retained known hidden/visible facts; not a complete classical effective-root inventory',
  wholeChartAbsenceOrStrengthAssessed:false,foodRoute:profile.methodRoutes.find(r=>r.id==='yi-food-restraint')?.status??null};
 if(!matched.length)return{...base,status:!exact.length?profile.missingPositions.length?'input-open-no-known-exact-support':'no-same-character-support-for-this-claim':'known-support-without-this-clash',observation};
 const evidenceIds=unique([...matched.flatMap(r=>r.evidenceIds),...clashes.map(f=>f.factId)]),counterEvidenceIds=interactions.filter(f=>!clashes.some(c=>c.factId===f.factId)).map(f=>f.factId);
 const notice=profile.missingPositions.includes('hour')?(snapshot.chart.status==='incomplete-time'?'Your birth time is unknown. ':'The birth hour is unresolved. ')+'The missing hour may add support or other relationships that change this interpretation.':'';
 const result={...base,status:'supported-cultural-structure',id:'reading-yi-root-context',title:'Having support and being able to use it',evidenceIds,counterEvidenceIds,observation,
  overview:'Having something to draw on can be different from being able to use it freely. The traditional passage below explores that distinction where support and an opposing relationship are recorded together.',
  freeLayers:['traditional-cultural-interpretation'],detailedLayers:['structural-context','traditional-cultural-interpretation'],
  freeParagraphs:['This cultural reading distinguishes a foothold from the conditions around it. The chart retains a supporting point together with an opposing relationship involving the same place. Jade’s contemporary symbolic interpretation is that having something to draw on and being able to use it in a particular setting can be different. The opposition is not treated as proof that the support has vanished.'],
  detailedParagraphs:['The chosen method distinguishes the presence of support from its effective contribution. Here, the support and a recorded opposition need to be considered together. Counting only the supporting side would skip the competing relationship; declaring the support lost would skip the fact that it remains part of the chart. This passage does not choose either shortcut.',
   'Jade’s contemporary symbolic interpretation is about available capacity versus usable capacity. Familiar experience or a dependable base may still need a different way of being drawn on when demands change. That is a conditional way to read this relationship, not a judgment that you are weak, unsupported, or able to withstand every demand.'],
  basis:'The retained hidden-stem table contains the same character as the day reference at a known position. That position also participates in a recorded branch opposition. These are observations of support and interaction, not proof of an effective root or of its loss. Other same-phase support and extra visible counterparts are kept separate; this passage does not rank the whole chart.',
  basisSources:[{title:'Zi Ping Zhen Quan — 六、論十幹得時不旺失時不弱',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_032.htm'}],
  coverageNotice:'Traditional chart interpretation — A limited reading of known support and interaction is included; whole-chart strength and effective response remain unassessed.',
  previewScope:'Also included: a limited cultural interpretation of a recorded support point and an opposing relationship at the same place.',
  conditions:{branchId:ZP_YI_BRANCH_ID,knownSameCharacterRootFactIds:matched.map(r=>r.factId),listedClashFactIds:clashes.map(f=>f.factId),otherInteractionIds:counterEvidenceIds,
   hiddenOccurrenceIsNotEffectiveStrength:true,dayStemAlreadyPresent:true,additionalPeerStemsNotRequiredForRootObservation:true,noNumericalRootScore:true,
   overallCapacity:'unassessed',effectiveRootUnderClash:'unassessed',foodRestraint:'unassessed even with visible Ding',wholeChartExclusion:false,
   sourcePaths:matched.flatMap(r=>r.sourcePaths),productScope:'only known same-character support with a listed clash; no claim of complete traditional root classification'},
  reportScope:{status:'entry-with-limited-root-context',bodyNotice:'A limited reading of a known support relationship is included. Overall strength, effective restraint or mediation, and a complete personal interpretation remain undetermined. More detail does not remove these limits.',
   coverageNotice:'Traditional chart interpretation — A limited support-and-interaction reading is included; whole-chart strength and effective response remain unassessed.',
   previewNotice:'The support passage is conditional. The detailed view does not settle whole-chart strength, effective restraint or mediation.'}};
 if(notice){result.freeParagraphs[0]+=' '+notice;result.detailedParagraphs[0]+=' '+notice;}return applyYiLinkedApplication(result,snapshot.derived.facts);
}

// Proposed reviewed extension only; no calendar or strength calculation.
export const YI_LINKED_APPLICATION_RULE='Jade-ZP-Yi-ObservedRootContext-v2';
const LINKED_APPLICATION_ROWS=[
 {
  "id": "depth-overview",
  "group": "both",
  "layer": "modern-reflection",
  "text": "In this reading, you may find it more useful to adapt a familiar strength to new conditions than to assume you need to start from scratch. There is a second theme to consider: help offered in several forms may still depend on the same condition. The examples below explore these two themes separately."
 },
 {
  "id": "depth-adapting-a-base",
  "group": "core",
  "layer": "modern-reflection",
  "text": "Something you know how to do may still be worth keeping even when the setting changes. The tension here is between a foundation you can return to and a need to use it differently. Starting over too quickly can overlook what still works; repeating the old approach without checking can overlook what has changed. This theme is about adjusting how you draw on a base, rather than deciding that the base is either enough for everything or no longer useful."
 },
 {
  "id": "depth-connected-help",
  "group": "linked",
  "layer": "modern-reflection",
  "text": "A different theme concerns the way other help fits together. Several offers can appear to give you more choice, yet one may depend on another. The useful distinction is between more help and more independent options. Keeping track of those connections can reveal what needs coordination and what would still be available if a shared condition changed."
 },
 {
  "id": "depth-work-example",
  "group": "core",
  "layer": "modern-reflection",
  "text": "At work, imagine being asked to use a familiar skill under a revised brief. The skill may still be useful even when the old approach needs adjustment. Identify one part that still fits and one requirement that has changed, then make a small, reversible trial against the new requirement. This illustrates keeping a base while checking its conditions of use. If the skill does not actually meet the task’s requirements, the example is not a reason to persist with it.",
  "delivery": "example"
 },
 {
  "id": "depth-help-example",
  "group": "linked",
  "layer": "modern-reflection",
  "text": "In everyday life, imagine a friend who can lend equipment and a community group that can provide space for a shared project. Access to the space may depend on that friend being there. Both offers can be useful, but they are connected rather than two independent fallbacks. Confirm when each is available and what happens if the shared condition falls through. This illustrates coordinating linked help, rather than adapting a skill. Where your sources of help are genuinely independent, this particular example does not apply.",
  "delivery": "example"
 },
 {
  "id": "depth-exercise",
  "group": "both",
  "layer": "modern-reflection",
  "text": "For a five-minute reflection, choose one low-stakes plan you are already considering. Write three short entries: what you can actually draw on; what must be true for it to be usable; and one small check you can make before relying on it. Use observed facts about the situation, not assumptions drawn from the chart. Stop with that one check; this exercise is not a basis for a major commitment.",
  "delivery": "exercise"
 },
 {
  "id": "depth-scope",
  "group": "both",
  "layer": "structural-context",
  "text": "Jade offers this chapter as a contemporary symbolic application of your chart, not a factual description of your abilities or support network. It does not settle overall chart strength or the traditional conditions for effective restraint or mediation."
 }
];
export function evaluateYiLinkedApplication(base,facts){
 if(base.status!=='supported-cultural-structure')return{eligible:false,rows:[]};
 const phase=base.observation.samePhaseCandidates;
 const pairs=base.observation.knownSupportInteractions.filter(pair=>pair.kind==='branch-combination'&&pair.positions.length===2&&pair.positions.every(position=>phase.some(row=>row.position===position))&&pair.positions.every(position=>!base.observation.matchedSupportPositions.includes(position)));
 if(pairs.length!==1)return{eligible:false,rows:[]};
 const pair=pairs[0],members=phase.filter(row=>pair.positions.includes(row.position)),core=base.freeParagraphEvidenceIds?.[0]??base.evidenceIds;
 const linked=unique([pair.factId,...members.flatMap(row=>row.evidenceIds)]),both=unique([...core,...linked]),available=new Set(facts.map(fact=>fact.factId));
 const rows=LINKED_APPLICATION_ROWS.map(row=>{const requires=row.group==='core'?core:row.group==='linked'?linked:both;return{...row,requires,missing:requires.filter(id=>!available.has(id))};});
 return{eligible:rows.every(row=>!row.missing.length),rows,core,linked,evidenceIds:both,pairFactId:pair.factId};
}
function applyYiLinkedApplication(base,facts){
 const extension=evaluateYiLinkedApplication(base,facts);if(!extension.eligible)return base;
 return{...base,ruleId:YI_LINKED_APPLICATION_RULE,evidenceIds:extension.evidenceIds,
  freeParagraphEvidenceIds:base.freeParagraphs.map(()=>extension.core),overviewEvidenceIds:extension.core,
  detailedParagraphs:extension.rows.map(row=>row.text),detailedLayers:extension.rows.map(row=>row.layer),
  detailedParagraphEvidenceIds:extension.rows.map(row=>row.requires),
  paragraphEvidence:extension.rows.map(({id,requires,layer,missing})=>({id,requires,layer,missing})),previewParagraphIndex:0,
  deliveryCapabilities:{ruleId:YI_LINKED_APPLICATION_RULE,sectionId:base.id,paragraphs:extension.rows.flatMap((row,index)=>row.delivery?[{index,role:row.delivery}]:[])},
  conditions:{...base.conditions,extensionRule:YI_LINKED_APPLICATION_RULE,linkedSupportPair:extension.pairFactId,listedPairIsContextOnly:true,fullMethodStillUnassessed:true},
  basis:base.basis+' The longer modern application also uses a recorded link between other potential support positions. It does not establish effective combination or extra strength.'};
}

// One root-approved qualitative bridge, separate from effective resource mediation.
export const YI_CONDITIONAL_SUPPORT_RULE='Jade-ZP-YiYou-ConditionalSupport-v1';
export const YI_CONDITIONAL_SUPPORT_SECTION='reading-yi-support';
export function buildYiConditionalSupport(snapshot,profile,ledger,existingRoot){
 assertClaimLedgerSource(ledger,snapshot);assertZipingProfileSource(profile,snapshot);
 const absent={ruleId:YI_CONDITIONAL_SUPPORT_RULE,status:'outside-reviewed-conditional-support',formation:null,overallStrength:null,restraintOrMediation:null};
 if(profile.branchId!==ZP_YI_BRANCH_ID||profile.status!=='entry-established'||existingRoot?.status==='supported-cultural-structure'||snapshot.chart.nearSolarBoundary)return absent;
 const p=snapshot.chart.pillars,unknown=p.hour==null&&snapshot.chart.status==='incomplete-time';
 // Symbol/position contract, never birth date, sample ID, device clock or payment.
 if(p.day!=='乙亥'||p.month!=='癸酉'||p.year!=='己亥'||!(unknown||p.hour==='戊寅'&&snapshot.chart.status==='calculated'))return absent;
 const byId=new Map(snapshot.derived.facts.map(f=>[f.factId,f]));
 const core=['month-relation:principal','hidden:month','hidden-relationship:month:0','visible-relationship:month','visible-relationship:year','hidden:year','hidden-relationship:year:0','hidden-relationship:year:1','phase-root:year','hidden:day','hidden-relationship:day:0','hidden-relationship:day:1','phase-root:day'];
 const extra=['visible-relationship:hour','hidden:hour','hidden-relationship:hour:0','hidden-relationship:hour:1','hidden-relationship:hour:2','phase-root:hour','stem-combination:month:hour','branch-combination:year:hour','branch-combination:day:hour'];
 if([...core,...(unknown?[]:extra)].some(id=>!byId.has(id)))return absent;
 for(const id of [...core,...(unknown?[]:extra)]){const f=byId.get(id),parts=id.split(':'),expected=f.kind==='hidden'?[parts[1]]:f.kind==='month-relation'?['day','month']:['stem-combination','branch-combination'].includes(f.kind)?parts.slice(1):['day',parts[1]];if(JSON.stringify(unique(f.positions))!==JSON.stringify(unique(expected))||JSON.stringify(unique(f.fieldDependencies))!==JSON.stringify(unique(expected.map(p=>'pillars.'+p))))throw new RangeError('YI_SUPPORT_POSITION_SOURCE_DRIFT');}

 const role=(id,stem,label)=>{const f=byId.get(id),v=f.value.relation??f.value;if((f.value.stem??v.otherStem??v.stem)!==stem||v.label!==label||v.dayStem!=='乙')throw new RangeError('YI_SUPPORT_ROLE_SOURCE_DRIFT');};
 role('hidden-relationship:month:0','辛','七杀');role('visible-relationship:month','癸','偏印');role('visible-relationship:year','己','偏财');
 for(const position of ['year','day',...(unknown?[]:['hour'])]){const h=byId.get('hidden:'+position),r=byId.get('phase-root:'+position);if(h.value.branch!==p[position][1]||h.value.stems[r.value.index]!=='甲'||r.value.stem!=='甲')throw new RangeError('YI_SUPPORT_ROOT_SOURCE_DRIFT');}
 if(!unknown){role('visible-relationship:hour','戊','正财');for(const[id,value]of [['stem-combination:month:hour',['癸','戊']],['branch-combination:year:hour',['亥','寅']],['branch-combination:day:hour',['亥','寅']]])if(JSON.stringify(byId.get(id).value)!==JSON.stringify(value))throw new RangeError('YI_SUPPORT_PAIR_SOURCE_DRIFT');}
 const evidenceIds=unique([...core,...(unknown?[]:extra)]),title=unknown?'A possible theme of help and its conditions':'Help and the conditions that come with it';
 const meaning='In this cultural reading, help matters not just because it is offered, but because of what it makes possible and what comes with accepting it. Jade reads the chart’s combination of demands, support and material commitments as a tension between getting clearer guidance and taking on more than you meant to promise.';
 const why='The support and commitment roles are both present alongside the month’s demanding role. This is why Jade considers them together rather than treating every offer of help as an uncomplicated benefit. It is a chosen symbolic interpretation, not a finding about your character or anyone else’s intentions.';
 const limit=unknown?'Your birth time is unknown. The known parts support only this provisional theme; the missing hour may change the relationships. The additional commitment and its connections in that hour are withheld.':'The chart does not establish that help is controlling, that you owe anyone, or that these examples describe your life. How the recorded relationships actually operate remains unassessed.';
 const distinction='Clear guidance can make a requirement easier to understand without changing what you have agreed to do. Help tied to an extra obligation changes the agreement as well. In this reading, these are different conditions: having a way to meet a request does not, by itself, settle whether its terms suit you.';
 const guidance='Imagine being invited to join an unfamiliar family custom. Someone explains the sequence and what your part would involve, then leaves you free to decide. The help changes what you understand; it need not enlarge your part. This illustrates guidance that makes participation more intelligible, rather than treating accepting help as surrendering your choice.';
 const obligation='Now imagine a friend offering equipment for a community gathering, provided you also organize the event and handle the cleanup. The offer may still be useful, but accepting it would mean accepting those tasks too. This illustrates an offer that changes the commitment, not simply one that supplies clearer instructions. Neither example is a claim that someone in your life behaves this way.';
 const synthesis='The practical distinction is not “accept help” versus “do everything alone.” It is whether the help clarifies an existing request or creates an additional promise. In Jade’s contemporary reading of these traditional relationships, both understanding and the terms of participation stay in view. Generosity need not be distrusted, and a useful offer need not be treated as cost-free.';
 const paragraphs=[meaning,why,distinction,guidance,obligation,synthesis,limit];
 const basis='The stable Yi day/You month retains Xin as the demanding category, month Gui as indirect support, year Ji as indirect material resources, and different-character Jia candidates in the known Hai positions. The source permits examining a support route conditionally; its example of two roles sharing the month is not established here. Same-phase candidates are not declared absent roots, and none of these observations proves effective support, strength or formation.';
 const extraBasis=unknown?'The hour is unknown: no Wu resource role, Yin contents, month/hour stem pairing or hour-related branch pairing is retained. No full-chart absence judgment is made.':'The known hour adds Wu as a different material-resource role. Month Gui/hour Wu form a recorded nonadjacent pair, while hour Yin pairs with the known year/day Hai positions. These are retained conditions, not established removal, transformation or loss of support. The contained Bing is not promoted to visible Ding food restraint.';
 return{...absent,status:'supported-cultural-structure',id:YI_CONDITIONAL_SUPPORT_SECTION,kind:unknown?'provisional-yi-support':'conditional-yi-support',title,evidenceIds,counterEvidenceIds:[],sourceRefs:['ZP-YI-RESOURCE-ROUTE','ZP-YI-FOOD-REQUIREMENTS','ZP-ROOT-VS-PEERS'],
  overview:unknown?'The known parts of this cultural reading offer a provisional theme: what help makes possible, and what accepting it might ask of you.':'This cultural reading explores the difference between help that makes a request clearer and help that also changes what you are agreeing to do.',
  overviewEvidenceIds:core,freeParagraphs:[meaning,why,limit],freeLayers:['modern-reflection','modern-reflection','structural-context'],freeParagraphEvidenceIds:[core,core,unknown?core:evidenceIds],
  detailedParagraphs:paragraphs,detailedLayers:paragraphs.map((_,i)=>i===6?'structural-context':'modern-reflection'),detailedParagraphEvidenceIds:paragraphs.map((_,i)=>i===6&&!unknown?evidenceIds:core),previewParagraphIndex:3,
  basisParagraphs:[basis,extraBasis],basisParagraphEvidenceIds:[core,unknown?core:extra],basisSources:[{title:'Zi Ping Zhen Quan — 三十九、論偏官 (primary support route; not a completed pattern)',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_035.htm'}],
  conditions:{branchId:ZP_YI_BRANCH_ID,contractId:YI_CONDITIONAL_SUPPORT_RULE,decisionIds:['P1','P2','P3','P4','P5'],modernBridge:'help-function-versus-attached-commitment; not response speed or a psychological fact',unknownHour:unknown,sourcePaths:evidenceIds.map(id=>'snapshot.derived.facts[factId='+id+']'),wholeChartExclusion:false,effectiveSupport:null,formation:null,overallStrength:null,extraCommitmentInHour:unknown?null:'observed-not-effective',sourceExampleSharedMonthEstablished:false,rootAbsenceClaim:false},
  coverageNotice:'Traditional chart interpretation — '+(unknown?'One provisional':'One limited')+' theme about help and its conditions is included. This does not complete the five life-topic chapters or establish an effective support route.',
  previewScope:'One '+(unknown?'provisional':'limited')+' cultural theme is included: help and the conditions that come with it. This is the same theme explained in the excerpt, not an additional topic.',
  reportScope:{status:'entry-with-conditional-support-theme',bodyNotice:'A limited cultural theme is included; a completed personal analysis and effective support route remain unestablished.',coverageNotice:'A limited theme, not a completed personal assessment.',previewNotice:unknown?'Missing birth time still limits this theme.':'No effective mediation or pattern judgment is supplied.'}};
}
