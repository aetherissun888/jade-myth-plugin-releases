// Shared retained review metadata only; no calculation or method activation.
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
export const ORDINARY_SOURCES=freeze([
 {id:'C-ZP-6',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_032.htm',locator:'六、論十幹得時不旺失時不弱; observed web line375, 2026-10-23',scope:'season is not a sufficient whole-chart strength verdict; roots and other positions matter',status:'historical text in uncollated commented transcription; original/comment separation needs review'},
 {id:'C-ZP-8',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_032.htm',locator:'八、論用神; observed web line499, 2026-10-23',scope:'month-based vocabulary; distinguish formation usage from later balancing/climate usage',status:'historical text in uncollated commented transcription; not scientific or professional approval'},
 {id:'C-ZP-9',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_033.htm',locator:'九、論用神成敗救應; observed web line55, 2026-10-23',scope:'formation, damaging conditions and rescue must be considered together; position matters',status:'candidate method evidence only; outcome/gender/medical statements not adopted'},
 {id:'C-ZP-10',url:'https://www.ncc.com.tw/fate/paleo/bg/bg_033.htm',locator:'十、論用神變化; observed web line129, 2026-10-23',scope:'month hidden stems, exposure and combinations may alter a candidate; table/prose discrepancy requires collation',status:'candidate only; not a replacement hidden-stem table'}
]);
export const ORDINARY_REVIEW_CARDS=freeze([
 {id:'W01',topic:'season versus whole-chart support',sourceIds:['C-ZP-6'],factKinds:['month-relation','exact-root','phase-root','visible-relationship'],
  proposal:'Separate seasonal context, roots and visible support/counterevidence. Do not count elements into strength.',
  counterconditions:['missing positions prevent whole-chart absence claims','month principal stem is not a complete seasonal or commander-days method','seasonal support and visible counterevidence may coexist'],
  decisions:['Agree a qualitative support rubric with named exceptions and positive/counterexamples; no weights are inferred from the text.']},
 {id:'W02',topic:'root presence versus root efficacy',sourceIds:['C-ZP-6'],factKinds:['hidden','hidden-relationship','exact-root','phase-root','branch-combination','branch-clash'],
  proposal:'Retain exact-stem and same-phase presence separately. Never turn table order or root counts into efficacy.',
  counterconditions:['burial/residual/long-life categories are method-dependent','a pair label does not establish removal or transformation','commented passage disputes a yin-long-life reading; do not merge positions into one rule'],
  decisions:['Collate original versus commentary and define effective-root conditions before a root-strength classifier.']},
 {id:'P01',topic:'ordinary formation candidate and month exposure',sourceIds:['C-ZP-8','C-ZP-10'],factKinds:['month-relation','month-exposure','hidden-relationship','visible-relationship'],
  proposal:'Review month hidden stems and exact exposure as inputs to a candidate, not proof of a formed pattern.',
  counterconditions:['multiple exposed month stems may compete','missing hour can hide a competing candidate','mixed-earth/commander-day conditions and special patterns are not supplied by the principal-stem probe'],
  decisions:['Specify exposure precedence, competing-candidate retention and exclusions using collated passages and contrasting cases.']},
 {id:'P02',topic:'formation, damage and rescue',sourceIds:['C-ZP-9'],factKinds:['visible-relationship','hidden-relationship','stem-combination','branch-combination','branch-clash'],
  proposal:'Document positive, damaging and rescue predicates together; preserve unresolved interactions without a verdict.',
  counterconditions:['absence of one clash label does not establish no damage','pair occurrence alone does not prove operative damage or rescue','strength, position and competing interactions remain relevant'],
  decisions:['Start with one fully reviewed ordinary-pattern branch; require each positive/damage/rescue predicate and omissions to be explicit before activation.']},
 {id:'T01',topic:'separate meanings of useful element',sourceIds:['C-ZP-8'],factKinds:['month-relation','month-exposure'],
  proposal:'Keep formation reference, balancing recommendation and climate adjustment in separate fields.',
  counterconditions:['historical and commentary uses of the same name must not be silently equated','no generic favorable-element list follows from a ten-category label'],
  decisions:['Approve terminology and field semantics; special/conforming/transforming patterns remain out of scope.']}
]);
