/** Internal method-premise review over retained facts; never a life-topic generator. */
import{relateStems}from'../relationships.js';
import{LunarUtil}from'../vendor/lunar-typescript-1.8.6/dist/index.js';
export const LIFE_ROUTE_REVIEW_VERSION='Jade-ZP-LifeRoute-Premises-v1';
const held=new WeakMap(),positions=['year','month','day','hour'],unique=a=>[...new Set(a)].sort();
const fail=code=>{throw new RangeError(code);};
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
export function assessLifeRoutePremises(snapshot){
 if(snapshot?.schemaVersion!=='jm-foundation-schema-v1'||!snapshot.chart?.pillars||!Array.isArray(snapshot.derived?.facts))fail('LIFE_ROUTE_SNAPSHOT_REQUIRED');
 const p=snapshot.chart.pillars,facts=snapshot.derived.facts,byId=new Map(facts.map(f=>[f.factId,f]));
 if(byId.size!==facts.length)fail('LIFE_ROUTE_DUPLICATE_FACT');
 const missingPositions=positions.filter(k=>!p[k]),pair=p.day&&p.month?p.day[0]+p.month[1]:null;
 const base={version:LIFE_ROUTE_REVIEW_VERSION,profile:'Jade-ZP-MonthPattern-v1',entryPair:pair,missingPositions,
  inputState:!pair?'day-month-unresolved':missingPositions.length?'partial-known-scope':'complete-retained-input',
  customerInferenceChanged:false,newLifeDomains:[],eligibleForPublic:false,purchasable:false,
  formalVerdicts:{strength:null,effectiveMediation:null,effectiveRoot:null,formation:null,usefulElement:null},otherInteractionsAssessed:false};
 const finish=(state,more={})=>{const r=freeze({...base,state,...more});held.set(r,snapshot);return r;};
 if(!pair)return finish('entry-input-open');
 if(!['乙寅','丁卯'].includes(pair))return finish('outside-two-reviewed-entries');
 const entryIds=['month-relation:principal','hidden:month','hidden-relationship:month:0'];
 if(entryIds.some(id=>!byId.has(id)))return finish('evidence-incomplete',{missingFactIds:entryIds.filter(id=>!byId.has(id))});
 const principal=byId.get(entryIds[0]),h=byId.get(entryIds[1]),first=byId.get(entryIds[2]),expected=pair==='乙寅'?['甲','劫财','peer']:['乙','偏印','resource'];
 if(principal.kind!=='month-relation'||principal.positions.join(':')!=='day:month'||principal.value.stem!==expected[0]||principal.value.relation.dayStem!==p.day[0]||principal.value.relation.label!==expected[1]||principal.value.relation.family!==expected[2]||h.value.branch!==p.month[1]||h.value.stems[0]!==expected[0]||first.value.stem!==expected[0]||first.value.relation.label!==expected[1])fail('LIFE_ROUTE_MONTH_SOURCE_DRIFT');
 const inventory=[],missing=[];
 for(const position of positions.filter(k=>p[k])){
  const hidden=byId.get('hidden:'+position);if(!hidden){missing.push('hidden:'+position);continue;}
  if(hidden.kind!=='hidden'||hidden.positions.join(':')!==position||hidden.value.branch!==p[position][1]||!Array.isArray(hidden.value.stems)||hidden.value.stems.join('')!==LunarUtil.ZHI_HIDE_GAN[p[position][1]].join(''))fail('LIFE_ROUTE_INVENTORY_SOURCE_DRIFT');
  const add=(id,visibility,index)=>{const f=byId.get(id);if(!f){missing.push(id);return;}
   const r=visibility==='hidden'?f.value.relation:f.value,stem=visibility==='hidden'?f.value.stem:f.value.otherStem;
   if(f.kind!==(visibility==='hidden'?'hidden-relationship':'visible-relationship')||f.positions.join(':')!=='day:'+position||r.dayStem!==p.day[0]||stem!==(visibility==='hidden'?hidden.value.stems[index]:p[position][0])||(visibility==='hidden'&&f.value.index!==index))fail('LIFE_ROUTE_ROLE_SOURCE_DRIFT');
   const table=relateStems(p.day[0],stem);if(r.family!==table.family||r.label!==table.label)fail('LIFE_ROUTE_RELATION_SOURCE_DRIFT');
   inventory.push({factId:id,position,visibility,stem,label:r.label,family:r.family,sourcePath:'snapshot.derived.facts[factId='+id+'].value'});
  };
  if(position!=='day')add('visible-relationship:'+position,'visible');
  hidden.value.stems.forEach((_,i)=>add('hidden-relationship:'+position+':'+i,'hidden',i));
 }
 if(missing.length)return finish('evidence-incomplete',{missingFactIds:unique(missing)});
 inventory.sort((a,b)=>a.factId.localeCompare(b.factId,'en'));
 const group=(family,visibility)=>inventory.filter(r=>r.family===family&&r.visibility===visibility);
 const roles=Object.fromEntries(['resource','output','managed','peer','constraint'].map(f=>[f,{visible:group(f,'visible'),hidden:group(f,'hidden')}]));
 const interactions=[];
 const retain=(id,kind,at,value)=>{const f=byId.get(id);if(!f){missing.push(id);return;}
  if(f.kind!==kind||f.positions.join(':')!==at.join(':')||f.value.join('')!==value)fail('LIFE_ROUTE_INTERACTION_SOURCE_DRIFT');
  interactions.push({factId:id,kind,positions:[...at],values:[...f.value],effective:null,sourcePath:'snapshot.derived.facts[factId='+id+']'});
 };
 if(pair==='乙寅'&&p.day[1]==='丑'&&p.hour?.[1]==='未')retain('branch-clash:day:hour','branch-clash',['day','hour'],'丑未');
 if(pair==='丁卯'&&p.month[0]==='己'&&p.hour?.[0]==='甲')retain('stem-combination:month:hour','stem-combination',['month','hour'],'己甲');
 if(missing.length)return finish('evidence-incomplete',{missingFactIds:missing});
 const entry={family:expected[2],label:expected[1],principalStem:expected[0],evidenceIds:entryIds,sourcePaths:['snapshot.chart.pillars.day[0]','snapshot.chart.pillars.month[1]',...entryIds.map(id=>'snapshot.derived.facts[factId='+id+']')]};
 const source=(chapter,paragraph,url)=>({chapter,paragraph,layer:'selected-main-text',url,commentaryMerged:false});
 const routes=pair==='乙寅'?[{
  id:'peer-expression-material-route',state:roles.output.hidden.length&&roles.managed.hidden.length?'observed-candidate-effects-unassessed':'candidate-not-established-in-known-scope',
  source:source('四十五、論建祿月劫',188,'https://www.ncc.com.tw/fate/paleo/bg/bg_035.htm'),
  evidenceIds:unique([...entryIds,...roles.output.hidden.map(r=>r.factId),...roles.output.visible.map(r=>r.factId),...roles.managed.hidden.map(r=>r.factId),...roles.managed.visible.map(r=>r.factId)]),
  missingMethodPredicates:['effective-expression-mediation','relative-capacity-and-root-efficacy','selection-against-other-month-peer-routes'],
  blockedInferences:['visible-support-count-is-strength','hidden-financial-or-expression-roles-absent','resource-pattern-route-selected-from-visible-count','income-or-career-talent'],
  exceptionScope:'The source also discusses distinct transformation/alternative routes; this paragraph is not encoded as a universal no-expression/no-value theorem.',
  sharedHourInventory:inventory.filter(r=>r.position==='hour'),knownInteractionFactIds:interactions.map(r=>r.factId)
 }]:[{
  id:'support-expression-route',state:roles.output.visible.length?'observed-candidate-capacity-unassessed':'candidate-not-established-in-known-scope',
  source:source('三十五、論印綬',250,'https://www.ncc.com.tw/fate/paleo/bg/bg_034.htm'),evidenceIds:unique([...entryIds,...roles.output.visible.map(r=>r.factId),...roles.resource.visible.map(r=>r.factId)]),
  missingMethodPredicates:['whole-chart-capacity','relative-support-condition','effective-expression-under-interaction'],
  blockedInferences:['support-plus-expression-is-effective-route','learning-or-work-ability-diagnosis','interpersonal-trait-from-category-names']
 },{
  id:'financial-adjustment-of-support-route',state:roles.managed.visible.length?'observed-alternative-root-and-capacity-unassessed':'candidate-not-established-in-known-scope',
  source:source('三十五、論印綬',256,'https://www.ncc.com.tw/fate/paleo/bg/bg_034.htm'),evidenceIds:unique([...entryIds,...roles.managed.visible.map(r=>r.factId),...roles.resource.visible.map(r=>r.factId)]),
  missingMethodPredicates:['relative-support-excess-not-count','whole-chart-capacity','deep-effective-backing','operative-noninterference'],
  blockedInferences:['visible-financial-role-automatically-protects-expression','pairing-means-removal-or-transformation','financial-or-cooperation-success']
 }];
 return finish('method-premises-unresolved',{
  entry,inventory,roles,interactions,routes,
  gapCause:'method-incomplete-even-with-complete-input',
  knownObservationScope:missingPositions.length?'retained-positions-only; no full-chart absence claim':'all-retained-positions; not all effective interactions',
  proposedLifeDomains:pair==='乙寅'?['work','learning','money']:['relationships','collaboration'],
  domainBridge:pair==='丁卯'?'The two reviewed support routes do not themselves establish an intimate-relationship or cooperation inference. Such a bridge is separately missing.':'Month-peer route selection and operative mediation must precede an occupational or resources inference.',
  noCustomerTextReason:'No supported new personal inference follows merely from completing this inventory. Existing modern applications and missing-topic notices remain unchanged.'
 });
}
export function assertLifeRouteSource(result,snapshot){if(held.get(result)!==snapshot)fail('LIFE_ROUTE_SOURCE_IDENTITY_MISMATCH');return true;}
