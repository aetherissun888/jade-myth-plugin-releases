import {prepareCustomerTiming,assertCustomerTiming} from '../annual-facts/customer-timing.js';
import {exportCustomerReadingWithPrivacy} from './privacy-reading.js';
import {prepareTimingExtension} from '../annual-facts/prepared-extension.js';
import {readingDeliveryScope} from '../content/reading-deliverability.js';
// Versioned presentation projection only. Existing page/CSS/DOM are not modified.
import {prepareLocalReport,exportLocalReport,exportCustomerReading,EXPORT_VERSION} from './export-adapter.js';
import {REPORT_CHAPTER_TITLES,reportChapterIndex as legacyIndex,mobileReportSummary as legacySummary} from '../report-mobile.js';
export {REPORT_CHAPTER_TITLES,releaseMobileReportState} from '../report-mobile.js';
export const TIMED_PRESENTATION_VERSION='jm-reading-presentation-v2.2';
export const READING_PRESENTATION_VERSION='jm-reading-presentation-v2.1';
export const PRESENTATION_VERSION='jm-reference-presentation-v1';
const held=new WeakMap();
const groups=Object.freeze({'input-certainty':0,orientation:0,season:1,roots:1,pairs:1,synthesis:1,reflection:2,'method-scope':3,'source-links':3});
const positions=['year','month','day','hour'];
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};

/** Text availability is separate from professional and commercial approval. */
export function readingCoverageNotice(coverage,sections){
 const domains=coverage?.domains,required=['work','learning','money','relationships','collaboration'];
 if(!Array.isArray(domains)||domains.length!==required.length||required.some(id=>domains.filter(d=>d.domain===id).length!==1)||domains.some(d=>typeof d.label!=='string'||!['interpreted','input-insufficient','method-not-supported'].includes(d.status)||(d.status==='interpreted'?typeof d.sectionId!=='string':d.sectionId!==null)))fail('PRESENTATION_COVERAGE_UNSUPPORTED');
 const included=domains.filter(d=>d.status==='interpreted');
 if(!Array.isArray(sections)||new Set(sections.map(s=>s.id)).size!==sections.length||new Set(included.map(d=>d.sectionId)).size!==included.length||included.some(d=>!sections.some(s=>s.id===d.sectionId&&Array.isArray(s.paragraphs)&&s.paragraphs.length&&s.paragraphs.every(p=>typeof p==='string'&&p.trim()))))fail('PRESENTATION_COVERAGE_SECTION_MISSING');
 const labels=domains.filter(d=>d.status==='interpreted').map(d=>d.label);
 return (labels.length?'Available in this candidate: '+labels.join('; ')+'.':coverage.structuralSupplement?.kind==='support-outlet-application'?'No full personal-topic chapter is included; a limited chart-context interpretation and contemporary learning example are available.':'No supported topic is included in this candidate.')+' Available topics describe text coverage, not a complete assessment or professional approval. Independent review is pending; this private draft is not for sale.';
}

/** Undefined version is the existing legacy call contract. New callers must pass
 * the assembly version; unknown versions/IDs must not silently land in Sources.
 */
export function reportChapterIndex(id='',assemblyVersion){
  if(assemblyVersion===undefined)return legacyIndex(id);
  if([TIMED_PRESENTATION_VERSION,READING_PRESENTATION_VERSION,'jm-reading-presentation-v2'].includes(assemblyVersion)){
  if(assemblyVersion===TIMED_PRESENTATION_VERSION){const key=id.startsWith('report-')?id.slice(7):id;if(['timing-year-reflection','timing-personal-cycles','timing-seasonal-calendar'].includes(key))return 2;if(key==='timing-reading-scope')return 3;}
  const key=id.startsWith('report-')?id.slice(7):id;
  if([READING_PRESENTATION_VERSION,TIMED_PRESENTATION_VERSION].includes(assemblyVersion)){
   if(['reading-month-peer-context','reading-rooted-expression'].includes(key))return 0;
   if(key==='reading-work-both')return 1;
   if(['reading-money-exchange','reading-relationship-both','reading-action'].includes(key))return 2;
  }
  if(key==='reading-yi-support')return 0;
  if(key==='reading-overview'||key==='reading-month-support'||key==='reading-yi-root-context')return 0;
  if(['reading-craft','reading-patient-craft','reading-learning','reading-equal-voice','reading-supported-authority'].includes(key))return 1;
  if(['reading-shared-money','reading-care-boundaries','reading-ideas-value','reading-mutual-space','reading-together'].includes(key))return 2;
  if(['reading-limits','reading-coverage'].includes(key))return 3;
  fail('PRESENTATION_SECTION_UNMAPPED');
 }
 if(assemblyVersion!==EXPORT_VERSION)fail('PRESENTATION_VERSION_UNSUPPORTED');
  const key=id.startsWith('report-')?id.slice(7):id;
  if(!Object.hasOwn(groups,key))fail('PRESENTATION_SECTION_UNMAPPED');
  return groups[key];
}

export function mobileReportSummary(report){
  if(report?.assemblyVersion!==EXPORT_VERSION){
    if(report?.assemblyVersion?.startsWith('jm-reference-'))fail('PRESENTATION_VERSION_UNSUPPORTED');
    return legacySummary(report);
  }
  const i=report.originalInput,c=report.chart;
  if(!i||!['minute','unknown','range'].includes(i.timePrecision))fail('PRESENTATION_INPUT_MISSING');
  const missing=positions.filter(p=>c.pillars[p]===null);
  const parts=[report.inputNotice];
  if(i.timePrecision==='range')parts.push(`Local range: ${i.range.start}–${i.range.end}. No single birth instant is assigned.`);
  if(i.occurrence)parts.push(`Repeated time: ${i.occurrence} occurrence.`);
  if(missing.length)parts.push(`Unresolved positions: ${missing.join(', ')}.`);
  if(c.yearMonthOptions.length>1)parts.push('Year/month alternatives remain available in the input details.');
  else if(c.nearSolarBoundary)parts.push('Near a calculated solar term; the flag is not an error bound.');
  parts.push('Independent review is pending. Not available to buy.');
  return parts.join(' ');
}

function projectSections(sections){
  return sections.map(s=>({...s,domId:`report-${s.id}`,chapterIndex:reportChapterIndex(s.id,EXPORT_VERSION)}));
}
function chapters(sections){
  return REPORT_CHAPTER_TITLES.map((title,index)=>({index,title,sectionIds:sections.filter(s=>s.chapterIndex===index).map(s=>s.id)})).filter(c=>c.sectionIds.length);
}

/** The input is calculated exactly once by A4. All views and export retain that
 * same frozen report; neither mobile nor free views select another candidate.
 */
export function preparePresentedReport(input,metadata){
  const pack=prepareLocalReport(input,metadata);
  if(!pack.ok)return pack;
  const r=pack.report,s=pack.reference.snapshot;
  const summary=mobileReportSummary(r),sections=projectSections(r.sections);
  if(new Set(sections.map(s=>s.id)).size!==sections.length)fail('PRESENTATION_DUPLICATE_SECTION');
  const declared=['input-certainty',...s.freeSectionIds,'method-scope'];
  if(declared.some(id=>!sections.some(s=>s.id===id)))fail('PRESENTATION_FREE_SECTION_MISSING');
  const freeSections=sections.filter(s=>declared.includes(s.id));
  const certainty=sections.find(s=>s.id==='input-certainty');
  const common={summary,inputNotice:r.inputNotice,completeness:summary,chartCompleteness:summary,
    inputKind:r.originalInput.timePrecision,status:r.chart.status,
    inputSummary:r.inputSummary,normalizedTime:r.normalizedTime,
    pillars:positions.map(position=>({position,value:r.chart.pillars[position],label:r.chart.pillars[position]??'unresolved',
      missingReason:r.chart.pillars[position]!==null?null:
        position==='hour'&&r.originalInput.timePrecision==='unknown'?'Birth time unknown':
        r.originalInput.timePrecision==='range'?'Changes within the supplied time range':'Calculated term boundary alternatives'})),
    // Keep year/month combinations paired; do not form an invented Cartesian product.
    yearMonthOptions:r.chart.yearMonthOptions,candidatePillars:r.chart.candidatePillars??[],
    uncertaintySection:certainty,sourceReportId:r.id,contentVersion:r.contentVersion,
    assemblyVersion:r.assemblyVersion,ruleVersion:r.evidenceSnapshot.ruleVersion,
    purchasable:false,fullPersonalizedReport:false};
  // Existing page uses report- prefixed IDs; offline HTML uses raw IDs. Remap
  // local source anchors for page projection only, leaving frozen exports intact.
  const sources=r.sources.map(x=>({...x,url:x.url==='#method-scope'?'#report-method-scope':x.url}));
  const reading=pack.reading;
  const customerSections=items=>items.map(item=>({...item,domId:'report-'+item.id,
    chapterIndex:reportChapterIndex(item.id,READING_PRESENTATION_VERSION),
    sourceRefs:[],fieldDependencies:[],basisNotes:''}));
  const deliveryScope=['jm-personal-reading-en-v2.1.24','jm-personal-reading-en-v2.1.25','jm-personal-reading-en-v2.1.26','jm-personal-reading-en-v2.1.27','jm-personal-reading-en-v2.1.28','jm-personal-reading-en-v2.1.29','jm-personal-reading-en-v2.1.30','jm-personal-reading-en-v2.1.31','jm-personal-reading-en-v2.1.32','jm-personal-reading-en-v2.1.33','jm-personal-reading-en-v2.1.34','jm-personal-reading-en-v2.1.35','jm-personal-reading-en-v2.1.36','jm-personal-reading-en-v2.1.37','jm-personal-reading-en-v2.1.38','jm-personal-reading-en-v2.1.39'].includes(reading.contentVersion)?readingDeliveryScope(reading):null;
  const customerCommon={...common,assemblyVersion:READING_PRESENTATION_VERSION,contentVersion:reading.contentVersion,readingTitle:'Your BaZi reading: a closer look',readingCoverage:reading.coverage,readingCoverageNotice:readingCoverageNotice(reading.coverage,reading.detailedSections),...(deliveryScope?{deliveryScope,purchasable:deliveryScope.availableToBuy,fullPersonalizedReport:deliveryScope.completePersonalAnalysis}:{})};
  const customerFree=customerSections(reading.freeSections),customerDetail=customerSections(reading.detailedSections);
  const view=freeze({ok:true,presentationVersion:PRESENTATION_VERSION,customerReadingVersion:READING_PRESENTATION_VERSION,
    customerFree:{common:customerCommon,sections:customerFree,chapters:chapters(customerFree),preview:reading.preview},
    customerDetailed:{common:customerCommon,sections:customerDetail,chapters:chapters(customerDetail)},
    free:{common,sections:freeSections,chapters:chapters(freeSections)},
    detailed:{common,sections,chapters:chapters(sections)},sources,
    sourceLinksSection:{domId:'report-source-links',chapterIndex:3},
    reviewStatus:r.reviewStatus});
  held.set(view,pack);return view;
}

export function exportPresentedReport(view,format,notes={},options){
  const pack=held.get(view);if(!pack)fail('PRESENTED_REPORT_REQUIRED');
  return exportLocalReport(pack,format,notes,options);
}

export function exportPresentedReading(view,format,notes={},options,tier='detailed',timingReading=null){
 const pack=held.get(view);if(!pack)fail('PRESENTED_REPORT_REQUIRED');
 if(timingReading){assertCustomerTiming(timingReading,pack);return exportCustomerReadingWithPrivacy({...pack.report,reading:pack.reading},format,notes,options,tier,timingReading);}
 return exportCustomerReading(pack,format,notes,options,tier);
}

// Explicit opt-in reference extension; the current customer sections/exports do
// not silently acquire unreviewed timing claims or another birth calculation.
export function preparePresentedTiming(view,options){
 const pack=held.get(view);if(!pack)fail('PRESENTED_REPORT_REQUIRED');
 return prepareTimingExtension(pack,options);
}

export function presentTimingReading(view,extension){
 const pack=held.get(view);if(!pack)fail('PRESENTED_REPORT_REQUIRED');
 return prepareCustomerTiming(pack,extension);
}
