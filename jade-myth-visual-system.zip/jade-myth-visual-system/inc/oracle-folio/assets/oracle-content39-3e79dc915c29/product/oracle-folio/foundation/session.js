// Memory-only synchronous UI boundary matching the existing local calculation flow.
// No worker, service, persistence, account or payment architecture is introduced.
import {preparePresentedReport,exportPresentedReport,exportPresentedReading,preparePresentedTiming,presentTimingReading} from './presentation.js';
import {cleanNotes} from './legacy-export.js';
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};

export function createReportSession({prepare=preparePresentedReport,onInternalError=()=>{}}={}){
  let revision=0,view=null,timing=null,timingReading=null,timingRevision=0,notes=cleanNotes(),disposed=false;
  let state=freeze({revision,status:'empty',view:null,error:null,timingRevision,notes:{...notes}});
  const requireActive=()=>{if(disposed)fail('SESSION_DISPOSED');};
  const publish=(status,error=null,resolution=null)=>state=freeze({revision,status,view,error,resolution,timingRevision,notes:{...notes}});
  const invalidate=status=>{revision++;view=null;timing=null;timingReading=null;timingRevision++;notes=cleanNotes();return publish(status);};
  const requireReady=expected=>{
    requireActive();if(expected!==revision)fail('STALE_VIEW');
    if(state.status!=='ready'||!view)fail('REPORT_NOT_READY');
  };
  return Object.freeze({
    read:()=>state,
    edit(){requireActive();return invalidate('pending');},
    clear(){requireActive();return invalidate('empty');},
    calculate(input,metadata){
      requireActive();invalidate('calculating');const started=revision;
      try{
        const candidate=prepare(input,metadata);
        if(revision!==started||disposed)return state;
        if(!candidate||typeof candidate.ok!=='boolean'||typeof candidate.then==='function')throw new TypeError('INVALID_PRESENTATION_RESULT');
        if(!candidate.ok)return publish('needs-input',candidate.error,candidate.resolution??null);
        // Prepared report identity is checked by the exporter when exported.
        if(candidate.presentationVersion!=='jm-reference-presentation-v1')throw new TypeError('INVALID_PRESENTATION_VERSION');
        view=candidate;return publish('ready');
      }catch(error){
        if(revision!==started||disposed)return state;
        view=null;notes=cleanNotes();publish('failed',{code:'LOCAL_REPORT_FAILED',message:'The local report could not be prepared. No current report is available.'});
        // Explicit diagnostic hook: no implicit logging of birth input or reports.
        onInternalError(error);return state;
      }
    },
    setNotes(expected,values){requireReady(expected);notes=cleanNotes(values);return publish('ready');},
    export(expected,format,options){requireReady(expected);return exportPresentedReport(view,format,notes,options);},
    exportReading(expected,format,options,tier='detailed'){requireReady(expected);return exportPresentedReading(view,format,notes,options,tier,timingReading);},
    prepareTiming(expected,options){
      requireReady(expected);timing=null;timingReading=null;timingRevision++;publish('ready');
      const candidate=preparePresentedTiming(view,options);
      if(candidate.ok){const projection=presentTimingReading(view,candidate);timing=candidate;timingReading=projection;publish('ready');}
      return candidate;
    },
    clearTiming(expected){requireReady(expected);timing=null;timingReading=null;timingRevision++;return publish('ready');},
    readTimingReading(expected){requireReady(expected);if(!timingReading)fail('TIMING_NOT_READY');return timingReading;},
    readTiming(expected){requireReady(expected);if(!timing)fail('TIMING_NOT_READY');return timing;},
    dispose(){if(!disposed){invalidate('disposed');disposed=true;}return state;}
  });
}
