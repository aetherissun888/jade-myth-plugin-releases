import {readPreparedFactContext,PREPARED_FACT_CONTEXT_VERSION} from './foundation/export-adapter.js';
// Local candidate only. Does not change the existing chart/report or a release recipe.
import {Solar,LunarUtil} from './vendor/lunar-typescript-1.8.6/dist/index.js';
import {offsetAt,TIMEZONE_VERSION} from './timezone.js';
import {validateInput,CONTRACT_VERSION} from './foundation/reference-report.js';
import {resolveInput} from './foundation/rules.js';
import {inputErrorCode} from './foundation/input-errors.js';
import {METHOD_VERSION,ENGINE_VERSION} from './calendar.js';
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
export const LUCK_METHOD=freeze({version:'jm-yun-utc-endpoint-minute-v1',schemaVersion:'jm-luck-cycle-v1',calendarMethod:METHOD_VERSION,
 engine:ENGINE_VERSION,timezone:TIMEZONE_VERSION,direction:'explicit-forward-or-backward',terms:'twelve-Jie; fixed-UTC8 engine facts converted to UTC',
 minuteDifference:'floor(laterUTC/60000)-floor(earlierUTC/60000)',ageUnits:{yearMinutes:4320,monthMinutes:360,dayMinutes:12,hoursPerRemainingMinute:2},
 addition:'UTC calendar years, then months, then days, then hours; clamp each year/month step',birthPrecision:'inclusive recorded minute; segmented at UTC-minute boundaries',
 jieGuardMilliseconds:120000,guardIsCertifiedErrorBound:false,cycles:8,cycleStarts:'first start plus 10n UTC calendar years, clamped independently; not chained ten-year additions',cycleAgeMeaning:'symbolic duration from birth; no nominal-age or real-event inference',
 authorization:'owner-approved local candidate 2026-10-23; not professional or public approval'});
const parts=ms=>{const d=new Date(ms);return [d.getUTCFullYear(),d.getUTCMonth()+1,d.getUTCDate(),d.getUTCHours(),d.getUTCMinutes(),d.getUTCSeconds()];};
const epoch=s=>Date.UTC(s.getYear(),s.getMonth()-1,s.getDay(),s.getHour(),s.getMinute(),s.getSecond())-28800000;
const iso=ms=>new Date(ms).toISOString();
export function ageFromEndpointMinutes(minutes){
 if(!Number.isSafeInteger(minutes)||minutes<0||minutes>50000)throw new RangeError('INVALID_YUN_MINUTES');
 const years=Math.floor(minutes/4320);minutes%=4320;const months=Math.floor(minutes/360);minutes%=360;
 return {years,months,days:Math.floor(minutes/12),hours:minutes%12*2};
}
export function addLuckCalendarUTC(ms,age){
 if(!Number.isFinite(ms)||!age||Object.keys(age).length!==4||!['years','months','days','hours'].every(k=>Number.isSafeInteger(age[k])&&age[k]>=0&&age[k]<=200))throw new RangeError('INVALID_YUN_AGE');
 const d=new Date(ms);if(!Number.isFinite(d.getTime()))throw new RangeError('INVALID_YUN_AGE');
 const day=d.getUTCDate();d.setUTCDate(1);d.setUTCFullYear(d.getUTCFullYear()+age.years);
 d.setUTCDate(Math.min(day,new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate()));
 const afterYear=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+age.months);
 d.setUTCDate(Math.min(afterYear,new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate()));
 d.setUTCDate(d.getUTCDate()+age.days);d.setUTCHours(d.getUTCHours()+age.hours);return d.getTime();
}
function localWindow(start,end,zone){
 try{return {status:'available',zone,start:iso(start+offsetAt(start,zone).seconds*1000).slice(0,-1),end:iso(end+offsetAt(end,zone).seconds*1000).slice(0,-1),startOffsetSeconds:offsetAt(start,zone).seconds,endOffsetSeconds:offsetAt(end,zone).seconds};}
 catch(e){if(e instanceof RangeError&&e.message==='Time zone or date outside the pinned data range.')return {status:'outside-pinned-timezone-range',zone,start:null,end:null};throw e;}
}
const cycleBase=()=>({schemaVersion:LUCK_METHOD.schemaVersion,method:LUCK_METHOD,chartContractVersion:CONTRACT_VERSION,eligibleForPublic:false,personalPrediction:false,professionalReview:'pending'});
const validDirection=options=>options&&Object.getPrototypeOf(options)===Object.prototype&&Object.keys(options).every(k=>k==='direction')&&['forward','backward'].includes(options.direction);
const blockedCycle=(code,extra={})=>freeze({...cycleBase(),status:'blocked',error:{code,retryable:false},...extra});
export function buildLuckCycle(input,options){
 if(!validDirection(options))return blockedCycle('EXPLICIT_DIRECTION_REQUIRED');
 let validated,chart;
 try{validated=validateInput(input);chart=resolveInput(validated);}catch(e){const code=inputErrorCode(e);if(!code)throw e;return blockedCycle(code);}
 return evaluateResolvedCycle(validated,chart,options);
}
// Same evaluator, same approved method and result schema. A copied/imported
// object cannot request a fallback recalculation; it fails provenance instead.
export function buildLuckCycleFromPrepared(pack,options){
 const c=readPreparedFactContext(pack);
 if(c.schemaVersion!==PREPARED_FACT_CONTEXT_VERSION||c.chartContractVersion!==CONTRACT_VERSION||c.chart.engineVersion!==LUCK_METHOD.engine||c.chart.timeZoneVersion!==LUCK_METHOD.timezone||c.chart.methodVersion!==LUCK_METHOD.calendarMethod)throw new RangeError('PREPARED_TIMING_VERSION_MISMATCH');
 return evaluateResolvedCycle(c.validatedInput,c.chart,options);
}
function evaluateResolvedCycle(validated,chart,options){
 const base=cycleBase(),blocked=blockedCycle;
 if(!validDirection(options))return blocked('EXPLICIT_DIRECTION_REQUIRED');
 const source={direction:options.direction,chartMethod:chart.methodVersion,zone:chart.timeZone??null,inputPrecision:validated.timePrecision,chartStatus:chart.status};
 if(validated.timePrecision!=='minute'||chart.status!=='calculated'||!chart.complete||!chart.instant)
  return blocked('RESOLVED_MINUTE_REQUIRED',{source,uncertainty:{pillars:chart.pillars??null,candidates:chart.candidates??[],yearMonthOptions:chart.yearMonthOptions??[],candidatePillars:chart.candidatePillars??[],gapMinutes:chart.gapMinutes??0,foldMinutes:chart.foldMinutes??0}});
 if(chart.methodVersion!==LUCK_METHOD.calendarMethod)return blocked('UNSUPPORTED_CHART_METHOD',{source});
 const birth=Date.parse(chart.instant),last=birth+59999;
 const endOffset=offsetAt(last,chart.timeZone).seconds;
 if(endOffset!==chart.offsetSeconds)return blocked('CIVIL_MINUTE_TRANSITION_REQUIRES_REVIEW',{source,uncertainty:{birthWindowUTC:[iso(birth),iso(last)],startOffsetSeconds:chart.offsetSeconds,endOffsetSeconds:endOffset}});
 const lunar=Solar.fromYmdHms(...parts(birth+28800000)).getLunar();
 const prev=lunar.getPrevJie(),next=lunar.getNextJie(),before=epoch(prev.getSolar()),after=epoch(next.getSolar());
 if(!(before<=birth&&after>birth))throw new RangeError('INVALID_JIE_ORDER');
 if(birth-before<=LUCK_METHOD.jieGuardMilliseconds||after-last<=LUCK_METHOD.jieGuardMilliseconds)
  return blocked('NEAR_JIE_REQUIRES_REVIEW',{source,uncertainty:{birthWindowUTC:[iso(birth),iso(last)],neighborJie:[{name:prev.getName(),instantUTC:iso(before)},{name:next.getName(),instantUTC:iso(after)}],guardIsCertifiedErrorBound:false}});
 const term=options.direction==='forward'?next:prev,termMs=epoch(term.getSolar());
 const evidence={birthWindowUTC:[iso(birth),iso(last)],term:{name:term.getName(),instantUTC:iso(termMs)},monthPillar:chart.pillars.month,
 sourceRefs:['T-YUN','J-YUN-UTC-APPROVED-V1'],independentEvidence:'research/method-audit-20261023; two astronomical anchors, not all-year certification'};
 const monthIndex=LunarUtil.JIA_ZI.indexOf(chart.pillars.month);if(monthIndex<0)throw new RangeError('INVALID_MONTH_PILLAR');
 const split=(Math.floor(birth/60000)+1)*60000,segments=split<=last?[[birth,split-1],[split,last]]:[[birth,last]];
 const candidates=segments.map(([low,high])=>{
  const minutes=Math.abs(Math.floor(termMs/60000)-Math.floor(low/60000)),age=ageFromEndpointMinutes(minutes),start=addLuckCalendarUTC(low,age),end=addLuckCalendarUTC(high,age);
  return {birthWindowUTC:[iso(low),iso(high)],endpointMinutes:minutes,symbolicAge:age,startWindowUTC:[iso(start),iso(end)],localStart:localWindow(start,end,chart.timeZone),
   cycles:Array.from({length:LUCK_METHOD.cycles},(_,i)=>{const from=addLuckCalendarUTC(start,{years:i*10,months:0,days:0,hours:0}),to=addLuckCalendarUTC(end,{years:i*10,months:0,days:0,hours:0});return {index:i+1,ganZhi:LunarUtil.JIA_ZI[(monthIndex+(options.direction==='forward'?1:-1)*(i+1)+600)%60],startWindowUTC:[iso(from),iso(to)],localStart:localWindow(from,to,chart.timeZone),meaning:'ordered traditional cycle; not an annual forecast'};})};
 });
 return freeze({...base,status:'local-candidate',source,evidence,candidates,uncertainty:{birthSecondsUnknown:true,astronomicalAccuracy:'not-certified',jieGuardIsHeuristic:true,exactRealWorldTiming:false},annualInterpretation:{status:'not-provided',reason:'Year enumeration does not establish LiChun intervals or event interpretations.'}});
}
export function renderLuckCycleMarkdown(result){
 if(result.schemaVersion!==LUCK_METHOD.schemaVersion||result.method.version!==LUCK_METHOD.version)throw new RangeError('UNSUPPORTED_LUCK_RESULT');
 const lines=['# Traditional cycle calculation — local candidate','',`Method: ${result.method.version}. Unreviewed; not for publication or sale.`,''];
 if(result.status==='blocked')return lines.concat(`Calculation withheld: ${result.error.code}. No birth time or direction was inferred.`,'').join('\n');
 lines.push(`Direction: ${result.source.direction}. Reference month: ${result.evidence.monthPillar}.`,
  `Reference Jie: ${result.evidence.term.name}, ${result.evidence.term.instantUTC}.`,
  'The windows retain the recorded minute. Calendar agreement does not validate predictions.','');
 for(const [i,c] of result.candidates.entries()){
  const duration=['year','month','day','hour'].map(unit=>`${c.symbolicAge[unit+'s']} ${unit}${c.symbolicAge[unit+'s']===1?'':'s'}`).join(', ');
  lines.push(`## Candidate ${i+1}`,`${c.endpointMinutes} endpoint minutes → symbolic duration: ${duration}.`,
   `Estimated first start window: ${c.startWindowUTC.join(' – ')}.`,
   c.localStart.status==='available'?`Pinned-zone display: ${c.localStart.start} – ${c.localStart.end} (${c.localStart.zone}).`:'Future local display is outside the pinned timezone data; no system-clock fallback.','',
   '| Cycle | Gan Zhi | Estimated UTC start window | Local display |','| --- | --- | --- | --- |',...c.cycles.map(x=>`| ${x.index} | ${x.ganZhi} | ${x.startWindowUTC.join(' – ')} | ${x.localStart.status} |`),'');
  if(c.cycles.some(x=>x.localStart.status!=='available'))lines.push('Future local display is outside the pinned timezone data for one or more cycles; UTC estimates are retained without a system-clock fallback.','');
 }
 return lines.concat('No annual event, health, income or relationship prediction is supplied.','').join('\n');
}
