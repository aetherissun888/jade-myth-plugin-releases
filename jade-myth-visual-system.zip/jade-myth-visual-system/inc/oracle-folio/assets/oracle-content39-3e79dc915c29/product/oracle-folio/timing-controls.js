/** Opt-in private timing inputs. No device-zone inference, network or persistence. */
import {ALL_TIMEZONES} from './timezone.js';
export function calendarZoneChoices(birthZone){
 const rows=[[birthZone,'Birthplace timezone'],['America/New_York','New York / Eastern Time'],['America/Chicago','Chicago / Central Time'],['America/Denver','Denver / Mountain Time'],['America/Los_Angeles','Los Angeles / Pacific Time'],['America/Anchorage','Anchorage / Alaska Time'],['Pacific/Honolulu','Honolulu / Hawaii Time'],[ALL_TIMEZONES.includes('UTC')?'UTC':'Etc/UTC','Universal Time (UTC)']];
 const unique=new Map();for(const [zone,label]of rows)if(ALL_TIMEZONES.includes(zone)&&!unique.has(zone))unique.set(zone,label);
 return [...unique].map(([value,label])=>({value,label}));
}
export function installTimingControls(root,anchor,{birthZone,isCurrent,onChange,onApply,onRemove}){
 const doc=root.ownerDocument,make=(tag,text,parent)=>{const n=doc.createElement(tag);if(text)n.textContent=text;if(parent)parent.append(n);return n;};
 const panel=make('details');panel.className='report-timing-controls';make('summary','Explore a year and your longer cycles',panel);
 make('p','Choose a year and a calendar timezone. The optional cycle direction must come from a convention you already know; you can leave it unknown. We do not infer it from your name or identity.',panel);
 const form=make('form','',panel),grid=make('div','',form);grid.className='report-timing-fields';
 const field=(text,id,tag)=>{const label=make('label',text,grid);label.htmlFor=id;const input=make(tag,'',label);input.id=id;return input;};
 const year=field('Year to explore','report-timing-year','input');year.type='number';year.min='1901';year.max='2026';year.step='1';year.required=true;year.placeholder='1901–2026';
 const zone=field('Calendar timezone','report-timing-zone','select');zone.required=true;
 const direction=field('Cycle direction (optional)','report-timing-direction','select');
 const option=(select,value,text)=>{const o=make('option',text,select);o.value=value;};
 option(zone,'','Choose a timezone');for(const choice of calendarZoneChoices(birthZone))option(zone,choice.value,choice.label);
 option(direction,'','Unknown — do not build a personal cycle');option(direction,'forward','Forward sequence');option(direction,'backward','Backward sequence');
 const buttons=make('div','',form);buttons.className='report-timing-actions';
 const build=make('button','Build timing view',buttons);build.type='submit';
 const remove=make('button','Remove timing view',buttons);remove.type='button';remove.disabled=true;
 const status=make('p','No timing view has been added.');status.setAttribute('role','status');status.setAttribute('aria-live','polite');panel.append(status);
 make('p','This is a private cultural reference, not a forecast or an offer to buy.',panel);
 const note=make('p','Saving with Omit birth details excludes calculated personal cycle dates. The selected shared calendar timezone still appears in saved copies.',panel);note.className='quiet';
 anchor.before(panel);
 const changed=()=>{if(!isCurrent())return;onChange();remove.disabled=true;status.textContent='Timing options changed. The previous timing view has been removed.';};
 const submit=event=>{event.preventDefault();if(!isCurrent())return;build.disabled=true;
  try{const result=onApply({targetYear:year.value.trim()===''?null:Number(year.value),displayZone:zone.value,direction:direction.value||null});remove.disabled=!result.ok;status.textContent=result.message;}
  catch{remove.disabled=true;status.textContent='The timing view could not be prepared. Your base reading is unchanged.';}
  finally{build.disabled=false;}
 };
 const clear=()=>{if(!isCurrent())return;onRemove();year.value='';zone.value='';direction.value='';remove.disabled=true;status.textContent='Timing view removed. Your base reading is unchanged.';};
 year.addEventListener('input',changed);zone.addEventListener('change',changed);direction.addEventListener('change',changed);form.addEventListener('submit',submit);remove.addEventListener('click',clear);
 return ()=>{year.removeEventListener('input',changed);zone.removeEventListener('change',changed);direction.removeEventListener('change',changed);form.removeEventListener('submit',submit);remove.removeEventListener('click',clear);panel.remove();};
}
