/** Original US-English editorial candidates. Historical category analogies are
 * not evidence of personality or outcomes. No imported modern translation. */
export const READING_CONTENT_VERSION='jm-personal-reading-en-v2.1.39';
export const READING_RULE_VERSION='jm-symbolic-theme-composition-v2.1';
export const READING_CARDS=[
 {id:'craft',domain:'work',title:'Ideas that can stand up to scrutiny',
 counterParagraph:'The supporting side of this reading makes review and mentorship worth considering alongside independence. A second pair of eyes can help you strengthen an idea before you need to defend it. Asking for that help and keeping your own judgment are compatible choices.',
 selectors:[{kind:'visible-relationship',family:'output',label:'伤官'},{kind:'hidden-relationship',family:'constraint'}],
 counterFamilies:['resource'],counterCondition:'Practical experience, job autonomy and available support can make questioning a strength rather than a source of friction.',
 bridge:'Expression/generation together with regulation/constraint: an original modern work analogy, not a formation verdict.',
 paragraphs:[
 'Your work reading centers on the meeting of expression and accountability: making something your own while knowing it has to hold up to a standard. A promising question for you is not simply “Can I do this well?” but “Can I explain why this way is better?” The chart brings both themes into the reading, rather than suggesting that originality and discipline are opposites.',
 'In a project review, this can look like noticing a weak assumption before the rest of the group does. The useful contribution is the alternative you can demonstrate: a draft, a comparison, a small test. When criticism arrives before that alternative, people may hear resistance where you meant improvement. A concrete trial gives your judgment somewhere to land without asking everyone to trust your taste immediately.',
 'The work setting to examine is one with a clear result and room to choose the method. A very open-ended role may leave you without useful feedback, while tightly prescribed methods may leave less room for your contribution. Before accepting a role, ask who decides what good work looks like, how disagreements are tested, and which decisions you would actually own. Those answers are more useful than a job title supposedly destined for you.',
 'For your next project, separate the nonnegotiable requirement from the habit you want to change. Keep the first visible while testing the second. This interpretation concerns the symbolic tension between expression and standards; it does not establish a particular talent or career outcome.'
 ]},
 {id:'learning',domain:'learning',title:'Turning what you absorb into something usable',
 counterParagraph:'The responsibility theme elsewhere in your chart adds a practical limit to this learning loop: other people may need the work before you feel ready. Agree on a first usable version and a later revision, so preparation does not quietly become an indefinite delay.',
 selectors:[{kind:'hidden-relationship',family:'resource'},{kind:'visible-relationship',family:'output'}],
 counterFamilies:['constraint'],counterCondition:'A deadline or a responsibility to other people may require completion before you feel fully prepared.',
 bridge:'Receiving/support and generation/expression are read as a learning-to-making sequence; no strength or useful-element conclusion.',
 paragraphs:[
 'There is a second, different theme here: learning becomes valuable when you can put it into your own words or make something with it. Your chart pairs the symbolism of receiving support with visible expression. This reading therefore asks about the distance between understanding an idea and using it, rather than treating more preparation as an automatic answer.',
 'Imagine learning a piece of music from several demonstrations. Trying a few measures, then describing where you lose the rhythm, can show what another general lesson would miss. That particular gap gives the next lesson a purpose. In this reading, receiving guidance and making it your own can take turns.',
 'Support also has a practical shape. A teacher can supply context, a colleague can review a draft, and a routine can protect uninterrupted time. Choose the kind that helps the task move. Receiving help does not mean surrendering authorship. Conversely, explaining everything yourself can become an expensive way to prove independence when a short question would unblock the work.',
 'Try a small learning loop: name the question, make a rough attempt, obtain one useful correction, then revise. Notice whether you are missing information or avoiding the discomfort of an imperfect first version. The chart supplies a lens for that distinction; your actual experience determines which side needs attention.'
 ]},
 {id:'shared-money',domain:'money',title:'Clear ownership before shared effort',
 counterParagraph:'There is also a support theme in the chart. In this reading, that leaves room for help to be freely given without every relationship becoming a transaction. Distinguish a gift from a loan or a shared obligation; clarity need not make generosity feel smaller.',
 selectors:[{kind:'visible-relationship',family:'peer'},{kind:'hidden-relationship',family:'managed'}],
 counterFamilies:['resource'],counterCondition:'Stable outside support and an already explicit agreement can reduce the ownership tension; peer symbolism is not evidence of rivalry.',
 bridge:'Peers/independence paired with things administered: an original analogy for shared resources, not income or risk prediction.',
 paragraphs:[
 'The money theme in this reading is ownership in shared situations. Independence appears alongside the traditional symbolism of managing tangible resources. That combination raises a specific question: when time, money or effort is pooled, are you clear about what remains yours to decide? It says more about the terms worth examining than about how much money you will have.',
 'Consider a shared purchase or a project with a friend. Equal enthusiasm does not answer who pays first, who keeps the item, or what happens if one person leaves. Talking about those details early protects the relationship from having to carry an unspoken business agreement. Generosity and clear terms can exist in the same conversation.',
 'A useful distinction is the difference between contributing and becoming responsible for everything. You might offer a fixed amount of time or money without taking on an unlimited obligation to rescue the plan. Put a review date beside the commitment. A small agreement that can be revisited is often easier to honor than a sweeping promise made while everyone is excited.',
 'Use this section to examine one real arrangement: what is shared, what is separate, and who has final authority? Decisions about investing, borrowing or affordability still need your actual finances and qualified advice. No gain, loss or financial aptitude is inferred from these symbols.'
 ]},
 {id:'care-boundaries',domain:'relationships',title:'Being dependable without disappearing into the role',
 counterParagraph:'The chart also leaves room for independent expression. Bring a preference of your own into the conversation, rather than talking only about what needs doing. A relationship can include both practical reliability and interests that neither person has to justify by being useful.',
 selectors:[{kind:'hidden-relationship',family:'resource',position:'hour'},{kind:'hidden-relationship',family:'constraint',position:'month'}],
 counterFamilies:['peer','output'],counterCondition:'Independent choices and direct communication may already keep responsibility from becoming silent overcommitment.',
 bridge:'Support/receiving together with responsibility/regulation: a modern reciprocal-care reading, not spouse-star or compatibility analysis.',
 paragraphs:[
 'In close relationships, this chart offers a lens on care and responsibility. The symbolism of support sits beside the symbolism of duty, making “being there” a more useful starting point than a prediction about romance. The question is whether dependability leaves room for both people to have needs, preferences and limits.',
 'A familiar situation is agreeing to handle the practical details because you know you can do them. Over time, the person who remembers everything can become the person who is never asked what they need. If that pattern exists in your life, make the task visible before resentment becomes the only sign that it is too much. An explicit request gives the other person a chance to respond.',
 'Receiving care may need as much clarity as offering it. “I need help” can mean company, advice, a concrete task or space to think. Naming which kind you want prevents a good intention from becoming a misunderstanding. Reciprocity does not require identical contributions; it requires an arrangement that both people can recognize and discuss.',
 'This is a reflection on your participation in a relationship, not a finding about another person’s love, fidelity or intentions. Compare it with how the two of you actually communicate. One useful conversation is to name something you gladly give and something you would like to stop doing automatically.'
 ]},
 {id:'equal-voice',domain:'collaboration',title:'A fair voice and a clear decision',
 counterParagraph:'A supporting theme also appears here. In a shared decision, a trusted adviser can help you test an assumption without becoming the person who decides for you. Make that role explicit: advice, a second opinion and final authority are different forms of involvement.',
 selectors:[{kind:'visible-relationship',family:'peer'},{kind:'hidden-relationship',family:'constraint'}],
 counterFamilies:['resource'],counterCondition:'Established trust, mentorship or an agreed decision process may make the independence/accountability tension easy to manage.',
 bridge:'Peer participation plus regulation: original analogy for decision rights, not a prediction of workplace conflict.',
 paragraphs:[
 'Collaboration brings a question separate from the quality of your work: how do equal voices reach a decision? Your reading combines independence with accountability. It invites you to examine whether a group gives you a real say while making clear who is responsible for the final choice.',
 'Planning a day out with friends can give everyone a say without requiring a vote on every detail. You might choose the destination together and let one person book the tickets within an agreed budget. The useful distinction is between a choice that needs everyone’s agreement and a decision someone has been trusted to make.',
 'When you disagree, identify what you need to protect. It may be the outcome, your authority over a task, or simply the chance to be heard. Those are different requests. Stating the real one makes it easier for someone else to respond without interpreting every objection as a challenge to their position.',
 'A useful experiment is a small, reversible assignment with written decision rights. Observe whether the arrangement makes cooperation easier. The symbols do not show that colleagues are competitive or that you must work alone; the practical agreement is what you can evaluate.'
 ]},
 {id:'ideas-value',domain:'money',title:'What a contribution asks of your resources',
 counterParagraph:'The peer theme elsewhere in the chart adds a shared-work question: is the stopping point yours to set, or does someone else also own the result? Agree on acceptance together before treating your own sense of completion as the whole agreement.',
 selectors:[{kind:'visible-relationship',family:'output'},{kind:'hidden-relationship',family:'managed'}],
 counterFamilies:['peer'],counterCondition:'Shared ownership or divided responsibilities may matter more than an individual completion process; no commercial success is implied.',
 bridge:'Generation/expression and tangible administration: original analogy for translating a contribution into a defined deliverable.',
 paragraphs:[
 'Your resource reading connects making a contribution with deciding what you can commit to it. The question is whether the result justifies the time, money or materials it takes. A worthwhile idea can still need a smaller scope; enjoying the work and being able to sustain it are different matters.',
 'Suppose a friend asks you to help with a birthday dinner. Bringing one dish and becoming responsible for the whole evening are different promises. Changing that dish to suit a guest may fit what you agreed; adding the shopping and cleanup changes the commitment. Naming the difference leaves room for generosity without quietly promising every part.',
 'Where money is involved, separate enthusiasm for the work from the terms of the exchange. Scope, payment, revisions and time limits need their own conversation. Enjoying the making does not tell you whether a price is affordable or an agreement is fair.',
 'This question matters most when extra work consumes resources you had committed elsewhere. In a freely chosen hobby or an explicitly open-ended gift, the exchange may be beside the point. Use actual costs and agreements to judge which situation you are in; the reading does not estimate earnings or recommend a financial decision.'
 ]},
 {id:'patient-craft',domain:'work',title:'Building quality through a repeatable process',
 counterParagraph:'An independence theme also appears in this chart. A repeatable process should leave some room to change the method when experience reveals a better one. Give yourself a review point instead of making a useful routine into a permanent rule.',
 selectors:[{kind:'visible-relationship',family:'output',label:'食神'},{kind:'hidden-relationship',family:'constraint'}],
 counterFamilies:['peer'],counterCondition:'Independent initiative or a fast-changing environment may call for a less settled process.',
 bridge:'The historical nourishment/production naming analogy, paired with regulation; a modern craft-process reflection, not an Eating-God formation or a talent verdict.',
 paragraphs:[
 'Your work reading connects patient production with the demand for a dependable result. Rather than centering on challenging an existing approach, this combination invites a question about craft: what can you make reliably good, and what process lets you keep doing it without starting from scratch each time?',
 'Think of a task you repeat: preparing a presentation, cooking for other people, writing a proposal or maintaining a system. A modest routine can free your attention for the part that deserves judgment. The goal is not to turn everything into a checklist. It is to stop spending the same energy on decisions you have already resolved.',
 'A repeatable method is most useful when the task is familiar but its quality varies. Compare two attempts and look for the step that changed: the preparation, the sequence or the review. If the assignment itself is unfamiliar, following the old routine more closely may preserve the wrong assumption. In that setting, test the approach before making it a habit.',
 'For one recurring task, ask someone to follow your process without your help. Where do they need to ask a question? That point may depend on judgment you have never explained. Decide which parts can be taught and which deserve your attention each time. This is a question about the work, not a claim of an inborn skill.'
 ]},
 {id:'supported-authority',domain:'work',title:'Responsibility with enough support to carry it',
 counterParagraph:'This chart also includes room for an independent contribution. Support need not mean accepting every existing method. Establish the requirement first, then make a specific proposal for what you would change and how the result could be checked.',
 selectors:[{kind:'visible-relationship',family:'constraint'},{kind:'hidden-relationship',family:'resource'}],
 counterFamilies:['output','peer'],counterCondition:'Scope to challenge a process or make independent decisions can change how responsibility is experienced.',
 bridge:'Regulation/responsibility plus support/receiving: original work analogy, not a formal authority-resource formation.',
 paragraphs:[
 'Your work reading emphasizes responsibility together with support. This is less a story about standing out through a new idea than about having the knowledge, authority and resources to carry what is entrusted to you. The central question is whether your responsibilities are matched by what you can actually control.',
 'An assignment can sound like recognition while leaving you dependent on approvals you cannot obtain. Before accepting it, ask what you can decide, what help is available, and what happens when priorities conflict. Responsibility becomes more workable when those answers are explicit.',
 'The supporting side of this pattern also gives preparation a purpose. Training, a documented process or an experienced reviewer can make a demanding task less personal. A correction then becomes information about the task rather than a verdict on your worth.',
 'Look at one obligation that feels heavy. Is the missing piece skill, permission, time or help? Each needs a different response. This reading does not establish that you are destined for leadership or that pressure is good for you; it offers a way to inspect the structure around the work.'
 ]},
 {id:'mutual-space',domain:'relationships',title:'Closeness with room for separate interests',
 counterParagraph:'Responsibility is another theme in the chart. Separate interests still sit inside real commitments to each other. Agree on what will reliably be handled before dividing the remaining time, so personal space is not purchased with someone else’s unspoken extra workload.',
 selectors:[{kind:'visible-relationship',family:'peer'},{kind:'hidden-relationship',family:'output'}],
 counterFamilies:['constraint'],counterCondition:'Care responsibilities or explicit shared commitments may limit how much separate time is available.',
 bridge:'Peer/independence and generation/expression: original relationship analogy, not spouse selection or compatibility.',
 paragraphs:[
 'Your relationship reading pairs individuality with expression. A useful theme is being able to stay close without needing to share every interest, opinion or activity. The question is what makes separate space feel like part of a good relationship rather than a withdrawal from it.',
 'Picture one person wanting to talk through a new interest while the other wants a quiet evening. A clear invitation is easier to answer than a test of affection: “I would like twenty minutes to show you this” leaves room for an honest yes, a different time, or a different kind of support.',
 'Separate preferences become easier to accommodate when shared commitments are visible. Agree on what you reliably do together, then leave room around it for individual projects and friendships. Independence does not have to mean handling every difficulty alone.',
 'Ask what you want someone close to you to understand, and what you are comfortable keeping as your own pursuit. The chart does not reveal anyone else’s feelings or show that a particular relationship will succeed; those depend on the people and their actions.'
 ]}
];


// Bounded combinations of different, compatible questions. These are editorial
// recipes, not evidence that one relation is more important than another.
const workMembers=['craft','patient-craft','supported-authority'];
const workApproaches=['testing an idea','developing a dependable process','carrying a responsibility with adequate support'];
const workLead=indexes=>{
 const parts=indexes.map(i=>workApproaches[i]);
 const list=parts.length===2?parts.join(' and '):parts.slice(0,-1).join(', ')+', and '+parts.at(-1);
 return 'Your work reading includes more than one approach: '+list+'. The sections below retain the approaches actually supported by this chart. They can describe different tasks; none is declared your single fixed work style.';
};
export const READING_COMPOSITIONS=[
 {id:'money-exchange',domain:'money',members:['ideas-value','shared-money'],title:'Useful work, clear terms',
  rationale:'Expression plus tangible administration concerns deliverables; peers plus tangible administration concerns shared ownership. Both questions are compatible and neither entails or outranks the other.',
  lead:'Two resource themes meet in your chart: turning a contribution into something useful, and being clear about ownership when effort is shared. The first asks what you are making and when it is done. The second asks who contributes, decides and benefits. A good agreement needs both answers; enthusiasm for the work does not settle either one.',
  fragments:[{member:'ideas-value',index:1},{member:'ideas-value',index:2},{member:'shared-money',index:1},{member:'shared-money',index:2},{member:'shared-money',index:3},{member:'shared-money',counter:true}]},
 {id:'relationship-both',domain:'relationships',members:['care-boundaries','mutual-space'],title:'Care with room to be yourself',
  rationale:'Support/duty and individuality/expression concern different aspects of reciprocal relationships. Keep both without diagnosing another person or making one a strength verdict.',
  lead:'This relationship reading brings care and individuality together. Being dependable can matter without becoming your whole role; having interests of your own can matter without making closeness feel secondary. The useful question is how the people involved can recognize both shared responsibilities and separate preferences.',
  fragments:[{member:'care-boundaries',index:1},{member:'care-boundaries',index:2},{member:'mutual-space',index:1},{member:'mutual-space',index:2},{member:'care-boundaries',index:3},{member:'mutual-space',counter:true}]},
 ...[[0,1],[0,2],[1,2],[0,1,2]].map(indexes=>({id:'work-both',domain:'work',members:indexes.map(i=>workMembers[i]),title:'More than one way to contribute',lead:workLead(indexes),
  rationale:'Distinct work questions may coexist. Retain concrete scenarios without treating visible/hidden placement, count or source order as psychological importance.',
  fragments:indexes.flatMap(i=>[{member:workMembers[i],index:1},{member:workMembers[i],index:2},{member:workMembers[i],counter:true}])}))
];
// Explicit question identity is required before any future refinement can
// supersede another card. No current cards declare such a refinement.
for(const card of READING_CARDS){card.question=card.id;card.refines=[];card.conflictsWith=[];}
export const READING_ACTIONS={
 'money-exchange':'Choose one shared project or purchase. Write two short lines: what a finished, useful result would look like, and who can decide what. Check those lines with the other person before adding more work or money. Notice whether you disagree about the result, the ownership, or both.',
 'ideas-value':'Choose one unfinished contribution. Name who would use it, the smallest version that would help them, and a stopping point for the first attempt. Make that version before expanding the project. Then ask whether it did what the recipient actually needed.',
 'shared-money':'Choose one shared commitment. Write down what each person is contributing, who can make which decisions, and how either person can revisit the arrangement. Ask the other person to describe the same agreement in their own words; compare any differences before adding another obligation.',
 'craft':'Choose one improvement you want to propose. Write the requirement you will preserve and make one small example of what you would change. Ask for feedback on that example before debating the whole approach.',
 'patient-craft':'Choose a task you repeat. Write down a short process and a clear example of an acceptable result. Try it once, then change only the step that caused an actual problem.',
 'supported-authority':'Choose one responsibility that feels difficult to carry. Name what you are accountable for and which decisions you can actually make. Ask for the specific permission, information or help missing between those two lists.',
 'relationship-both':'Name one shared task you willingly handle and one personal interest you want to protect time for. Discuss both in the same conversation, so caring for the relationship does not require guessing what either person needs.',
 'care-boundaries':'Name one task you have been handling automatically. Ask whether the current arrangement still works for both people, and make one specific request before agreeing to take on more.',
 'mutual-space':'Choose one interest you want to pursue independently and one activity you want to share. Make a clear invitation for the shared time rather than using it as an unspoken test of closeness.',
 'learning':'Choose something you recently learned. Use it in a small attempt, then ask for one concrete correction. Let that experience decide what you study next.',
 'equal-voice':'Before one shared task, agree on a decision each person can make independently and a decision you will make together. Revisit that agreement if the task changes.',
 'work-both':'Choose one current task and ask whether it needs a better idea, a more repeatable process or clearer responsibility. Test a small change to that part before changing the whole arrangement.'
};
