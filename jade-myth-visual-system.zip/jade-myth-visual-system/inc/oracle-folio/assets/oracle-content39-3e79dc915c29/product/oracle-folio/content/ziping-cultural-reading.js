/** One source-bounded cultural synthesis; no chart calculation or operative pattern verdict. */
import{assertClaimLedgerSource}from'./claim-ledger.js';
import{assertZipingProfileSource}from'./ziping-month-profile.js';
const unique=x=>[...new Set(x)].sort();
export const ZP_TWO_SUPPORTS_RULE='Jade-ZP-two-supports-cultural-reading-v1';
export function buildZipingCulturalReading(snapshot,profile,ledger){
 assertClaimLedgerSource(ledger,snapshot);assertZipingProfileSource(profile,snapshot);
 const base={ruleId:ZP_TWO_SUPPORTS_RULE,status:'not-established',evidenceIds:[],counterEvidenceIds:[],sourceRefs:['ZP-OFFICER-TWO-SUPPORTS','ZP-OFFICER-SUPPORT-FUNCTIONS'],
  formation:null,preferredSupport:null,personalityDiagnosis:false,unknownPositions:profile.missingPositions};
 if(profile.branchId!=='Jia-You-ZhengGuan-entry-v1')return{...base,status:'outside-this-cultural-branch'};
 if(profile.status!=='entry-established')return{...base,status:profile.status==='input-insufficient'?'input-insufficient':'outside-implemented-branch'};
 const facts=snapshot.derived.facts,visible=facts.filter(f=>f.kind==='visible-relationship').sort((a,b)=>a.factId.localeCompare(b.factId,'en')),wealth=visible.filter(f=>f.value.family==='managed'),resource=visible.filter(f=>f.value.family==='resource');
 if(!wealth.length||!resource.length)return{...base,status:profile.missingPositions.length?'input-open':'not-established'};
 const evidenceIds=unique([...profile.entry.evidenceIds,...wealth.map(f=>f.factId),...resource.map(f=>f.factId)]);
 const supportingPairs=facts.filter(f=>f.kind==='stem-combination'&&wealth.some(w=>f.value.includes(w.value.otherStem))&&resource.some(r=>f.value.includes(r.value.otherStem)));
 const counters=unique([...profile.contexts.flatMap(c=>c.evidenceIds),...supportingPairs.map(f=>f.factId)]);
 const conditions={monthPatternEntry:profile.branchId,visibleWealth:wealth.map(f=>f.factId),visibleResource:resource.map(f=>f.factId),
  sourcePaths:[...profile.entry.sourcePaths,...[...wealth,...resource].map(f=>'snapshot.derived.facts[factId='+f.factId+']')],
  interpretation:'two potential support functions and their possible trade-off; not proven simultaneous effective use',
  productScope:'withhold this optional synthesis when known listed interaction context requires separate review; this does not declare the chart damaged',
  missingHourNotAnAbsence:true,positionsStable:true,knownListedContextCount:profile.contexts.length,pairedSupportContextCount:supportingPairs.length,globalContextAssessed:false,operativeNoninterference:'unassessed'};
 if(counters.length)return{...base,status:'withheld-known-context',evidenceIds,counterEvidenceIds:counters,conditions};
 const hourNotice=profile.missingPositions.includes('hour')?(snapshot.chart.status==='incomplete-time'?'Your birth time is unknown. ':'The birth hour is unresolved. ')+'This passage uses only the stable parts of your chart; the missing hour could add conditions that change the interpretation.':'';
 const result={...base,status:'supported-cultural-structure',evidenceIds,conditions,
  title:'Results and preparation can pull in different directions',id:'reading-month-support',
  overview:'A distinctive connection in this reading is the balance between delivering something useful and preserving the support to do it well. The interpretation below explores that relationship.',
  freeLayers:['traditional-cultural-interpretation','structural-context'],
  detailedLayers:['traditional-cultural-interpretation','traditional-cultural-interpretation','traditional-cultural-interpretation','modern-reflection','structural-context'],
  freeParagraphs:[
   'In this cultural reading, you may feel a pull between getting a useful result and making sure you are properly prepared for it. Both can serve a wish to meet a clear standard. The tension is that keeping something running and giving yourself room to learn are not always the same priority.',
   'This theme comes from a combination in your chart: responsibility is considered alongside both material backing and receiving help. In this tradition, the two forms of backing need to work together rather than being counted as two separate advantages.'
  ],
  detailedParagraphs:[
   'This chapter is Jade’s contemporary symbolic interpretation of two support roles in the traditional structure. One is the ability to manage something tangible and bring it to a usable result. The other is the knowledge, guidance or protection that helps you carry the demand. Because both appear in the known chart, this is a reading about their relationship, rather than a single label for your character.',
   'The first path gives a standard something concrete to stand on: a finished piece of work, a maintained commitment or resources that make a responsibility possible. Its limit is that immediate output can consume the time and backing needed to keep doing the work well. A result that is visible today and the support that sustains it are related, but they are not interchangeable.',
   'The second path changes how a demand is carried. Preparation or an experienced person can make a responsibility more manageable; it can also absorb attention that would otherwise go into acting. The distinction is between support that enables a decision and preparation that keeps postponing it. That distinction is Jade’s modern application of the traditional support relationship, not an ancient statement about your habits.',
   'Consider the difference between work that is already familiar and a task you have never done. In the first, more preparation may add little while a clear stopping point helps you deliver. In the second, rushing toward a visible result can remove the learning or help the task genuinely needs. The point is not always to choose output or always to choose support, but to notice which one is doing useful work in the situation.',
   'Zi Ping treats the two supports as a question of whether they can coexist without obstructing one another. Their appearance here does not settle that question. This reading therefore keeps both possibilities in view instead of naming one as your favorable element, promising success, or claiming a completed pattern.'
  ],
  basis:'The stable month-led starting category appears together with openly recorded practical-resource and support categories. The source distinguishes what feeds a responsibility from what protects or relieves it, and makes their effective coexistence conditional. The everyday language is Jade’s original cultural interpretation of that structure, not a quotation about your personality.'};
 if(hourNotice){result.freeParagraphs[1]+=' '+hourNotice;result.detailedParagraphs[0]+=' '+hourNotice;}
 return result;
}
