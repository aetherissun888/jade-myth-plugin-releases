/** Additive private timing facts over one already-prepared natal snapshot.
 * No UI, natal recalculation, prediction, network, storage or payment. */
import {readPreparedFactContext} from '../foundation/export-adapter.js';
import {buildLuckCycleFromPrepared,LUCK_METHOD,renderLuckCycleMarkdown} from '../luck-cycle.js';
import {buildAnnualFacts,ANNUAL_FACTS_METHOD,annualFactsSection} from './calendar.js';
export const PREPARED_TIMING_VERSION='jm-prepared-timing-extension-v1';
const held=new WeakMap();
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
const error=(code,message)=>freeze({ok:false,schemaVersion:PREPARED_TIMING_VERSION,error:{code,message,retryable:false}});
export function prepareTimingExtension(pack,options){
 const context=readPreparedFactContext(pack);
 if(!options||Object.getPrototypeOf(options)!==Object.prototype||Object.keys(options).some(k=>!['direction','targetYear','displayZone'].includes(k)))return error('INVALID_TIMING_OPTIONS','Supply a supported target year and explicit display timezone.');
 const {direction,targetYear,displayZone}=options,missing=direction==null||direction==='';
 if(!missing&&!['forward','backward'].includes(direction))return error('INVALID_DIRECTION','Choose forward or backward, or leave direction unknown.');
 let annual;
 try{annual=buildAnnualFacts(targetYear,displayZone);}
 catch(e){if(e instanceof RangeError&&['UNSUPPORTED_TARGET_YEAR','EXPLICIT_DISPLAY_ZONE_REQUIRED'].includes(e.message))return error(e.message,'Use target year 1901–2026 and an explicitly supported IANA timezone.');throw e;}
 const luck=buildLuckCycleFromPrepared(pack,missing?{}:{direction});
 const chart=context.chart;
 if(luck.method.version!==LUCK_METHOD.version||annual.methodVersion!==ANNUAL_FACTS_METHOD||annual.engineVersion!==chart.engineVersion||annual.timeZoneVersion!==chart.timeZoneVersion)fail('PREPARED_TIMING_VERSION_MISMATCH');
 if(luck.source&&(luck.source.zone!==chart.timeZone||luck.source.chartStatus!==chart.status||luck.source.inputPrecision!==context.validatedInput.timePrecision))fail('PREPARED_TIMING_SOURCE_DRIFT');
 if(luck.status==='local-candidate'&&(luck.evidence.birthWindowUTC[0]!==chart.instant||luck.evidence.monthPillar!==chart.pillars.month))fail('PREPARED_TIMING_SOURCE_DRIFT');
 const result=freeze({ok:true,schemaVersion:PREPARED_TIMING_VERSION,
  source:{reportId:context.sourceReportId,createdAt:context.sourceCreatedAt,factContextVersion:context.schemaVersion,chartContractVersion:context.chartContractVersion,assemblyVersion:context.sourceAssemblyVersion,ruleVersion:context.ruleVersion,readingContentVersion:context.readingContentVersion,readingCompositionVersion:context.readingCompositionVersion,selectionVersion:context.selectionVersion,calendarMethod:chart.methodVersion,engineVersion:chart.engineVersion,timeZoneVersion:chart.timeZoneVersion},
  chart,normalizedTime:context.normalizedTime,
  directionSelection:{status:missing?'not-provided':'explicit',value:missing?null:direction,inferred:false},
  luckCycle:luck,annualCalendar:annual,
  eligibleForPublic:false,purchasable:false,professionalReview:'pending',
  privacy:'Private in-memory reference. Contains birth and cycle information; not the customer reading export.',
  personalAnnualInterpretation:{status:'not-provided',reason:'Shared Jie dates and cycle order do not establish personal good/bad periods or real-world events.'}});
 held.set(result,pack);return result;
}
// Pair identity is a local provenance check, not authentication or revocation of
// copies already held by callers. Current UI consumers must use session guards.
export function assertTimingSource(extension,pack){
 readPreparedFactContext(pack);
 if(held.get(extension)!==pack)fail('PREPARED_TIMING_REQUIRED');
 return extension;
}
export function renderPreparedTimingMarkdown(extension){
 if(!held.has(extension))fail('PREPARED_TIMING_REQUIRED');
 const source=extension.source;
 return ['# Cycle and shared calendar facts — private reference','',
  'Synthetic review evidence when used with the review fixtures. Not a personal forecast, customer reading or commercial report.','',
  `Source report: ${source.reportId}. Source content: ${source.readingContentVersion}.`,
  `Snapshot method: ${source.calendarMethod}; engine: ${source.engineVersion}; timezone: ${source.timeZoneVersion}.`,
  `Birth input status: ${extension.chart.status}; direction: ${extension.directionSelection.value??'not supplied'}.`,
  '',renderLuckCycleMarkdown(extension.luckCycle),'',
  ...annualFactsSection(extension.annualCalendar).paragraphs,
  '', 'The annual section is a shared calendar. It is not a favorable/unfavorable personal timing interpretation.',''].join('\n');
}
