// Isolated foundation probe; no UI, service, payment or production integration.
import {calculateChart, METHOD_VERSION} from '../calendar.js';
import {civilCandidates,cityById} from '../timezone.js';
import {LunarUtil} from '../vendor/lunar-typescript-1.8.6/dist/index.js';
import {relateStems} from '../relationships.js';

export const VERSION='jm-foundation-probe-v2';
export const POSITIONS=['year','month','day','hour'];
const STEMS=[...'甲乙丙丁戊己庚辛壬癸'];
const BRANCHES=[...'子丑寅卯辰巳午未申酉戌亥'];
const pairs=rows=>rows.flatMap((a,i)=>rows.slice(i+1).map(b=>[a,b]));
const unique=rows=>[...new Map(rows.map(x=>[JSON.stringify(x),x])).values()];
const fail=code=>{throw new RangeError(code);};
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};

export function resolveInput(input){
 const {timePrecision,...base}=input;
 if(timePrecision==='unknown'){
  if(base.time!==null||base.range!=null||base.occurrence!=null)fail('INVALID_INPUT');
  return calculateChart(base);
 }
 if(timePrecision==='minute'){
  if(typeof base.time!=='string'||base.range!=null)fail('INVALID_INPUT');
  return calculateChart(base);
 }
 if(timePrecision!=='range'||base.time!=null||base.occurrence!=null)fail('INVALID_INPUT');
 const {start,end}=base.range||{},re=/^([01]\d|2[0-3]):[0-5]\d$/;
 if(!re.test(start)||!re.test(end)||start>end)fail('UNSUPPORTED_RANGE');
 // Reuse the existing date/place validation; do not invent another calendar.
 calculateChart({date:base.date,time:start,cityId:base.cityId});
 const minutes=t=>Number(t.slice(0,2))*60+Number(t.slice(3));
 const p=base.date.split('-').map(Number),zone=cityById(base.cityId).zone;
 const charts=[],instantCandidates=[];let gapMinutes=0,foldMinutes=0,validMinutes=0,nearSolarBoundary=false;
 for(let n=minutes(start);n<=minutes(end);n++){
  const h=Math.floor(n/60),m=n%60,time=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
  const instants=civilCandidates([...p,h,m,0],zone);
  if(!instants.length){gapMinutes++;continue;} validMinutes++;
  if(instants.length>1)foldMinutes++;
  for(const occurrence of instants.length>1?['first','second']:[null]){
   const c=calculateChart({date:base.date,time,cityId:base.cityId,occurrence});
   // A stable pillar does not mean the minute is distant from a solar term.
   // Preserve the existing calculator flag across every retained occurrence.
   nearSolarBoundary ||= c.nearSolarBoundary;
   instantCandidates.push({localTime:time,occurrence,startInstant:c.instant,endInstant:new Date(Date.parse(c.instant)+59999).toISOString(),offsetSeconds:c.offsetSeconds});
   // A minute straddling a term carries both alternatives, never null as a value.
   for(const ym of c.yearMonthOptions)charts.push({...c.pillars,...ym});
  }
 }
 if(!charts.length)return {status:'nonexistent-range',complete:false,methodVersion:METHOD_VERSION,range:base.range,gapMinutes,foldMinutes,validMinutes};
 const candidatePillars=unique(charts),pillars=Object.fromEntries(POSITIONS.map(k=>[k,new Set(charts.map(c=>c[k])).size===1?charts[0][k]:null]));
 const reference=calculateChart({date:base.date,time:null,cityId:base.cityId});
 return {...reference,status:'range-time',timePrecision:'range',range:base.range,complete:false,pillars,instant:null,
  yearMonthOptions:unique(charts.map(c=>({year:c.year,month:c.month}))),candidatePillars,candidateCount:candidatePillars.length,
  gapMinutes,foldMinutes,validMinutes,timeResolution:{instantCandidates},nearSolarBoundary:nearSolarBoundary||candidatePillars.some(c=>c.year!==charts[0].year||c.month!==charts[0].month)};
}

export function derive(chart){
 if(chart.methodVersion!==METHOD_VERSION)fail('UNSUPPORTED_METHOD');
 if(!['calculated','incomplete-time','boundary-minute','range-time'].includes(chart.status))fail('UNRESOLVED_TIME');
 if(!chart.pillars?.day)fail('MISSING_DAY');
 const rows=POSITIONS.filter(p=>chart.pillars[p]!=null).map(position=>{
  const value=chart.pillars[position];
  const si=STEMS.indexOf(value?.[0]),bi=BRANCHES.indexOf(value?.[1]);
  if(typeof value!=='string'||value.length!==2||si<0||bi<0||si%2!==bi%2)fail('INVALID_PILLAR');
  return {position,stem:value[0],branch:value[1],hidden:[...LunarUtil.ZHI_HIDE_GAN[value[1]]]};
 });
 const dayStem=chart.pillars.day[0],facts=[];
 const add=(kind,key,value,positions,sourceRefs)=>{const fact={factId:`${kind}:${key}`,kind,value,positions,fieldDependencies:positions.map(p=>`pillars.${p}`),sourceRefs};facts.push(fact);return fact;};
 for(const r of rows){
  add('hidden',r.position,{branch:r.branch,stems:r.hidden},[r.position],['S-HIDDEN']);
  if(r.position!=='day')add('visible-relationship',r.position,relateStems(dayStem,r.stem),['day',r.position],['S-TEN']);
  for(let i=0;i<r.hidden.length;i++){
   const stem=r.hidden[i],relation=relateStems(dayStem,stem);
   add('hidden-relationship',`${r.position}:${i}`,{stem,index:i,relation},['day',r.position],['S-HIDDEN','S-TEN']);
   if(stem===dayStem)add('exact-root',r.position,{stem,branch:r.branch,index:i},['day',r.position],['S-HIDDEN','J-ROOT']);
   else if(relation.family==='peer')add('phase-root',r.position,{stem,branch:r.branch,index:i},['day',r.position],['S-HIDDEN','J-ROOT']);
  }
 }
 const month=rows.find(r=>r.position==='month');
 if(month){
  add('month-relation','principal',{stem:month.hidden[0],relation:relateStems(dayStem,month.hidden[0])},['day','month'],['S-HIDDEN','S-TEN','J-MONTH']);
  for(const r of rows.filter(r=>r.position!=='day'&&month.hidden.includes(r.stem)))add('month-exposure',r.position,{stem:r.stem,monthBranch:month.branch},['month',r.position],['S-HIDDEN','J-EXPOSURE']);
 }
 for(const [a,b] of pairs(rows)){
  const key=`${a.position}:${b.position}`,positions=[a.position,b.position];
  if(LunarUtil.HE_GAN_5[STEMS.indexOf(a.stem)]===b.stem)add('stem-combination',key,[a.stem,b.stem],positions,['S-PAIRS']);
  if(LunarUtil.HE_ZHI_6[BRANCHES.indexOf(a.branch)]===b.branch)add('branch-combination',key,[a.branch,b.branch],positions,['S-PAIRS']);
  if(LunarUtil.CHONG[BRANCHES.indexOf(a.branch)]===b.branch)add('branch-clash',key,[a.branch,b.branch],positions,['S-PAIRS']);
 }
 return {dayStem,rows,facts,missing:POSITIONS.filter(p=>chart.pillars[p]==null)};
}

export const RULES=[
 {id:'R01',title:'Month principal stem: peer or resource relation',kind:'month-relation',families:['peer','resource'],needs:['day','month'],signal:'support',sources:['S-HIDDEN','S-TEN','J-MONTH']},
 {id:'R02',title:'Month principal stem: output, managed or constraint relation',kind:'month-relation',families:['output','managed','constraint'],needs:['day','month'],signal:'counter',sources:['S-HIDDEN','S-TEN','J-MONTH']},
 {id:'R03',title:'Exact Day Master stem in a branch',kind:'exact-root',needs:['day'],signal:'support',sources:['S-HIDDEN','J-ROOT']},
 {id:'R04',title:'Same phase, different stem in a branch',kind:'phase-root',needs:['day'],signal:'support',sources:['S-HIDDEN','J-ROOT']},
 {id:'R05',title:'A month hidden stem is also visible',kind:'month-exposure',needs:['day','month'],signal:'neutral',sources:['S-HIDDEN','J-EXPOSURE']},
 {id:'R06',title:'Visible peer or resource relations',kind:'visible-relationship',families:['peer','resource'],needs:['day'],signal:'support',sources:['S-TEN']},
 {id:'R07',title:'Visible output, managed or constraint relations',kind:'visible-relationship',families:['output','managed','constraint'],needs:['day'],signal:'counter',sources:['S-TEN']},
 {id:'R08',title:'Visible five-combination stem pair',kind:'stem-combination',needs:['day'],signal:'neutral',sources:['S-PAIRS']},
 {id:'R09',title:'Six-combination branch pair',kind:'branch-combination',needs:['day'],signal:'neutral',sources:['S-PAIRS']},
 {id:'R10',title:'Six-clash branch pair',kind:'branch-clash',needs:['day'],signal:'neutral',sources:['S-PAIRS']}
];

export function analyze(chart){
 const d=derive(chart);
 const findings=RULES.map(r=>{
  const matches=d.facts.filter(f=>f.kind===r.kind&&(!r.families||r.families.includes((f.value.relation||f.value).family)));
  const missing=r.needs.filter(p=>d.missing.includes(p));
  // Without a matching positive, missing positions forbid a global absence claim.
  const status=missing.length?'insufficient':matches.length?'supported':d.missing.length?'insufficient':'not-triggered';
  return {ruleId:r.id,ruleVersion:VERSION,title:r.title,status,signal:r.signal,evidenceIds:matches.map(f=>f.factId),
   missingDependencies:status==='insufficient'?[...new Set([...missing,...d.missing])].map(p=>`pillars.${p}`):[],
   omittedPositions:d.missing,sourceRefs:r.sources,scope:'stable displayed positions only',reviewStatus:'AI-assisted-unreviewed'};
 });
 const support=findings.filter(f=>f.status==='supported'&&f.signal==='support').map(f=>f.ruleId);
 const counter=findings.filter(f=>f.status==='supported'&&f.signal==='counter').map(f=>f.ruleId);
 const conflicts=[];
 if(support.length&&counter.length)conflicts.push({id:'mixed-relations',status:'contested',ruleIds:[...support,...counter],resolution:'retain both; no strength score or final useful-element decision'});
 const combine=d.facts.filter(f=>f.kind==='branch-combination'),clash=d.facts.filter(f=>f.kind==='branch-clash');
 for(const a of combine)for(const b of clash)if(a.positions.some(p=>b.positions.includes(p)))conflicts.push({id:`overlap:${a.factId}:${b.factId}`,status:'contested',evidenceIds:[a.factId,b.factId],resolution:'both pair labels remain; no automatic transformation or cancellation'});
 return {derived:d,findings,reconciled:{supportEvidence:support,counterEvidence:counter,conflicts,omissions:d.missing,
  strengthConclusion:null,patternConclusion:null,usefulElement:null,annualTiming:null}};
}

function explainFact(f){
 const p=f.positions.join(' / '),v=f.value;
 if(f.kind==='hidden')return `${p}: ${v.branch} contains ${v.stems.join(', ')} in the retained hidden-stem table. Table order is not a percentage.`;
 if(f.kind==='month-relation')return `The month branch's first listed hidden stem is ${v.stem}. Relative to the Day Master it is ${v.relation.label} (${v.relation.pinyin}); this is one seasonal input, not a complete strength judgment.`;
 if(f.kind==='visible-relationship')return `${p}: ${v.otherStem} is ${v.label} (${v.pinyin}) relative to ${v.dayStem}; ${v.direction.toLowerCase()} within the Five Phases model.`;
 if(f.kind==='exact-root')return `${p}: the branch ${v.branch} lists the exact Day Master stem ${v.stem}. This probe records an exact-stem root at this position; its presence alone does not establish strength.`;
 if(f.kind==='phase-root')return `${p}: ${v.branch} contains ${v.stem}, the same phase as the Day Master but a different stem. This remains separate from an exact-stem root.`;
 if(f.kind==='month-exposure')return `${p}: ${v.stem} occurs in the month branch ${v.monthBranch} and as a visible non-day stem. Visibility does not by itself establish a formation.`;
 if(f.kind==='hidden-relationship')return `${p}: hidden stem ${v.stem} has the relative label ${v.relation.label}. It is not counted as a visible stem.`;
 return `${p}: ${v.join(' / ')} matches the ${f.kind.replaceAll('-',' ')} table. This identifies a symbolic relation, not an event or an automatic change of phase.`;
}

export function makeSnapshot(chart){
 const a=analyze(chart),supported=a.findings.filter(f=>f.status==='supported');
 const entries=supported.map(f=>({...f,calculatedBasis:f.evidenceIds.map(id=>({factId:id,text:explainFact(a.derived.facts.find(x=>x.factId===id))})),
  interpretationBoundary:'These labels belong to the declared traditional model. Their presence does not establish personality, health, income or another person’s intentions.',
  reflectionPrompt:f.signal==='support'?'In an ordinary project, what support can you verify independently of this chart?':f.signal==='counter'?'What real requirement or cost would you check before making a reversible decision?':'What changes when you compare the stated positions separately instead of treating the label as an outcome?'}));
 return freeze({schemaVersion:'jm-foundation-schema-v1',ruleVersion:VERSION,contentVersion:'jm-foundation-en-draft-v1',
  methodVersion:chart.methodVersion,engineVersion:chart.engineVersion,timeZoneVersion:chart.timeZoneVersion,
  reviewStatus:'AI-assisted-unreviewed',purchasable:false,personalPrediction:false,chart:JSON.parse(JSON.stringify(chart)),
  ...a,free:entries.slice(0,3),detail:entries,coverage:{scope:'foundation structure only',supportedRules:supported.length,
   missingPositions:a.derived.missing,paidReportEligible:false,reason:'independent review and full content coverage pending'},
  limitations:['No final strength, formation, useful-element or annual prediction.','A reflection is original optional writing, not an instruction derived from fate.','Missing positions are not supplied by a template.']});
}
