/** Compact report-only navigation. Native controls; no chart/state/storage work. */
export function installReportJump(root,toc,sections,isCurrent){
 const doc=root.ownerDocument,allowed=new Set(sections.map(s=>s.domId));
 const wrapper=doc.createElement('div');wrapper.className='report-mobile-jump';
 const label=doc.createElement('label');label.htmlFor='report-mobile-section';label.textContent='Jump to a section';
 const row=doc.createElement('div');row.className='report-mobile-jump-row';
 const select=doc.createElement('select');select.id=label.htmlFor;
 const option=(value,text)=>{const n=doc.createElement('option');n.value=value;n.textContent=text;select.append(n);};
 option('','Choose a section');for(const s of sections)option(s.domId,s.title);
 const go=doc.createElement('button');go.type='button';go.textContent='Go';go.setAttribute('aria-label','Go to selected section');go.disabled=true;
 row.append(select,go);wrapper.append(label,row);toc.before(wrapper);
 const reset=()=>{select.value='';go.disabled=true;};
 const change=()=>{if(!isCurrent()||!allowed.has(select.value))reset();else go.disabled=false;};
 const jump=()=>{
  if(!isCurrent()||!allowed.has(select.value)){reset();return;}
  const target=doc.getElementById(select.value);
  if(!target||!root.contains(target)){reset();return;}
  for(let node=target.parentElement;node&&root.contains(node);node=node.parentElement)if(node.tagName==='DETAILS')node.open=true;
  target.focus({preventScroll:true});
  target.scrollIntoView({block:'start',behavior:doc.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  reset();
 };
 select.addEventListener('change',change);go.addEventListener('click',jump);
 return ()=>{select.removeEventListener('change',change);go.removeEventListener('click',jump);wrapper.remove();};
}
