/** Original cultural prompts over captured facts, not a personal fortune engine. */
import {assertTimingSource} from './prepared-extension.js';
import {readPreparedFactContext} from '../foundation/export-adapter.js';
import {relateStems} from '../relationships.js';
import {assertClaimLedgerSource} from '../content/claim-ledger.js';
export const CUSTOMER_TIMING_VERSION='jm-customer-timing-reading-v1';
export const CUSTOMER_TIMING_CONTENT_VERSION='jm-timing-en-cultural-v1.2';
const held=new WeakMap();
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
const months=['January','February','March','April','May','June','July','August','September','October','November','December'];
// Formats an already captured UTC/local civil string. Never consults the device
// timezone or computes a new astronomical boundary.
function dateText(value,clock=false){
 const m=/^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d)/.exec(value??'');if(!m)fail('TIMING_DISPLAY_DATE_UNAVAILABLE');
 const base=`${months[Number(m[2])-1]} ${Number(m[3])}, ${m[1]}`;
 return clock?`${base} at ${Number(m[4])%12||12}:${m[5]} ${Number(m[4])<12?'a.m.':'p.m.'}`:base;
}
const lenses={
 peer:{title:'Your space among other people',domain:'collaboration',meaning:'The symbolic lens for your selected year is independence alongside participation. Consider where you want to make your own contribution and where a shared agreement matters. This is a question to examine in your actual circumstances, not a prediction that other people will compete with you.',action:'Choose one shared commitment. Name a decision you can make yourself and a decision that needs agreement. Ask whether everyone involved understands that distinction the same way.'},
 resource:{title:'What helps you learn and grow',domain:'learning',meaning:'The symbolic lens for your selected year is receiving support and making use of what you learn. Consider what kind of help would actually move a task forward: information, instruction, feedback or protected time. Collecting more material and taking a useful next step are different activities.',action:'Choose one thing you want to learn or finish. Identify one specific source of help, use it in a small attempt, then decide what you still need from the result.'},
 output:{title:'What you want to make or express',domain:'work',meaning:'The symbolic lens for your selected year is expression through a contribution you can make or share. Consider what you would like another person to understand, use or respond to. A visible first attempt can give a conversation more substance than a plan that keeps expanding in private.',action:'Name one contribution and the person it is for. Make a small version, ask one concrete question about it, and use the response before deciding what to add.'},
 managed:{title:'The resources you choose to commit',domain:'money',meaning:'The symbolic lens for your selected year is working with tangible commitments. Consider how time, materials or money are tied to a result you actually want. Deciding what is worth maintaining can be as useful as adding another project. This comparison does not establish earnings, losses or financial aptitude.',action:'Choose one existing commitment. Write the result it serves, the resources it uses and a point when you will review whether to continue. Use your actual finances for any money decision.'},
 constraint:{title:'The commitments shaping your choices',domain:'work',meaning:'The symbolic lens for your selected year is responsibility and the standards around a task. Consider which requirements are explicit, who can change them and what you have agreed to carry. A clear obligation can guide a choice, while an assumed one may need a conversation.',action:'Choose one responsibility. Check the actual agreement or instruction, identify a decision you can make and ask for clarification on one thing that is still uncertain.'}
};
const blockedReasons={EXPLICIT_DIRECTION_REQUIRED:'No cycle direction was supplied. Your birth reading and the selected-year calendar remain available; no personal cycle schedule has been guessed.',RESOLVED_MINUTE_REQUIRED:'A single cycle schedule is unavailable because the birth time is unknown, covers a range or retains a calendar-boundary alternative. The selected-year reflection uses only the stable part of your birth chart.',NEAR_JIE_REQUIRES_REVIEW:'The recorded birth minute is close to a calculated seasonal boundary. Personal cycle dates are withheld rather than choosing a single schedule.',CIVIL_MINUTE_TRANSITION_REQUIRES_REVIEW:'The historical local clock changed inside the recorded minute. Personal cycle dates are withheld because that minute cannot be treated as one continuous interval.'};
// References an actual supported chapter, not a legacy card ID or a new verdict.
export function resolveTimingNatalTheme(reading,domain){
 const rows=reading.coverage?.domains?.filter(d=>d.domain===domain);
 if(!rows||rows.length!==1||!['interpreted','input-insufficient','method-not-supported'].includes(rows[0].status))fail('TIMING_NATAL_COVERAGE_REQUIRED');
 const coverage=rows[0];if(coverage.status!=='interpreted')return null;
 const sections=reading.detailedSections.filter(s=>s.id===coverage.sectionId);
 if(sections.length!==1||typeof sections[0].title!=='string'||!sections[0].title.trim()||!Array.isArray(sections[0].paragraphs)||!sections[0].paragraphs.length||sections[0].paragraphs.some(p=>typeof p!=='string'||!p.trim()))fail('TIMING_NATAL_THEME_DRIFT');
 const section=sections[0],links=reading.claimLedger?.paragraphLinks?.filter(l=>l.sectionId===section.id),byId=new Map((reading.claimLedger?.claims??[]).map(c=>[c.claimId,c]));
 if(!links||links.length!==1||links[0].paragraphs.length!==section.paragraphs.length)fail('TIMING_NATAL_THEME_DRIFT');
 const claims=links[0].paragraphs.flatMap((p,i)=>{
  if(p.paragraph!==i+1||!p.claimIds?.length)fail('TIMING_NATAL_THEME_DRIFT');
  return p.claimIds.map(id=>{const claim=byId.get(id);if(!claim||claim.text!==section.paragraphs[i])fail('TIMING_NATAL_THEME_DRIFT');return claim;});
 });
 const refs=new Map(claims.flatMap(c=>[...(c.factRefs??[]),...(c.counterFactRefs??[])]).map(f=>[f.factId,f]));
 const unique=a=>[...new Set(a)].sort();
 return freeze({mappingVersion:'jm-timing-natal-topic-reference-v1',domain,sectionId:section.id,title:section.title,
  contentVersion:reading.contentVersion,compositionVersion:reading.ruleVersion,claimIds:unique(claims.map(c=>c.claimId)),
  factRefs:[...refs.values()].sort((a,b)=>a.factId.localeCompare(b.factId,'en')).map(f=>({factId:f.factId,originPosition:f.originPosition,originPositions:[...f.originPositions],comparisonDependencies:[...f.comparisonDependencies],sourceRefs:[...f.sourceRefs]})),
  sourceRefs:unique([...claims.flatMap(c=>(c.sources??[]).map(s=>s.id)),...[...refs.values()].flatMap(f=>f.sourceRefs)]),temporalEffectInferred:false,coverageChanged:false});
}
export function prepareCustomerTiming(pack,extension){
 assertTimingSource(extension,pack);const c=readPreparedFactContext(pack),annual=extension.annualCalendar;
 const natal=c.chart.pillars.day?.[0];if(!natal)fail('STABLE_DAY_REQUIRED');
 const relation=relateStems(natal,annual.yearGanZhi[0]),lens=lenses[relation.family];if(!lens)fail('TIMING_CATEGORY_UNAVAILABLE');
 const claims=[{claimId:'year-stem-comparison',kind:'calculated-symbolic-category',premises:{natalDayStem:natal,selectedYearStem:annual.yearGanZhi[0],targetYear:annual.targetYear},relation,sourceRefs:['S-TEN','S-LUNAR-1.8.6'],interpretation:'Original modern reflection using historical category analogies; not a complete natal/cycle/year method or prediction',reviewStatus:'pending'}];
 assertClaimLedgerSource(pack.reading.claimLedger,pack.reference.snapshot);
 const baseTheme=resolveTimingNatalTheme(pack.reading,lens.domain);
 if(baseTheme)claims.push({claimId:'natal-theme-reference',kind:'existing-natal-reading-reference',premises:{sourceReportId:c.sourceReportId,sourceReadingContentVersion:c.readingContentVersion,sourceReadingCompositionVersion:c.readingCompositionVersion},natalTheme:baseTheme,sourceRefs:baseTheme.sourceRefs,interpretation:'Reference to an existing supported chapter from this same prepared report; not annual amplification, a new domain or a personal outcome',reviewStatus:'private-reference; original review boundaries retained'});
 const referenceYear=Number(c.sourceCreatedAt.slice(0,4));
 const yearPosition=annual.targetYear<referenceYear?'past':annual.targetYear>referenceYear?'future':'current';
 const timeFrame={past:`This is a look back at ${annual.targetYear}, relative to the report created in ${referenceYear}. Use what actually happened then; no past event is inferred from the chart.`,current:`This is a reflection on the selected year ${annual.targetYear}, the year this report was created. Compare the question with circumstances you can observe.`,future:`This is a planning question for ${annual.targetYear}, relative to the report created in ${referenceYear}. It does not tell you what will happen.`}[yearPosition];
 const pastActions={peer:'Think back to one shared commitment from that period. Who could make a decision alone, and which choices needed agreement? Use an actual conversation or decision to check whether that distinction was clear.',resource:'Recall something you were learning or trying to finish then. Which help did you actually use, and what changed after you used it? Separate that experience from the help you hoped would be available.',output:'Look back at something you made or shared then. Who used it or responded, and what did their response change? Use an actual example instead of assuming that expression had to be successful.',managed:'Look back at one commitment from that period. Compare the time, money or materials it used with the result it served. What did you continue, change or stop, and why?',constraint:'Recall one responsibility from that period. Compare what you were explicitly asked to do with what you assumed was expected. Which decision or conversation clarified the difference?'};
 const action=yearPosition==='past'?pastActions[relation.family]:yearPosition==='future'?'For planning, rather than prediction: '+lens.action:lens.action;
 const yearParagraphs=[`For the traditional year labeled ${annual.targetYear}, your reflection theme is “${lens.title.toLowerCase()}.”`,timeFrame,lens.meaning,
  ...(baseTheme?[`This connects with “${baseTheme.title}” in your birth reading. ${yearPosition==='past'?'Ask whether that question helps you understand a situation from that period':yearPosition==='future'?'Ask whether that question could help with a choice you may need to plan for':'Ask whether that question helps with a situation you can observe'}. The annual comparison offers another question; it does not establish that the birth theme becomes stronger.`]:[]),action];
 const year={id:'timing-year-reflection',title:`Your ${annual.targetYear} reflection: ${lens.title.toLowerCase()}`,chapterIndex:2,paragraphs:yearParagraphs};
 const cycleParagraphs=[];const luck=extension.luckCycle;
 if(luck.status==='blocked'){
  const precision=c.validatedInput.timePrecision;
  const reason=luck.error.code==='RESOLVED_MINUTE_REQUIRED'?
   precision==='unknown'?'Your birth time is unknown, so a personal cycle schedule cannot be calculated. The year reflection uses only chart information that does not require that hour.':
   precision==='range'?'Your supplied birth-time range does not resolve one minute for this calculation. No single personal cycle schedule is supplied.':
   'The birth input retains more than one calendar possibility. No single personal cycle schedule is supplied.':blockedReasons[luck.error.code];
  cycleParagraphs.push(reason??'Personal cycle dates are unavailable under the current input and method. No replacement schedule is supplied.');
 }
 else{
  cycleParagraphs.push(`You explicitly chose the ${extension.directionSelection.value} sequence. These are approximate starts in a traditional symbolic cycle calculation, not dates on which a personal event must occur. Each step represents roughly ten years under that convention.`,
   'Dates use the local clock at your birthplace when it can be determined. Otherwise the estimate is labeled Universal Time (UTC). These dates describe the chosen calculation, not events in your life.');
  if(luck.candidates.length>1)cycleParagraphs.push('The recorded minute produces more than one possible schedule. Both remain below; neither has been selected as the more accurate personal reading.');
  for(const [i,schedule]of luck.candidates.entries()){
   if(luck.candidates.length>1)cycleParagraphs.push(`Possible schedule ${i+1}`);
   for(const cycle of schedule.cycles){
    const comparison=relateStems(natal,cycle.ganZhi[0]),meaning=lenses[comparison.family];
    const local=cycle.localStart.status==='available',window=local?[cycle.localStart.start,cycle.localStart.end]:cycle.startWindowUTC;
    const a=dateText(window[0]),b=dateText(window[1]),when=a===b?'around '+a:'between '+a+' and '+b;
    cycleParagraphs.push(`Cycle ${cycle.index}: ${meaning.title}. Estimated start ${when}${local?'':' (UTC; local date unavailable)'}.`);
    claims.push({claimId:`cycle-${i+1}-${cycle.index}`,kind:'calculated-cycle-symbol-comparison',sourceCycleLabel:cycle.ganZhi,sourceStartWindowUTC:cycle.startWindowUTC,relation:comparison,sourceRefs:['S-TEN','T-YUN','J-YUN-UTC-APPROVED-V1'],reviewStatus:'pending',prediction:false});
   }
  }
  cycleParagraphs.push('These short labels reuse the same reflection themes as the year view. Repeated labels do not imply repeated events. A complete personal cycle reading would need additional reviewed conditions that this candidate does not provide.');
 }
 const cycles={id:'timing-personal-cycles',title:'Estimated cycle starts: a calculation, not a forecast',chapterIndex:2,privacyClass:luck.status==='local-candidate'?'birth-derived-dates':'input-limit',paragraphs:cycleParagraphs};
 const zoneLabel=annual.displayZone==='UTC'?'Universal Time (UTC)':annual.displayZone.split('/').slice(1).join(' / ').replaceAll('_',' ');
 const calendar={id:'timing-seasonal-calendar',title:`Optional reference appendix: shared seasonal dates for ${annual.targetYear}`,chapterIndex:3,optional:true,role:'shared-calendar-reference',paragraphs:[
  `This traditional year runs from approximately ${dateText(annual.start.displayLocal,true)} to ${dateText(annual.endExclusive.displayLocal,true)} in the selected calendar timezone (${zoneLabel}). It follows seasonal boundaries rather than January 1 or the first day of each month.`,
  'This appendix is the same for everyone who selects this year and timezone. It is not part of your personal interpretation or twelve separate forecasts. Times are approximate and shown to the minute.',
  ...annual.months.map(m=>`Seasonal period ${m.number}: from approximately ${dateText(m.start.displayLocal,true)} until the next boundary at ${dateText(m.endExclusive.displayLocal,true)}`)
 ]};
 const scope={id:'timing-reading-scope',title:'About the timing view',chapterIndex:3,paragraphs:[
  'The selected-year question is a limited cultural reflection. Cycle starts are calculation estimates; the seasonal appendix is shared reference. A complete personal timing interpretation is not supplied or available to purchase. These comparisons do not establish good or bad periods, health outcomes, investment results or another person’s feelings.',
  'If you omit birth details when saving, personal cycle dates are excluded. The selected shared calendar timezone, symbols and reading text remain in the file and may still be identifying.'
 ]};
 const result=freeze({schemaVersion:CUSTOMER_TIMING_VERSION,contentVersion:CUSTOMER_TIMING_CONTENT_VERSION,sourceReportId:c.sourceReportId,sourceReadingContentVersion:c.readingContentVersion,sourceReadingCompositionVersion:c.readingCompositionVersion,sourceTimingVersion:extension.schemaVersion,targetYear:annual.targetYear,calendarDisplayZone:annual.displayZone,directionSelection:extension.directionSelection,referenceYear,yearPosition,freeSections:[{...year,paragraphs:[yearParagraphs[0],timeFrame,action]},scope],detailedSections:[year,cycles,scope,calendar],claims,purchasable:false,professionalReview:'pending'});
 held.set(result,{pack,extension});return result;
}
export function assertCustomerTiming(reading,pack){if(held.get(reading)?.pack!==pack)fail('CUSTOMER_TIMING_PROVENANCE_REQUIRED');return reading;}
