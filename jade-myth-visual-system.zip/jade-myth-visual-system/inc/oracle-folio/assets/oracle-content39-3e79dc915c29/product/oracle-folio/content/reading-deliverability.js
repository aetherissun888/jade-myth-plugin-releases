/** Display/offer preflight only. Never authenticates payment or grants access. */
import{assertClaimLedgerSource}from'./claim-ledger.js';
export const READING_DELIVERABILITY_VERSION='jm-reading-deliverability-v1.1';
const held=new WeakMap(),domains=['work','learning','money','relationships','collaboration'];
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const fail=code=>{throw new RangeError(code);};
export function buildReadingDeliverability(snapshot,reading){
 assertClaimLedgerSource(reading.claimLedger,snapshot);
 const coverage=reading.coverage?.domains,free=reading.freeSections,detail=reading.detailedSections;
 if(!Array.isArray(coverage)||coverage.length!==domains.length||domains.some(id=>coverage.filter(d=>d.domain===id).length!==1)||!Array.isArray(free)||!Array.isArray(detail))fail('DELIVERY_CAPABILITY_CONTEXT_INVALID');
 const byId=new Map(detail.map(s=>[s.id,s]));if(byId.size!==detail.length)fail('DELIVERY_CAPABILITY_SECTION_DUPLICATE');
 const topics=coverage.map(d=>{
  if(!['interpreted','input-insufficient','method-not-supported'].includes(d.status))fail('DELIVERY_CAPABILITY_STATUS_INVALID');
  const section=byId.get(d.sectionId);
  if(d.status==='interpreted'&&(!section||!section.paragraphs?.length||section.paragraphs.some(p=>typeof p!=='string'||!p.trim())))fail('DELIVERY_COVERAGE_SECTION_MISSING');
  if(d.status!=='interpreted'&&d.sectionId!==null)fail('DELIVERY_UNAVAILABLE_TOPIC_HAS_SECTION');
  return {domain:d.domain,label:d.label,status:d.status,title:section?.title??null,sectionId:section?.id??null,availableInFree:d.status==='interpreted'&&free.some(s=>s.id===d.sectionId)};
 });
 const preview=reading.preview;
 if(preview&&!byId.get(preview.sectionId)?.paragraphs.includes(preview.paragraph))fail('DELIVERY_PREVIEW_NOT_IN_REPORT');
 const available=topics.filter(d=>d.status==='interpreted'),missing=topics.filter(d=>d.status!=='interpreted');
 if(new Set(available.map(d=>d.sectionId)).size!==available.length)fail('DELIVERY_TOPIC_COVERAGE_ALIAS');
 const additions=detail.filter(s=>!['reading-overview','reading-coverage','reading-limits'].includes(s.id)).map(s=>{
  const freeClaims=new Set(reading.reportPlan.freeLinks[s.id]??[]),claimIds=(reading.reportPlan.detailLinks[s.id]??[]).filter(id=>!freeClaims.has(id));
  return {sectionId:s.id,title:s.title,additionalClaimIds:claimIds,additionalTextPresent:s.paragraphs.some(p=>!free.find(f=>f.id===s.id)?.paragraphs.includes(p)),valueReviewed:false};
 });
 const methodStages=reading.reportPlan.traditionalMethods.map(m=>({id:m.id,status:m.status==='HOLD'?'not-assessed':m.status}));
 const unresolvedPositions=['year','month','day','hour'].filter(p=>!snapshot.chart.pillars[p]);
 const blockers=['RELEASE_NOT_APPROVED','DETAILED_VALUE_REVIEW_PENDING','COMMERCIAL_DELIVERY_NOT_INTEGRATED'];
 if(methodStages.some(m=>m.status==='not-assessed'))blockers.push('COMPLETE_METHOD_CHAIN_UNASSESSED');
 if(missing.length)blockers.push('ADVERTISED_FULL_TOPIC_SET_NOT_AVAILABLE');
 if(unresolvedPositions.length)blockers.push('BIRTH_INFORMATION_UNRESOLVED');
 const summary={includedTopics:available.map(d=>d.label),inputLimitedTopics:missing.filter(d=>d.status==='input-insufficient').map(d=>d.label),unsupportedTopics:missing.filter(d=>d.status==='method-not-supported').map(d=>d.label),
  coreReadingIncluded:reading.reportPlan.culturalReading?.status==='supported-cultural-structure',
  boundedStructureExplanationIncluded:reading.reportPlan.culturalReading?.status==='supported-cultural-structure',wholeChartSynthesisAssessed:false,completePersonalAnalysis:false,availableToBuy:false,
  notice:'This draft includes only the topics listed for your chart. More detail does not complete missing topics, supply unknown birth information or establish an unfinished method.'};
 const result=freeze({version:READING_DELIVERABILITY_VERSION,contentVersion:reading.contentVersion,profileVersion:reading.interpretationProfile.profileVersion,reportPlanVersion:reading.reportPlan.version,
  topics,detailAdditions:additions,methodStages,unresolvedPositions,customerSummary:summary,
  completeOffer:{kind:'planned-complete-personal-reading',canOrder:false,blockerCodes:[...new Set(blockers)].sort(),paymentAuthorization:false,canGrantEntitlement:false},
  valueBoundary:'Additional claims or text do not prove customer value or traditional/predictive validity. Unassessed differs from an assessed but unresolved judgment.'});
 held.set(reading,result);return result;
}
export function preflightCompleteReadingOffer(reading){
 const result=held.get(reading);
 if(!result||reading.deliveryCapabilities!==result)fail('DELIVERY_PREFLIGHT_REQUIRES_BOUND_READING');
 return result.completeOffer;
}
/** Same bound scope for page and file projections. Not an entitlement token.
 * coreReadingIncluded is the v1 compatibility alias for a bounded passage,
 * never evidence of an assessed whole-chart synthesis.
 */
export function readingDeliveryScope(reading){
 preflightCompleteReadingOffer(reading);
 return held.get(reading).customerSummary;
}
