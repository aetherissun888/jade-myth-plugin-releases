# Approved bounded qualitative reading — 2026-10-28

Content34 implements root-approved Jade-ZP-JiaYin-Qualitative-v1 P1–P5 inside the original Jia/Yin composer. The full known source-example route gains a declared local interpretive emphasis, not a global strength/formation/useful-element verdict. A separately identified provisional-known-foundation passage uses intact known year/month/day facts only when the hour is unknown; it neither promotes complete work coverage nor treats missing counterconditions as absent. Range and known opposition behavior remain as before. Main plan section0.4 records full fact/source/product-decision mapping. Independent GUI approval is separate; existing version readers and source layers are preserved. No new school, score or predictive claim.

# Source-listed officer corrective chain — 2026-10-27

Client26/plan2.2 introduces separate Jade-ZP-JiaYou-CombineRival-v1 over original snapshot facts. Primary9p37/31p160 source the local mixed-context/corrective pair; source case is symbolic, not a historical/calendar gold. Helper backing, actual source positions, known extra rival/damage and input incompleteness are separate nodes. Root effectiveness/whole capacity/formation/useful element remain unassessed. The original entryprofile1.3 is unchanged; Xu31p161 whole-reading disagreement is not merged. Previously supported two-support reading stays intact. Contract/source metadata/actual4case outputs are in task MODULE1-JIA-YOU.

# Conditional rooted-expression contrast — 2026-10-27

Entry profile1.3 remains the same month-led starting check. Separate rule Jade-ZP-JiaYin-CompetingRootContext-v1 (client25/plan2.1) adds a limited cultural contrast for the declared full known month/hour expression context with actual root oppositions and only the admitted Shen/Geng counterconditions. The original positive expression route remains withheld in that case; root efficacy/formation/strength stay unassessed. No new life topic is granted. Source conditions and current actual generated customer output are in task ROLE-CONTRAST-CONTRACT.md and ROLE-CONTRAST/. Other unknown/additional-context cases refuse the contrast.

# Root-admissibility predicate v1 — 2026-10-27

Separate versioned root-support admission is now attached to the original compiler/final ledger. Four primary examples, two position-only exclusions, disputed transmitted lifecycle readings, required original fact/source binding and unknown/interaction review are explicit. This does not expand the customer profile branches, rank strength or establish effective roots. Customercontent24/profile1.3 and all existing interpretation prose remain unchanged; current extra evidence needs a later pinned runtime recipe before GUI acceptance. See content/ziping-root-admissibility.mjs and task ROOT-PREDICATE-CONTRACT.md.

# Current / 2026-10-27 phase1 — profile1.3.0

Adds the declared Jia/Yin rooted-expression route through the existing bound snapshot, claim ledger and report plan (client2.1.24/plan2.0). Primary chapter45 paragraphs182/196 and a literal example are retained in rooted-expression-source.json; adjacent Xu commentary is metadata-only, not a runtime rule. The synthetic1924-02-15 HongKong04:00 fixture reproduces the transmitted symbols, not a historical birth date or independent calendar gold.

Full known source inventory, same-character month/hour root observations, month/hour Bing exposure, hidden support and explicit counter/uncertainty guards select one limited cultural reading and attributed contemporary work application. Hidden material resources remain present. “No exposed wealth/authority” is never turned into “no hidden wealth”; presence does not prove effective strength or formation. The product’s conservative review gates are not classical necessary-and-sufficient conditions. All global formation/strength/effective-root/useful-element outcomes remain unassessed. See source module and locked task contract for exact conditions.

New section is covered by presentation/session/export allowlists; source-bound work decisions are recorded separately from legacy modern-card selection. Existing Jia/You, Yi/You and three month-peer behaviors remain. The old outside-check wording now distinguishes that particular day/month check from separately supported supplements. FrozenWP31 remains content23; client24 is internal source only, not newly GUI/production/payment accepted.

---

# Jade-ZP-MonthPattern-v1 / bounded entries

## Current / Stage92 reviewed linked-support application integrated

Client2.1.20/plan1.8, selectedprofile1.2.0 unchanged. Rootv1 retains short support/clash reading; rootv2 conditionally adds reviewed modern applications only when the separate known linked-support context is present. Per-paragraph actual fact references, modern-reflection layers, real preview and actual delivery roles share one compiler. Missing prerequisites preserve the previous short reading or withhold as before. Whole strength/effective roots/restraint/formation remain unassessed; no classical efficacy inferred from the neutral pair.

## Current / Stage89 detailed-header scope correction

Client2.1.19/plan1.7.2 shares one actual-section scope function between free preview and detailed-page introduction. No-prompt or entry-only reports no longer inherit an unsupported practical-prompt promise. Profile1.2.0, root conditions, interpretation bodies and draft separation unchanged. V27 remains immutable; a separate delta carries only the current correction.

## Current / Stage87 preview scope correction

Selected profile1.2.0 and root contract unchanged. Client2.1.18/plan1.7.1 narrows the culture-only upgrade description to the short explanation actually supplied; no exercises or full analysis promised. Interpretation bodies unchanged fromcaf5b3c. Independent delta preview reuses pinned immutableV26 assets; it is not a deployable self-contained package.

## Current / Stage86

Selected profile1.2.0 unchanged. Separate Jade-ZP-Yi-ObservedRootContext-v1 adapter uses existing exact/phase/visible/pair facts; a known exact support with recorded clash receives a limited culture passage, not effective-root/strength/food-control judgment. Client2.1.17/plan1.7. Main/commentary source disagreement retained in yi-root-context-source.json; no numeric root weights adopted. Three Jia customer texts unchanged.

## Current / Stage85

Profile1.2.0 now has separate Jia/You正官 and Yi/You七杀entry results. Single snapshot/calendar retained. Yi branch has independently typed observations and entry-only customer scope; no Jia rescue or two-supports narrative transfer. Client2.1.16/plan1.6. Five short primary/commentary records in yi-you-entry-source.json; raw example is not a dated historical gold. Full食制/印化/strength/formation conditions remain unassessed. Historical stages below retain earlier versions, not the current coverage limit.


Owner-selected 2026-10-26. Main working text: the specifically checked NCC annotated transcription, not a claimed facsimile. Rule priority: approved original-text short whitelist; original cross-chapter checks; Xu commentary as separately labelled contrast; explicit product conventions. Source snippets/date/location/HTML and snippet hashes: approved-short-snippets.json. Preface is a version clue only, never scientific proof. 戊甲/戊申 variants are retained; the latter is a parallel-passage reading candidate, not a real birth gold standard.

## Implemented branch

`content/ziping-month-profile.mjs::evaluateZipingMonthProfile(snapshot,ledger)`. Profileversion1.0.0; branch Jia-You-ZhengGuan-entry-v1. Requires existing stable Jia day and You month, retained Xin hidden-stem/relationship facts. Establishes the **month-pattern analysis entry**, not formation, strength, success, personality or fate. Existing known Xin year/month/hour appearances are separate facts, never counted into strength. Non-Jia/You is outside this branch; unresolved day/month is insufficient, without choosing one alternative.

Geng/Ding in known visible/hidden positions, existing Bing-Xin pairs, listed You-month branch co-occurrences and Si/You/Chou members are explicit conservative review checks. Product map includes Mao opposition, Chen pairing, repeated You, Zi additional break-context review and Xu additional harm-context review. These trigger literal recorded context only; they are not claimed as a complete quotation/table from the main text. No pair/group is automatically effective, damaging, rescued or transformed. The selected chapter's meeting usage is not silently replaced with a different seasonal-group system. `LunarUtil.ZHI_XING` is the Jian-Chu duty cycle, not a punishment table, and is not used.

All-known/no-hit says only no **listed** condition in recorded positions; never whole-chart purity. Unknown hour retains stable entry/known Xin and known context, never a global exclusion. No strength score, climate conclusion, formed-pattern verdict or element-supplement recommendation. No gender/name inference.

## Three explicit layers

1. Captured calculation/table facts with source position/path and the unchanged calculation-method version.
2. Source-supported entry **within the chosen framework**, labelled entry-only. The ledger marks this limited entry active; it does not leave all implemented work labelled HOLD.
3. Insufficient/unknown conditions and conservative product context. Whole formation/damage/rescue, strength and useful-element decisions remain undetermined. Old life-topic cards remain modern editorial applications; this branch does not relabel them as classically proven.

## Existing architecture and versions

The compiler first binds its ledger to the original snapshot, then evaluates the one statically imported profile, builds the report plan and final ledger. No per-user method chooser or second chart engine. Copied/mismatched snapshots and incompatible calendar/engine/timezone/rule versions reject. Source hash lock: calculation-policy-lock.json. Calendar policy remains civil-clock-sect2-utc8-terms-v1/lunar-typescript1.8.6/IANA2026e. The profile never changes clock/timezone/day boundaries or luck-cycle conventions.

Internal report planv1.4, customer content2.1.13. The selected profile explanation reaches the existing optional About basis in free/detail/HTML/TXT/JSON/ZIP; core life-topic paragraphs and real preview excerpt are retained. The small explicit NCC source-URL allowlist is for serialized source links only, not broader permissions or runtime network fetching. Old artifacts and rights are not silently upgraded.

No public/paid release or external expert certification follows from internal verification. This is the first bounded branch, not implementation of the whole book. The old finance/resource effective-interaction branch is not automatically reopened.

Next proposed bounded branch: in this same Jia/You frame, when Mao is known, retain the original text's Chen-You / Mao-Xu pairing and Si-You-Chou member configurations as **rescue candidates with explicit positional counterconditions**, not automatic resolved opposition or successful formation. Establish those conditions before any effective verdict; broader root/balance and finance/resource use remain separate dependencies. No automatic broad expansion.

## 2026-10-26 update — profile1.1.0, internal rescue candidates

Same-snapshot rescue review is connected to the original profile. Required members advance a known Mao/You opposition to a named candidate; competing routes/repeated endpoints/other oppositions remain explicit. Source paragraph61 routes, original counterexamples and separate commentary caution are retained in rescue-short-source.json. No operative rescue, formation or personal claim is activated. Missing input never completes a route.

Four natal-slot parity matters: with Jia day, You month and known Mao, complete Hai/Mao/Wei or Si/You/Chou plus the opposition endpoints would occupy four yin branches, incompatible with a valid Jia day branch. Source illustrations are retained OUTSIDE_NATAL_SCOPE, not turned into impossible birth fixtures or a fifth transit position. Chen/You and Mao/Xu routes have real main-engine examples. See stage82.

Customer content remains2.1.13;48 saved exports unchanged. Profile version1.1.0 is an internal analytical-contract change. Effective position/nature, roots/strength and competing interactions remain unassessed. Next possible work is limited to those exact conditions, not a declaration of completed rescue or a broader method.

## Stage83 / client2.1.14 — bounded cultural synthesis

Original compiler plan1.5 now adds one conditional two-supports cultural interpretation when the established Jia/You entry has stable visible wealth/resource premises and no known declared interaction context requiring review. Its own contract Jade-ZP-two-supports-cultural-reading-v1 is separate from the unchanged1.1.0 entry/rescue profile. It describes conditional roles/trade-off, NOT effective noninterference, formation or personal diagnosis. Profile identity is bound to the same snapshot.

Original chapter31 p156 andp158 short-source functions are separately recorded. The latter's single-use background does not supply a preference ranking for a both-present chart. Modern English and everyday illustration are typed separately from source-based cultural structure. Free/detail/preview share one plan; unknown stable input retained; explicit context suppresses optional synthesis without declaring failure. No new classical method score or source chapter auto-import. The next Yi/You entry is only prepared in NEXT-YI-YOU-ENTRY.md, not runtime-active.

## Stage84 / client2.1.15 — reviewed attribution and unknown scope

Narrow text correction only, plan1.5.1: the main detailed passage labels Jade’s contemporary symbolic application directly; it does not attribute modern decision habits to ancient text. Overview mentions other everyday chapters only when actually present. An unresolved hour receives an explicit in-body warning that it can add conditions changing the interpretation. Rule premises/counters/snapshot and formal method limitations unchanged. Current revised customer Library retains the same identity/version history.

## Bounded N02/E life-route premise review — 2026-10-27

`Jade-ZP-LifeRoute-Premises-v1` records the selected original clauses and missing operative predicates for Yi/Yin and Ding/Mao in the original compiler ledger. This does not expand active profile entries, expose new personal inferences or infer strength from category counts. Month-peer route selection, support/expression capacity and financial-adjustment conditions remain separate; intimate/cooperation bridges are not supplied by those categories. Unknown-hour scope and method insufficiency are independent. See `life-route-premises-source.json` for exact selected clause hashes/layers and task Module2 for before/after evidence. Profile1.3/content26 remain unchanged because no customer interpretation is activated.

## Reviewed N02 limited application — 2026-10-27

`Jade-ZP-N02-SupportOutlet-Application-v1` reuses the same Yi/Yin facts and bound life-route reviewer. A traditional supporting foothold is not a personal independence/ability finding. Month/hour footing and shared hour expression/resources with Chou/Wei opposition support only the limited conditional comparison plus attributed modern learning example. No month-entry activation, life-domain promotion, effective mediation/strength/formation verdict or sale approval. Unknown hour/required-fact loss withdraws the new passage and retains earlier supported context. E's proposed extra chapter was independently declined for duplication; it is not integrated. Current content27/plan2.3 preserves old version readers.

## Content36 — reviewed N10 qualitative component (2026-10-28)

`Jade-ZP-N10-AimsMeans-v1`, contract `Jade-ZP-N10-Qualitative-v1`, applies only to the reviewed Geng/Wu, Ding/Hai, Gui/Wei, Bing/Chen configuration or its explicitly unknown hour. Original chapter45 regular route and narrower exception remain separate from Xu commentary. The NQ1–NQ5 editorial choice reads visible material-resource roles alongside contained expression as a conditional aims/means theme; placement does not establish effectiveness, ability or objective preference. Known other support/constraint and Wu/Wei pairing are not discarded; unknown cannot prove a single/unmixed full chart. This is a bounded component in the existing month-peer compiler, not a new completed month-pattern entry or a second calculation engine. Full strength, formation, useful-element, income and public/paid eligibility remain unestablished. Actual pipeline and adversarial fact-withdrawal evidence is in task execution/G2-N10-QUALITATIVE-INTEGRATION, with the approved clause/decision mapping in sibling G2-N10-QUALITATIVE-CONTRACT.

## Content37 — N03 bounded learning context (2026-10-28)

`Jade-ZP-N03-LearningThreeWay-v1` refines only an existing learning chapter over reviewed Gui/Hai, Yi/Mao, Bing/Wu, Wu/Xu facts. Month principal/exposure, year officer, hour expression, other known hidden/root observations and both recorded pairs are required and traceable. The selected chapter35 primary distinguishes officer-present and expression-using routes; its formal strength conditions are not assumed. Xu comparison is separate, not a waiver. Guidance/own explanation/task requirement is a root-approved Jade contemporary qualitative bridge, not a source-proved psychological fact. It replaces old generic practice prose and adds no life domain. Unknown withdraws the composite and preserves the actual old stable report (which has no learning chapter). Original month profile remains outside-implemented-branch; no formed pattern, effective combination, strong/weak, useful-element, intelligence or academic outcome is inferred. Task G2-N03-LEARNING-PREPARATION/SOURCE.json records cached clauses and transmission variants; G2-N03-LEARNING-INTEGRATION records actual before/after and conditions.


## Limited Yi/You help-and-conditions reading — content39

`Jade-ZP-YiYou-ConditionalSupport-v1` is a root-approved Jade cultural translation, not effective resource mediation or a formed pattern. It applies only to reviewed Yi/Hai, Gui/You, Ji/Hai known-position facts and the separately known Wu/Yin hour or explicit unknown hour; actual fact/position/source conditions drive selection, never date or sample ID. The traditional chapter39 support route remains conditional; its shared-month example is not presumed satisfied. The single theme contrasts guidance that clarifies an existing request with help that adds obligations. No response-speed/psychological preference, wealth event, overall strength or effective combination verdict is assigned. Known-hour extra relationships remain contextual; unknown withholds them and marks the theme provisional. Existing supported root/clash passages take precedence to avoid duplicate delivery. No new complete life domain or sale eligibility is granted. Source clauses remain the existing whitelist; contract and actual output evidence are under task execution/G2-YI-SUPPORT-QUALITATIVE-CONTRACT and G2-YI-SUPPORT-INTEGRATION.
