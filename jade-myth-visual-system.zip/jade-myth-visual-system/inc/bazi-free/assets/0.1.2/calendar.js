import {Solar} from './vendor/lunar-typescript-1.8.6/dist/index.js';
import {cityById,civilCandidates,TIMEZONE_VERSION,offsetAt} from './timezone.js';
export const METHOD_VERSION='civil-clock-sect2-utc8-terms-v1';
export const ENGINE_VERSION='lunar-typescript-1.8.6';
const fields=date=>[date.getUTCFullYear(),date.getUTCMonth()+1,date.getUTCDate(),date.getUTCHours(),date.getUTCMinutes(),date.getUTCSeconds()];
function validateDate(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))throw new RangeError('Enter a Gregorian date as YYYY-MM-DD.');
  const p=value.split('-').map(Number),d=new Date(Date.UTC(p[0],p[1]-1,p[2]));
  if(p[0]<1901||p[0]>2026||fields(d).slice(0,3).some((n,i)=>n!==p[i]))throw new RangeError('Use a valid Gregorian date from 1901 to 2026.');return p;
}
function solar(parts){return Solar.fromYmdHms(...parts);}
function yearMonth(epochMs){const ec=solar(fields(new Date(epochMs+8*3600000))).getLunar().getEightChar();return {year:ec.getYear(),month:ec.getMonth()};}
function datePillars(parts){const ec=solar(parts).getLunar().getEightChar();ec.setSect(2);return {day:ec.getDay(),hour:ec.getTime()};}
function termEpochs(parts){
  return Object.entries(solar([...parts.slice(0,3),0,0,0]).getLunar().getJieQiTable()).map(([name,term])=>({name,epochMs:Date.UTC(term.getYear(),term.getMonth()-1,term.getDay(),term.getHour(),term.getMinute(),term.getSecond())-8*3600000}));
}
const stableField=(rows,key)=>new Set(rows.map(row=>row[key])).size===1?rows[0][key]:null;
const unique=(rows,key)=>[...new Map(rows.map(row=>[key(row),row])).values()];
export function calculateChart({date,time=null,cityId,occurrence=null}){
  const p=validateDate(date),city=cityById(cityId);
  if(occurrence!==null&&occurrence!=='first'&&occurrence!=='second')throw new RangeError('Choose a valid repeated-time occurrence.');
  const base={schemaVersion:1,methodVersion:METHOD_VERSION,engineVersion:ENGINE_VERSION,timeZoneVersion:TIMEZONE_VERSION,cityId:city.id,timeZone:city.zone,date,time,personalPrediction:false};
  if(time===null){
    // Scan actual valid wall-clock minutes. No noon or guessed birth time is substituted.
    const instants=[];for(let minute=0;minute<1440;minute++)instants.push(...civilCandidates([...p,Math.floor(minute/60),minute%60,0],city.zone).map(c=>c.epochMs));
    if(!instants.length)return {...base,status:'nonexistent-date',complete:false};
    const first=Math.min(...instants),last=Math.max(...instants)+59999;
    const terms=termEpochs([...p,0,0,0]).filter(t=>t.epochMs>=first&&t.epochMs<=last);
    const probes=[first,last,...terms.flatMap(t=>[t.epochMs-1,t.epochMs+1000])].filter(ms=>{const local=fields(new Date(ms+offsetAt(ms,city.zone).seconds*1000));return local.slice(0,3).every((v,i)=>v===p[i]);});
    const options=unique(probes.map(yearMonth),r=>r.year+r.month),day=datePillars([...p,0,0,0]).day;
    return {...base,status:'incomplete-time',complete:false,pillars:{year:stableField(options,'year'),month:stableField(options,'month'),day,hour:null},yearMonthOptions:options,instant:null,nearSolarBoundary:terms.length>0};
  }
  if(typeof time!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw new RangeError('Enter a local clock time as HH:MM, or select time unknown.');
  const [h,m]=time.split(':').map(Number),candidates=civilCandidates([...p,h,m,0],city.zone);
  if(!candidates.length)return {...base,status:'nonexistent-time',complete:false};
  if(candidates.length>1&&occurrence===null)return {...base,status:'ambiguous-time',complete:false,candidates};
  if(candidates.length===1&&occurrence!==null)throw new RangeError('This clock time is not repeated; clear the occurrence selection.');
  const chosen=candidates[occurrence==='second'?1:0];
  const options=unique([yearMonth(chosen.epochMs),yearMonth(chosen.epochMs+59999)],r=>r.year+r.month),local=datePillars([...p,h,m,0]);
  const distance=Math.min(...termEpochs([...p,h,m,0]).map(t=>Math.abs(t.epochMs-chosen.epochMs)));
  return {...base,status:options.length>1?'boundary-minute':'calculated',complete:options.length===1,pillars:{year:stableField(options,'year'),month:stableField(options,'month'),...local},yearMonthOptions:options,instant:new Date(chosen.epochMs).toISOString(),offsetSeconds:chosen.seconds,abbreviation:chosen.abbreviation,daylightSaving:chosen.daylightSaving,occurrence:candidates.length>1?occurrence:null,nearSolarBoundary:distance<120000};
}
