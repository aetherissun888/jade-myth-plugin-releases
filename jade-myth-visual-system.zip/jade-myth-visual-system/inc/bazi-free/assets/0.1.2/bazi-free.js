import {initMobileFlow} from './mobile-free.js';
import {initPlacePicker,resetPlacePicker} from './place-picker.js';
import {setFreeChart,clearFreeChart} from './free-reflection-ui.js';
import {calculateChart} from './calendar.js';
import {cityById,formatOffset} from './timezone.js';
const $=id=>document.getElementById(id),date=$('birth-date'),time=$('birth-time'),city=$('birth-city'),unknown=$('time-unknown'),occurrence=$('occurrence'),status=$('birth-status');
const STEMS={甲:['Jia','Wood'],乙:['Yi','Wood'],丙:['Bing','Fire'],丁:['Ding','Fire'],戊:['Wu','Earth'],己:['Ji','Earth'],庚:['Geng','Metal'],辛:['Xin','Metal'],壬:['Ren','Water'],癸:['Gui','Water']};
const BRANCHES={子:'Zi',丑:'Chou',寅:'Yin',卯:'Mao',辰:'Chen',巳:'Si',午:'Wu',未:'Wei',申:'Shen',酉:'You',戌:'Xu',亥:'Hai'};

const text=(parent,tag,value)=>{const n=document.createElement(tag);n.textContent=value;parent.append(n);return n;};
function clearOutput(){clearFreeChart();$('calculation-details').replaceChildren();$('pillars').replaceChildren();$('day-master').textContent='';$('mobile-record-summary').textContent='';$('mobile-master').textContent='';$('chart-version').textContent=''; $('chart-result').hidden=true;$('chart-empty').hidden=false;}
function resetOccurrence(){ $('occurrence-choice').hidden=true;occurrence.replaceChildren();const option=document.createElement('option');option.value='';option.textContent='Choose the recorded occurrence';occurrence.append(option);}
function pending(){clearOutput();resetOccurrence();status.dataset.state='pending';status.textContent='Details changed. Calculate to view this chart.';}
for(const input of [date,time,city])input.addEventListener('input',pending);
city.addEventListener('change',()=>{$('zone-label').textContent=city.value?cityById(city.value).zone+' · Historical offsets from IANA 2026e':'Choose the actual birthplace, or use explicit manual confirmation.';});
unknown.addEventListener('change',()=>{time.value='';time.disabled=unknown.checked;pending();});
occurrence.addEventListener('change',()=>{clearOutput();status.textContent='Occurrence selected. Calculate to view the chart.';});
function render(result){
  if(!result.pillars){status.dataset.state='error';status.classList.add('error');clearOutput();if(result.status==='ambiguous-time'){
    resetOccurrence();$('occurrence-choice').hidden=false;
    result.candidates.forEach((c,i)=>{const option=document.createElement('option');option.value=i===0?'first':'second';option.textContent=`${i===0?'First':'Second'} · ${formatOffset(c.seconds)} · ${c.abbreviation}`;occurrence.append(option);});
    status.textContent='This time occurred twice. Choose the recorded occurrence, then calculate again.';if(matchMedia('(max-width:760px)').matches)$('occurrence-choice').scrollIntoView({block:'nearest'});
  }else status.textContent='This local clock time did not exist because the clock moved forward. Check the birth record; choose time unknown only if the time is genuinely unknown.';return;}
  $('chart-empty').hidden=true;$('chart-result').hidden=false;$('pillars').replaceChildren();
  for(const [key,label] of [['year','Year'],['month','Month'],['day','Day'],['hour','Hour']]){
    const figure=document.createElement('figure');figure.className='pillar';$('pillars').append(figure);text(figure,'h3',label);
    const value=result.pillars[key];const chars=text(figure,'span',value||'—');chars.className='characters';if(value)chars.lang='zh-Hans';
    text(figure,'p',value?STEMS[value[0]][0]+' '+BRANCHES[value[1]]:key==='hour'?'Time unknown':'Boundary uncertain');
  }
  const stem=result.pillars.day[0],name=STEMS[stem];$('mobile-master').textContent=`${name[0]} (${stem}) · ${name[1]}`;
  $('day-master').textContent=`Your day stem is ${name[0]} (${stem}), called the Day Master. In the five-phase classification used here, it corresponds to ${name[1]}. This identifies a component of the chart; it does not establish your character, compatibility or future.`;
  $('mobile-record-summary').textContent=result.date+' · '+(result.time||'time unknown')+' · '+cityById(result.cityId).label;
  $('chart-completeness').textContent=(result.status==='incomplete-time'?'Incomplete chart · birth time unknown':result.status==='boundary-minute'?'Incomplete chart · solar-term change within this minute':'Four pillars calculated under the stated rules');
  const alternatives=result.yearMonthOptions.length>1?'Possible year / month pairs: '+result.yearMonthOptions.map(v=>v.year+' / '+v.month).join(' or ')+'. ':'';
  $('boundary-note').hidden=!(result.nearSolarBoundary||alternatives);$('boundary-note').textContent=alternatives+'The record is near a solar-term boundary. Minute precision and the calendar model may affect the result; do not treat this as a second-precise birth chart.';
  const details=$('calculation-details');details.replaceChildren();
  for(const [label,value] of [['Date / time',result.date+' · '+(result.time||'unknown')],['Birth city / IANA zone',cityById(result.cityId).label+' · '+result.timeZone],['Resolved instant',result.instant||'Not assigned without a known time'],['Recorded-clock offset',result.instant?formatOffset(result.offsetSeconds)+' · '+result.abbreviation:'Not assigned'],['Clock convention','Local civil clock including historical DST; no true solar time correction'],['Day boundary','Midnight; sect 2 late-Zi hour convention']]){text(details,'dt',label);text(details,'dd',value);}
  $('chart-version').textContent=`${result.engineVersion} · IANA ${result.timeZoneVersion} · ${result.methodVersion}`;
  setFreeChart(result);
  status.classList.remove('error');status.dataset.state='success';document.dispatchEvent(new Event('jade-chart-ready'));
  status.textContent='Chart calculated locally. Birth details have not been uploaded or saved by this page.';
}
function calculate(){try{render(calculateChart({date:date.value,time:unknown.checked?null:time.value,cityId:city.value,occurrence:occurrence.value||null}));}catch(error){clearOutput();status.classList.add('error');status.dataset.state='error';status.textContent=error instanceof RangeError?error.message:'The local calculation could not finish. No chart is available.';if(matchMedia('(max-width:760px)').matches)status.scrollIntoView({block:'nearest'});}}
$('calculate').addEventListener('click',calculate);
function clearDetails(){date.value='';time.value='';city.value='';unknown.checked=false;time.disabled=false;resetOccurrence();resetPlacePicker();clearOutput();$('zone-label').textContent='Choose the actual birthplace, or use explicit manual confirmation.';status.classList.remove('error');status.dataset.state='cleared';status.textContent='Details and chart cleared from this page.';}
$('clear').addEventListener('click',clearDetails);
window.addEventListener('pagehide',clearDetails);
window.addEventListener('pageshow',event=>{if(event.persisted)clearDetails();});
// No storage, birth-data fetch, geolocation or submitting form.


initPlacePicker();

initMobileFlow();
