/** Content eligibility only. It neither calculates a chart nor infers a missing birth hour. */
export const PHASE_RULES=Object.freeze({wood:{label:'Wood',stems:['甲','乙']},fire:{label:'Fire',stems:['丙','丁']},earth:{label:'Earth',stems:['戊','己']},metal:{label:'Metal',stems:['庚','辛']},water:{label:'Water',stems:['壬','癸']}});
const text=v=>typeof v==='string'&&v.trim().length>0&&!/\b(?:TODO|TBD|lorem ipsum)\b|\[insert\b/i.test(v);
const records=content=>Array.isArray(content?.records)?content.records:[];
export function readableRecord(r){return !!r&&['contentId','title','prompt','action','basisNotes','authorship','version'].every(k=>text(r[k]))&&Array.isArray(r.paragraphs)&&r.paragraphs.length>=2&&r.paragraphs.every(text)&&Array.isArray(r.fieldDependencies)&&r.fieldDependencies.length>0&&r.fieldDependencies.every(text)&&Array.isArray(r.sourceRefs)&&r.sourceRefs.includes('S1')&&r.sourceRefs.includes('S2');}
export function selectSharedReflection(chart,content){
 const stem=chart?.pillars?.day?.[0],pair=Object.entries(PHASE_RULES).find(([,v])=>v.stems.includes(stem));if(!pair)return null;
 const [phase,rule]=pair,matches=records(content).filter(r=>r.scope==='shared-five-phase-exercise'&&r.phase===phase);
 if(matches.length!==1)return null;const r=matches[0];
 return readableRecord(r)&&r.phaseLabel===rule.label&&JSON.stringify(r.applicableDayStems)===JSON.stringify(rule.stems)&&r.usesHour===false&&r.fullPersonalizedReport===false&&JSON.stringify(r.fieldDependencies)===JSON.stringify(['pillars.day.stem in '+rule.stems.join('|')])?r:null;
}
export function sharedReflectionBasis(chart,record){return `Basis: day stem = ${chart.pillars.day[0]} · ${record.phaseLabel}. Shared phase exercise, not a full personalized report. ${record.contentId}.`;}
