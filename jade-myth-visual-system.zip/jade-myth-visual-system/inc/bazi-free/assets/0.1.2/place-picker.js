import {PLACE_META} from './vendor/places-meta.js';
import {ALL_TIMEZONES,registerPlace,clearRegisteredPlaces} from './timezone.js';
const $=id=>document.getElementById(id);
let requestId=0,worker=null,ready=false,timer;
function changed(){requestId++;$('place-selected').dataset.selected='false'; $('birth-city').value='';$('birth-city').dispatchEvent(new Event('input'));$('place-selected').textContent='No birthplace selected.';}
function use(place){requestId++;const entry=registerPlace(place);$('place-search-status').dataset.state='selected';
 if(matchMedia('(max-width:760px)').matches){document.querySelector('.mobile-place-help')?.removeAttribute('open');document.querySelector('.manual-place')?.removeAttribute('open');}
 const option=document.createElement('option');option.value=entry.id;option.textContent=entry.label;$('birth-city').append(option);$('birth-city').value=entry.id;$('birth-city').dispatchEvent(new Event('input'));$('birth-city').dispatchEvent(new Event('change'));
 $('place-selected').dataset.selected='true';$('place-query').value=entry.label;$('place-results').replaceChildren();
 const full=document.createElement('span');full.className='desktop-label';full.textContent=`Selected: ${entry.label} · ${entry.zone}`+(entry.latitude!=null?` · ${entry.latitude}, ${entry.longitude} (WGS84 point)`:'')+(entry.id.startsWith('manual:')?' · Manually confirmed; no coordinate lookup performed.':' · Time zone from the place record. Confirm the actual birth location if near a zone boundary.');
 const compact=document.createElement('span');compact.className='mobile-only';compact.textContent=`${entry.label} · ${entry.zone}. `+(entry.id.startsWith('manual:')?'Manually confirmed.':'Check birthplace and zone.');$('place-selected').replaceChildren(full,compact);
}
function search(){
 changed();const query=$('place-query').value;
 if(query.trim().length<2){$('place-results').replaceChildren();$('place-search-status').dataset.state='idle';$('place-search-status').textContent='Type at least two letters. Choose the exact place from the results; nothing is selected automatically.';return;}
 if(!ready){$('place-search-status').dataset.state='loading';$('place-search-status').textContent='The offline place index is loading. You can use the manual confirmation below.';return;}
 worker.postMessage({requestId:++requestId,query,country:$('place-country').value});$('place-search-status').dataset.state='searching';$('place-search-status').textContent='Searching locally…';
}
export function resetPlacePicker(){document.querySelector('.mobile-place-help')?.removeAttribute('open');document.querySelector('.manual-place')?.removeAttribute('open');requestId++;clearTimeout(timer);clearRegisteredPlaces();for(const option of [...$('birth-city').options])if(/^(gn:|manual:)/.test(option.value))option.remove();$('place-country').value='';$('place-selected').dataset.selected='false';$('place-query').value='';$('place-results').replaceChildren();$('place-selected').textContent='No birthplace selected.';$('manual-confirm').checked=false;$('manual-name').value='';$('manual-region').value='';$('manual-country').value='';$('manual-zone').value='';$('manual-lat').value='';$('manual-lon').value='';}
export function initPlacePicker(){
 for(const[code,name]of Object.entries(PLACE_META.countries).sort((a,b)=>a[1].localeCompare(b[1]))){for(const target of ['place-country','manual-country']){const o=document.createElement('option');o.value=code;o.textContent=name;$(target).append(o);}}
 for(const zone of ALL_TIMEZONES){const o=document.createElement('option');o.value=zone;$('iana-zones').append(o);}
 $('place-data-scope').textContent=`Offline search: ${PLACE_META.count.toLocaleString()} place records, including ${PLACE_META.usCount.toLocaleString()} in the United States. Small or historical places may be missing. Use manual confirmation when needed.`;
 $('place-query').addEventListener('input',()=>{changed();clearTimeout(timer);timer=setTimeout(search,140);});$('place-country').addEventListener('change',search);
 try{worker=new Worker(new URL('./place-worker.js',import.meta.url),{type:'module'});worker.onmessage=({data})=>{
  if(data.ready){ready=true;$('place-search-status').dataset.state='ready';$('place-search-status').textContent='Offline index ready. Search by city, state/province or country.';if($('place-query').value.trim()&&!$('birth-city').value)search();return;}
  if(data.requestId!==requestId)return;const root=$('place-results');root.replaceChildren();$('place-search-status').dataset.state=data.total?'results':'empty';$('place-search-status').textContent=data.total?`${Math.min(data.total,20)} of ${data.total} matches. Check city, state/province, country and IANA zone before choosing.`:'No matching place. Refine the name or confirm a manual birthplace and IANA time zone below.';
  for(const place of data.places){const button=document.createElement('button');button.type='button';button.className='place-result';const strong=document.createElement('strong');strong.textContent=place.label;button.append(strong);const small=document.createElement('span');small.textContent=place.zone+(place.featureCode==='PPLH'||place.featureCode==='PPLQ'?' · historical or abandoned place record':'');button.append(small);button.addEventListener('click',()=>{try{use(place);}catch(error){$('place-search-status').dataset.state='error';$('place-search-status').textContent=error.message;}});root.append(button);}
 };worker.onerror=()=>{$('place-search-status').dataset.state='error';$('place-search-status').textContent='The offline search could not load. You can still confirm a manual birthplace and IANA time zone below.';};}catch{$('place-search-status').textContent='Offline search is unavailable in this browser; use manual confirmation below.';}
 $('apply-manual-place').addEventListener('click',()=>{
  changed();try{const name=$('manual-name').value.trim(),region=$('manual-region').value.trim(),cc=$('manual-country').value,zone=$('manual-zone').value.trim(),lat=$('manual-lat').value.trim(),lon=$('manual-lon').value.trim();
   if(name.length<2||!PLACE_META.countries[cc])throw new RangeError('Enter the actual birthplace and choose its country.');if((lat==='')!==(lon===''))throw new RangeError('Enter both coordinates, or leave both blank.');
   const numeric=(value,max)=>{if(!/^-?\d+(\.\d+)?$/.test(value)||Math.abs(Number(value))>max)throw new RangeError('Use valid signed decimal WGS84 coordinates.');return Number(value);};
   use({id:'manual:'+crypto.randomUUID(),name,region,country:PLACE_META.countries[cc],countryCode:cc,label:[name,region,PLACE_META.countries[cc]].filter(Boolean).join(', '),zone,latitude:lat===''?null:numeric(lat,90),longitude:lon===''?null:numeric(lon,180),userConfirmed:$('manual-confirm').checked,source:'User-confirmed manual birthplace',sourceVersion:'manual-place-v1'});$('place-search-status').textContent='Manual birthplace selected. Coordinates have not been used to infer a time zone or change to true solar time.';
  }catch(error){$('place-search-status').dataset.state='error';$('place-search-status').textContent=error.message;}
 });
}
