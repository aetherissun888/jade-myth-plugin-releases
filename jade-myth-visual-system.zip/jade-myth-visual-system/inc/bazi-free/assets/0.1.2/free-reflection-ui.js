import {CONTENT} from './free-content.js';
import {selectSharedReflection,sharedReflectionBasis} from './free-routing.js';
const root=document.getElementById('free-reflection');
const T=(tag,value)=>{const node=document.createElement(tag);node.textContent=value;root.append(node);return node;};
export function clearFreeChart(){root.replaceChildren();document.dispatchEvent(new Event('jade-chart-cleared'));}
export function setFreeChart(chart){
 clearFreeChart();const record=selectSharedReflection(chart,CONTENT);
 if(!record){T('p','The chart facts remain available. A shared exercise is unavailable for this chart or content version.');return;}
 T('p','Shared exercise · AI-assisted draft. Not independently reviewed.').className='quiet';T('h3',record.title);record.paragraphs.forEach(p=>T('p',p));T('h3',record.prompt);T('p',record.action);T('p',sharedReflectionBasis(chart,record)).className='quiet';
}
