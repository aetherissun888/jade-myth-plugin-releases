import {PLACE_GZIP_B64} from './vendor/places-data.mjs';
import {PLACE_META} from './vendor/places-meta.mjs';
import {createPlaceIndex,searchPlaces} from './place-search.mjs';
const bytes=Uint8Array.from(atob(PLACE_GZIP_B64),c=>c.charCodeAt(0));
const text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
const index=createPlaceIndex(text,PLACE_META);
self.postMessage({ready:true,count:PLACE_META.count,usCount:PLACE_META.usCount,fullUSExtractIncluded:PLACE_META.fullUSExtractIncluded});
self.onmessage=({data})=>self.postMessage({requestId:data.requestId,...searchPlaces(index,PLACE_META,data.query,data.country)});
