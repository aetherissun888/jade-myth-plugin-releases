import {TZ_DATA} from './vendor/timezones-2026e.mjs';
export const TIMEZONE_VERSION=TZ_DATA.version;
export const CITIES=Object.freeze([]);
export const ALL_TIMEZONES=Object.freeze(Object.keys(TZ_DATA.zones).sort());
const registered=new Map();
export function registerPlace(place){
 if(!place||typeof place.id!=='string'||!/^gn:\d+$|^manual:[a-zA-Z0-9-]+$/.test(place.id)||typeof place.label!=='string'||place.label.length<2||place.label.length>240||!ALL_TIMEZONES.includes(place.zone))throw new RangeError('Choose a supported place record and exact IANA time zone.');
 if(place.id.startsWith('manual:')&&place.userConfirmed!==true)throw new RangeError('Confirm the manual birthplace and IANA time zone.');
 for(const [key,max]of [['latitude',90],['longitude',180]])if(place[key]!=null&&(!Number.isFinite(place[key])||Math.abs(place[key])>max))throw new RangeError('Use valid WGS84 coordinates or leave them blank.');
 const value=Object.freeze({...place});registered.set(value.id,value);return value;
}
export function clearRegisteredPlaces(){registered.clear();}
export function cityById(id){const city=registered.get(id)||CITIES.find(c=>c.id===id);if(!city)throw new RangeError('Select the actual birthplace or confirm a manual place and IANA time zone.');return city;}

export function offsetAt(epochMs,zone){
  const rows=TZ_DATA.zones[zone],seconds=epochMs/1000;
  if(!rows||seconds<TZ_DATA.utcRange[0]||seconds>=TZ_DATA.utcRange[1])throw new RangeError('Time zone or date outside the pinned data range.');
  let low=0,high=rows.length;while(low+1<high){const mid=(low+high)>>1;if(rows[mid][0]<=seconds)low=mid;else high=mid;}
  return {seconds:rows[low][1],abbreviation:rows[low][2],daylightSaving:rows[low][3]};
}
export function civilCandidates(parts,zone){
  const wall=Date.UTC(...[parts[0],parts[1]-1,parts[2],parts[3]||0,parts[4]||0,parts[5]||0]);
  const rows=TZ_DATA.zones[zone];if(!rows)throw new RangeError('Unsupported IANA time zone.');
  return [...new Set(rows.map(r=>r[1]))].flatMap(seconds=>{
    const epochMs=wall-seconds*1000;const actual=offsetAt(epochMs,zone);
    return actual.seconds===seconds?[{epochMs,...actual}]:[];
  }).sort((a,b)=>a.epochMs-b.epochMs);
}
export function formatOffset(seconds){const sign=seconds<0?'-':'+';const n=Math.abs(seconds);return `UTC${sign}${String(Math.floor(n/3600)).padStart(2,'0')}:${String(Math.floor(n%3600/60)).padStart(2,'0')}`+(n%60?':'+String(n%60).padStart(2,'0'):'');}
