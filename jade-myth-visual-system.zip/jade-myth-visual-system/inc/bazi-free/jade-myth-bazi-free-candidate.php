<?php
/**
 * Embedded Module: Jade & Myth Free BaZi
 * Description: Isolated, noindex, client-only basic chart and shared phase exercises. No reports, accounts or payments.
 * Version: 0.1.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Aetheris Sun LLC
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
define('JM_BAZI_FREE_VERSION', '0.1.2');
define('JM_BAZI_FREE_SLUG', 'divination/bazi');
function jm_bazi_free_collision() { return (bool) get_page_by_path(JM_BAZI_FREE_SLUG, OBJECT, 'page'); }
// This embedded profile handles its exact path at template_redirect priority0.
// No rewrite/options writes or separate plugin activation are required.
function jm_bazi_free_is_request() {
    $canonical = home_url('/' . JM_BAZI_FREE_SLUG . '/');
    $expected = rtrim((string) wp_parse_url($canonical, PHP_URL_PATH), '/');
    $path = rtrim((string) wp_parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH), '/');
    return $path === $expected && !jm_bazi_free_collision();
}
add_action('template_redirect', function () {
    if (!jm_bazi_free_is_request()) { return; }
    $canonical = home_url('/' . JM_BAZI_FREE_SLUG . '/');
    $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
    if ($method !== 'GET' && $method !== 'HEAD') { status_header(405); header('Allow: GET, HEAD'); header('Cache-Control: no-store'); exit; }
    $request = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    if ((string) wp_parse_url($request, PHP_URL_PATH) !== (string) wp_parse_url($canonical, PHP_URL_PATH) || wp_parse_url($request, PHP_URL_QUERY) !== null) {
        wp_safe_redirect($canonical, 301); exit;
    }
    global $wp_query;
    if (is_object($wp_query)) { $wp_query->is_404 = false; $wp_query->is_home = false; }
    status_header(200); nocache_headers();
    if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    do_action('litespeed_control_set_nocache', 'Local-only Four Pillars input');
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Robots-Tag: noindex, follow');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');
    header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
    header("Content-Security-Policy: default-src 'none'; script-src 'self'; worker-src 'self'; style-src 'self'; font-src 'self'; img-src 'self'; connect-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'; frame-ancestors 'self'");
    if ($method === 'HEAD') { exit; }
    $template = file_get_contents(__DIR__ . '/view.html');
    echo str_replace(array('__ASSET_BASE__', '__CANONICAL__', '__HOME_URL__'), array(esc_url(plugins_url('assets/' . JM_BAZI_FREE_VERSION . '/', __FILE__)), esc_url($canonical), esc_url(home_url('/'))), $template);
    exit;
}, 0);
add_filter('redirect_canonical', function ($redirect) { return jm_bazi_free_is_request() ? false : $redirect; });
add_action('admin_notices', function () {
    if (jm_bazi_free_collision() && current_user_can('activate_plugins')) { echo '<div class="notice notice-error"><p>Jade &amp; Myth Free BaZi is disabled because a page already owns /divination/bazi/. No page was replaced.</p></div>'; }
});
