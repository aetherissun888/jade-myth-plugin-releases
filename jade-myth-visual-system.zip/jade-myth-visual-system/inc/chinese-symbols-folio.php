<?php
/**
 * Chinese Symbols specimen folio.
 *
 * The accepted composition is route-specific: a complete textile banner,
 * centred title field, four reading routes, an asymmetrical evidence spread,
 * and the full source-led article below. Museum images remain uncropped.
 */

if ( ! defined( 'ABSPATH' ) && 'cli' !== PHP_SAPI ) {
	exit;
}

/** Add stable reading anchors and return the complete table of contents. */
function jade_myth_symbols_prepare_content( $content, &$toc ) {
	$content = preg_replace( '/<h1[^>]*>.*?<\/h1>/is', '', $content, 1 );
	$toc     = array();

	preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $content, $matches );
	foreach ( $matches[1] as $index => $heading ) {
		$label   = trim( wp_strip_all_tags( $heading ) );
		$id      = 'reading-' . ( $index + 1 );
		$content = preg_replace(
			'/<h2([^>]*)>' . preg_quote( $heading, '/' ) . '<\/h2>/is',
			'<h2$1 id="' . esc_attr( $id ) . '">' . $heading . '</h2>',
			$content,
			1
		);
		$toc[] = array( 'id' => $id, 'label' => $label );
	}

	return $content;
}

/** Render the full, uncropped feature textile used by the accepted masthead. */
function jade_myth_symbols_feature_image( $post_id ) {
	$image_id = get_post_thumbnail_id( $post_id );
	if ( ! $image_id ) {
		return '';
	}

	return wp_get_attachment_image(
		$image_id,
		'full',
		false,
		array(
			'class'         => 'jm-symbols-folio__banner-image',
			'alt'           => get_post_meta( $post_id, 'jm_feature_image_alt', true ),
			'loading'       => 'eager',
			'fetchpriority' => 'high',
			'decoding'      => 'async',
			'sizes'         => '(max-width: 760px) calc(100vw - 24px), (max-width: 1600px) calc(100vw - 48px), 1536px',
		)
	);
}

/** Render one preview from the already-published inline-image rights record. */
function jade_myth_symbols_specimen( $record, $modifier, $heading ) {
	if ( ! is_array( $record ) || empty( $record['content_url'] ) ) {
		return '';
	}

	$width  = ! empty( $record['width'] ) ? absint( $record['width'] ) : 1;
	$height = ! empty( $record['height'] ) ? absint( $record['height'] ) : 1;
	ob_start();
	?>
	<figure class="jm-symbols-specimen jm-symbols-specimen--<?php echo esc_attr( $modifier ); ?>">
		<div class="jm-symbols-specimen__image-field">
			<img src="<?php echo esc_url( $record['content_url'] ); ?>" alt="<?php echo esc_attr( $record['alt'] ); ?>" width="<?php echo esc_attr( $width ); ?>" height="<?php echo esc_attr( $height ); ?>" loading="lazy" decoding="async" sizes="(max-width: 760px) calc(100vw - 40px), 720px">
		</div>
		<figcaption>
			<h2><?php echo esc_html( $heading ); ?></h2>
			<p><?php echo esc_html( $record['caption'] ); ?></p>
			<small><a href="<?php echo esc_url( $record['credit_url'] ); ?>" rel="external noopener"><?php echo esc_html( $record['credit'] ); ?></a><span aria-hidden="true"> · </span><a href="<?php echo esc_url( $record['license_url'] ); ?>" rel="external noopener"><?php echo esc_html( $record['rights'] ); ?></a></small>
		</figcaption>
	</figure>
	<?php
	return ob_get_clean();
}

/** Render the owner-approved specimen-index composition and full article. */
function jade_myth_chinese_symbols_folio( $content ) {
	$post_id         = get_the_ID();
	$title           = get_the_title( $post_id );
	$review_status   = get_post_meta( $post_id, 'jm_review_status', true );
	$reviewed_by     = get_post_meta( $post_id, 'jm_reviewed_by', true );
	$last_reviewed   = get_post_meta( $post_id, 'jm_last_reviewed', true );
	$source_count    = max( 1, absint( get_post_meta( $post_id, 'jm_sources_count', true ) ) );
	$reading_minutes = max( 3, (int) ceil( str_word_count( wp_strip_all_tags( $content ) ) / 220 ) );
	$inline_records  = jade_myth_inline_image_records( get_post_meta( $post_id, 'jm_inline_images', true ) );
	$content         = jade_myth_symbols_prepare_content( $content, $toc );
	$routes          = array(
		array( '01', '物', 'Surface, date & use', 'Begin with the object', 'reading-1' ),
		array( '02', '合', 'Words & combinations', 'Read pictures together', 'reading-2' ),
		array( '03', '花', 'Plants & animals', 'Compare form and company', 'reading-4' ),
		array( '04', '礼', 'Rank, religion & travel', 'Locate the social setting', 'reading-6' ),
	);

	ob_start();
	?>
	<article class="jm-symbols-folio alignfull" data-content-type="symbols_authority_gateway" data-project-group="mythology">
		<header class="jm-symbols-folio__lead">
			<figure class="jm-symbols-folio__banner">
				<?php echo jade_myth_symbols_feature_image( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<figcaption>
					<a href="<?php echo esc_url( get_post_meta( $post_id, 'jm_feature_image_credit_url', true ) ); ?>" rel="external noopener"><?php echo esc_html( get_post_meta( $post_id, 'jm_feature_image_credit', true ) ); ?></a>
					<span aria-hidden="true"> · </span><?php echo esc_html( get_post_meta( $post_id, 'jm_feature_image_rights', true ) ); ?>
				</figcaption>
			</figure>

			<div class="jm-symbols-folio__title-field">
				<p class="jm-symbols-folio__eyebrow">Jade &amp; Myth / Visual Culture Index</p>
				<h1><?php echo esc_html( $title ); ?></h1>
				<p class="jm-symbols-folio__dek">Read motifs through dated objects, materials, wordplay, rank, religion, and use. This is a map for careful looking, not a one-meaning decoding chart.</p>
				<dl class="jm-symbols-folio__ledger" aria-label="Editorial record">
					<div><dt>Reading</dt><dd><?php echo esc_html( $reading_minutes ); ?> min</dd></div>
					<div><dt>Sources</dt><dd><?php echo esc_html( $source_count ); ?> referenced</dd></div>
					<div><dt>Review</dt><dd><?php echo esc_html( $review_status ? str_replace( '_', ' ', $review_status ) : 'Editorial review' ); ?></dd></div>
				</dl>
			</div>

			<nav class="jm-symbols-routes" aria-label="Four routes through the pattern field">
				<?php foreach ( $routes as $route ) : ?>
					<a href="#<?php echo esc_attr( $route[4] ); ?>">
						<span class="jm-symbols-routes__mark" aria-hidden="true"><?php echo esc_html( $route[1] ); ?></span>
						<span><b><?php echo esc_html( $route[0] ); ?></b><strong><?php echo esc_html( $route[2] ); ?></strong><small><?php echo esc_html( $route[3] ); ?></small></span>
					</a>
				<?php endforeach; ?>
			</nav>

			<?php if ( count( $inline_records ) >= 2 ) : ?>
				<section class="jm-symbols-folio__specimens" aria-label="Selected object records">
					<?php echo jade_myth_symbols_specimen( $inline_records[1], 'phoenix', 'Phoenixes among seasonal flowers' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo jade_myth_symbols_specimen( $inline_records[0], 'dragons', 'Dragons within a woven system' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</section>
			<?php endif; ?>

			<a class="jm-symbols-folio__continue" href="#reading-1"><span>Continue reading</span><b aria-hidden="true">↓</b></a>
		</header>

		<div class="jm-symbols-folio__reading">
			<aside class="jm-symbols-folio__toc" aria-label="On this page">
				<p>Contents</p>
				<ol>
					<?php foreach ( $toc as $item ) : ?>
						<li><a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ol>
			</aside>
			<div class="jm-symbols-folio__article">
				<div class="jm-symbols-folio__boundary"><span>Evidence boundary</span><p>Objects and sources can document historical associations. They do not prove promised effects.</p></div>
				<div class="jm-reading__content"><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<aside class="jm-symbols-folio__record" aria-label="Editorial record">
				<p>Editorial record</p>
				<dl>
					<div><dt>Reviewed by</dt><dd><?php echo esc_html( $reviewed_by ? $reviewed_by : 'Jade & Myth Editorial' ); ?></dd></div>
					<div><dt>Last reviewed</dt><dd><?php echo esc_html( $last_reviewed ? $last_reviewed : get_the_modified_date( 'F j, Y' ) ); ?></dd></div>
					<div><dt>Use</dt><dd>Cultural education and research.</dd></div>
				</dl>
			</aside>
		</div>
	</article>
	<?php
	return ob_get_clean();
}
