<?php
/** Image attribution is independent of article authorship and artifact ownership. */
function jade_myth_image_rights_metadata( $credit, $source, $class, $name = '', $type = '', $acquire = '' ) {
	$result = array();
	$host = strtolower( (string) parse_url( $source, PHP_URL_HOST ) );
	if ( $name && in_array( $type, array( 'Person', 'Organization' ), true ) ) {
		$result['creator'] = array( '@type' => $type, 'name' => $name );
	} elseif ( 'E3' === $class && 0 === strpos( $credit, 'Jade & Myth Editorial' ) ) {
		$result['creator'] = array( '@type' => 'Organization', 'name' => 'Jade & Myth Editorial' );
	} elseif ( 'www.metmuseum.org' === $host && 0 === strpos( $credit, 'The Metropolitan Museum of Art' ) ) {
		// Institution's own Open Access collection photography, not the artifact maker.
		$result['creator'] = array( '@type' => 'Organization', 'name' => 'The Metropolitan Museum of Art' );
	} elseif ( 'commons.wikimedia.org' === $host && 0 === strpos( $credit, 'Gary Todd' ) ) {
		$result['creator'] = array( '@type' => 'Person', 'name' => 'Gary Todd' );
	}
	// Never substitute an article author or an anonymous scan's book author.
	if ( ! $acquire ) {
		if ( 'E3' === $class && isset( $result['creator'] ) && 'Jade & Myth Editorial' === $result['creator']['name'] ) {
			$acquire = 'https://jadeandmyth.com/ai-disclosure/#image-reuse';
		} elseif ( 'www.metmuseum.org' === $host ) {
			$acquire = 'https://www.metmuseum.org/policies/image-resources';
		} elseif ( 'commons.wikimedia.org' === $host ) {
			$acquire = $source;
		}
	}
	if ( 'https' === parse_url( $acquire, PHP_URL_SCHEME ) ) {
		$result['acquireLicensePage'] = $acquire;
	}
	return $result;
}
