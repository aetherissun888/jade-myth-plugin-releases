<?php
/**
 * Jade & Myth Daily Almanac.
 *
 * A local, read-only cultural-calendar service. Calculation uses the bundled
 * MIT-licensed 6tail lunar-php standalone library; editorial reflections are
 * deliberately non-predictive and are held in this file for version control.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use com\nlf\calendar\Solar;

final class Jade_Myth_Almanac {
	const CONTENT_VERSION = '2026.08.01';
	const CALCULATION_VERSION = '6tail-lunar-php-standalone@pinned';

	private static $terms = array(
		'立春' => array( 'Spring Begins', 'Lìchūn', 'Spring', 'A threshold for renewing attention and beginning small.' ),
		'雨水' => array( 'Rain Water', 'Yǔshuǐ', 'Spring', 'A season for noticing the quiet conditions that help things gather.' ),
		'惊蛰' => array( 'Awakening of Insects', 'Jīngzhé', 'Spring', 'A reminder that dormant questions may deserve a closer look.' ),
		'春分' => array( 'Spring Equinox', 'Chūnfēn', 'Spring', 'A seasonal point for balancing attention between action and observation.' ),
		'清明' => array( 'Clear and Bright', 'Qīngmíng', 'Spring', 'A time often associated with tending memory, landscape, and clear seeing.' ),
		'谷雨' => array( 'Grain Rain', 'Gǔyǔ', 'Spring', 'A closing spring marker that invites patient, grounded attention.' ),
		'立夏' => array( 'Summer Begins', 'Lìxià', 'Summer', 'A threshold for noticing the shift into longer, brighter days.' ),
		'小满' => array( 'Grain Buds', 'Xiǎomǎn', 'Summer', 'A season that values enoughness: growth without the demand for completion.' ),
		'芒种' => array( 'Grain in Ear', 'Mángzhòng', 'Summer', 'A seasonal marker for choosing what deserves careful cultivation.' ),
		'夏至' => array( 'Summer Solstice', 'Xiàzhì', 'Summer', 'A high point of light that can make room for pause as well as activity.' ),
		'小暑' => array( 'Minor Heat', 'Xiǎoshǔ', 'Summer', 'An early-summer invitation to simplify the pace and preserve attention.' ),
		'大暑' => array( 'Major Heat', 'Dàshǔ', 'Summer', 'A late-summer prompt to leave generous space around the day.' ),
		'立秋' => array( 'Autumn Begins', 'Lìqiū', 'Autumn', 'A threshold for taking stock and returning to what has lasting value.' ),
		'处暑' => array( 'Limit of Heat', 'Chǔshǔ', 'Autumn', 'A season of transition that rewards measured, observant movement.' ),
		'白露' => array( 'White Dew', 'Báilù', 'Autumn', 'A time to notice detail, texture, and the change in the air around familiar things.' ),
		'秋分' => array( 'Autumn Equinox', 'Qiūfēn', 'Autumn', 'A seasonal point for balancing what is kept, shared, and set aside.' ),
		'寒露' => array( 'Cold Dew', 'Hánlù', 'Autumn', 'A prompt to gather clear notes from what the season has revealed.' ),
		'霜降' => array( 'Frost Descent', 'Shuāngjiàng', 'Autumn', 'A late-autumn marker for honoring the work of preparation.' ),
		'立冬' => array( 'Winter Begins', 'Lìdōng', 'Winter', 'A threshold for turning inward with curiosity rather than haste.' ),
		'小雪' => array( 'Minor Snow', 'Xiǎoxuě', 'Winter', 'A time to value quiet continuity and small, repeatable rituals.' ),
		'大雪' => array( 'Major Snow', 'Dàxuě', 'Winter', 'A winter marker for reading slowly and leaving room for stillness.' ),
		'冬至' => array( 'Winter Solstice', 'Dōngzhì', 'Winter', 'A turning point of light, often approached through reunion, food, and reflection.' ),
		'小寒' => array( 'Minor Cold', 'Xiǎohán', 'Winter', 'A prompt to work with the season as it is, not as it ought to be.' ),
		'大寒' => array( 'Major Cold', 'Dàhán', 'Winter', 'A closing winter marker for conserving attention before the next threshold.' ),
	);

	private static $focuses = array(
		'Read one source slowly before drawing a conclusion.',
		'Name one question worth carrying forward.',
		'Return to a small task with undivided attention.',
		'Notice the material details in an ordinary object or place.',
		'Make room for a conversation that adds context rather than certainty.',
		'Choose one unfinished note, book, or idea to revisit with care.',
		'Let curiosity set the pace for one part of the day.',
	);

	private static $gentle = array(
		'Leave enough time between decisions to see their context.',
		'Prefer a measured next step to an overfull plan.',
		'Let a question remain open when the evidence is not yet clear.',
		'Resist turning a seasonal reflection into a fixed rule.',
		'Choose attention over urgency where you can.',
		'Keep interpretation separate from what a source directly says.',
		'Allow rest, reading, and observation to count as progress.',
	);

	public static function bootstrap() {
		require_once JADE_MYTH_VISUAL_DIR . 'vendor/6tail/Lunar.php';
	}

	public static function register_routes() {
		register_rest_route( 'jade-myth/v1', '/almanac', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'args'                => array(
				'timezone' => array(
					'required'          => false,
					'sanitize_callback' => array( __CLASS__, 'sanitize_timezone' ),
				),
			),
			'callback'            => function( WP_REST_Request $request ) {
				return rest_ensure_response( self::for_timezone( $request->get_param( 'timezone' ) ) );
			},
		) );
	}

	public static function sanitize_timezone( $timezone ) {
		$timezone = is_string( $timezone ) ? trim( $timezone ) : '';
		return in_array( $timezone, timezone_identifiers_list(), true ) ? $timezone : '';
	}

	public static function for_timezone( $timezone = '' ) {
		$timezone = self::sanitize_timezone( $timezone );
		if ( ! $timezone ) {
			$timezone = wp_timezone_string();
		}
		if ( ! $timezone || ! in_array( $timezone, timezone_identifiers_list(), true ) ) {
			$timezone = 'America/Los_Angeles';
		}

		$date = new DateTimeImmutable( 'now', new DateTimeZone( $timezone ) );
		$key  = 'jm_almanac_v1_' . md5( self::CONTENT_VERSION . '|' . $timezone . '|' . $date->format( 'Y-m-d' ) );
		$data = get_transient( $key );
		if ( false !== $data ) {
			return $data;
		}

		$data = self::build( $date, $timezone );
		// The timezone/date key prevents stale results from surviving a local midnight.
		set_transient( $key, $data, HOUR_IN_SECONDS * 18 );
		return $data;
	}

	private static function build( DateTimeImmutable $date, $timezone ) {
		$base = array(
			'civil_date'         => $date->format( 'Y-m-d' ),
			'civil_label'        => $date->format( 'F j, Y' ),
			'timezone'           => $timezone,
			'content_version'    => self::CONTENT_VERSION,
			'calculation_version'=> self::CALCULATION_VERSION,
			'disclaimer'         => 'For cultural reflection, not fortune-telling.',
			'methodology_url'    => home_url( '/daily-almanac/' ),
			'sources'            => array(
				array( 'label' => 'Hong Kong Observatory — Chinese Calendar', 'url' => 'https://www.hko.gov.hk/en/gts/time/Calendar.htm' ),
				array( 'label' => 'Hong Kong Observatory — 24 Solar Terms', 'url' => 'https://www.hko.gov.hk/en/gts/time/24solarterms.htm' ),
				array( 'label' => '6tail lunar-php (MIT)', 'url' => 'https://github.com/6tail/lunar-php' ),
			),
		);

		try {
			$solar = Solar::fromYmd( (int) $date->format( 'Y' ), (int) $date->format( 'n' ), (int) $date->format( 'j' ) );
			$lunar = $solar->getLunar();
			// getJieQi() returns the library's normalized Chinese term key on the
			// term date itself. The near-term object is only needed between terms.
			$term_key = $lunar->getJieQi();
			$current = null;
			if ( ! $term_key ) {
				$current = $lunar->getPrevJieQiByWholeDay( true );
				$term_key = $current ? $current->getName() : '立春';
			}
			$next = $lunar->getNextJieQiByWholeDay( true );
			$term = self::$terms[ $term_key ] ?? self::$terms['立春'];
			$weekday = (int) $date->format( 'N' ) - 1;

			$base['lunar'] = array(
				'month'   => (int) $lunar->getMonth(),
				'day'     => (int) $lunar->getDay(),
				'is_leap' => (bool) $lunar->isLeap(),
				'display' => sprintf( 'Lunar month %d · day %d%s', absint( $lunar->getMonth() ), absint( $lunar->getDay() ), $lunar->isLeap() ? ' (leap month)' : '' ),
			);
			$base['solar_term'] = array(
				'name'            => $term[0],
				'transliteration' => $term[1],
				'chinese'         => $term_key,
				'season'          => $term[2],
				'reflection'      => $term[3],
			);
			$base['next_solar_term'] = $next ? array(
				'chinese' => $next->getName(),
				'date'    => $next->getSolar()->toYmd(),
			) : null;
			$base['today_focus'] = self::$focuses[ $weekday ];
			$base['go_gently_with'] = self::$gentle[ $weekday ];
			$base['status'] = 'calculated';
		} catch ( Throwable $error ) {
			// Public output stays useful even if a future host PHP change blocks the library.
			$base['lunar'] = null;
			$base['solar_term'] = array(
				'name'       => 'Seasonal reflection',
				'reflection' => 'Read the archive with attention to place, time, and source.',
			);
			$base['next_solar_term'] = null;
			$base['today_focus'] = self::$focuses[ (int) $date->format( 'N' ) - 1 ];
			$base['go_gently_with'] = self::$gentle[ (int) $date->format( 'N' ) - 1 ];
			$base['status'] = 'civil-date-fallback';
		}

		return $base;
	}

	public static function card( $variant = 'mobile' ) {
		$data = self::for_timezone();
		$variant = in_array( $variant, array( 'desktop', 'mobile', 'page' ), true ) ? $variant : 'mobile';
		$classes = 'jm-live-almanac jm-live-almanac--' . $variant;
		$lunar_label = ! empty( $data['lunar']['display'] ) ? $data['lunar']['display'] : 'Lunar calendar';
		ob_start();
		?>
		<aside class="<?php echo esc_attr( $classes ); ?>" data-jm-almanac-card data-jm-almanac-variant="<?php echo esc_attr( $variant ); ?>" aria-label="Today’s Almanac">
			<span class="jm-live-almanac__label">Today’s Almanac</span>
			<time datetime="<?php echo esc_attr( $data['civil_date'] ); ?>" data-jm-almanac-date><?php echo esc_html( $data['civil_label'] ); ?></time>
			<p class="jm-live-almanac__season" data-jm-almanac-season><?php echo esc_html( $lunar_label . ' · ' . ( $data['solar_term']['name'] ?? 'Seasonal reflection' ) ); ?></p>
			<div class="jm-live-almanac__item jm-live-almanac__item--focus"><i aria-hidden="true">⌁</i><div><b>Today’s focus</b><strong data-jm-almanac-focus><?php echo esc_html( $data['today_focus'] ); ?></strong></div></div>
			<div class="jm-live-almanac__item jm-live-almanac__item--gently"><i aria-hidden="true">⌂</i><div><b>Go gently with</b><strong data-jm-almanac-gently><?php echo esc_html( $data['go_gently_with'] ); ?></strong></div></div>
			<small data-jm-almanac-disclaimer><?php echo esc_html( $data['disclaimer'] ); ?></small>
			<a class="jm-live-almanac__link" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Read today’s context <span aria-hidden="true">→</span></a>
		</aside>
		<?php
		return ob_get_clean();
	}
}
