<?php
/** Approved mobile collection entrances; all links remain ordinary anchors. */
function jade_myth_mobile_bottom_nav() {
	$bottom = array(
		array( 'Explore', '/explore/', 'explore', is_page( array('explore','creatures','mysteries','wisdom','sanctuary') ) ),
		array( 'Oracle', '/divination', 'oracle', is_front_page() || is_page('divination') ),
		array( 'Daily Almanac', '/daily-almanac/', 'calendar', is_page('daily-almanac') ),
		array( 'Account', '/account/', 'account', is_page('account') ),
	);
	ob_start(); ?>
	<nav class="jm-bottom-nav" aria-label="Mobile primary navigation">
	<?php foreach ( $bottom as $item ) : ?>
		<a href="<?php echo esc_url(home_url($item[1])); ?>"<?php echo $item[3] ? ' aria-current="true"' : ''; ?>><span class="nav-symbol"><?php
		if ( $item[2] === 'oracle' ) { ?>
			<img class="oracle-icon" src="<?php echo esc_url(JADE_MYTH_VISUAL_URL . 'art/motion-v1/taiji-icon.webp'); ?>" width="26" height="26" alt="">
		<?php } else { echo jade_myth_icon($item[2]); } ?></span><span><?php echo esc_html($item[0]); ?></span></a>
	<?php endforeach; ?>
	</nav>
	<?php return ob_get_clean();
}

function jade_myth_mobile_explore_gallery() {
	ob_start(); ?>
	<nav class="jm-mobile-explore-gallery" aria-label="Explore collections">
	<?php foreach ( array('creatures'=>'Creatures','mysteries'=>'Mysteries','wisdom'=>'Wisdom','sanctuary'=>'Sanctuary') as $slug=>$label ) : ?>
		<a href="<?php echo esc_url(home_url('/'.$slug.'/')); ?>"><?php echo jm_cf_img('mobile-'.$slug,false,true); ?><span><?php echo esc_html($label); ?><b aria-hidden="true">→</b></span></a>
	<?php endforeach; ?>
	</nav>
	<?php return ob_get_clean();
}
