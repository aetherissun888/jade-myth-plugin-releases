<?php
/**
 * Plugin Name: Jade & Myth Visual System
 * Description: Complete editorial visual system, navigation, homepage and mobile shell for Jade & Myth.
 * Version: 5.4.14
 * Author: Aetheris Sun LLC
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JADE_MYTH_VISUAL_VERSION', '5.4.14' );
define( 'JADE_MYTH_VISUAL_URL', plugin_dir_url( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_DIR', plugin_dir_path( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_PACKAGE', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/jade-myth-visual-system.zip?version=5.4.14' );
define( 'JADE_MYTH_VISUAL_ASSETS', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/' );

require_once JADE_MYTH_VISUAL_DIR . 'inc/class-jade-myth-almanac.php';
Jade_Myth_Almanac::bootstrap();

/**
 * Editorial metadata is registered here so the GitHub publisher can update it
 * through the authenticated WordPress REST API without installing an opaque SEO
 * suite. Every field remains private to edit-context REST responses.
 */
add_action( 'init', function () {
	$fields = array(
		'jm_seo_title'        => 120,
		'jm_meta_description' => 180,
		'jm_content_type'     => 60,
		'jm_review_status'    => 60,
		'jm_author_name'      => 100,
		'jm_reviewed_by'      => 100,
		'jm_last_reviewed'    => 20,
		'jm_focus_query'      => 120,
		'jm_entity_id'        => 80,
		'jm_parent_pillar'    => 80,
		'jm_rights_status'    => 40,
		'jm_sources_count'    => 4,
	);
	foreach ( $fields as $key => $max_length ) {
		register_post_meta( 'page', $key, array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) use ( $max_length ) {
				return mb_substr( sanitize_text_field( $value ), 0, $max_length );
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_pages' );
			},
		) );
	}
} );

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_singular( 'page' ) ) {
		$seo_title = get_post_meta( get_queried_object_id(), 'jm_seo_title', true );
		if ( $seo_title ) {
			return $seo_title . ' | Jade & Myth';
		}
	}
	return $title;
} );

add_action( 'wp_head', function () {
	if ( ! is_singular( 'page' ) || is_front_page() ) {
		return;
	}
	$post_id     = get_queried_object_id();
	$description = get_post_meta( $post_id, 'jm_meta_description', true );
	if ( $description ) {
		printf( "\n<meta name=\"description\" content=\"%s\">\n", esc_attr( $description ) );
	}

	$content_type = get_post_meta( $post_id, 'jm_content_type', true );
	if ( ! $content_type ) {
		return;
	}
	$author_name = get_post_meta( $post_id, 'jm_author_name', true );
	$reviewed    = get_post_meta( $post_id, 'jm_last_reviewed', true );
	$canonical   = get_permalink( $post_id );
	$schema      = array(
		'@context'      => 'https://schema.org',
		'@graph'        => array(
			array(
				'@type'            => 'Article',
				'@id'              => $canonical . '#article',
				'headline'         => get_the_title( $post_id ),
				'description'      => $description,
				'url'              => $canonical,
				'mainEntityOfPage' => $canonical,
				'inLanguage'       => 'en-US',
				'author'           => array(
					'@type' => 'Organization',
					'name'  => $author_name ? $author_name : 'Jade & Myth Editorial',
				),
				'publisher'        => array(
					'@type' => 'Organization',
					'name'  => 'Jade & Myth',
					'url'   => home_url( '/' ),
				),
				'dateModified'     => $reviewed ? $reviewed : get_the_modified_date( 'c', $post_id ),
			),
			array(
				'@type'           => 'BreadcrumbList',
				'@id'             => $canonical . '#breadcrumbs',
				'itemListElement' => array(
					array(
						'@type'    => 'ListItem',
						'position' => 1,
						'name'     => 'Home',
						'item'     => home_url( '/' ),
					),
					array(
						'@type'    => 'ListItem',
						'position' => 2,
						'name'     => get_the_title( $post_id ),
						'item'     => $canonical,
					),
				),
			),
		),
	);
	printf(
		"<script type=\"application/ld+json\">%s</script>\n",
		wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}, 20 );

add_action( 'rest_api_init', function () {
	Jade_Myth_Almanac::register_routes();
	register_rest_route( 'jade-myth/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			return array(
				'plugin'  => 'jade-myth-visual-system',
				'version' => JADE_MYTH_VISUAL_VERSION,
				'active'  => true,
			);
		},
	) );

	register_rest_route( 'jade-myth/v1', '/update', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$result   = $upgrader->run( array(
				'package'           => JADE_MYTH_VISUAL_PACKAGE,
				'destination'       => WP_PLUGIN_DIR,
				'clear_destination' => true,
				'clear_working'     => true,
				'hook_extra'        => array(
					'plugin' => plugin_basename( __FILE__ ),
					'type'   => 'plugin',
					'action' => 'update',
				),
			) );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
			if ( ! $result ) {
				return new WP_Error( 'jm_update_failed', 'The approved package could not be installed.', array( 'status' => 500 ) );
			}

			activate_plugin( plugin_basename( __FILE__ ) );
			return array(
				'success' => true,
				'version' => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );

	/**
	 * Clear the origin page cache after an approved visual-system deployment.
	 *
	 * This route is deliberately private: it requires the same update_plugins
	 * capability as the self-update route and is called only by the repository's
	 * authenticated deployment workflow.  Without it, LiteSpeed can continue to
	 * serve a fully rendered, pre-update HTML page after the plugin files change.
	 */
	register_rest_route( 'jade-myth/v1', '/purge-cache', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			/** LiteSpeed Cache listens for this documented WordPress action. */
			do_action( 'litespeed_purge_all' );

			return array(
				'success'         => true,
				'cache_purge'     => 'requested',
				'plugin_version'  => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'brand.css',
		array(),
		JADE_MYTH_VISUAL_VERSION
	);
	wp_enqueue_script(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'visual.js',
		array(),
		JADE_MYTH_VISUAL_VERSION,
		true
	);
} );

/**
 * Jade & Myth supplies its own site shell. Remove Hostinger's translated
 * template parts at render time so placeholder navigation and footer content
 * never reach the browser. This intentionally replaces the former client-side
 * observer and timer cleanup, which could repeatedly react to its own DOM work.
 */
add_filter( 'render_block_core/template-part', function ( $block_content, $block ) {
	if ( is_admin() ) {
		return $block_content;
	}

	$attributes = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$area       = isset( $attributes['area'] ) ? $attributes['area'] : '';
	$slug       = isset( $attributes['slug'] ) ? $attributes['slug'] : '';

	if ( in_array( $area, array( 'header', 'footer' ), true ) || in_array( $slug, array( 'header', 'footer' ), true ) ) {
		return '';
	}

	return $block_content;
}, 10, 2 );

function jade_myth_icon( $name ) {
	$icons = array(
		'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V21h13V10.5"/><path d="M9.5 21v-6h5v6"/>',
		'explore' => '<circle cx="12" cy="12" r="9"/><path d="m15.8 8.2-2.3 5.3-5.3 2.3 2.3-5.3 5.3-2.3Z"/>',
		'calendar'=> '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/><path d="M8 14h3m2 0h3m-8 3h3"/>',
		'saved'  => '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
		'account'=> '<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( $icons[ $name ] ?? '' ) . '</svg>';
}

function jade_myth_header() {
	$links = array(
		'Explore'       => '/explore/',
		'Creatures'     => '/creatures/',
		'Mysteries'     => '/mysteries/',
		'Wisdom'        => '/wisdom/',
		'Daily Almanac' => '/daily-almanac/',
		'Sanctuary'     => '/sanctuary/',
		'Shop'          => '/shop/',
	);
	ob_start();
	?>
	<header class="jm-header" data-jm-header>
		<div class="jm-header__inner">
			<a class="jm-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Jade &amp; Myth home">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="46" height="46" alt="">
				<span>Jade <i>&amp;</i> Myth</span>
			</a>
			<nav class="jm-desktop-nav" aria-label="Primary navigation">
				<?php foreach ( $links as $label => $path ) : ?>
					<a href="<?php echo esc_url( home_url( $path ) ); ?>"<?php echo 'Shop' === $label ? ' class="jm-shop-link" data-note="Coming later"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<a class="jm-account-link" href="<?php echo esc_url( home_url( '/account/' ) ); ?>">Account</a>
				<a class="jm-search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
			</nav>
			<div class="jm-mobile-actions">
				<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
				<button type="button" aria-label="Open menu" aria-expanded="false" data-jm-menu-toggle><?php echo jade_myth_icon( 'menu' ); ?></button>
			</div>
		</div>
		<nav class="jm-mobile-menu" aria-label="Mobile navigation" data-jm-menu>
			<?php foreach ( $links as $label => $path ) : ?>
				<a href="<?php echo esc_url( home_url( $path ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
	</header>
	<?php
	return ob_get_clean();
}

/**
 * Render a deliberately non-collecting newsletter control.
 *
 * The public site does not yet have a verified consent processor, double
 * opt-in, suppression list, or current collection notice. Do not accept an
 * address until those operational requirements are ready.
 */
function jade_myth_newsletter_hold( $id_prefix = 'jm-email', $master = false ) {
	$id = sanitize_html_class( $id_prefix );
	if ( $master ) {
		return '<aside class="jm-newsletter-hold jm-newsletter-hold--master" aria-label="Newsletter status">'
			. '<strong>Newsletter registration is not open yet.</strong>'
			. '<span>No email address is collected from this site today.</span>'
			. '</aside>';
	}
	return sprintf(
		'<form class="jm-newsletter-hold" data-jm-newsletter-hold aria-describedby="%1$s-notice">'
		. '<label for="%1$s">Email address</label>'
		. '<input id="%1$s" type="email" autocomplete="email" inputmode="email" placeholder="Newsletter opening soon" disabled aria-disabled="true">'
		. '<button type="button" aria-describedby="%1$s-notice">Subscribe</button>'
		. '<p id="%1$s-notice" class="screen-reader-text" role="status">The mailing list is not open yet. No email address is collected from this form.</p>'
		. '</form>',
		esc_attr( $id )
	);
}

function jade_myth_homepage() {
	$hero = esc_url( JADE_MYTH_VISUAL_URL . 'hero-ding-landscape.png' );
	ob_start();
	?>
	<main class="jm-home">
		<div class="jm-master-home" aria-label="Jade &amp; Myth visual archive">
			<section class="jm-master-panel jm-master-panel--hero"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-hero.png' ); ?>" width="1672" height="941" alt="Enter the living archive of ancient China, with today’s Almanac.">
				<?php echo Jade_Myth_Almanac::card( 'desktop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<a class="jm-hotspot jm-hotspot--brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Jade &amp; Myth home</span></a>
				<a class="jm-hotspot jm-hotspot--explore" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore</span></a>
				<a class="jm-hotspot jm-hotspot--creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Creatures</span></a>
				<a class="jm-hotspot jm-hotspot--mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Mysteries</span></a>
				<a class="jm-hotspot jm-hotspot--wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Wisdom</span></a>
				<a class="jm-hotspot jm-hotspot--almanac" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Daily Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--sanctuary" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Sanctuary</span></a>
				<a class="jm-hotspot jm-hotspot--shop" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>"><span>Shop</span></a>
				<a class="jm-hotspot jm-hotspot--search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><span>Search</span></a>
				<a class="jm-hotspot jm-hotspot--hero-cta" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Open today’s Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--hero-card" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View today’s Almanac</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--map"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-map.png' ); ?>" width="1672" height="941" alt="Explore the map: a living atlas of stories, objects and places across China.">
				<a class="jm-hotspot jm-hotspot--map-cta" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Open the atlas</span></a>
				<a class="jm-hotspot jm-hotspot--map-canvas" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore the interactive map</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--sections"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-sections.png' ); ?>" width="1672" height="941" alt="Jade &amp; Myth paths, featured Sanxingdui dossier, feelings, member Almanac, field notes and newsletter.">
				<div class="jm-master-hotspots jm-master-hotspots--sections">
					<a class="jm-hotspot jm-hotspot--path-creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Explore creatures</span></a>
					<a class="jm-hotspot jm-hotspot--path-mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Explore lost civilizations</span></a>
					<a class="jm-hotspot jm-hotspot--path-wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Explore Daoist wisdom</span></a>
					<a class="jm-hotspot jm-hotspot--dossier" href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>"><span>Explore the Sanxingdui dossier</span></a>
					<a class="jm-hotspot jm-hotspot--feelings" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Choose how you feel</span></a>
					<a class="jm-hotspot jm-hotspot--member" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View your member Almanac</span></a>
					<a class="jm-hotspot jm-hotspot--field" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Read field notes</span></a>
				</div>
				<div class="jm-master-newsletter"><?php echo jade_myth_newsletter_hold( 'jm-master-email', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<nav class="jm-master-trust" aria-label="Editorial and legal links">
					<div class="jm-master-trust__core">
						<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>"><span>Editorial standards</span></a>
						<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>"><span>Sources &amp; methods</span></a>
						<a href="<?php echo esc_url( home_url( '/trust/' ) ); ?>"><span>Trust center</span></a>
					</div>
					<a class="jm-master-trust__contact" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><span>Contact</span></a>
				</nav>
			</div></section>
		</div>

		<div class="jm-mobile-home">
		<section class="jm-hero" style="--jm-hero-image:url('<?php echo $hero; ?>')">
			<div class="jm-hero__content">
				<h1>Enter the living archive of ancient China.</h1>
				<p>Stories, symbols, seasonal rhythms, and forgotten questions—carefully researched for curious modern lives.</p>
				<a class="jm-button jm-button--light" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Open today’s Almanac <span aria-hidden="true">→</span></a>
			</div>
			<?php echo Jade_Myth_Almanac::card( 'mobile' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section class="jm-wonder jm-shell">
			<div class="jm-section-intro">
				<span class="jm-section-label">Start with wonder</span>
				<h2>Three paths into China’s enduring imagination.</h2>
			</div>
			<div class="jm-path-rail">
				<a href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>01</span><h3>Creatures</h3><p>Mythical beings, animals, and the natural world.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>02</span><h3>Lost Civilizations</h3><p>Empires, kingdoms, and forgotten cities.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>03</span><h3>Daoist Wisdom</h3><p>Teachings, texts, and the living way of Dao.</p><i>Explore →</i></a>
			</div>
		</section>

		<section class="jm-dossier">
			<div class="jm-shell jm-dossier__grid">
				<div>
					<span class="jm-section-label jm-section-label--gold">Featured dossier</span>
					<h2>Sanxingdui: China’s Bronze Age enigma</h2>
					<p>How new discoveries continue to reshape the story of one of the ancient world’s most singular civilizations.</p>
					<a href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>">Explore the dossier →</a>
				</div>
				<dl>
					<div><dt>Approach</dt><dd>Evidence before speculation</dd></div>
					<div><dt>Sources</dt><dd>Museum and archaeological records</dd></div>
					<div><dt>Reading time</dt><dd>18 minutes</dd></div>
				</dl>
			</div>
		</section>

		<section class="jm-discovery jm-shell">
			<div class="jm-feelings">
				<span class="jm-section-label">Choose how you feel</span>
				<h2>Begin where you are.</h2>
				<nav aria-label="Explore by feeling">
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Lost <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Anxious <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Grieving <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Low <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Curious <span>→</span></a>
				</nav>
			</div>
			<div class="jm-member">
				<span class="jm-section-label">Member preview</span>
				<h2>Your personalized Almanac, made meaningful.</h2>
				<p>Daily cultural context, private collections, and thoughtful reminders shaped around your rhythm.</p>
				<strong>$9.90 <small>/ month</small></strong>
				<a class="jm-button" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Preview membership →</a>
			</div>
			<article class="jm-field-note">
				<span class="jm-section-label">Field notes</span>
				<h2>On the edges of the map</h2>
				<p>Real places, objects, sounds, and conversations—documented with permission and credited sources.</p>
				<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Read field notes →</a>
			</article>
		</section>

		<section class="jm-newsletter">
			<div class="jm-shell">
				<div><span class="jm-section-label jm-section-label--gold">Join the archive</span><h2>Stories, wisdom, and wonder—delivered.</h2><p>One carefully researched dispatch each week. No noise.</p></div>
				<?php echo jade_myth_newsletter_hold( 'jm-email' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</section>
		</div>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * The public collection directory is intentionally curated rather than an
 * automatic dump of every draft or tag. This keeps the archive intelligible
 * as the editorial catalogue grows, and prevents unreviewed records appearing
 * as public authority pages.
 */
function jade_myth_explore_directory() {
	$collections = array(
		array(
			'number' => '01',
			'eyebrow' => 'Foundational text',
			'title'   => 'Shan Hai Jing Atlas',
			'copy'    => 'A source-guided entrance to the Classic of Mountains and Seas: geography, beings, transmission, and later imagination.',
			'link'    => '/shan-hai-jing/',
			'cta'     => 'Enter the atlas',
		),
		array(
			'number' => '02',
			'eyebrow' => 'Mythic beings',
			'title'   => 'Creatures & entities',
			'copy'    => 'Named beings, symbols, and creature records, each separated from later folklore and modern adaptation.',
			'link'    => '/creatures/',
			'cta'     => 'Browse creatures',
		),
		array(
			'number' => '03',
			'eyebrow' => 'Material evidence',
			'title'   => 'Archaeology & lost worlds',
			'copy'    => 'Objects, excavation records, museums, and the historical questions that remain open.',
			'link'    => '/mysteries/',
			'cta'     => 'Explore mysteries',
		),
		array(
			'number' => '04',
			'eyebrow' => 'Living traditions',
			'title'   => 'Wisdom & seasonal life',
			'copy'    => 'Daoist thought, seasonal practices, and cultural reflection — without supernatural promises.',
			'link'    => '/wisdom/',
			'cta'     => 'Read wisdom',
		),
	);
	$records = array(
		array( 'Zhu Yin', 'Torch-shadow deity record', '/zhu-yin/' ),
		array( 'Fenghuang', 'Auspicious bird record', '/fenghuang/' ),
		array( 'Sanxingdui', 'Bronze Age Shu in context', '/sanxingdui/' ),
	);
	ob_start();
	?>
	<main class="jm-explore alignfull">
		<section class="jm-explore__masthead">
			<div class="jm-explore__masthead-inner">
				<p class="jm-explore__eyebrow">Jade &amp; Myth / Collection directory</p>
				<h1>Explore the Archive</h1>
				<p>Follow cultural records through text, landscape, objects, and later reception. Every collection identifies the boundary between source, interpretation, folklore, and modern imagination.</p>
				<div class="jm-explore__route" aria-label="Archive route">
					<span>Begin with a source</span><i aria-hidden="true"></i><span>Follow a collection</span><i aria-hidden="true"></i><span>Read a reviewed record</span>
				</div>
			</div>
		</section>

		<section class="jm-explore__catalogue" aria-labelledby="jm-collections-title">
			<div class="jm-explore__section-head">
				<div><p class="jm-explore__label">Catalogue</p><h2 id="jm-collections-title">Collections to begin with</h2></div>
				<p>Choose a collection, then move from its overview to source-led guides and reviewed entities. The structure stays stable as the archive expands.</p>
			</div>
			<div class="jm-explore__collection-grid">
				<?php foreach ( $collections as $collection ) : ?>
					<a class="jm-explore__collection" href="<?php echo esc_url( home_url( $collection['link'] ) ); ?>">
						<span class="jm-explore__number"><?php echo esc_html( $collection['number'] ); ?></span>
						<p class="jm-explore__label"><?php echo esc_html( $collection['eyebrow'] ); ?></p>
						<h3><?php echo esc_html( $collection['title'] ); ?></h3>
						<p><?php echo esc_html( $collection['copy'] ); ?></p>
						<span class="jm-explore__link"><?php echo esc_html( $collection['cta'] ); ?> <b aria-hidden="true">→</b></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-explore__shelves" aria-labelledby="jm-shelves-title">
			<div class="jm-explore__shelves-intro">
				<p class="jm-explore__label">Open shelves</p>
				<h2 id="jm-shelves-title">Reviewed records</h2>
				<p>These entries have crossed the current source, evidence, and editorial review gate. New records enter here only after the same check.</p>
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Read our editorial policy <b aria-hidden="true">→</b></a>
			</div>
			<div class="jm-explore__records">
				<?php foreach ( $records as $index => $record ) : ?>
					<a href="<?php echo esc_url( home_url( $record[2] ) ); ?>"><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><strong><?php echo esc_html( $record[0] ); ?></strong><em><?php echo esc_html( $record[1] ); ?></em><b aria-hidden="true">↗</b></a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-explore__method" aria-labelledby="jm-method-title">
			<div class="jm-explore__method-mark" aria-hidden="true">山<br>海</div>
			<div><p class="jm-explore__label">How to use this archive</p><h2 id="jm-method-title">One directory, clear paths.</h2></div>
			<ol>
				<li><b>01</b><span>Start with a collection overview.</span></li>
				<li><b>02</b><span>Follow links into entity and dossier pages.</span></li>
				<li><b>03</b><span>Check sources, review status, and related records.</span></li>
			</ol>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * Primary collection directories use a single stable catalogue anatomy while
 * retaining distinct material cues. The routes are deliberately hand-curated:
 * a directory is an editorial finding aid, not an automatic tag archive that
 * could expose a private or unreviewed draft.
 */
function jade_myth_collection_directory( $collection_key ) {
	$directories = array(
		'creatures' => array(
			'eyebrow'        => 'Jade & Myth / Creature archive',
			'title'           => 'Creatures & entities',
			'dek'             => 'A source-led catalogue of named beings, celestial figures, and later creature traditions. Textual record, folklore, and modern reception remain visibly distinct.',
			'route'           => array( 'Read the source', 'Locate the figure', 'Compare later reception' ),
			'catalogue_label' => 'Catalogue of beings',
			'catalogue_title' => 'Find a being by its record',
			'catalogue_copy'  => 'Begin with the textual world that frames an entry, then follow only reviewed links into individual records.',
			'paths'           => array(
				array( '01', 'Foundational text', 'Mountains, seas & named beings', 'The Shan Hai Jing is a starting point for geography, beings, transmission, and later imagination.', '/shan-hai-jing/', 'Open the atlas' ),
				array( '02', 'Cosmology', 'Sky, direction & symbol', 'Read the Four Symbols as a historical cosmological system, not a generic zodiac.', '/four-symbols/', 'Read the sky record' ),
				array( '03', 'Entity records', 'Named figures in context', 'Reviewed entries identify what a source states and what later traditions add.', '/zhu-yin/', 'Browse a record' ),
				array( '04', 'Reading method', 'Myth beyond “monster”', 'Use the mythology guide to separate a text, a ritual tradition, and a modern story world.', '/chinese-mythology/', 'Read the guide' ),
			),
			'records'         => array(
				array( 'Zhu Yin', 'Torch-shadow deity record', '/zhu-yin/' ),
				array( 'Fenghuang', 'Auspicious bird record', '/fenghuang/' ),
				array( 'The Four Symbols', 'Cosmological directions and sky figures', '/four-symbols/' ),
				array( 'Nüwa', 'Mythic figure and repair-of-the-sky traditions', '/nuwa/' ),
			),
			'boundary'        => 'An ancient description is evidence for a narrative tradition. It is not evidence that a being existed as a biological species.',
		),
		'mysteries' => array(
			'eyebrow'        => 'Jade & Myth / Evidence archive',
			'title'           => 'Mysteries & material worlds',
			'dek'             => 'Objects, excavations, lost places, and questions that are still open. This collection starts with what museums, sites, and published research can establish.',
			'route'           => array( 'Inspect the object', 'Trace the evidence', 'Keep the question open' ),
			'catalogue_label' => 'Material record',
			'catalogue_title' => 'Follow the evidence trail',
			'catalogue_copy'  => 'A mystery is not a licence to invent an answer. These routes distinguish excavated material, textual history, and unresolved interpretation.',
			'paths'           => array(
				array( '01', 'Open dossier', 'Sanxingdui and Bronze Age Shu', 'An archaeological guide to what the discoveries show, and to the limits of the present record.', '/sanxingdui/', 'Open the dossier' ),
				array( '02', 'Research field', 'Ancient Chinese mysteries', 'A route through historical questions with an evidence-first editorial frame.', '/ancient-mysteries/', 'Explore the field' ),
				array( '03', 'Source desk', 'Texts, editions & collections', 'Find the publications and institutional records that anchor a public claim.', '/sources/', 'Consult sources' ),
				array( '04', 'Editorial method', 'How an open question is handled', 'See the archive’s boundaries for uncertainty, attribution, and later interpretation.', '/editorial-policy/', 'Read the method' ),
			),
			'records'         => array(
				array( 'Sanxingdui', 'Bronze Age Shu in archaeological context', '/sanxingdui/' ),
				array( 'Ancient Chinese Mysteries', 'Evidence-first research field guide', '/ancient-mysteries/' ),
				array( 'The Shan Hai Jing', 'Source guide to a layered textual landscape', '/shan-hai-jing/' ),
				array( 'Sources & editions', 'The archive’s public research desk', '/sources/' ),
			),
			'boundary'        => 'Where evidence stops, the page says so. Possibility, folklore, and a verified archaeological conclusion are never presented as the same thing.',
		),
		'wisdom' => array(
			'eyebrow'        => 'Jade & Myth / Reading room',
			'title'           => 'Wisdom & seasonal life',
			'dek'             => 'Texts, calendars, and cultural reflection for readers who want context rather than prescriptions. No spiritual promise, medical advice, or personal prediction is made here.',
			'route'           => array( 'Read the text', 'Notice the season', 'Keep your own judgment' ),
			'catalogue_label' => 'Reading paths',
			'catalogue_title' => 'Context before conclusion',
			'catalogue_copy'  => 'These routes connect a calendar fact or received tradition to clear sourcing and a contemporary reading practice that remains voluntary.',
			'paths'           => array(
				array( '01', 'Living calendar', 'Today’s Almanac', 'A free cultural calendar with local-date lunar and solar-term context.', '/daily-almanac/', 'Open today’s record' ),
				array( '02', 'Methodology', 'How the Almanac works', 'Read the calculation, the labelled traditional record, and the editorial boundary.', '/almanac-methodology/', 'Read the method' ),
				array( '03', 'Cultural reflection', 'Living wisdom', 'A reading route for ideas, texts, and attention without claims of personal transformation.', '/living-wisdom/', 'Enter the reading room' ),
				array( '04', 'Quiet attention', 'Sanctuary', 'A gentle route back to cultural context, quiet reading, and the wider archive.', '/sanctuary/', 'Visit Sanctuary' ),
			),
			'records'         => array(
				array( 'Today’s Almanac', 'Calendar fact and editorial cultural context', '/daily-almanac/' ),
				array( 'The 24 solar terms', 'Seasonal framework and calculation notes', '/almanac-methodology/' ),
				array( 'Living wisdom', 'Cultural reflection entry point', '/living-wisdom/' ),
				array( 'Sanctuary', 'Quiet reading and archive pathways', '/sanctuary/' ),
			),
			'boundary'        => 'These materials support reading and reflection. They do not diagnose, treat, predict, protect, or promise a change in a reader’s life.',
		),
		'sanctuary' => array(
			'eyebrow'        => 'Jade & Myth / Quiet shelf',
			'title'           => 'Sanctuary',
			'dek'             => 'A quieter entry into the archive: a place to pause with a text, seasonal observation, or carefully sourced story. It is cultural reflection, never a substitute for care.',
			'route'           => array( 'Pause with a text', 'Choose a gentle path', 'Return to the archive' ),
			'catalogue_label' => 'Quiet catalogue',
			'catalogue_title' => 'Choose a calmer route',
			'catalogue_copy'  => 'Each route stays connected to the public archive, so an inviting surface never loses its source, context, or editorial responsibility.',
			'paths'           => array(
				array( '01', 'Seasonal pause', 'Today’s Almanac', 'Begin with a date, a solar term, and an optional cultural prompt.', '/daily-almanac/', 'Open today’s record' ),
				array( '02', 'Slow reading', 'Wisdom & seasonal life', 'Explore text, tradition, and reflection with clear non-prescriptive boundaries.', '/wisdom/', 'Browse the reading room' ),
				array( '03', 'Guided discovery', 'Explore the Archive', 'Follow a collection into reviewed records, sources, and related reading.', '/explore/', 'Explore collections' ),
				array( '04', 'Trust desk', 'Editorial standards', 'See how the archive handles evidence, uncertainty, and responsible cultural interpretation.', '/editorial-policy/', 'Read our standards' ),
			),
			'records'         => array(
				array( 'Today’s Almanac', 'A date-led invitation to cultural context', '/daily-almanac/' ),
				array( 'Wisdom & seasonal life', 'Reading paths without personal claims', '/wisdom/' ),
				array( 'Explore the Archive', 'Return to a source-led collection', '/explore/' ),
				array( 'Editorial policy', 'How trust and boundaries are maintained', '/editorial-policy/' ),
			),
			'boundary'        => 'If a reader is distressed or needs health, legal, financial, or emergency support, this archive is not the right service. Its role is cultural context and quiet reading.',
		),
	);

	if ( ! isset( $directories[ $collection_key ] ) ) {
		return '';
	}

	$directory = $directories[ $collection_key ];
	$slug      = sanitize_html_class( $collection_key );
	ob_start();
	?>
	<main class="jm-collection-directory jm-collection-directory--<?php echo esc_attr( $slug ); ?> alignfull">
		<header class="jm-collection-directory__masthead">
			<div class="jm-collection-directory__masthead-inner">
				<div class="jm-collection-directory__masthead-copy">
					<p class="jm-collection-directory__eyebrow"><?php echo esc_html( $directory['eyebrow'] ); ?></p>
					<h1><?php echo esc_html( $directory['title'] ); ?></h1>
					<p><?php echo esc_html( $directory['dek'] ); ?></p>
				</div>
				<div class="jm-collection-directory__specimen" aria-hidden="true"><span></span><i></i><b></b></div>
			</div>
			<div class="jm-collection-directory__route" aria-label="Collection reading route">
				<?php foreach ( $directory['route'] as $index => $step ) : ?>
					<span><b><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></b><?php echo esc_html( $step ); ?></span>
				<?php endforeach; ?>
			</div>
		</header>

		<section class="jm-collection-directory__catalogue" aria-labelledby="jm-<?php echo esc_attr( $slug ); ?>-catalogue-title">
			<div class="jm-collection-directory__section-head">
				<div><p class="jm-collection-directory__label"><?php echo esc_html( $directory['catalogue_label'] ); ?></p><h2 id="jm-<?php echo esc_attr( $slug ); ?>-catalogue-title"><?php echo esc_html( $directory['catalogue_title'] ); ?></h2></div>
				<p><?php echo esc_html( $directory['catalogue_copy'] ); ?></p>
			</div>
			<div class="jm-collection-directory__path-grid">
				<?php foreach ( $directory['paths'] as $path ) : ?>
					<a class="jm-collection-directory__path" href="<?php echo esc_url( home_url( $path[4] ) ); ?>">
						<span class="jm-collection-directory__number"><?php echo esc_html( $path[0] ); ?></span>
						<p class="jm-collection-directory__label"><?php echo esc_html( $path[1] ); ?></p>
						<h3><?php echo esc_html( $path[2] ); ?></h3>
						<p><?php echo esc_html( $path[3] ); ?></p>
						<span class="jm-collection-directory__link"><?php echo esc_html( $path[5] ); ?> <b aria-hidden="true">→</b></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-collection-directory__shelf" aria-labelledby="jm-<?php echo esc_attr( $slug ); ?>-shelf-title">
			<div class="jm-collection-directory__shelf-intro">
				<p class="jm-collection-directory__label">Open shelf</p>
				<h2 id="jm-<?php echo esc_attr( $slug ); ?>-shelf-title">Current public records</h2>
				<p>Only routes that are public and have passed the archive’s present review gate appear here. New material is added deliberately, not automatically.</p>
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Read the editorial standard <b aria-hidden="true">→</b></a>
			</div>
			<div class="jm-collection-directory__records">
				<?php foreach ( $directory['records'] as $index => $record ) : ?>
					<a href="<?php echo esc_url( home_url( $record[2] ) ); ?>"><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><strong><?php echo esc_html( $record[0] ); ?></strong><em><?php echo esc_html( $record[1] ); ?></em><b aria-hidden="true">↗</b></a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-collection-directory__boundary" aria-label="Editorial boundary">
			<div class="jm-collection-directory__boundary-mark" aria-hidden="true"></div>
			<div><p class="jm-collection-directory__label">Editorial boundary</p><h2>Context is part of the collection.</h2></div>
			<p><?php echo esc_html( $directory['boundary'] ); ?></p>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * The Almanac has one stable, indexable home. It renders server-side first,
 * then visual.js refreshes it for the visitor's IANA time zone.
 */
function jade_myth_daily_almanac_page() {
	ob_start();
	?>
	<main class="jm-almanac-page alignfull">
		<header class="jm-almanac-page__masthead">
			<div class="jm-almanac-page__inner">
				<p class="jm-almanac-page__eyebrow">A living cultural calendar</p>
				<h1>Today’s Almanac</h1>
				<p>Daily context shaped by the lunar calendar and the twenty-four solar terms—read as a cultural invitation, never a prediction.</p>
			</div>
		</header>
		<section class="jm-almanac-page__reading" aria-label="Today’s cultural reflection">
			<div class="jm-almanac-page__card-wrap"><?php echo Jade_Myth_Almanac::card( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div class="jm-almanac-page__context">
				<p class="jm-almanac-page__eyebrow">How to read it</p>
				<h2>Calendar fact, then cultural context.</h2>
				<p>The date, lunar conversion, and solar term are calculated locally from a versioned calendar library. The daily focus and gentle prompt are editorial reflections, kept separate from the calculation.</p>
				<ul>
					<li>No fortune, fate, health, wealth, or relationship claims.</li>
					<li>No personal data is needed to view the free Almanac.</li>
					<li>Source links, calculation version, and the named traditional rule set are included in the public response.</li>
				</ul>
				<p class="jm-almanac-page__sources"><a href="https://www.hko.gov.hk/en/gts/time/Calendar.htm" rel="noopener noreferrer" target="_blank">Chinese calendar reference</a><a href="https://www.hko.gov.hk/en/gts/time/24solarterms.htm" rel="noopener noreferrer" target="_blank">24 solar terms reference</a></p>
			</div>
		</section>
		<?php echo Jade_Myth_Almanac::traditional_record_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</main>
	<?php
	return ob_get_clean();
}

add_filter( 'the_content', function ( $content ) {
	if ( is_front_page() && in_the_loop() && is_main_query() ) {
		return jade_myth_homepage();
	}
	if ( is_page( 'explore' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_explore_directory();
	}
	if ( is_page( array( 'creatures', 'mysteries', 'wisdom', 'sanctuary' ) ) && in_the_loop() && is_main_query() ) {
		return jade_myth_collection_directory( get_post_field( 'post_name', get_the_ID() ) );
	}
	if ( is_page( 'daily-almanac' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_daily_almanac_page();
	}
	if ( ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$content_type = get_post_meta( get_the_ID(), 'jm_content_type', true );
	$article_types = array(
		'cultural_reference',
		'archaeological_guide',
		'mythology_entity',
		'archaeology_entity',
	);
	if ( ! in_array( $content_type, $article_types, true ) ) {
		return $content;
	}

	$title          = get_the_title();
	$review_status  = get_post_meta( get_the_ID(), 'jm_review_status', true );
	$reviewed_by    = get_post_meta( get_the_ID(), 'jm_reviewed_by', true );
	$last_reviewed  = get_post_meta( get_the_ID(), 'jm_last_reviewed', true );
	$source_count   = absint( get_post_meta( get_the_ID(), 'jm_sources_count', true ) );
	$source_count   = $source_count ? $source_count : 1;
	$reading_minutes = max( 3, (int) ceil( str_word_count( wp_strip_all_tags( $content ) ) / 220 ) );
	$content         = preg_replace( '/<h1[^>]*>.*?<\\/h1>/is', '', $content, 1 );

	preg_match_all( '/<h2[^>]*>(.*?)<\\/h2>/is', $content, $matches );
	$toc = array();
	foreach ( $matches[1] as $index => $heading ) {
		$label = trim( wp_strip_all_tags( $heading ) );
		$id    = 'reading-' . ( $index + 1 );
		$content = preg_replace( '/<h2([^>]*)>' . preg_quote( $heading, '/' ) . '<\\/h2>/is', '<h2$1 id="' . esc_attr( $id ) . '">' . $heading . '</h2>', $content, 1 );
		$toc[] = array( 'id' => $id, 'label' => $label );
	}

	ob_start();
	?>
	<article class="jm-reading alignfull" data-content-type="<?php echo esc_attr( $content_type ); ?>">
		<header class="jm-reading__masthead">
			<div class="jm-reading__masthead-inner">
				<p class="jm-reading__kicker">Jade &amp; Myth / Research Archive</p>
				<h1><?php echo esc_html( $title ); ?></h1>
				<div class="jm-reading__ledger" aria-label="Article record">
					<span><b>Record</b><?php echo esc_html( ucwords( str_replace( '_', ' ', $content_type ) ) ); ?></span>
					<span><b>Reading</b><?php echo esc_html( $reading_minutes ); ?> min</span>
					<span><b>Sources</b><?php echo esc_html( $source_count ); ?> referenced</span>
					<span><b>Review</b><?php echo esc_html( $review_status ? str_replace( '_', ' ', $review_status ) : 'Editorial review' ); ?></span>
				</div>
			</div>
		</header>
		<div class="jm-reading__frame">
			<aside class="jm-reading__index" aria-label="On this page">
				<p>Contents</p>
				<ol>
					<?php foreach ( $toc as $item ) : ?>
						<li><a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ol>
			</aside>
			<div class="jm-reading__body">
				<div class="jm-reading__provenance"><span>Interpret with care</span><p>Primary text, later interpretation, and modern retelling are kept distinct throughout this archive.</p></div>
				<div class="jm-reading__content"><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<aside class="jm-reading__record" aria-label="Editorial record">
				<p>Editorial record</p>
				<dl>
					<div><dt>Reviewed by</dt><dd><?php echo esc_html( $reviewed_by ? $reviewed_by : 'Jade & Myth Editorial' ); ?></dd></div>
					<div><dt>Last reviewed</dt><dd><?php echo esc_html( $last_reviewed ? $last_reviewed : get_the_modified_date( 'F j, Y' ) ); ?></dd></div>
					<div><dt>Use</dt><dd>Cultural education and research.</dd></div>
				</dl>
			</aside>
		</div>
	</article>
	<?php
	return ob_get_clean();
}, 99 );

add_action( 'wp_body_open', function () {
	echo jade_myth_header();
}, 5 );

add_action( 'wp_footer', function () {
	$bottom = array(
		'Home'     => array( '/', 'home' ),
		'Explore'  => array( '/explore/', 'explore' ),
		'Almanac'  => array( '/daily-almanac/', 'calendar' ),
		'Saved'    => array( '/saved/', 'saved' ),
		'Account'  => array( '/account/', 'account' ),
	);
	?>
	<footer class="jm-footer">
		<div class="jm-shell jm-footer__inner">
			<div class="jm-footer__brand"><img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="42" height="42" alt=""><div><b>Jade &amp; Myth</b><span>Ancient myths. Living rituals.</span></div></div>
			<nav aria-label="Trust links">
				<div class="jm-footer__trust-core">
					<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Editorial standards</a>
					<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Sources &amp; methods</a>
					<a href="<?php echo esc_url( home_url( '/trust/' ) ); ?>">Trust center</a>
				</div>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a>
			</nav>
			<small>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Aetheris Sun LLC. Cultural education, not medical or supernatural advice.</small>
		</div>
	</footer>
	<nav class="jm-bottom-nav" aria-label="Mobile primary navigation">
		<?php foreach ( $bottom as $label => $item ) : ?>
			<a href="<?php echo esc_url( home_url( $item[0] ) ); ?>"><?php echo jade_myth_icon( $item[1] ); ?><span><?php echo esc_html( $label ); ?></span></a>
		<?php endforeach; ?>
	</nav>
	<?php
}, 99 );

add_filter( 'get_custom_logo', function () {
	return sprintf(
		'<a href="%1$s" class="custom-logo-link" rel="home" aria-label="Jade &amp; Myth"><img src="%2$s" class="custom-logo" alt="Jade &amp; Myth" width="64" height="64"></a>',
		esc_url( home_url( '/' ) ),
		esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' )
	);
} );
