<?php
/**
 * Plugin Name: Jade & Myth Visual System
 * Description: Complete editorial visual system, navigation, homepage and mobile shell for Jade & Myth.
 * Version: 4.3.1
 * Author: Aetheris Sun LLC
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JADE_MYTH_VISUAL_VERSION', '4.3.1' );
define( 'JADE_MYTH_VISUAL_URL', plugin_dir_url( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_PACKAGE', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/jade-myth-visual-system.zip' );
define( 'JADE_MYTH_VISUAL_ASSETS', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/' );

add_action( 'rest_api_init', function () {
	register_rest_route( 'jade-myth/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			return array(
				'plugin'  => 'jade-myth-visual-system',
				'version' => JADE_MYTH_VISUAL_VERSION,
				'active'  => true,
			);
		},
	) );

	register_rest_route( 'jade-myth/v1', '/update', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$result   = $upgrader->run( array(
				'package'           => JADE_MYTH_VISUAL_PACKAGE,
				'destination'       => WP_PLUGIN_DIR,
				'clear_destination' => true,
				'clear_working'     => true,
				'hook_extra'        => array(
					'plugin' => plugin_basename( __FILE__ ),
					'type'   => 'plugin',
					'action' => 'update',
				),
			) );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
			if ( ! $result ) {
				return new WP_Error( 'jm_update_failed', 'The approved package could not be installed.', array( 'status' => 500 ) );
			}

			activate_plugin( plugin_basename( __FILE__ ) );
			return array(
				'success' => true,
				'version' => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'brand.css',
		array(),
		JADE_MYTH_VISUAL_VERSION
	);
	wp_enqueue_script(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'visual.js',
		array(),
		JADE_MYTH_VISUAL_VERSION,
		true
	);
} );

function jade_myth_icon( $name ) {
	$icons = array(
		'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V21h13V10.5"/><path d="M9.5 21v-6h5v6"/>',
		'explore' => '<circle cx="12" cy="12" r="9"/><path d="m15.8 8.2-2.3 5.3-5.3 2.3 2.3-5.3 5.3-2.3Z"/>',
		'calendar'=> '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/><path d="M8 14h3m2 0h3m-8 3h3"/>',
		'saved'  => '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
		'account'=> '<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( $icons[ $name ] ?? '' ) . '</svg>';
}

function jade_myth_header() {
	$links = array(
		'Explore'       => '/explore/',
		'Creatures'     => '/creatures/',
		'Mysteries'     => '/mysteries/',
		'Wisdom'        => '/wisdom/',
		'Daily Almanac' => '/daily-almanac/',
		'Sanctuary'     => '/sanctuary/',
		'Shop'          => '/shop/',
	);
	ob_start();
	?>
	<header class="jm-header" data-jm-header>
		<div class="jm-header__inner">
			<a class="jm-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Jade &amp; Myth home">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="46" height="46" alt="">
				<span>Jade <i>&amp;</i> Myth</span>
			</a>
			<nav class="jm-desktop-nav" aria-label="Primary navigation">
				<?php foreach ( $links as $label => $path ) : ?>
					<a href="<?php echo esc_url( home_url( $path ) ); ?>"<?php echo 'Shop' === $label ? ' class="jm-shop-link" data-note="Coming later"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<a class="jm-search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
			</nav>
			<div class="jm-mobile-actions">
				<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
				<button type="button" aria-label="Open menu" aria-expanded="false" data-jm-menu-toggle><?php echo jade_myth_icon( 'menu' ); ?></button>
			</div>
		</div>
		<nav class="jm-mobile-menu" aria-label="Mobile navigation" data-jm-menu>
			<?php foreach ( $links as $label => $path ) : ?>
				<a href="<?php echo esc_url( home_url( $path ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
	</header>
	<?php
	return ob_get_clean();
}

function jade_myth_homepage() {
	$hero = esc_url( JADE_MYTH_VISUAL_URL . 'hero-ding-landscape.png' );
	ob_start();
	?>
	<main class="jm-home">
		<div class="jm-master-home" aria-label="Jade &amp; Myth visual archive">
			<section class="jm-master-panel jm-master-panel--hero"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-hero.png' ); ?>" width="1672" height="941" alt="Enter the living archive of ancient China, with today’s Almanac.">
				<a class="jm-hotspot jm-hotspot--brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Jade &amp; Myth home</span></a>
				<a class="jm-hotspot jm-hotspot--explore" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore</span></a>
				<a class="jm-hotspot jm-hotspot--creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Creatures</span></a>
				<a class="jm-hotspot jm-hotspot--mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Mysteries</span></a>
				<a class="jm-hotspot jm-hotspot--wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Wisdom</span></a>
				<a class="jm-hotspot jm-hotspot--almanac" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Daily Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--sanctuary" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Sanctuary</span></a>
				<a class="jm-hotspot jm-hotspot--shop" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>"><span>Shop</span></a>
				<a class="jm-hotspot jm-hotspot--search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><span>Search</span></a>
				<a class="jm-hotspot jm-hotspot--hero-cta" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Open today’s Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--hero-card" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View today’s Almanac</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--map"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-map.png' ); ?>" width="1672" height="941" alt="Explore the map: a living atlas of stories, objects and places across China.">
				<a class="jm-hotspot jm-hotspot--map-cta" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Open the atlas</span></a>
				<a class="jm-hotspot jm-hotspot--map-canvas" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore the interactive map</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--sections"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-sections.png' ); ?>" width="1672" height="941" alt="Jade &amp; Myth paths, featured Sanxingdui dossier, feelings, member Almanac, field notes and newsletter.">
				<div class="jm-master-hotspots jm-master-hotspots--sections">
					<a class="jm-hotspot jm-hotspot--path-creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Explore creatures</span></a>
					<a class="jm-hotspot jm-hotspot--path-mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Explore lost civilizations</span></a>
					<a class="jm-hotspot jm-hotspot--path-wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Explore Daoist wisdom</span></a>
					<a class="jm-hotspot jm-hotspot--dossier" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Explore the Sanxingdui dossier</span></a>
					<a class="jm-hotspot jm-hotspot--feelings" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Choose how you feel</span></a>
					<a class="jm-hotspot jm-hotspot--member" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View your member Almanac</span></a>
					<a class="jm-hotspot jm-hotspot--field" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Read field notes</span></a>
				</div>
				<form class="jm-master-newsletter" action="#" method="post">
					<label for="jm-master-email">Email address</label>
					<input id="jm-master-email" type="email" autocomplete="email" required>
					<button type="submit">Subscribe</button>
				</form>
				<nav class="jm-master-trust" aria-label="Editorial and legal links">
					<a class="jm-master-trust__editorial" href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>"><span>Editorial Policy</span></a>
					<a class="jm-master-trust__sources" href="<?php echo esc_url( home_url( '/sources/' ) ); ?>"><span>Sources</span></a>
					<a class="jm-master-trust__advisors" href="<?php echo esc_url( home_url( '/cultural-advisors/' ) ); ?>"><span>Cultural Advisors</span></a>
					<a class="jm-master-trust__ai" href="<?php echo esc_url( home_url( '/ai-disclosure/' ) ); ?>"><span>AI Disclosure</span></a>
					<a class="jm-master-trust__privacy" href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><span>Privacy</span></a>
					<a class="jm-master-trust__refunds" href="<?php echo esc_url( home_url( '/refund-policy/' ) ); ?>"><span>Refunds</span></a>
					<a class="jm-master-trust__affiliate" href="<?php echo esc_url( home_url( '/affiliate-disclosure/' ) ); ?>"><span>Affiliate Disclosure</span></a>
					<a class="jm-master-trust__contact" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><span>Contact</span></a>
				</nav>
			</div></section>
		</div>

		<div class="jm-mobile-home">
		<section class="jm-hero" style="--jm-hero-image:url('<?php echo $hero; ?>')">
			<div class="jm-hero__content">
				<h1>Enter the living archive of ancient China.</h1>
				<p>Stories, symbols, seasonal rhythms, and forgotten questions—carefully researched for curious modern lives.</p>
				<a class="jm-button jm-button--light" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Open today’s Almanac <span aria-hidden="true">→</span></a>
			</div>
			<aside class="jm-almanac-card" aria-label="Today’s Almanac">
				<span class="jm-section-label">Today’s Almanac</span>
				<time datetime="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( wp_date( 'F j, Y' ) ); ?></time>
				<p class="jm-almanac-season">Seasonal reflection · Summer</p>
				<div class="jm-almanac-guidance jm-almanac-guidance--good"><b>Favorable</b><span>Learning, reflection, and tending to unfinished work.</span></div>
				<div class="jm-almanac-guidance jm-almanac-guidance--avoid"><b>Avoid</b><span>Rushing decisions or overcommitting your energy.</span></div>
				<small>For cultural reflection, not fortune-telling.</small>
			</aside>
		</section>

		<section class="jm-wonder jm-shell">
			<div class="jm-section-intro">
				<span class="jm-section-label">Start with wonder</span>
				<h2>Three paths into China’s enduring imagination.</h2>
			</div>
			<div class="jm-path-rail">
				<a href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>01</span><h3>Creatures</h3><p>Mythical beings, animals, and the natural world.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>02</span><h3>Lost Civilizations</h3><p>Empires, kingdoms, and forgotten cities.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>03</span><h3>Daoist Wisdom</h3><p>Teachings, texts, and the living way of Dao.</p><i>Explore →</i></a>
			</div>
		</section>

		<section class="jm-dossier">
			<div class="jm-shell jm-dossier__grid">
				<div>
					<span class="jm-section-label jm-section-label--gold">Featured dossier</span>
					<h2>Sanxingdui: China’s Bronze Age enigma</h2>
					<p>How new discoveries continue to reshape the story of one of the ancient world’s most singular civilizations.</p>
					<a href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>">Explore the dossier →</a>
				</div>
				<dl>
					<div><dt>Approach</dt><dd>Evidence before speculation</dd></div>
					<div><dt>Sources</dt><dd>Museum and archaeological records</dd></div>
					<div><dt>Reading time</dt><dd>18 minutes</dd></div>
				</dl>
			</div>
		</section>

		<section class="jm-discovery jm-shell">
			<div class="jm-feelings">
				<span class="jm-section-label">Choose how you feel</span>
				<h2>Begin where you are.</h2>
				<nav aria-label="Explore by feeling">
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Lost <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Anxious <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Grieving <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Low <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Curious <span>→</span></a>
				</nav>
			</div>
			<div class="jm-member">
				<span class="jm-section-label">Member preview</span>
				<h2>Your personalized Almanac, made meaningful.</h2>
				<p>Daily cultural context, private collections, and thoughtful reminders shaped around your rhythm.</p>
				<strong>$9.90 <small>/ month</small></strong>
				<a class="jm-button" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Preview membership →</a>
			</div>
			<article class="jm-field-note">
				<span class="jm-section-label">Field notes</span>
				<h2>On the edges of the map</h2>
				<p>Real places, objects, sounds, and conversations—documented with permission and credited sources.</p>
				<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Read field notes →</a>
			</article>
		</section>

		<section class="jm-newsletter">
			<div class="jm-shell">
				<div><span class="jm-section-label jm-section-label--gold">Join the archive</span><h2>Stories, wisdom, and wonder—delivered.</h2><p>One carefully researched dispatch each week. No noise.</p></div>
				<form action="#" method="post"><label for="jm-email">Email address</label><div><input id="jm-email" type="email" placeholder="you@example.com" required><button type="submit">Subscribe</button></div></form>
			</div>
		</section>
		</div>
	</main>
	<?php
	return ob_get_clean();
}

add_filter( 'the_content', function ( $content ) {
	if ( is_front_page() && in_the_loop() && is_main_query() ) {
		return jade_myth_homepage();
	}
	return $content;
}, 99 );

add_action( 'wp_body_open', function () {
	echo jade_myth_header();
}, 5 );

add_action( 'wp_footer', function () {
	$bottom = array(
		'Home'     => array( '/', 'home' ),
		'Explore'  => array( '/explore/', 'explore' ),
		'Almanac'  => array( '/daily-almanac/', 'calendar' ),
		'Saved'    => array( '/saved/', 'saved' ),
		'Account'  => array( '/account/', 'account' ),
	);
	?>
	<footer class="jm-footer">
		<div class="jm-shell jm-footer__inner">
			<div class="jm-footer__brand"><img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="42" height="42" alt=""><div><b>Jade &amp; Myth</b><span>Ancient myths. Living rituals.</span></div></div>
			<nav aria-label="Trust links">
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Editorial Policy</a>
				<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Sources</a>
				<a href="<?php echo esc_url( home_url( '/cultural-advisors/' ) ); ?>">Cultural Advisors</a>
				<a href="<?php echo esc_url( home_url( '/ai-disclosure/' ) ); ?>">AI Disclosure</a>
				<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy</a>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a>
			</nav>
			<small>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Aetheris Sun LLC. Cultural education, not medical or supernatural advice.</small>
		</div>
	</footer>
	<nav class="jm-bottom-nav" aria-label="Mobile primary navigation">
		<?php foreach ( $bottom as $label => $item ) : ?>
			<a href="<?php echo esc_url( home_url( $item[0] ) ); ?>"><?php echo jade_myth_icon( $item[1] ); ?><span><?php echo esc_html( $label ); ?></span></a>
		<?php endforeach; ?>
	</nav>
	<?php
}, 99 );

add_filter( 'get_custom_logo', function () {
	return sprintf(
		'<a href="%1$s" class="custom-logo-link" rel="home" aria-label="Jade &amp; Myth"><img src="%2$s" class="custom-logo" alt="Jade &amp; Myth" width="64" height="64"></a>',
		esc_url( home_url( '/' ) ),
		esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' )
	);
} );
