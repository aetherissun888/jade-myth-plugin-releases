<?php
/**
 * Plugin Name: Jade & Myth Visual System
 * Description: Complete editorial visual system, navigation, homepage and mobile shell for Jade & Myth.
 * Version: 7.8.1
 * Author: Aetheris Sun LLC
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JADE_MYTH_VISUAL_VERSION', '7.8.1' );
define( 'JADE_MYTH_VISUAL_URL', plugin_dir_url( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_DIR', plugin_dir_path( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_PACKAGE', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/jade-myth-visual-system.zip?version=7.8.1' );
define( 'JADE_MYTH_VISUAL_ASSETS', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/' );

require_once JADE_MYTH_VISUAL_DIR . 'inc/class-jade-myth-almanac.php';
require_once JADE_MYTH_VISUAL_DIR . 'inc/class-jade-myth-newsletter.php';
require_once JADE_MYTH_VISUAL_DIR . 'inc/image-rights.php';
Jade_Myth_Almanac::bootstrap();

/**
 * Pre-launch utility routes are useful to visitors but are not search results.
 * Keeping the list in one place makes robots and sitemap behavior agree.
 */
function jade_myth_noindex_slugs() {
	return array( 'account', 'saved', 'shop', 'newsletter-confirmed', 'newsletter-unsubscribed' );
}

/**
 * Retired thin aliases resolve permanently to the stronger canonical record.
 */
function jade_myth_redirect_map() {
	return array(
		'fenghuang'     => '/fenghuang-explained/',
		'living-wisdom' => '/wisdom/chinese-philosophy/',
	);
}

function jade_myth_search_excluded_page_ids() {
	$slugs = array_merge( jade_myth_noindex_slugs(), array_keys( jade_myth_redirect_map() ) );
	$ids   = array();
	foreach ( $slugs as $slug ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $page ) {
			$ids[] = (int) $page->ID;
		}
	}
	return array_values( array_unique( $ids ) );
}

add_filter( 'wp_robots', function ( $robots ) {
	if ( is_page( jade_myth_noindex_slugs() ) ) {
		unset( $robots['index'], $robots['follow'] );
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
} );

add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	if ( 'page' !== $post_type ) {
		return $args;
	}
	$args['post__not_in'] = array_values( array_unique( array_merge(
		isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(),
		jade_myth_search_excluded_page_ids()
	) ) );
	return $args;
}, 10, 2 );

add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'jm_editorial_sitemap' ) ) {
		return;
	}

	$records = new WP_Query( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'posts_per_page' => 500,
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
		'meta_query'     => array(
			array(
				'key'     => 'jm_content_type',
				'compare' => 'EXISTS',
			),
		),
	) );

	status_header( 200 );
	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>';
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
	foreach ( $records->posts as $record_id ) {
		$content_type = trim( (string) get_post_meta( $record_id, 'jm_content_type', true ) );
		if ( '' === $content_type ) {
			continue;
		}
		echo '<url><loc>' . esc_url( get_permalink( $record_id ) ) . '</loc>';
		echo '<lastmod>' . esc_html( get_post_modified_time( DATE_W3C, true, $record_id ) ) . '</lastmod></url>';
	}
	echo '</urlset>';
	exit;
}, 0 );

add_action( 'template_redirect', function () {
	if ( ! is_singular( 'page' ) ) {
		return;
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	$map  = jade_myth_redirect_map();
	if ( isset( $map[ $slug ] ) ) {
		wp_safe_redirect( home_url( $map[ $slug ] ), 301, 'Jade & Myth Canonical Control' );
		exit;
	}
}, 1 );

/**
 * The block theme prints a generic page-title H1 above the custom museum
 * directories. CSS historically hid it, but leaving a second hidden H1 in the
 * document weakens heading semantics. Remove that block server-side only where
 * the visual system renders its own visible H1.
 */
add_filter( 'render_block_core/post-title', function ( $block_content ) {
	$page_id      = get_queried_object_id();
	$owns_heading = $page_id && '' !== (string) get_post_meta( $page_id, 'jm_content_type', true );
	$post_content = $page_id ? (string) get_post_field( 'post_content', $page_id ) : '';
	$has_body_h1  = (bool) preg_match( '/<h1\b/i', $post_content );

	if ( $owns_heading || $has_body_h1 || is_page( array( 'explore', 'creatures', 'mysteries', 'wisdom', 'daily-almanac', 'sanctuary', 'chinese-philosophy', 'newsletter' ) ) ) {
		return '';
	}
	return $block_content;
} );

/**
 * Editorial metadata is registered here so the GitHub publisher can update it
 * through the authenticated WordPress REST API without installing an opaque SEO
 * suite. Every field remains private to edit-context REST responses.
 */
add_action( 'init', function () {
	$fields = array(
		'jm_seo_title'        => 120,
		'jm_meta_description' => 180,
		'jm_content_type'     => 60,
		'jm_review_status'    => 60,
		'jm_author_name'      => 100,
		'jm_reviewed_by'      => 100,
		'jm_last_reviewed'    => 20,
		'jm_focus_query'      => 120,
		'jm_entity_id'        => 80,
		'jm_parent_pillar'    => 80,
		'jm_rights_status'    => 40,
		'jm_sources_count'    => 4,
		'jm_project_group'    => 40,
		'jm_subcollection'    => 100,
		'jm_feature_image_alt'            => 260,
		'jm_feature_image_caption'        => 500,
		'jm_feature_image_credit'         => 220,
		'jm_feature_image_credit_url'     => 500,
		'jm_feature_image_rights'         => 220,
		'jm_feature_image_evidence_class' => 8,
		'jm_feature_image_disclosure'     => 500,
		'jm_feature_image_license_url'    => 500,
		'jm_feature_image_creator_name'   => 220,
		'jm_feature_image_creator_type'   => 20,
		'jm_feature_image_acquire_license_url' => 500,
	);
	foreach ( $fields as $key => $max_length ) {
		register_post_meta( 'page', $key, array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) use ( $max_length ) {
				return mb_substr( sanitize_text_field( $value ), 0, $max_length );
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_pages' );
			},
		) );
	}
} );

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_singular( 'page' ) ) {
		$seo_title = get_post_meta( get_queried_object_id(), 'jm_seo_title', true );
		if ( $seo_title ) {
			return $seo_title . ' | Jade & Myth';
		}
	}
	return $title;
} );

/** Return the truthful primary schema type for a public page. */
function jade_myth_primary_schema_type( $post_id ) {
	if ( is_front_page() ) {
		return 'WebSite';
	}
	$path = '/' . trim( get_page_uri( $post_id ), '/' ) . '/';
	$collections = array(
		'/explore/', '/creatures/', '/mysteries/', '/sanctuary/', '/wisdom/',
		'/wisdom/chinese-philosophy/',
	);
	if ( in_array( $path, $collections, true ) ) {
		return 'CollectionPage';
	}
	if ( ! get_post_meta( $post_id, 'jm_content_type', true ) ) {
		return 'WebPage';
	}
	return 'Article';
}

/** Resolve a real public collection parent for structured breadcrumbs. */
function jade_myth_schema_parent( $post_id ) {
	$parent_id = wp_get_post_parent_id( $post_id );
	if ( $parent_id ) {
		return get_post( $parent_id );
	}
	$groups = array(
		'creatures'     => 'creatures',
		'mysteries'     => 'mysteries',
		'wisdom'        => 'wisdom',
		'sanctuary'     => 'sanctuary',
		'daily-almanac' => 'daily-almanac',
		'mythology'     => 'explore',
		'foundations'   => 'explore',
	);
	$group = get_post_meta( $post_id, 'jm_project_group', true );
	if ( isset( $groups[ $group ] ) ) {
		$parent = get_page_by_path( $groups[ $group ] );
		if ( $parent && (int) $parent->ID !== (int) $post_id ) {
			return $parent;
		}
	}
	return null;
}

add_action( 'wp_head', function () {
	if ( ! is_singular( 'page' ) ) {
		return;
	}
	$post_id     = get_queried_object_id();
	$description = get_post_meta( $post_id, 'jm_meta_description', true );
	if ( $description ) {
		printf( "\n<meta name=\"description\" content=\"%s\">\n", esc_attr( $description ) );
	}

	$content_type = get_post_meta( $post_id, 'jm_content_type', true );
	$author_name = get_post_meta( $post_id, 'jm_author_name', true );
	$reviewed    = get_post_meta( $post_id, 'jm_last_reviewed', true );
	$canonical   = get_permalink( $post_id );
	$primary_type = jade_myth_primary_schema_type( $post_id );
	$image_id    = get_post_thumbnail_id( $post_id );
	$image_data  = $image_id ? wp_get_attachment_image_src( $image_id, 'full' ) : false;
	$image_alt   = get_post_meta( $post_id, 'jm_feature_image_alt', true );
	$image_url   = $image_data ? $image_data[0] : '';
	if ( $image_url ) {
		printf( "<meta property=\"og:type\" content=\"%s\">\n", 'Article' === $primary_type ? 'article' : 'website' );
		printf( "<meta property=\"og:title\" content=\"%s\">\n", esc_attr( get_the_title( $post_id ) ) );
		printf( "<meta property=\"og:description\" content=\"%s\">\n", esc_attr( $description ) );
		printf( "<meta property=\"og:url\" content=\"%s\">\n", esc_url( $canonical ) );
		printf( "<meta property=\"og:image\" content=\"%s\">\n", esc_url( $image_url ) );
		printf( "<meta property=\"og:image:width\" content=\"%d\">\n", absint( $image_data[1] ) );
		printf( "<meta property=\"og:image:height\" content=\"%d\">\n", absint( $image_data[2] ) );
		printf( "<meta property=\"og:image:alt\" content=\"%s\">\n", esc_attr( $image_alt ) );
		printf( "<meta name=\"twitter:card\" content=\"summary_large_image\">\n" );
		printf( "<meta name=\"twitter:image\" content=\"%s\">\n", esc_url( $image_url ) );
	}
	$organization_id = home_url( '/' ) . '#organization';
	$website_id = home_url( '/' ) . '#website';
	$primary = array(
		'@type'       => $primary_type,
		'@id'         => $canonical . '#' . strtolower( $primary_type ),
		'name'        => 'WebSite' === $primary_type ? 'Jade & Myth' : get_the_title( $post_id ),
		'description' => $description,
		'url'         => $canonical,
		'inLanguage'  => 'en-US',
	);
	if ( 'Article' === $primary_type ) {
		$primary['headline'] = get_the_title( $post_id );
		$primary['mainEntityOfPage'] = $canonical;
		$primary['author'] = array(
			'@type' => 'Organization',
			'name'  => $author_name ? $author_name : 'Jade & Myth Editorial',
		);
		$primary['publisher'] = array( '@id' => $organization_id );
		$primary['dateModified'] = $reviewed ? $reviewed : get_the_modified_date( 'c', $post_id );
		$primary['datePublished'] = get_the_date( 'c', $post_id );
	} elseif ( 'WebSite' !== $primary_type ) {
		$primary['isPartOf'] = array( '@id' => $website_id );
	}
	$graph = array(
		$primary,
		array(
			'@type' => 'Organization',
			'@id'   => $organization_id,
			'name'  => 'Jade & Myth',
			'url'   => home_url( '/' ),
		),
	);
	if ( 'WebSite' !== $primary_type ) {
		$crumbs = array(
			array(
				'@type' => 'ListItem', 'position' => 1,
				'name' => 'Home', 'item' => home_url( '/' ),
			),
		);
		$parent = jade_myth_schema_parent( $post_id );
		if ( $parent ) {
			$crumbs[] = array(
				'@type' => 'ListItem', 'position' => 2,
				'name' => get_the_title( $parent ), 'item' => get_permalink( $parent ),
			);
		}
		$crumbs[] = array(
			'@type' => 'ListItem', 'position' => count( $crumbs ) + 1,
			'name' => get_the_title( $post_id ), 'item' => $canonical,
		);
		$graph[] = array(
			'@type' => 'BreadcrumbList', '@id' => $canonical . '#breadcrumbs',
			'itemListElement' => $crumbs,
		);
	}
	$schema = array(
		'@context'      => 'https://schema.org',
		'@graph'        => $graph,
	);
	if ( $image_url ) {
		$image_schema_id = $canonical . '#primary-image';
		$schema['@graph'][0]['image'] = array( '@id' => $image_schema_id );
		$image_node = array(
			'@type'      => 'ImageObject',
			'@id'        => $image_schema_id,
			'contentUrl' => $image_url,
			'url'        => $image_url,
			'width'      => absint( $image_data[1] ),
			'height'     => absint( $image_data[2] ),
			'caption'    => get_post_meta( $post_id, 'jm_feature_image_caption', true ),
			'creditText'       => get_post_meta( $post_id, 'jm_feature_image_credit', true ),
			'copyrightNotice'  => get_post_meta( $post_id, 'jm_feature_image_rights', true ),
			'license'          => get_post_meta( $post_id, 'jm_feature_image_license_url', true ),
		);
		$schema['@graph'][] = array_merge( $image_node, jade_myth_image_rights_metadata(
			get_post_meta( $post_id, 'jm_feature_image_credit', true ),
			get_post_meta( $post_id, 'jm_feature_image_credit_url', true ),
			get_post_meta( $post_id, 'jm_feature_image_evidence_class', true ),
			get_post_meta( $post_id, 'jm_feature_image_creator_name', true ),
			get_post_meta( $post_id, 'jm_feature_image_creator_type', true ),
			get_post_meta( $post_id, 'jm_feature_image_acquire_license_url', true )
		) );
	}
	printf(
		"<script type=\"application/ld+json\">%s</script>\n",
		wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}, 20 );

/* Dedicated editorial and image sitemaps make the approved public archive
 * discoverable without replacing WordPress core's complete page sitemap. */
add_action( 'init', function () {
	add_rewrite_rule( '^jade-myth-image-sitemap\.xml$', 'index.php?jm_image_sitemap=1', 'top' );
	add_rewrite_rule( '^jade-myth-editorial-sitemap\.xml$', 'index.php?jm_editorial_sitemap=1', 'top' );
	if ( get_option( 'jm_image_sitemap_version' ) !== JADE_MYTH_VISUAL_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'jm_image_sitemap_version', JADE_MYTH_VISUAL_VERSION, false );
	}
}, 20 );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'jm_image_sitemap';
	$vars[] = 'jm_editorial_sitemap';
	return $vars;
} );

add_filter( 'redirect_canonical', function ( $redirect, $requested ) {
	if ( get_query_var( 'jm_image_sitemap' ) || get_query_var( 'jm_editorial_sitemap' ) ) {
		return false;
	}
	return $redirect;
}, 10, 2 );

add_filter( 'robots_txt', function ( $output, $public ) {
	if ( $public ) {
		$output .= "\nSitemap: " . home_url( '/jade-myth-editorial-sitemap.xml' ) . "\n";
		$output .= "\nSitemap: " . home_url( '/jade-myth-image-sitemap.xml' ) . "\n";
	}
	return $output;
}, 10, 2 );

add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'jm_image_sitemap' ) ) {
		return;
	}

	$records = new WP_Query( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'posts_per_page' => 500,
		'orderby'        => 'modified',
		'order'          => 'DESC',
		'fields'         => 'ids',
	) );

	status_header( 200 );
	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>';
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
	foreach ( $records->posts as $record_id ) {
		$image_url = wp_get_attachment_image_url( get_post_thumbnail_id( $record_id ), 'full' );
		$content = get_post_field( 'post_content', $record_id );
		$inline_matches = array();
		$has_inline = preg_match_all( '/<figure[^>]*jm-inline-figure[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*>.*?<figcaption>.*?<p>(.*?)<\/p>.*?<\/figcaption>.*?<\/figure>/si', $content, $inline_matches, PREG_SET_ORDER );
		if ( ! $image_url && ! $has_inline ) {
			continue;
		}
		echo '<url><loc>' . esc_url( get_permalink( $record_id ) ) . '</loc>';
		if ( $image_url ) {
			echo '<image:image><image:loc>' . esc_url( $image_url ) . '</image:loc>';
			$caption = get_post_meta( $record_id, 'jm_feature_image_caption', true );
			if ( $caption ) {
				echo '<image:caption>' . esc_html( $caption ) . '</image:caption>';
			}
			echo '<image:title>' . esc_html( get_the_title( $record_id ) ) . '</image:title>';
			$license = get_post_meta( $record_id, 'jm_feature_image_license_url', true );
			if ( $license ) {
				echo '<image:license>' . esc_url( $license ) . '</image:license>';
			}
			echo '</image:image>';
		}
		if ( $has_inline ) {
			foreach ( $inline_matches as $match ) {
				echo '<image:image><image:loc>' . esc_url( html_entity_decode( $match[1] ) ) . '</image:loc>';
				echo '<image:caption>' . esc_html( wp_strip_all_tags( $match[2] ) ) . '</image:caption>';
				echo '<image:title>' . esc_html( get_the_title( $record_id ) ) . '</image:title></image:image>';
			}
		}
		echo '</url>';
	}
	echo '</urlset>';
	exit;
} );

add_action( 'rest_api_init', function () {
	Jade_Myth_Almanac::register_routes();
	register_rest_route( 'jade-myth/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			return array(
				'plugin'  => 'jade-myth-visual-system',
				'version' => JADE_MYTH_VISUAL_VERSION,
				'active'  => true,
			);
		},
	) );

	register_rest_route( 'jade-myth/v1', '/update', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$result   = $upgrader->run( array(
				'package'           => JADE_MYTH_VISUAL_PACKAGE,
				'destination'       => WP_PLUGIN_DIR,
				'clear_destination' => true,
				'clear_working'     => true,
				'hook_extra'        => array(
					'plugin' => plugin_basename( __FILE__ ),
					'type'   => 'plugin',
					'action' => 'update',
				),
			) );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
			if ( ! $result ) {
				return new WP_Error( 'jm_update_failed', 'The approved package could not be installed.', array( 'status' => 500 ) );
			}

			activate_plugin( plugin_basename( __FILE__ ) );
			return array(
				'success' => true,
				'version' => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );

	/**
	 * Clear the origin page cache after an approved visual-system deployment.
	 *
	 * This route is deliberately private: it requires the same update_plugins
	 * capability as the self-update route and is called only by the repository's
	 * authenticated deployment workflow.  Without it, LiteSpeed can continue to
	 * serve a fully rendered, pre-update HTML page after the plugin files change.
	 */
	register_rest_route( 'jade-myth/v1', '/purge-cache', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			/** LiteSpeed Cache listens for this documented WordPress action. */
			do_action( 'litespeed_purge_all' );

			return array(
				'success'         => true,
				'cache_purge'     => 'requested',
				'plugin_version'  => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'brand.css',
		array(),
		JADE_MYTH_VISUAL_VERSION
	);
	if ( is_page( array( 'wisdom', 'daily-almanac', 'sanctuary', 'chinese-philosophy' ) ) ) {
		wp_enqueue_style(
			'jade-myth-museum-collections',
			JADE_MYTH_VISUAL_URL . 'museum-collections.css',
			array( 'jade-myth-visual-system' ),
			JADE_MYTH_VISUAL_VERSION
		);
	}
	wp_enqueue_script(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'visual.js',
		array(),
		JADE_MYTH_VISUAL_VERSION,
		true
	);
	if ( is_page( 'newsletter' ) && Jade_Myth_Newsletter::ready() ) {
		wp_enqueue_script(
			'cloudflare-turnstile',
			'https://challenges.cloudflare.com/turnstile/v0/api.js',
			array(),
			null,
			array( 'strategy' => 'async', 'in_footer' => true )
		);
	}
} );

/**
 * Jade & Myth supplies its own site shell. Remove Hostinger's translated
 * template parts at render time so placeholder navigation and footer content
 * never reach the browser. This intentionally replaces the former client-side
 * observer and timer cleanup, which could repeatedly react to its own DOM work.
 */
add_filter( 'render_block_core/template-part', function ( $block_content, $block ) {
	if ( is_admin() ) {
		return $block_content;
	}

	$attributes = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$area       = isset( $attributes['area'] ) ? $attributes['area'] : '';
	$slug       = isset( $attributes['slug'] ) ? $attributes['slug'] : '';

	if ( in_array( $area, array( 'header', 'footer' ), true ) || in_array( $slug, array( 'header', 'footer' ), true ) ) {
		return '';
	}

	return $block_content;
}, 10, 2 );

function jade_myth_icon( $name ) {
	$icons = array(
		'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V21h13V10.5"/><path d="M9.5 21v-6h5v6"/>',
		'explore' => '<circle cx="12" cy="12" r="9"/><path d="m15.8 8.2-2.3 5.3-5.3 2.3 2.3-5.3 5.3-2.3Z"/>',
		'calendar'=> '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/><path d="M8 14h3m2 0h3m-8 3h3"/>',
		'saved'  => '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
		'account'=> '<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( $icons[ $name ] ?? '' ) . '</svg>';
}

function jade_myth_header() {
	$links = array(
		'Explore'       => '/explore/',
		'Creatures'     => '/creatures/',
		'Mysteries'     => '/mysteries/',
		'Wisdom'        => '/wisdom/',
		'Daily Almanac' => '/daily-almanac/',
		'Sanctuary'     => '/sanctuary/',
		'Shop'          => '/shop/',
	);
	ob_start();
	?>
	<header class="jm-header" data-jm-header>
		<div class="jm-header__inner">
			<a class="jm-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Jade &amp; Myth home">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="46" height="46" alt="">
				<span>Jade <i>&amp;</i> Myth</span>
			</a>
			<nav class="jm-desktop-nav" aria-label="Primary navigation">
				<?php foreach ( $links as $label => $path ) : ?>
					<a href="<?php echo esc_url( home_url( $path ) ); ?>"<?php echo 'Shop' === $label ? ' class="jm-shop-link" data-note="Coming later"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<a class="jm-account-link" href="<?php echo esc_url( home_url( '/account/' ) ); ?>">Account</a>
				<a class="jm-search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
			</nav>
			<div class="jm-mobile-actions">
				<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
				<button type="button" aria-label="Open menu" aria-expanded="false" data-jm-menu-toggle><?php echo jade_myth_icon( 'menu' ); ?></button>
			</div>
		</div>
		<nav class="jm-mobile-menu" aria-label="Mobile navigation" data-jm-menu>
			<?php foreach ( $links as $label => $path ) : ?>
				<a href="<?php echo esc_url( home_url( $path ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
	</header>
	<?php
	return ob_get_clean();
}

/**
 * Render a deliberately non-collecting newsletter control.
 *
 * The public site does not yet have a verified consent processor, double
 * opt-in, suppression list, or current collection notice. Do not accept an
 * address until those operational requirements are ready.
 */
function jade_myth_newsletter_hold( $id_prefix = 'jm-email', $master = false ) {
	unset( $id_prefix );
	return Jade_Myth_Newsletter::compact_control( $master ? 'master' : 'default' );
}

function jade_myth_homepage() {
	$hero = esc_url( JADE_MYTH_VISUAL_URL . 'hero-ding-landscape.png' );
	ob_start();
	?>
	<main class="jm-home">
		<div class="jm-master-home" aria-label="Jade &amp; Myth visual archive">
			<section class="jm-master-panel jm-master-panel--hero"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-hero.png' ); ?>" width="1672" height="941" alt="Enter the living archive of ancient China, with today’s Almanac.">
				<?php echo Jade_Myth_Almanac::card( 'desktop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<a class="jm-hotspot jm-hotspot--brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Jade &amp; Myth home</span></a>
				<a class="jm-hotspot jm-hotspot--explore" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore</span></a>
				<a class="jm-hotspot jm-hotspot--creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Creatures</span></a>
				<a class="jm-hotspot jm-hotspot--mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Mysteries</span></a>
				<a class="jm-hotspot jm-hotspot--wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Wisdom</span></a>
				<a class="jm-hotspot jm-hotspot--almanac" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Daily Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--sanctuary" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Sanctuary</span></a>
				<a class="jm-hotspot jm-hotspot--shop" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>"><span>Shop</span></a>
				<a class="jm-hotspot jm-hotspot--search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><span>Search</span></a>
				<a class="jm-hotspot jm-hotspot--hero-cta" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Open today’s Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--hero-card" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View today’s Almanac</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--map"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-map.png' ); ?>" width="1672" height="941" alt="Explore the map: a living atlas of stories, objects and places across China.">
				<a class="jm-hotspot jm-hotspot--map-cta" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Open the atlas</span></a>
				<a class="jm-hotspot jm-hotspot--map-canvas" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore the interactive map</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--sections"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-sections.png' ); ?>" width="1672" height="941" alt="Jade &amp; Myth paths, featured Sanxingdui dossier, feelings, member Almanac, field notes and newsletter.">
				<div class="jm-master-hotspots jm-master-hotspots--sections">
					<a class="jm-hotspot jm-hotspot--path-creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Explore creatures</span></a>
					<a class="jm-hotspot jm-hotspot--path-mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Explore lost civilizations</span></a>
					<a class="jm-hotspot jm-hotspot--path-wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Explore Daoist wisdom</span></a>
					<a class="jm-hotspot jm-hotspot--dossier" href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>"><span>Explore the Sanxingdui dossier</span></a>
					<a class="jm-hotspot jm-hotspot--feelings" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Choose how you feel</span></a>
					<a class="jm-hotspot jm-hotspot--member" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View your member Almanac</span></a>
					<a class="jm-hotspot jm-hotspot--field" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Read field notes</span></a>
				</div>
				<div class="jm-master-newsletter"><?php echo jade_myth_newsletter_hold( 'jm-master-email', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<nav class="jm-master-trust" aria-label="Editorial and legal links">
					<div class="jm-master-trust__core">
						<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>"><span>Editorial standards</span></a>
						<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>"><span>Sources &amp; methods</span></a>
						<a href="<?php echo esc_url( home_url( '/trust/' ) ); ?>"><span>Trust center</span></a>
					</div>
					<a class="jm-master-trust__contact" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><span>Contact</span></a>
				</nav>
			</div></section>
		</div>

		<div class="jm-mobile-home">
		<section class="jm-hero" style="--jm-hero-image:url('<?php echo $hero; ?>')">
			<div class="jm-hero__content">
				<h1>Enter the living archive of ancient China.</h1>
				<p>Stories, symbols, seasonal rhythms, and forgotten questions—carefully researched for curious modern lives.</p>
				<a class="jm-button jm-button--light" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Open today’s Almanac <span aria-hidden="true">→</span></a>
			</div>
			<?php echo Jade_Myth_Almanac::card( 'mobile' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section class="jm-wonder jm-shell">
			<div class="jm-section-intro">
				<span class="jm-section-label">Start with wonder</span>
				<h2>Three paths into China’s enduring imagination.</h2>
			</div>
			<div class="jm-path-rail">
				<a href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>01</span><h3>Creatures</h3><p>Mythical beings, animals, and the natural world.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>02</span><h3>Lost Civilizations</h3><p>Empires, kingdoms, and forgotten cities.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>03</span><h3>Daoist Wisdom</h3><p>Teachings, texts, and the living way of Dao.</p><i>Explore →</i></a>
			</div>
		</section>

		<section class="jm-dossier">
			<div class="jm-shell jm-dossier__grid">
				<div>
					<span class="jm-section-label jm-section-label--gold">Featured dossier</span>
					<h2>Sanxingdui: China’s Bronze Age enigma</h2>
					<p>How new discoveries continue to reshape the story of one of the ancient world’s most singular civilizations.</p>
					<a href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>">Explore the dossier →</a>
				</div>
				<dl>
					<div><dt>Approach</dt><dd>Evidence before speculation</dd></div>
					<div><dt>Sources</dt><dd>Museum and archaeological records</dd></div>
					<div><dt>Reading time</dt><dd>18 minutes</dd></div>
				</dl>
			</div>
		</section>

		<section class="jm-discovery jm-shell">
			<div class="jm-feelings">
				<span class="jm-section-label">Choose how you feel</span>
				<h2>Begin where you are.</h2>
				<nav aria-label="Explore by feeling">
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Lost <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Anxious <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Grieving <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Low <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Curious <span>→</span></a>
				</nav>
			</div>
			<div class="jm-member">
				<span class="jm-section-label">Member preview</span>
				<h2>Your personalized Almanac, made meaningful.</h2>
				<p>Daily cultural context, private collections, and thoughtful reminders shaped around your rhythm.</p>
				<strong>$9.90 <small>/ month</small></strong>
				<a class="jm-button" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Preview membership →</a>
			</div>
			<article class="jm-field-note">
				<span class="jm-section-label">Field notes</span>
				<h2>On the edges of the map</h2>
				<p>Real places, objects, sounds, and conversations—documented with permission and credited sources.</p>
				<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Read field notes →</a>
			</article>
		</section>

		<section class="jm-newsletter">
			<div class="jm-shell">
				<div><span class="jm-section-label jm-section-label--gold">Join the archive</span><h2>Stories, wisdom, and wonder—delivered.</h2><p>One carefully researched dispatch each week. No noise.</p></div>
				<?php echo jade_myth_newsletter_hold( 'jm-email' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</section>
		</div>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * Translate the stable editorial subcollection into a short reader-facing
 * shelf label. The raw slug remains the source of truth; this map only keeps
 * public directory rows readable as the library grows.
 */
function jade_myth_collection_label( $subcollection ) {
	$labels = array(
		'reading-methods'                                => 'Reading method',
		'creation-and-repair-narratives'                  => 'Creation narratives',
		'sky-and-directional-symbols'                     => 'Sky & direction',
		'solar-myths-and-archery'                         => 'Solar narratives',
		'moon-myths-and-later-festival-reception'         => 'Moon traditions',
		'fox-traditions-and-reception'                    => 'Fox traditions',
		'auspicious-beings-and-political-symbolism'       => 'Auspicious beings',
		'bronze-imagery-and-later-naming'                 => 'Bronze imagery',
		'lost-texts-and-spirit-catalogs'                  => 'Textual afterlives',
		'zhuangzi-and-transformation'                     => 'Zhuangzi & transformation',
		'birds-and-auspicious-beings'                     => 'Bird traditions',
		'dragon-traditions-and-flood-narratives'          => 'Dragon traditions',
		'dragon-traditions-and-translation'               => 'Translation & dragons',
		'archaeology-and-material-culture'                => 'Archaeology',
		'supernatural-literature-and-modern-media'        => 'Literature & reception',
		'texts-and-wisdom'                                => 'Texts & interpretation',
		'heart-mind-emotion-and-self-cultivation'         => 'Heart-mind & emotion',
		'terms-readers-commonly-mistranslate'             => 'Terms in translation',
		'texts-and-translation'                           => 'Texts & translation',
		'traditions-in-contact'                           => 'Traditions in contact',
		'ethics-government-and-order'                     => 'Ethics & government',
		'calendar-and-seasonal-life'                      => 'Calendar & seasonal time',
		'shan-hai-jing-textual-beings'                    => 'Shan Hai Jing text',
		'cosmogony-and-later-textual-traditions'          => 'Cosmogony & transmission',
		'imperial-mausolea-and-archaeology'               => 'Imperial archaeology',
		'desert-archaeology-and-historical-sources'       => 'Desert archaeology',
		'textual-reports-mechanisms-and-limits-of-evidence' => 'Texts & mechanisms',
	);

	if ( isset( $labels[ $subcollection ] ) ) {
		return $labels[ $subcollection ];
	}

	return $subcollection ? ucwords( str_replace( '-', ' ', $subcollection ) ) : 'Archive record';
}

/**
 * A public shelf is driven by explicit editorial metadata, never by a broad
 * WordPress category or a tag. This means an approved future record appears
 * in exactly one place after the publisher writes its assigned group, while a
 * draft, private page, or uncategorised legacy page cannot leak into a public
 * collection.
 */
function jade_myth_collection_records( $collection_key ) {
	$directory_page = get_page_by_path( $collection_key, OBJECT, 'page' );
	$query = new WP_Query( array(
		'post_type'              => 'page',
		'post_status'            => 'publish',
		// Collection shelves show their own approved records, not every nested
		// child in a long-form atlas. A child page remains reachable from its
		// named parent directory and its related-reading routes without turning
		// the Wisdom shelf into a 36-row flat list.
		'post_parent'            => 0,
		'posts_per_page'         => 60,
		'orderby'                => 'title',
		'order'                  => 'ASC',
		'no_found_rows'          => true,
		'ignore_sticky_posts'    => true,
		'post__not_in'           => $directory_page ? array( (int) $directory_page->ID ) : array(),
		'meta_query'             => array(
			array(
				'key'     => 'jm_project_group',
				'value'   => $collection_key,
				'compare' => '=',
			),
		),
	) );

	$records = array();
	foreach ( $query->posts as $record ) {
		$summary = get_post_meta( $record->ID, 'jm_meta_description', true );
		if ( ! $summary ) {
			$summary = wp_trim_words( wp_strip_all_tags( $record->post_content ), 22, '…' );
		}
		$records[] = array(
			'title'        => get_the_title( $record ),
			'subcollection' => jade_myth_collection_label( get_post_meta( $record->ID, 'jm_subcollection', true ) ),
			'subcollection_key' => get_post_meta( $record->ID, 'jm_subcollection', true ),
			'summary'      => $summary,
			'url'          => get_permalink( $record ),
		);
	}

	return $records;
}

/**
 * Turn the Creatures shelf into a stable museum finding aid. Editorial
 * subcollection metadata remains the source of truth, while the rooms below
 * give readers a smaller first decision than an undifferentiated A-Z list.
 * Unknown future subcollections are never hidden; they enter New accessions
 * until the editorial map assigns them a permanent room.
 */
/** Short finding-aid labels; forms are browsing aids, not ancient taxonomic ranks. */
function jade_myth_creature_label( $record ) {
	$slug = basename( rtrim( wp_parse_url( $record['url'], PHP_URL_PATH ), '/' ) );
	$labels = array(
		'shanhaijing-bifang' => array( 'Bifang · 毕方', 'Bird · Shan Hai Jing' ),
		'shanhaijing-jingwei' => array( 'Jingwei · 精卫', 'Bird · Shan Hai Jing' ),
		'shanhaijing-tiangou' => array( 'Tiangou · 天狗', 'Beast · Shan Hai Jing and later traditions' ),
		'nine-tailed-fox' => array( 'Nine-tailed fox · 九尾狐', 'Beast · Shan Hai Jing and later traditions' ),
		'yinglong' => array( 'Yinglong · 应龙', 'Dragon · Shan Hai Jing and later traditions' ),
		'zhu-yin' => array( 'Zhu Yin · 烛阴', 'Divine being · Shan Hai Jing' ),
		'chinese-dragons-explained' => array( 'Chinese dragons · 龙', 'Dragon traditions' ),
		'fenghuang-explained' => array( 'Fenghuang · 凤凰', 'Auspicious bird traditions' ),
		'qilin' => array( 'Qilin · 麒麟', 'Auspicious beast traditions' ),
		'bai-ze' => array( 'Bai Ze · 白泽', 'Spirit catalogue traditions' ),
		'kunpeng' => array( 'Kunpeng · 鲲鹏', 'Fish and bird transformation · Zhuangzi' ),
		'taotie' => array( 'Taotie · 饕餮', 'Bronze motif and later naming' ),
	);
	return isset( $labels[ $slug ] ) ? $labels[ $slug ] : array( $record['title'], $record['subcollection'] );
}

function jade_myth_creature_rooms( $records ) {
	$rooms = array(
		'shan-hai-jing' => array(
			'number' => '01',
			'label'  => '山海经 · Text and beings',
			'title'  => 'Shan Hai Jing',
			'copy'   => 'Birds, beasts, and divine beings with entries in the classic.',
			'keys'   => array( 'shan-hai-jing-textual-beings', 'fox-traditions-and-reception', 'dragon-traditions-and-flood-narratives' ),
			'records' => array(),
		),
		'dragons-auspicious' => array(
			'number' => '02',
			'label'  => '龙凤与瑞兽 · Cultural traditions',
			'title'  => 'Dragons & auspicious beings',
			'copy'   => 'Long, fenghuang, and qilin across Chinese texts and art.',
			'keys'   => array(
				'dragon-traditions-and-translation',
				'birds-and-auspicious-beings',
				'auspicious-beings-and-political-symbolism',
			),
			'records' => array(),
		),
		'transformations-texts' => array(
			'number' => '03',
			'label'  => '志怪与寓言 · Other sources',
			'title'  => 'Spirit lore & transformations',
			'copy'   => 'Bai Ze traditions and the Kunpeng of the Zhuangzi.',
			'keys'   => array(
				'lost-texts-and-spirit-catalogs',
				'zhuangzi-and-transformation',
			),
			'records' => array(),
		),
		'objects-motifs' => array(
			'number' => '04',
			'label'  => '青铜纹饰 · Objects',
			'title'  => 'Bronze faces & motifs',
			'copy'   => 'Taotie imagery and the history of its later name.',
			'keys'   => array( 'bronze-imagery-and-later-naming' ),
			'records' => array(),
		),
	);

	foreach ( $records as $record ) {
		$placed = false;
		foreach ( $rooms as &$room ) {
			if ( in_array( $record['subcollection_key'], $room['keys'], true ) ) {
				$room['records'][] = $record;
				$placed = true;
				break;
			}
		}
		unset( $room );
		if ( ! $placed ) {
			if ( ! isset( $rooms['new-accessions'] ) ) {
				$rooms['new-accessions'] = array(
					'number' => '05',
					'label'  => 'Editorial intake',
					'title'  => 'New accessions',
					'copy'   => 'Recently released records awaiting a permanent place in the collection map.',
					'keys'   => array(),
					'records' => array(),
				);
			}
			$rooms['new-accessions']['records'][] = $record;
		}
	}

	return array_filter( $rooms, static function ( $room ) {
		return ! empty( $room['records'] );
	} );
}

/**
 * The owner-approved Creatures composition is the production visual contract.
 * Its navigation remains usable through semantic hotspots, while the source
 * PNG is delivered without cropping, recolouring, filtering, or recomposition.
 */
add_filter( 'body_class', function ( $classes ) {
	if ( is_page( 'creatures' ) ) {
		$classes[] = 'jm-creatures-master-page';
	}
	return $classes;
} );

add_action( 'wp_head', function () {
	if ( is_page( 'creatures' ) ) {
		printf(
			'<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n",
			esc_url( JADE_MYTH_VISUAL_URL . 'creatures-approved-master.png' )
		);
	}
}, 1 );

function jade_myth_creatures_directory( $directory, $records, $authority_content ) {
	$rooms             = jade_myth_creature_rooms( $records );
	$record_count      = count( $records );
	$room_count        = count( $rooms );
	$authority_content = preg_replace( '/<h1\b[^>]*>.*?<\/h1>/is', '', $authority_content, 1 );

	ob_start();
	?>
	<main class="jm-creatures-index alignfull" data-jm-creature-index>
		<section class="jm-creatures-master" aria-labelledby="jm-creatures-master-title">
			<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'creatures-approved-master.png' ); ?>" width="1536" height="1024" alt="" aria-hidden="true" loading="eager" fetchpriority="high" decoding="async">
			<div class="jm-creatures-master__accessible">
				<h1 id="jm-creatures-master-title"><?php echo esc_html( $directory['title'] ); ?></h1>
				<p><?php echo esc_html( $directory['dek'] ); ?></p>
				<p><?php echo esc_html( $record_count ); ?> reviewed records in <?php echo esc_html( $room_count ); ?> collection rooms. Source before retelling.</p>
			</div>
			<nav class="jm-creatures-master__hotspots" aria-label="Creatures collection navigation">
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Jade &amp; Myth home</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--explore" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>" aria-current="page"><span>Creatures</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Mysteries</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Wisdom</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--almanac" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Daily Almanac</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--sanctuary" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Sanctuary</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--shop" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>"><span>Shop</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--account" href="<?php echo esc_url( home_url( '/account/' ) ); ?>"><span>Account</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><span>Search Jade &amp; Myth</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--browse" href="#creature-collection-desk"><span>Browse the collection</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--filter" href="#jm-creature-filter"><span>Search creatures, sources, and materials</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--room-one" href="#creature-room-objects-motifs"><span>Excavated material</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--room-two" href="#creature-room-shan-hai-jing"><span>Historical sources</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--room-three" href="#creature-room-transformations-texts"><span>Open interpretations</span></a>
				<a class="jm-creatures-master__hotspot jm-creatures-master__hotspot--room-four" href="#creature-room-dragons-auspicious"><span>Living traditions</span></a>
			</nav>
		</section>

		<section class="jm-creatures-index__desk" id="creature-collection-desk" aria-labelledby="creature-index-title">
			<header class="jm-creatures-index__continuation">
				<p class="jm-collection-directory__label">Reviewed collection</p>
				<h2 id="creature-index-title">Browse every creature record.</h2>
				<p>Start with the Shan Hai Jing, or explore the other traditions below. These reading groups are not an ancient classification: a being can appear in several traditions.</p>
			</header>
			<aside class="jm-creatures-gateway" aria-label="Shan Hai Jing guide">
				<p class="jm-collection-directory__label">Start here · 山海经</p>
				<h2><a href="<?php echo esc_url( home_url( '/shan-hai-jing/' ) ); ?>">The Classic of Mountains and Seas <span aria-hidden="true">↗</span></a></h2>
				<p>Read the eighteen-chapter guide, then follow the birds, beasts, and divine beings into their own records.</p>
			</aside>

			<div class="jm-creatures-index__tools" role="search">
				<label for="jm-creature-filter">Find a creature or source tradition</label>
				<div><input id="jm-creature-filter" type="search" inputmode="search" autocomplete="off" placeholder="Try dragon, fox, bronze, or Shan Hai Jing" data-jm-creature-filter><button type="button" data-jm-creature-clear hidden>Clear</button></div>
				<p role="status" aria-live="polite" data-jm-creature-status>Showing <?php echo esc_html( $record_count ); ?> reviewed records in <?php echo esc_html( $room_count ); ?> rooms.</p>
			</div>

			<div class="jm-creatures-index__rooms">
				<?php foreach ( $rooms as $room_key => $room ) : ?>
					<details class="jm-creatures-room" id="creature-room-<?php echo esc_attr( $room_key ); ?>" data-jm-creature-room open>
						<summary>
							<span><?php echo esc_html( $room['number'] ); ?></span>
							<div><p><?php echo esc_html( $room['label'] ); ?></p><h3><?php echo esc_html( $room['title'] ); ?></h3><small><?php echo esc_html( count( $room['records'] ) ); ?> records · <?php echo esc_html( $room['copy'] ); ?></small></div>
							<b aria-hidden="true"></b>
						</summary>
						<ul>
							<?php foreach ( $room['records'] as $record ) :
								$display = jade_myth_creature_label( $record );
								$search_text = strtolower( $record['title'] . ' ' . $record['subcollection'] . ' ' . $record['summary'] . ' ' . implode( ' ', $display ) );
								?>
								<li data-jm-creature-record data-search="<?php echo esc_attr( $search_text ); ?>">
									<a href="<?php echo esc_url( $record['url'] ); ?>"><small><?php echo esc_html( $display[1] ); ?></small><strong><?php echo esc_html( $display[0] ); ?></strong><b aria-hidden="true">↗</b></a>
								</li>
							<?php endforeach; ?>
						</ul>
					</details>
				<?php endforeach; ?>
			</div>
			<div class="jm-creatures-index__empty" data-jm-creature-empty hidden><h3>No matching record is open yet.</h3><p>Try a broader name or browse the four collection rooms above.</p></div>
		</section>

		<section class="jm-creatures-index__method" aria-labelledby="creature-method-title">
			<div><p class="jm-collection-directory__label">Reading method</p><h2 id="creature-method-title">The index is short. The evidence stays deep.</h2><p>The complete authority guide remains part of this canonical page. Open it when you want the taxonomy, translation cautions, image-rights method, and full source list.</p></div>
			<details>
				<summary><span>Open the complete source-led guide</span><small>Definitions, source worlds, translation, images, groupings, and bibliography</small></summary>
				<div class="jm-collection-directory__guide-inner"><?php echo wp_kses_post( $authority_content ); ?></div>
			</details>
		</section>

		<section class="jm-collection-directory__boundary jm-creatures-index__boundary" aria-label="Editorial boundary">
			<div class="jm-collection-directory__boundary-mark" aria-hidden="true"></div>
			<div><p class="jm-collection-directory__label">Editorial boundary</p><h2>Context is part of the collection.</h2></div>
			<p><?php echo esc_html( $directory['boundary'] ); ?></p>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

function jade_myth_collection_record_rows( $records, $empty_title, $empty_copy, $empty_link = '' ) {
	ob_start();
	if ( $records ) :
		?>
		<div class="jm-collection-directory__records">
			<?php foreach ( $records as $index => $record ) : ?>
				<a href="<?php echo esc_url( $record['url'] ); ?>">
					<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
					<strong><?php echo esc_html( $record['title'] ); ?></strong>
					<em><small><?php echo esc_html( $record['subcollection'] ); ?></small><?php echo esc_html( $record['summary'] ); ?></em>
					<i aria-hidden="true">↗</i>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	else :
		?>
		<div class="jm-collection-directory__empty">
			<p class="jm-collection-directory__label">Collection status</p>
			<h3><?php echo esc_html( $empty_title ); ?></h3>
			<p><?php echo esc_html( $empty_copy ); ?></p>
			<?php if ( $empty_link ) : ?>
				<a href="<?php echo esc_url( home_url( $empty_link ) ); ?>">Browse the archive <b aria-hidden="true">→</b></a>
			<?php endif; ?>
		</div>
		<?php
	endif;
	return ob_get_clean();
}

/**
 * The public collection directory is a deliberate finding aid, not a dump of
 * tags. Its mythology shelf is populated only by explicitly assigned, public
 * records, so a newly released guide becomes discoverable without creating a
 * competing blog index.
 */
function jade_myth_explore_directory() {
	$collections = array(
		array(
			'number' => '01',
			'eyebrow' => 'Foundational text',
			'title'   => 'Shan Hai Jing Atlas',
			'copy'    => 'A source-guided entrance to the Classic of Mountains and Seas: geography, beings, transmission, and later imagination.',
			'link'    => '/shan-hai-jing/',
			'cta'     => 'Enter the atlas',
		),
		array(
			'number' => '02',
			'eyebrow' => 'Mythic beings',
			'title'   => 'Creatures & entities',
			'copy'    => 'Named beings, symbols, and creature records, each separated from later folklore and modern adaptation.',
			'link'    => '/creatures/',
			'cta'     => 'Browse creatures',
		),
		array(
			'number' => '03',
			'eyebrow' => 'Material evidence',
			'title'   => 'Archaeology & lost worlds',
			'copy'    => 'Objects, excavation records, museums, and the historical questions that remain open.',
			'link'    => '/mysteries/',
			'cta'     => 'Explore mysteries',
		),
		array(
			'number' => '04',
			'eyebrow' => 'Texts & ideas',
			'title'   => 'Wisdom reading room',
			'copy'    => 'Classical texts, translation, commentary, and modern reception, handled without self-help claims.',
			'link'    => '/wisdom/',
			'cta'     => 'Read wisdom',
		),
	);
	$records = jade_myth_collection_records( 'mythology' );
	ob_start();
	?>
	<main class="jm-explore alignfull">
		<section class="jm-explore__masthead">
			<div class="jm-explore__masthead-inner">
				<p class="jm-explore__eyebrow">Jade &amp; Myth / Collection directory</p>
				<h1>Explore the Archive</h1>
				<p>Follow cultural records through text, landscape, objects, and later reception. Every collection identifies the boundary between source, interpretation, folklore, and modern imagination.</p>
				<div class="jm-explore__route" aria-label="Archive route">
					<span>Begin with a source</span><i aria-hidden="true"></i><span>Follow a collection</span><i aria-hidden="true"></i><span>Read a reviewed record</span>
				</div>
				<a class="jm-explore__map-link" href="<?php echo esc_url( home_url( '/chinese-culture-guide/' ) ); ?>">New to the archive? Start with the map of Chinese culture <b aria-hidden="true">→</b></a>
			</div>
		</section>

		<section class="jm-explore__catalogue" aria-labelledby="jm-collections-title">
			<div class="jm-explore__section-head">
				<div><p class="jm-explore__label">Catalogue</p><h2 id="jm-collections-title">Collections to begin with</h2></div>
				<p>Choose a collection, then move from its overview to source-led guides and reviewed entities. The structure stays stable as the archive expands.</p>
			</div>
			<div class="jm-explore__collection-grid">
				<?php foreach ( $collections as $collection ) : ?>
					<a class="jm-explore__collection" href="<?php echo esc_url( home_url( $collection['link'] ) ); ?>">
						<span class="jm-explore__number"><?php echo esc_html( $collection['number'] ); ?></span>
						<p class="jm-explore__label"><?php echo esc_html( $collection['eyebrow'] ); ?></p>
						<h3><?php echo esc_html( $collection['title'] ); ?></h3>
						<p><?php echo esc_html( $collection['copy'] ); ?></p>
						<span class="jm-explore__link"><?php echo esc_html( $collection['cta'] ); ?> <b aria-hidden="true">→</b></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-explore__shelves" id="jm-public-mythology" aria-labelledby="jm-shelves-title">
			<div class="jm-explore__shelves-intro">
				<p class="jm-explore__label">Open shelves</p>
				<h2 id="jm-shelves-title">Mythology & cosmos</h2>
				<p>These publicly available records are assigned to mythology and cosmos. Each separates a received text, later tradition, and contemporary interpretation.</p>
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Read our editorial policy <b aria-hidden="true">→</b></a>
			</div>
			<?php echo jade_myth_collection_record_rows( $records, 'Mythology records are being prepared.', 'A source-led mythology record appears here only after it has cleared the current editorial release gate.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section class="jm-explore__method" aria-labelledby="jm-method-title">
			<div class="jm-explore__method-mark" aria-hidden="true">山<br>海</div>
			<div><p class="jm-explore__label">How to use this archive</p><h2 id="jm-method-title">One directory, clear paths.</h2></div>
			<ol>
				<li><b>01</b><span>Start with a collection overview.</span></li>
				<li><b>02</b><span>Follow links into entity and dossier pages.</span></li>
				<li><b>03</b><span>Check sources, review status, and related records.</span></li>
			</ol>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * Primary collection directories share a readable museum-catalogue grammar,
 * while their public shelves are driven by the one-to-one collection metadata
 * above. There are no filler cross-links between Wisdom, Daily Almanac, and
 * Sanctuary: each route owns its own subject and published records.
 */
function jade_myth_collection_facsimile( $collection_key ) {
	$panels = array(
		'wisdom' => array(
			'file' => 'approved-wisdom-collection-panel.png',
			'width' => 568,
		),
		'daily-almanac' => array(
			'file' => 'approved-daily-almanac-collection-panel.png',
			'width' => 582,
		),
		'sanctuary' => array(
			'file' => 'approved-sanctuary-collection-panel.png',
			'width' => 522,
		),
	);

	if ( ! isset( $panels[ $collection_key ] ) ) {
		return '';
	}

	$panel = $panels[ $collection_key ];
	ob_start();
	?>
	<figure class="jm-museum-hero__facsimile jm-museum-hero__facsimile--<?php echo esc_attr( $collection_key ); ?>" aria-hidden="true">
		<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . $panel['file'] . '?ver=' . JADE_MYTH_VISUAL_VERSION ); ?>" alt="" width="<?php echo esc_attr( $panel['width'] ); ?>" height="941" fetchpriority="high" decoding="async">
	</figure>
	<?php
	return ob_get_clean();
}

function jade_myth_reference_wisdom_directory( $records ) {
	ob_start();
	?>
	<main class="jm-museum-directory jm-museum-directory--wisdom alignfull">
		<header class="jm-museum-hero">
			<div class="jm-museum-hero__inner">
				<div class="jm-museum-hero__copy">
					<p class="jm-museum-hero__eyebrow">Reading room</p>
					<h1>Wisdom</h1>
					<p class="jm-museum-hero__dek">Primary texts and methods of reading from the Chinese intellectual tradition, presented with sources, context, and room for interpretation.</p>
					<dl class="jm-museum-hero__ledger">
						<div><dt>Collection</dt><dd>Texts and interpretation</dd></div>
						<div><dt>Standard</dt><dd>Source-led public records</dd></div>
					</dl>
					<a class="jm-wisdom-feature" href="<?php echo esc_url( home_url( '/wisdom/chinese-philosophy/' ) ); ?>">
						<span class="jm-wisdom-feature__index" aria-hidden="true">JM / W.01</span>
						<span class="jm-wisdom-feature__copy">
							<small>Featured reading room</small>
							<strong>Chinese thought for everyday questions</strong>
							<em>Read the ideas in their texts, histories, and translations.</em>
						</span>
						<b aria-hidden="true">&#8594;</b>
					</a>
				</div>
				<?php echo jade_myth_collection_facsimile( 'wisdom' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</header>
		<section class="jm-museum-catalogue" aria-labelledby="jm-wisdom-catalogue-title">
			<header class="jm-museum-catalogue__intro">
				<h2 id="jm-wisdom-catalogue-title">Texts held in context</h2>
				<p>Only published guides assigned to Wisdom appear here. Calendar records remain in Daily Almanac, and cultural-practice essays remain in Sanctuary.</p>
			</header>
			<div class="jm-museum-records" aria-label="Wisdom reading list">
				<?php if ( $records ) : ?>
					<?php foreach ( $records as $record ) : ?>
						<a class="jm-museum-record" href="<?php echo esc_url( $record['url'] ); ?>">
							<span class="jm-museum-record__group"><?php echo esc_html( $record['subcollection'] ); ?></span>
							<strong><?php echo esc_html( $record['title'] ); ?></strong>
							<small><?php echo esc_html( str_replace( array( '—', '–' ), '-', wp_trim_words( $record['summary'], 24, '…' ) ) ); ?></small>
							<span class="jm-museum-record__link">Read the record <b aria-hidden="true">→</b></span>
						</a>
					<?php endforeach; ?>
				<?php else : ?>
					<div class="jm-museum-empty"><h2>Reviewed texts are in preparation.</h2><p>A guide appears here after source, translation, and claim review.</p></div>
				<?php endif; ?>
			</div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * A nested Wisdom finding aid. Child records stay out of the top-level shelf,
 * but remain discoverable through one stable, indexable collection route.
 */
function jade_myth_chinese_philosophy_directory() {
	$parent_id = get_queried_object_id();
	$children  = get_pages( array(
		'child_of'    => $parent_id,
		'parent'      => $parent_id,
		'post_status' => 'publish',
		'sort_column' => 'menu_order,post_title',
		'sort_order'  => 'ASC',
	) );

	ob_start();
	?>
	<main class="jm-thought-directory alignfull">
		<header class="jm-thought-directory__hero">
			<div class="jm-thought-directory__hero-inner">
				<p class="jm-thought-directory__eyebrow">Wisdom / Reading room W.01</p>
				<h1>Chinese thought for<br>everyday questions</h1>
				<p class="jm-thought-directory__dek">A source-led route through terms, texts, and arguments that still invite close reading. These records offer cultural context, not therapy, prediction, or a single formula for living.</p>
				<div class="jm-thought-directory__seal" aria-hidden="true"><span>&#24515;</span><i></i></div>
			</div>
		</header>
		<section class="jm-thought-directory__catalogue" aria-labelledby="jm-thought-catalogue-title">
			<header class="jm-thought-directory__intro">
				<div><p>Collection register</p><h2 id="jm-thought-catalogue-title">Begin with a question, then follow the source.</h2></div>
				<dl>
					<div><dt>Scope</dt><dd>Early texts, later readings, translation</dd></div>
					<div><dt>Method</dt><dd>Named sources and explicit uncertainty</dd></div>
					<div><dt>Boundary</dt><dd>Cultural education, never personal diagnosis</dd></div>
				</dl>
			</header>
			<div class="jm-thought-directory__records" role="list">
				<?php foreach ( $children as $index => $child ) :
					$summary = get_post_meta( $child->ID, 'jm_meta_description', true );
					$group   = jade_myth_collection_label( get_post_meta( $child->ID, 'jm_subcollection', true ) );
					?>
					<a class="jm-thought-record" href="<?php echo esc_url( get_permalink( $child ) ); ?>" role="listitem">
						<span class="jm-thought-record__number"><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
						<span class="jm-thought-record__text"><small><?php echo esc_html( $group ); ?></small><strong><?php echo esc_html( get_the_title( $child ) ); ?></strong><em><?php echo esc_html( $summary ); ?></em></span>
						<b aria-hidden="true">&#8599;</b>
					</a>
				<?php endforeach; ?>
			</div>
			<p class="jm-thought-directory__note">Each record names its textual or institutional sources and separates historical argument from modern application. New entries appear here only after editorial release.</p>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

function jade_myth_reference_sanctuary_directory( $records ) {
	ob_start();
	?>
	<main class="jm-museum-directory jm-museum-directory--sanctuary alignfull">
		<header class="jm-museum-hero">
			<div class="jm-museum-hero__inner">
				<div class="jm-museum-hero__copy">
					<p class="jm-museum-hero__eyebrow">Cultural sanctuary</p>
					<h1>Sanctuary</h1>
					<p class="jm-museum-hero__dek">Source-led essays on places, practices, and artworks, held within their historical and cultural contexts.</p>
					<dl class="jm-museum-hero__ledger">
						<div><dt>Collection</dt><dd>Place and cultural practice</dd></div>
						<div><dt>Boundary</dt><dd>Context, not clinical advice</dd></div>
					</dl>
				</div>
				<?php echo jade_myth_collection_facsimile( 'sanctuary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</header>
		<section class="jm-museum-sanctuary" aria-labelledby="jm-sanctuary-catalogue-title">
			<header class="jm-museum-catalogue__intro">
				<h2 id="jm-sanctuary-catalogue-title">A collection with a clear boundary</h2>
				<p>Sanctuary does not borrow Wisdom or Almanac records to appear complete. Every essay must earn its place through the same source and cultural-context review.</p>
			</header>
			<div class="jm-museum-sanctuary__collection">
				<?php if ( $records ) : ?>
					<div class="jm-museum-records" aria-label="Sanctuary reading list">
						<?php foreach ( $records as $record ) : ?>
							<a class="jm-museum-record" href="<?php echo esc_url( $record['url'] ); ?>">
								<span class="jm-museum-record__group"><?php echo esc_html( $record['subcollection'] ); ?></span>
								<strong><?php echo esc_html( $record['title'] ); ?></strong>
								<small><?php echo esc_html( str_replace( array( '—', '–' ), '-', wp_trim_words( $record['summary'], 24, '…' ) ) ); ?></small>
								<span class="jm-museum-record__link">Read the record <b aria-hidden="true">→</b></span>
							</a>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<div class="jm-museum-empty jm-museum-empty--sanctuary">
						<h2>Collection-specific essays are in preparation.</h2>
						<p>The first record will appear after source, rights, and cultural-context review.</p>
						<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Browse the archive <b aria-hidden="true">→</b></a>
					</div>
				<?php endif; ?>
				</div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

function jade_myth_collection_directory( $collection_key, $authority_content = '' ) {
	$directories = array(
		'creatures' => array(
			'eyebrow'        => 'Jade & Myth / Creature archive',
			'title'           => 'Creatures & entities',
			'dek'             => 'A source-led catalogue of named beings, celestial figures, and later creature traditions. Textual record, folklore, and modern reception remain visibly distinct.',
			'route'           => array( 'Read the source', 'Locate the figure', 'Compare later reception' ),
			'catalogue_label' => 'Collection scope',
			'catalogue_title' => 'Records of beings, not proof of species',
			'catalogue_copy'  => 'Each entry identifies the source that names a figure, distinguishes later retelling, and keeps biological or historical conclusions within the evidence.',
			'scope'           => array( 'Received texts', 'Visual and material traditions', 'Later literary reception' ),
			'record_title'    => 'Reviewed creature records',
			'empty_title'     => 'Creature records are being prepared.',
			'empty_copy'      => 'Only source-led entities with an approved release decision appear on this shelf.',
			'boundary'        => 'An ancient description is evidence for a narrative tradition. It is not evidence that a being existed as a biological species.',
		),
		'mysteries' => array(
			'eyebrow'        => 'Jade & Myth / Evidence archive',
			'title'           => 'Mysteries & material worlds',
			'dek'             => 'Objects, excavations, lost places, and questions that are still open. This collection starts with what museums, sites, and published research can establish.',
			'route'           => array( 'Inspect the object', 'Trace the evidence', 'Keep the question open' ),
			'catalogue_label' => 'Collection scope',
			'catalogue_title' => 'What the material record can establish',
			'catalogue_copy'  => 'This collection brings objects, sites, research questions, and later literary reception into view without treating an unanswered question as a solved mystery.',
			'scope'           => array( 'Excavated material', 'Historical sources', 'Open interpretations' ),
			'record_title'    => 'Reviewed mysteries & material records',
			'empty_title'     => 'Material-culture records are being prepared.',
			'empty_copy'      => 'A dossier appears here only after its evidence and uncertainty boundary are reviewed.',
			'boundary'        => 'Where evidence stops, the page says so. Possibility, folklore, and a verified archaeological conclusion are never presented as the same thing.',
		),
		'wisdom' => array(
			'eyebrow'        => 'Jade & Myth / Reading room',
			'title'           => 'Wisdom & texts',
			'dek'             => 'A reading room for Chinese texts, translation, commentary, and later reception. It offers context for ideas, not prescriptions, predictions, or personal transformation claims.',
			'route'           => array( 'Read a text', 'Trace its reception', 'Keep your own judgment' ),
			'catalogue_label' => 'Collection scope',
			'catalogue_title' => 'Texts held in context',
			'catalogue_copy'  => 'The Wisdom room contains texts and their histories of reading. Calendar records belong in the Daily Almanac; quiet-practice essays belong in Sanctuary.',
			'scope'           => array( 'Received texts', 'Translation & commentary', 'Modern reception' ),
			'record_title'    => 'Reviewed texts & ideas',
			'empty_title'     => 'Text guides are being prepared.',
			'empty_copy'      => 'A text guide appears here only after its sources, translations, and modern-use claims have passed review.',
			'boundary'        => 'These materials support reading and reflection. They do not diagnose, treat, predict, protect, or promise a change in a reader’s life.',
		),
		'sanctuary' => array(
			'eyebrow'        => 'Jade & Myth / Quiet shelf',
			'title'           => 'Sanctuary',
			'dek'             => 'A quiet cultural shelf for source-led essays on places, practices, and careful attention. It is an archive collection, never a substitute for clinical, emergency, legal, or financial support.',
			'route'           => array( 'Observe a practice', 'Read its context', 'Return with care' ),
			'catalogue_label' => 'Collection scope',
			'catalogue_title' => 'Place, practice & cultural attention',
			'catalogue_copy'  => 'Sanctuary will hold its own source-led essays on living traditions and contemplative cultural practice. It does not borrow Wisdom or Almanac records to look complete.',
			'scope'           => array( 'Living traditions', 'Place & etiquette', 'Quiet cultural reading' ),
			'record_title'    => 'Sanctuary records',
			'empty_title'     => 'Collection-specific essays are in preparation.',
			'empty_copy'      => 'The first Sanctuary record will appear after the same source, rights, and cultural-context review required everywhere in the archive.',
			'empty_link'      => '/explore/',
			'boundary'        => 'If a reader is distressed or needs health, legal, financial, or emergency support, this archive is not the right service. Its role is cultural context and quiet reading.',
		),
	);

	if ( ! isset( $directories[ $collection_key ] ) ) {
		return '';
	}

	$directory = $directories[ $collection_key ];
	$slug      = sanitize_html_class( $collection_key );
	$records   = jade_myth_collection_records( $collection_key );
	if ( 'creatures' === $collection_key ) {
		return jade_myth_creatures_directory( $directory, $records, $authority_content );
	}
	if ( 'wisdom' === $collection_key ) {
		return jade_myth_reference_wisdom_directory( $records );
	}
	if ( 'sanctuary' === $collection_key ) {
		return jade_myth_reference_sanctuary_directory( $records );
	}
	ob_start();
	?>
	<main class="jm-collection-directory jm-collection-directory--<?php echo esc_attr( $slug ); ?> alignfull">
		<header class="jm-collection-directory__masthead">
			<div class="jm-collection-directory__masthead-inner">
				<div class="jm-collection-directory__masthead-copy">
					<p class="jm-collection-directory__eyebrow"><?php echo esc_html( $directory['eyebrow'] ); ?></p>
					<h1><?php echo esc_html( $directory['title'] ); ?></h1>
					<p><?php echo esc_html( $directory['dek'] ); ?></p>
				</div>
				<div class="jm-collection-directory__specimen" aria-hidden="true"><span></span><i></i><b></b></div>
			</div>
			<div class="jm-collection-directory__route" aria-label="Collection reading route">
				<?php foreach ( $directory['route'] as $index => $step ) : ?>
					<span><b><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></b><?php echo esc_html( $step ); ?></span>
				<?php endforeach; ?>
			</div>
		</header>

		<section class="jm-collection-directory__catalogue" aria-labelledby="jm-<?php echo esc_attr( $slug ); ?>-catalogue-title">
			<div class="jm-collection-directory__section-head">
				<div><p class="jm-collection-directory__label"><?php echo esc_html( $directory['catalogue_label'] ); ?></p><h2 id="jm-<?php echo esc_attr( $slug ); ?>-catalogue-title"><?php echo esc_html( $directory['catalogue_title'] ); ?></h2></div>
				<p><?php echo esc_html( $directory['catalogue_copy'] ); ?></p>
			</div>
			<div class="jm-collection-directory__scope" role="list">
				<?php foreach ( $directory['scope'] as $scope ) : ?>
					<p role="listitem"><?php echo esc_html( $scope ); ?></p>
				<?php endforeach; ?>
			</div>
		</section>

		<?php if ( $authority_content ) : ?>
			<?php $authority_content = preg_replace( '/<h1\b[^>]*>.*?<\/h1>/is', '', $authority_content, 1 ); ?>
			<section class="jm-collection-directory__guide" aria-label="<?php echo esc_attr( $directory['title'] ); ?> guide">
				<div class="jm-collection-directory__guide-inner">
					<p class="jm-collection-directory__label">Authority guide</p>
					<?php echo wp_kses_post( $authority_content ); ?>
				</div>
			</section>
		<?php endif; ?>

		<section class="jm-collection-directory__shelf" aria-labelledby="jm-<?php echo esc_attr( $slug ); ?>-shelf-title">
			<div class="jm-collection-directory__shelf-intro">
				<p class="jm-collection-directory__label">Open shelf</p>
				<h2 id="jm-<?php echo esc_attr( $slug ); ?>-shelf-title"><?php echo esc_html( $directory['record_title'] ); ?></h2>
				<p>Only public, explicitly assigned records appear on this shelf. A draft cannot be listed here, and a guide cannot belong to more than one primary collection.</p>
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Read the editorial standard <b aria-hidden="true">→</b></a>
			</div>
			<?php echo jade_myth_collection_record_rows( $records, $directory['empty_title'], $directory['empty_copy'], isset( $directory['empty_link'] ) ? $directory['empty_link'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section class="jm-collection-directory__boundary" aria-label="Editorial boundary">
			<div class="jm-collection-directory__boundary-mark" aria-hidden="true"></div>
			<div><p class="jm-collection-directory__label">Editorial boundary</p><h2>Context is part of the collection.</h2></div>
			<p><?php echo esc_html( $directory['boundary'] ); ?></p>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * The Almanac has one stable, indexable home. It renders server-side first,
 * then visual.js refreshes it for the visitor's IANA time zone.
 */
function jade_myth_daily_almanac_page() {
	$records  = jade_myth_collection_records( 'daily-almanac' );
	$data     = Jade_Myth_Almanac::for_timezone();
	$record   = isset( $data['traditional_record'] ) && is_array( $data['traditional_record'] ) ? $data['traditional_record'] : array();
	$lunar    = isset( $data['lunar'] ) && is_array( $data['lunar'] ) ? $data['lunar'] : array();
	$term     = isset( $data['solar_term'] ) && is_array( $data['solar_term'] ) ? $data['solar_term'] : array();
	$date     = new DateTimeImmutable( ( isset( $data['civil_date'] ) ? $data['civil_date'] : gmdate( 'Y-m-d' ) ) . ' 12:00:00', new DateTimeZone( 'UTC' ) );
	$terms    = static function( $items ) {
		if ( ! is_array( $items ) || ! $items ) {
			return 'Not listed';
		}
		$labels = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$label = trim( ( isset( $item['zh'] ) ? $item['zh'] : '' ) . ( ! empty( $item['en'] ) ? ' / ' . $item['en'] : '' ) );
			if ( $label ) {
				$labels[] = $label;
			}
		}
		return $labels ? implode( '; ', $labels ) : 'Not listed';
	};
	ob_start();
	?>
	<main class="jm-museum-directory jm-museum-directory--almanac alignfull" data-jm-reference-almanac>
		<header class="jm-museum-hero">
			<div class="jm-museum-hero__inner">
				<div class="jm-museum-hero__copy">
					<p class="jm-museum-hero__eyebrow">Living calendar</p>
					<h1>Daily Almanac</h1>
					<p class="jm-museum-hero__dek">A free, local-date cultural calendar with lunar, solar-term, and transparent method records.</p>
					<dl class="jm-museum-hero__ledger">
						<div><dt>Access</dt><dd>Free daily record</dd></div>
						<div><dt>Method</dt><dd>Named and versioned</dd></div>
					</dl>
				</div>
				<?php echo jade_myth_collection_facsimile( 'daily-almanac' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</header>
		<section class="jm-museum-almanac" aria-labelledby="jm-almanac-record-title">
			<header class="jm-museum-catalogue__intro">
				<h2 id="jm-almanac-record-title">Today’s cultural calendar</h2>
				<p>The record follows the visitor’s local date. Traditional labels are shown as historical calendar terms, not instructions or predictions.</p>
			</header>
			<div class="jm-museum-almanac__record" aria-label="Today’s Almanac record">
			<div class="jm-museum-almanac__date">
				<span data-jm-reference-year><?php echo esc_html( $date->format( 'Y' ) ); ?></span>
				<b data-jm-reference-month><?php echo esc_html( strtoupper( $date->format( 'F' ) ) ); ?></b>
				<time datetime="<?php echo esc_attr( $data['civil_date'] ); ?>" data-jm-reference-day><?php echo esc_html( $date->format( 'j' ) ); ?></time>
				<strong data-jm-reference-weekday><?php echo esc_html( strtoupper( $date->format( 'l' ) ) ); ?></strong>
				<small data-jm-reference-lunar-date><?php echo esc_html( isset( $lunar['display'] ) ? $lunar['display'] : 'Lunar calendar' ); ?></small>
			</div>
			<dl class="jm-museum-almanac__facts">
				<div><dt>Lunar</dt><dd data-jm-reference-lunar><?php echo esc_html( isset( $lunar['display'] ) ? $lunar['display'] : 'Lunar calendar' ); ?></dd></div>
				<div><dt>Solar term</dt><dd data-jm-reference-term><?php echo esc_html( isset( $term['name'] ) ? $term['name'] . ( ! empty( $term['chinese'] ) ? ' ' . $term['chinese'] : '' ) : 'Not listed' ); ?></dd></div>
				<div><dt>Appropriate</dt><dd data-jm-reference-yi><?php echo esc_html( $terms( isset( $record['suitable'] ) ? $record['suitable'] : array() ) ); ?></dd></div>
				<div><dt>Avoided</dt><dd data-jm-reference-ji><?php echo esc_html( $terms( isset( $record['discouraged'] ) ? $record['discouraged'] : array() ) ); ?></dd></div>
				<div><dt>Method source</dt><dd data-jm-reference-method><?php echo esc_html( isset( $record['edition'] ) ? $record['edition'] : 'Versioned cultural calendar record' ); ?></dd></div>
			</dl>
			</div>
		</section>
		<section class="jm-museum-catalogue jm-museum-catalogue--almanac" aria-labelledby="jm-almanac-library-title">
			<header class="jm-museum-catalogue__intro">
				<h2 id="jm-almanac-library-title">Almanac and seasonal time</h2>
				<p>Guides to the calendar, solar terms, and the history of their use.</p>
			</header>
			<div class="jm-museum-records">
				<?php if ( $records ) : ?>
					<?php foreach ( $records as $archive_record ) : ?>
						<a class="jm-museum-record" href="<?php echo esc_url( $archive_record['url'] ); ?>">
							<span class="jm-museum-record__group"><?php echo esc_html( $archive_record['subcollection'] ); ?></span>
							<strong><?php echo esc_html( $archive_record['title'] ); ?></strong>
							<small><?php echo esc_html( str_replace( array( '—', '–' ), '-', wp_trim_words( $archive_record['summary'], 24, '…' ) ) ); ?></small>
							<span class="jm-museum-record__link">Read the record <b aria-hidden="true">→</b></span>
						</a>
					<?php endforeach; ?>
				<?php else : ?>
					<div class="jm-museum-empty"><h2>Reviewed guides are in preparation.</h2><p>The live daily record remains available without an account.</p></div>
				<?php endif; ?>
			</div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

function jade_myth_primary_figure( $post_id ) {
	$image_id = get_post_thumbnail_id( $post_id );
	if ( ! $image_id ) {
		return '';
	}

	$alt        = get_post_meta( $post_id, 'jm_feature_image_alt', true );
	$caption    = get_post_meta( $post_id, 'jm_feature_image_caption', true );
	$credit     = get_post_meta( $post_id, 'jm_feature_image_credit', true );
	$credit_url = get_post_meta( $post_id, 'jm_feature_image_credit_url', true );
	$rights     = get_post_meta( $post_id, 'jm_feature_image_rights', true );
	$class      = get_post_meta( $post_id, 'jm_feature_image_evidence_class', true );
	$disclosure = get_post_meta( $post_id, 'jm_feature_image_disclosure', true );
	$labels     = array(
		'E1' => 'Documentary object',
		'E2' => 'Explanatory diagram',
		'E3' => 'Editorial interpretation',
	);

	$image = wp_get_attachment_image(
		$image_id,
		'large',
		false,
		array(
			'class'         => 'jm-editorial-figure__image',
			'alt'           => $alt,
			'loading'       => 'eager',
			'fetchpriority' => 'high',
			'decoding'      => 'async',
			'sizes'         => '(max-width: 767px) calc(100vw - 32px), (max-width: 1180px) calc(100vw - 96px), 860px',
		)
	);
	if ( ! $image ) {
		return '';
	}

	ob_start();
	?>
	<figure class="jm-editorial-figure jm-editorial-figure--<?php echo esc_attr( strtolower( $class ? $class : 'record' ) ); ?>">
		<div class="jm-editorial-figure__visual"><?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
		<figcaption>
			<span class="jm-editorial-figure__class"><?php echo esc_html( isset( $labels[ $class ] ) ? $labels[ $class ] : 'Editorial image' ); ?></span>
			<?php if ( $caption ) : ?><p><?php echo esc_html( $caption ); ?></p><?php endif; ?>
			<?php if ( $credit || $rights ) : ?>
				<small>
					<?php if ( $credit_url && $credit ) : ?><a href="<?php echo esc_url( $credit_url ); ?>" rel="external noopener"><?php echo esc_html( $credit ); ?></a><?php else : ?><?php echo esc_html( $credit ); ?><?php endif; ?>
					<?php if ( $credit && $rights ) : ?><span aria-hidden="true"> · </span><?php endif; ?><?php echo esc_html( $rights ); ?>
				</small>
			<?php endif; ?>
			<?php if ( $disclosure ) : ?><small class="jm-editorial-figure__disclosure"><?php echo esc_html( $disclosure ); ?></small><?php endif; ?>
		</figcaption>
	</figure>
	<?php
	return ob_get_clean();
}

add_filter( 'the_content', function ( $content ) {
	if ( is_front_page() && in_the_loop() && is_main_query() ) {
		return jade_myth_homepage();
	}
	if ( is_page( 'explore' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_explore_directory();
	}
	if ( is_page( array( 'creatures', 'mysteries', 'wisdom', 'sanctuary' ) ) && in_the_loop() && is_main_query() ) {
		$collection_key = get_post_field( 'post_name', get_the_ID() );
		return jade_myth_collection_directory( $collection_key, 'creatures' === $collection_key ? $content : '' );
	}
	if ( is_page( 'daily-almanac' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_daily_almanac_page();
	}
	if ( is_page( 'chinese-philosophy' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_chinese_philosophy_directory();
	}
	if ( is_page( 'newsletter' ) && in_the_loop() && is_main_query() ) {
		return Jade_Myth_Newsletter::page();
	}
	if ( ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	/*
	 * A reading-room layout belongs to every released archive record, not a
	 * short whitelist of editorial labels. The old whitelist left reviewed
	 * Mysteries and Wisdom records in the theme's generic page template.
	 * The controlled publisher requires a stable project group and
	 * subcollection, so those fields are the durable visual release gate.
	 */
	$content_type  = get_post_meta( get_the_ID(), 'jm_content_type', true );
	$project_group = get_post_meta( get_the_ID(), 'jm_project_group', true );
	$subcollection = get_post_meta( get_the_ID(), 'jm_subcollection', true );
	if ( ! $project_group || ! $subcollection ) {
		return $content;
	}

	$title          = get_the_title();
	$review_status  = get_post_meta( get_the_ID(), 'jm_review_status', true );
	$reviewed_by    = get_post_meta( get_the_ID(), 'jm_reviewed_by', true );
	$last_reviewed  = get_post_meta( get_the_ID(), 'jm_last_reviewed', true );
	$source_count   = absint( get_post_meta( get_the_ID(), 'jm_sources_count', true ) );
	$source_count   = $source_count ? $source_count : 1;
	$reading_minutes = max( 3, (int) ceil( str_word_count( wp_strip_all_tags( $content ) ) / 220 ) );
	$primary_figure  = jade_myth_primary_figure( get_the_ID() );
	$content         = preg_replace( '/<h1[^>]*>.*?<\\/h1>/is', '', $content, 1 );

	preg_match_all( '/<h2[^>]*>(.*?)<\\/h2>/is', $content, $matches );
	$toc = array();
	foreach ( $matches[1] as $index => $heading ) {
		$label = trim( wp_strip_all_tags( $heading ) );
		$id    = 'reading-' . ( $index + 1 );
		$content = preg_replace( '/<h2([^>]*)>' . preg_quote( $heading, '/' ) . '<\\/h2>/is', '<h2$1 id="' . esc_attr( $id ) . '">' . $heading . '</h2>', $content, 1 );
		$toc[] = array( 'id' => $id, 'label' => $label );
	}

	ob_start();
	?>
	<article class="jm-reading alignfull" data-content-type="<?php echo esc_attr( $content_type ); ?>" data-project-group="<?php echo esc_attr( $project_group ); ?>">
		<header class="jm-reading__masthead">
			<div class="jm-reading__masthead-inner">
				<p class="jm-reading__kicker">Jade &amp; Myth / Research Archive</p>
				<h1><?php echo esc_html( $title ); ?></h1>
				<div class="jm-reading__ledger" aria-label="Article record">
					<span><b>Record</b><?php echo esc_html( ucwords( str_replace( '_', ' ', $content_type ) ) ); ?></span>
					<span><b>Reading</b><?php echo esc_html( $reading_minutes ); ?> min</span>
					<span><b>Sources</b><?php echo esc_html( $source_count ); ?> referenced</span>
					<span><b>Review</b><?php echo esc_html( $review_status ? str_replace( '_', ' ', $review_status ) : 'Editorial review' ); ?></span>
				</div>
			</div>
		</header>
		<div class="jm-reading__frame">
			<aside class="jm-reading__index" aria-label="On this page">
				<p>Contents</p>
				<ol>
					<?php foreach ( $toc as $item ) : ?>
						<li><a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ol>
			</aside>
			<div class="jm-reading__body">
				<div class="jm-reading__provenance"><span>Interpret with care</span><p>Primary text, later interpretation, and modern retelling are kept distinct throughout this archive.</p></div>
				<?php echo $primary_figure; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<div class="jm-reading__content"><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<aside class="jm-reading__record" aria-label="Editorial record">
				<p>Editorial record</p>
				<dl>
					<div><dt>Reviewed by</dt><dd><?php echo esc_html( $reviewed_by ? $reviewed_by : 'Jade & Myth Editorial' ); ?></dd></div>
					<div><dt>Last reviewed</dt><dd><?php echo esc_html( $last_reviewed ? $last_reviewed : get_the_modified_date( 'F j, Y' ) ); ?></dd></div>
					<div><dt>Use</dt><dd>Cultural education and research.</dd></div>
				</dl>
			</aside>
		</div>
	</article>
	<?php
	return ob_get_clean();
}, 99 );

add_action( 'wp_body_open', function () {
	echo jade_myth_header();
}, 5 );

add_action( 'wp_footer', function () {
	$bottom = array(
		'Home'     => array( '/', 'home' ),
		'Explore'  => array( '/explore/', 'explore' ),
		'Almanac'  => array( '/daily-almanac/', 'calendar' ),
		'Saved'    => array( '/saved/', 'saved' ),
		'Account'  => array( '/account/', 'account' ),
	);
	?>
	<footer class="jm-footer">
		<div class="jm-shell jm-footer__inner">
			<div class="jm-footer__brand"><img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="42" height="42" alt=""><div><b>Jade &amp; Myth</b><span>Ancient myths. Living rituals.</span></div></div>
			<nav aria-label="Trust links">
				<div class="jm-footer__trust-core">
					<a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a>
					<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Editorial standards</a>
					<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Sources &amp; methods</a>
					<a href="<?php echo esc_url( home_url( '/trust/' ) ); ?>">Trust center</a>
				</div>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a>
			</nav>
			<small>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Aetheris Sun LLC. Cultural education, not medical or supernatural advice.</small>
		</div>
	</footer>
	<nav class="jm-bottom-nav" aria-label="Mobile primary navigation">
		<?php foreach ( $bottom as $label => $item ) : ?>
			<a href="<?php echo esc_url( home_url( $item[0] ) ); ?>"><?php echo jade_myth_icon( $item[1] ); ?><span><?php echo esc_html( $label ); ?></span></a>
		<?php endforeach; ?>
	</nav>
	<?php
}, 99 );

add_filter( 'get_custom_logo', function () {
	return sprintf(
		'<a href="%1$s" class="custom-logo-link" rel="home" aria-label="Jade &amp; Myth"><img src="%2$s" class="custom-logo" alt="Jade &amp; Myth" width="64" height="64"></a>',
		esc_url( home_url( '/' ) ),
		esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' )
	);
} );
