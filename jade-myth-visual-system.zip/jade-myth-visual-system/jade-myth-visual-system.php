<?php
/**
 * Plugin Name: Jade & Myth Visual System
 * Description: Complete editorial visual system, navigation, homepage and mobile shell for Jade & Myth.
 * Version: 5.2.2
 * Author: Aetheris Sun LLC
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JADE_MYTH_VISUAL_VERSION', '5.2.2' );
define( 'JADE_MYTH_VISUAL_URL', plugin_dir_url( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_DIR', plugin_dir_path( __FILE__ ) );
define( 'JADE_MYTH_VISUAL_PACKAGE', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/jade-myth-visual-system.zip?version=5.2.2' );
define( 'JADE_MYTH_VISUAL_ASSETS', 'https://raw.githubusercontent.com/aetherissun888/jade-myth-plugin-releases/main/' );

require_once JADE_MYTH_VISUAL_DIR . 'inc/class-jade-myth-almanac.php';
Jade_Myth_Almanac::bootstrap();

/**
 * Editorial metadata is registered here so the GitHub publisher can update it
 * through the authenticated WordPress REST API without installing an opaque SEO
 * suite. Every field remains private to edit-context REST responses.
 */
add_action( 'init', function () {
	$fields = array(
		'jm_seo_title'        => 120,
		'jm_meta_description' => 180,
		'jm_content_type'     => 60,
		'jm_review_status'    => 60,
		'jm_author_name'      => 100,
		'jm_reviewed_by'      => 100,
		'jm_last_reviewed'    => 20,
		'jm_focus_query'      => 120,
		'jm_entity_id'        => 80,
		'jm_parent_pillar'    => 80,
		'jm_rights_status'    => 40,
		'jm_sources_count'    => 4,
	);
	foreach ( $fields as $key => $max_length ) {
		register_post_meta( 'page', $key, array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) use ( $max_length ) {
				return mb_substr( sanitize_text_field( $value ), 0, $max_length );
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_pages' );
			},
		) );
	}
} );

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_singular( 'page' ) ) {
		$seo_title = get_post_meta( get_queried_object_id(), 'jm_seo_title', true );
		if ( $seo_title ) {
			return $seo_title . ' | Jade & Myth';
		}
	}
	return $title;
} );

add_action( 'wp_head', function () {
	if ( ! is_singular( 'page' ) || is_front_page() ) {
		return;
	}
	$post_id     = get_queried_object_id();
	$description = get_post_meta( $post_id, 'jm_meta_description', true );
	if ( $description ) {
		printf( "\n<meta name=\"description\" content=\"%s\">\n", esc_attr( $description ) );
	}

	$content_type = get_post_meta( $post_id, 'jm_content_type', true );
	if ( ! $content_type ) {
		return;
	}
	$author_name = get_post_meta( $post_id, 'jm_author_name', true );
	$reviewed    = get_post_meta( $post_id, 'jm_last_reviewed', true );
	$canonical   = get_permalink( $post_id );
	$schema      = array(
		'@context'      => 'https://schema.org',
		'@graph'        => array(
			array(
				'@type'            => 'Article',
				'@id'              => $canonical . '#article',
				'headline'         => get_the_title( $post_id ),
				'description'      => $description,
				'url'              => $canonical,
				'mainEntityOfPage' => $canonical,
				'inLanguage'       => 'en-US',
				'author'           => array(
					'@type' => 'Organization',
					'name'  => $author_name ? $author_name : 'Jade & Myth Editorial',
				),
				'publisher'        => array(
					'@type' => 'Organization',
					'name'  => 'Jade & Myth',
					'url'   => home_url( '/' ),
				),
				'dateModified'     => $reviewed ? $reviewed : get_the_modified_date( 'c', $post_id ),
			),
			array(
				'@type'           => 'BreadcrumbList',
				'@id'             => $canonical . '#breadcrumbs',
				'itemListElement' => array(
					array(
						'@type'    => 'ListItem',
						'position' => 1,
						'name'     => 'Home',
						'item'     => home_url( '/' ),
					),
					array(
						'@type'    => 'ListItem',
						'position' => 2,
						'name'     => get_the_title( $post_id ),
						'item'     => $canonical,
					),
				),
			),
		),
	);
	printf(
		"<script type=\"application/ld+json\">%s</script>\n",
		wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}, 20 );

add_action( 'rest_api_init', function () {
	Jade_Myth_Almanac::register_routes();
	register_rest_route( 'jade-myth/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			return array(
				'plugin'  => 'jade-myth-visual-system',
				'version' => JADE_MYTH_VISUAL_VERSION,
				'active'  => true,
			);
		},
	) );

	register_rest_route( 'jade-myth/v1', '/update', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$result   = $upgrader->run( array(
				'package'           => JADE_MYTH_VISUAL_PACKAGE,
				'destination'       => WP_PLUGIN_DIR,
				'clear_destination' => true,
				'clear_working'     => true,
				'hook_extra'        => array(
					'plugin' => plugin_basename( __FILE__ ),
					'type'   => 'plugin',
					'action' => 'update',
				),
			) );

			if ( is_wp_error( $result ) ) {
				return $result;
			}
			if ( ! $result ) {
				return new WP_Error( 'jm_update_failed', 'The approved package could not be installed.', array( 'status' => 500 ) );
			}

			activate_plugin( plugin_basename( __FILE__ ) );
			return array(
				'success' => true,
				'version' => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );

	/**
	 * Clear the origin page cache after an approved visual-system deployment.
	 *
	 * This route is deliberately private: it requires the same update_plugins
	 * capability as the self-update route and is called only by the repository's
	 * authenticated deployment workflow.  Without it, LiteSpeed can continue to
	 * serve a fully rendered, pre-update HTML page after the plugin files change.
	 */
	register_rest_route( 'jade-myth/v1', '/purge-cache', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'update_plugins' );
		},
		'callback'            => function () {
			/** LiteSpeed Cache listens for this documented WordPress action. */
			do_action( 'litespeed_purge_all' );

			return array(
				'success'         => true,
				'cache_purge'     => 'requested',
				'plugin_version'  => JADE_MYTH_VISUAL_VERSION,
			);
		},
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'brand.css',
		array(),
		JADE_MYTH_VISUAL_VERSION
	);
	wp_enqueue_script(
		'jade-myth-visual-system',
		JADE_MYTH_VISUAL_URL . 'visual.js',
		array(),
		JADE_MYTH_VISUAL_VERSION,
		true
	);
} );

function jade_myth_icon( $name ) {
	$icons = array(
		'home'    => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V21h13V10.5"/><path d="M9.5 21v-6h5v6"/>',
		'explore' => '<circle cx="12" cy="12" r="9"/><path d="m15.8 8.2-2.3 5.3-5.3 2.3 2.3-5.3 5.3-2.3Z"/>',
		'calendar'=> '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/><path d="M8 14h3m2 0h3m-8 3h3"/>',
		'saved'  => '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
		'account'=> '<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( $icons[ $name ] ?? '' ) . '</svg>';
}

function jade_myth_header() {
	$links = array(
		'Explore'       => '/explore/',
		'Creatures'     => '/creatures/',
		'Mysteries'     => '/mysteries/',
		'Wisdom'        => '/wisdom/',
		'Daily Almanac' => '/daily-almanac/',
		'Sanctuary'     => '/sanctuary/',
		'Shop'          => '/shop/',
	);
	ob_start();
	?>
	<header class="jm-header" data-jm-header>
		<div class="jm-header__inner">
			<a class="jm-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Jade &amp; Myth home">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="46" height="46" alt="">
				<span>Jade <i>&amp;</i> Myth</span>
			</a>
			<nav class="jm-desktop-nav" aria-label="Primary navigation">
				<?php foreach ( $links as $label => $path ) : ?>
					<a href="<?php echo esc_url( home_url( $path ) ); ?>"<?php echo 'Shop' === $label ? ' class="jm-shop-link" data-note="Coming later"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<a class="jm-search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
			</nav>
			<div class="jm-mobile-actions">
				<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="Search"><?php echo jade_myth_icon( 'search' ); ?></a>
				<button type="button" aria-label="Open menu" aria-expanded="false" data-jm-menu-toggle><?php echo jade_myth_icon( 'menu' ); ?></button>
			</div>
		</div>
		<nav class="jm-mobile-menu" aria-label="Mobile navigation" data-jm-menu>
			<?php foreach ( $links as $label => $path ) : ?>
				<a href="<?php echo esc_url( home_url( $path ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
	</header>
	<?php
	return ob_get_clean();
}

function jade_myth_homepage() {
	$hero = esc_url( JADE_MYTH_VISUAL_URL . 'hero-ding-landscape.png' );
	ob_start();
	?>
	<main class="jm-home">
		<div class="jm-master-home" aria-label="Jade &amp; Myth visual archive">
			<section class="jm-master-panel jm-master-panel--hero"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-hero.png' ); ?>" width="1672" height="941" alt="Enter the living archive of ancient China, with today’s Almanac.">
				<?php echo Jade_Myth_Almanac::card( 'desktop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<a class="jm-hotspot jm-hotspot--brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Jade &amp; Myth home</span></a>
				<a class="jm-hotspot jm-hotspot--explore" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore</span></a>
				<a class="jm-hotspot jm-hotspot--creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Creatures</span></a>
				<a class="jm-hotspot jm-hotspot--mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Mysteries</span></a>
				<a class="jm-hotspot jm-hotspot--wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Wisdom</span></a>
				<a class="jm-hotspot jm-hotspot--almanac" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Daily Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--sanctuary" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Sanctuary</span></a>
				<a class="jm-hotspot jm-hotspot--shop" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>"><span>Shop</span></a>
				<a class="jm-hotspot jm-hotspot--search" href="<?php echo esc_url( home_url( '/?s=' ) ); ?>"><span>Search</span></a>
				<a class="jm-hotspot jm-hotspot--hero-cta" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>Open today’s Almanac</span></a>
				<a class="jm-hotspot jm-hotspot--hero-card" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View today’s Almanac</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--map"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-map.png' ); ?>" width="1672" height="941" alt="Explore the map: a living atlas of stories, objects and places across China.">
				<a class="jm-hotspot jm-hotspot--map-cta" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Open the atlas</span></a>
				<a class="jm-hotspot jm-hotspot--map-canvas" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Explore the interactive map</span></a>
			</div></section>

			<section class="jm-master-panel jm-master-panel--sections"><div class="jm-master-stage">
				<img src="<?php echo esc_url( JADE_MYTH_VISUAL_ASSETS . 'home-master-sections.png' ); ?>" width="1672" height="941" alt="Jade &amp; Myth paths, featured Sanxingdui dossier, feelings, member Almanac, field notes and newsletter.">
				<div class="jm-master-hotspots jm-master-hotspots--sections">
					<a class="jm-hotspot jm-hotspot--path-creatures" href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>Explore creatures</span></a>
					<a class="jm-hotspot jm-hotspot--path-mysteries" href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>Explore lost civilizations</span></a>
					<a class="jm-hotspot jm-hotspot--path-wisdom" href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>Explore Daoist wisdom</span></a>
					<a class="jm-hotspot jm-hotspot--dossier" href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>"><span>Explore the Sanxingdui dossier</span></a>
					<a class="jm-hotspot jm-hotspot--feelings" href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>"><span>Choose how you feel</span></a>
					<a class="jm-hotspot jm-hotspot--member" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>"><span>View your member Almanac</span></a>
					<a class="jm-hotspot jm-hotspot--field" href="<?php echo esc_url( home_url( '/explore/' ) ); ?>"><span>Read field notes</span></a>
				</div>
				<form class="jm-master-newsletter" action="#" method="post">
					<label for="jm-master-email">Email address</label>
					<input id="jm-master-email" type="email" autocomplete="email" required>
					<button type="submit">Subscribe</button>
				</form>
				<nav class="jm-master-trust" aria-label="Editorial and legal links">
					<a class="jm-master-trust__editorial" href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>"><span>Editorial Policy</span></a>
					<a class="jm-master-trust__sources" href="<?php echo esc_url( home_url( '/sources/' ) ); ?>"><span>Sources</span></a>
					<a class="jm-master-trust__advisors" href="<?php echo esc_url( home_url( '/cultural-advisors/' ) ); ?>"><span>Cultural Advisors</span></a>
					<a class="jm-master-trust__ai" href="<?php echo esc_url( home_url( '/ai-disclosure/' ) ); ?>"><span>AI Disclosure</span></a>
					<a class="jm-master-trust__privacy" href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><span>Privacy</span></a>
					<a class="jm-master-trust__refunds" href="<?php echo esc_url( home_url( '/refund-policy/' ) ); ?>"><span>Refunds</span></a>
					<a class="jm-master-trust__affiliate" href="<?php echo esc_url( home_url( '/affiliate-disclosure/' ) ); ?>"><span>Affiliate Disclosure</span></a>
					<a class="jm-master-trust__contact" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><span>Contact</span></a>
				</nav>
			</div></section>
		</div>

		<div class="jm-mobile-home">
		<section class="jm-hero" style="--jm-hero-image:url('<?php echo $hero; ?>')">
			<div class="jm-hero__content">
				<h1>Enter the living archive of ancient China.</h1>
				<p>Stories, symbols, seasonal rhythms, and forgotten questions—carefully researched for curious modern lives.</p>
				<a class="jm-button jm-button--light" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Open today’s Almanac <span aria-hidden="true">→</span></a>
			</div>
			<?php echo Jade_Myth_Almanac::card( 'mobile' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section class="jm-wonder jm-shell">
			<div class="jm-section-intro">
				<span class="jm-section-label">Start with wonder</span>
				<h2>Three paths into China’s enduring imagination.</h2>
			</div>
			<div class="jm-path-rail">
				<a href="<?php echo esc_url( home_url( '/creatures/' ) ); ?>"><span>01</span><h3>Creatures</h3><p>Mythical beings, animals, and the natural world.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/mysteries/' ) ); ?>"><span>02</span><h3>Lost Civilizations</h3><p>Empires, kingdoms, and forgotten cities.</p><i>Explore →</i></a>
				<a href="<?php echo esc_url( home_url( '/wisdom/' ) ); ?>"><span>03</span><h3>Daoist Wisdom</h3><p>Teachings, texts, and the living way of Dao.</p><i>Explore →</i></a>
			</div>
		</section>

		<section class="jm-dossier">
			<div class="jm-shell jm-dossier__grid">
				<div>
					<span class="jm-section-label jm-section-label--gold">Featured dossier</span>
					<h2>Sanxingdui: China’s Bronze Age enigma</h2>
					<p>How new discoveries continue to reshape the story of one of the ancient world’s most singular civilizations.</p>
					<a href="<?php echo esc_url( home_url( '/sanxingdui/' ) ); ?>">Explore the dossier →</a>
				</div>
				<dl>
					<div><dt>Approach</dt><dd>Evidence before speculation</dd></div>
					<div><dt>Sources</dt><dd>Museum and archaeological records</dd></div>
					<div><dt>Reading time</dt><dd>18 minutes</dd></div>
				</dl>
			</div>
		</section>

		<section class="jm-discovery jm-shell">
			<div class="jm-feelings">
				<span class="jm-section-label">Choose how you feel</span>
				<h2>Begin where you are.</h2>
				<nav aria-label="Explore by feeling">
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Lost <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Anxious <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Grieving <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/sanctuary/' ) ); ?>">Low <span>→</span></a>
					<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Curious <span>→</span></a>
				</nav>
			</div>
			<div class="jm-member">
				<span class="jm-section-label">Member preview</span>
				<h2>Your personalized Almanac, made meaningful.</h2>
				<p>Daily cultural context, private collections, and thoughtful reminders shaped around your rhythm.</p>
				<strong>$9.90 <small>/ month</small></strong>
				<a class="jm-button" href="<?php echo esc_url( home_url( '/daily-almanac/' ) ); ?>">Preview membership →</a>
			</div>
			<article class="jm-field-note">
				<span class="jm-section-label">Field notes</span>
				<h2>On the edges of the map</h2>
				<p>Real places, objects, sounds, and conversations—documented with permission and credited sources.</p>
				<a href="<?php echo esc_url( home_url( '/explore/' ) ); ?>">Read field notes →</a>
			</article>
		</section>

		<section class="jm-newsletter">
			<div class="jm-shell">
				<div><span class="jm-section-label jm-section-label--gold">Join the archive</span><h2>Stories, wisdom, and wonder—delivered.</h2><p>One carefully researched dispatch each week. No noise.</p></div>
				<form action="#" method="post"><label for="jm-email">Email address</label><div><input id="jm-email" type="email" placeholder="you@example.com" required><button type="submit">Subscribe</button></div></form>
			</div>
		</section>
		</div>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * The public collection directory is intentionally curated rather than an
 * automatic dump of every draft or tag. This keeps the archive intelligible
 * as the editorial catalogue grows, and prevents unreviewed records appearing
 * as public authority pages.
 */
function jade_myth_explore_directory() {
	$collections = array(
		array(
			'number' => '01',
			'eyebrow' => 'Foundational text',
			'title'   => 'Shan Hai Jing Atlas',
			'copy'    => 'A source-guided entrance to the Classic of Mountains and Seas: geography, beings, transmission, and later imagination.',
			'link'    => '/shan-hai-jing/',
			'cta'     => 'Enter the atlas',
		),
		array(
			'number' => '02',
			'eyebrow' => 'Mythic beings',
			'title'   => 'Creatures & entities',
			'copy'    => 'Named beings, symbols, and creature records, each separated from later folklore and modern adaptation.',
			'link'    => '/creatures/',
			'cta'     => 'Browse creatures',
		),
		array(
			'number' => '03',
			'eyebrow' => 'Material evidence',
			'title'   => 'Archaeology & lost worlds',
			'copy'    => 'Objects, excavation records, museums, and the historical questions that remain open.',
			'link'    => '/mysteries/',
			'cta'     => 'Explore mysteries',
		),
		array(
			'number' => '04',
			'eyebrow' => 'Living traditions',
			'title'   => 'Wisdom & seasonal life',
			'copy'    => 'Daoist thought, seasonal practices, and cultural reflection — without supernatural promises.',
			'link'    => '/wisdom/',
			'cta'     => 'Read wisdom',
		),
	);
	$records = array(
		array( 'Zhu Yin', 'Torch-shadow deity record', '/zhu-yin/' ),
		array( 'Fenghuang', 'Auspicious bird record', '/fenghuang/' ),
		array( 'Sanxingdui', 'Bronze Age Shu in context', '/sanxingdui/' ),
	);
	ob_start();
	?>
	<main class="jm-explore alignfull">
		<section class="jm-explore__masthead">
			<div class="jm-explore__masthead-inner">
				<p class="jm-explore__eyebrow">Jade &amp; Myth / Collection directory</p>
				<h1>Explore the Archive</h1>
				<p>Follow cultural records through text, landscape, objects, and later reception. Every collection identifies the boundary between source, interpretation, folklore, and modern imagination.</p>
				<div class="jm-explore__route" aria-label="Archive route">
					<span>Begin with a source</span><i aria-hidden="true"></i><span>Follow a collection</span><i aria-hidden="true"></i><span>Read a reviewed record</span>
				</div>
			</div>
		</section>

		<section class="jm-explore__catalogue" aria-labelledby="jm-collections-title">
			<div class="jm-explore__section-head">
				<div><p class="jm-explore__label">Catalogue</p><h2 id="jm-collections-title">Collections to begin with</h2></div>
				<p>Choose a collection, then move from its overview to source-led guides and reviewed entities. The structure stays stable as the archive expands.</p>
			</div>
			<div class="jm-explore__collection-grid">
				<?php foreach ( $collections as $collection ) : ?>
					<a class="jm-explore__collection" href="<?php echo esc_url( home_url( $collection['link'] ) ); ?>">
						<span class="jm-explore__number"><?php echo esc_html( $collection['number'] ); ?></span>
						<p class="jm-explore__label"><?php echo esc_html( $collection['eyebrow'] ); ?></p>
						<h3><?php echo esc_html( $collection['title'] ); ?></h3>
						<p><?php echo esc_html( $collection['copy'] ); ?></p>
						<span class="jm-explore__link"><?php echo esc_html( $collection['cta'] ); ?> <b aria-hidden="true">→</b></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-explore__shelves" aria-labelledby="jm-shelves-title">
			<div class="jm-explore__shelves-intro">
				<p class="jm-explore__label">Open shelves</p>
				<h2 id="jm-shelves-title">Reviewed records</h2>
				<p>These entries have crossed the current source, evidence, and editorial review gate. New records enter here only after the same check.</p>
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Read our editorial policy <b aria-hidden="true">→</b></a>
			</div>
			<div class="jm-explore__records">
				<?php foreach ( $records as $index => $record ) : ?>
					<a href="<?php echo esc_url( home_url( $record[2] ) ); ?>"><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><strong><?php echo esc_html( $record[0] ); ?></strong><em><?php echo esc_html( $record[1] ); ?></em><b aria-hidden="true">↗</b></a>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="jm-explore__method" aria-labelledby="jm-method-title">
			<div class="jm-explore__method-mark" aria-hidden="true">山<br>海</div>
			<div><p class="jm-explore__label">How to use this archive</p><h2 id="jm-method-title">One directory, clear paths.</h2></div>
			<ol>
				<li><b>01</b><span>Start with a collection overview.</span></li>
				<li><b>02</b><span>Follow links into entity and dossier pages.</span></li>
				<li><b>03</b><span>Check sources, review status, and related records.</span></li>
			</ol>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

/**
 * The Almanac has one stable, indexable home. It renders server-side first,
 * then visual.js refreshes it for the visitor's IANA time zone.
 */
function jade_myth_daily_almanac_page() {
	ob_start();
	?>
	<main class="jm-almanac-page alignfull">
		<header class="jm-almanac-page__masthead">
			<div class="jm-almanac-page__inner">
				<p class="jm-almanac-page__eyebrow">A living cultural calendar</p>
				<h1>Today’s Almanac</h1>
				<p>Daily context shaped by the lunar calendar and the twenty-four solar terms—read as a cultural invitation, never a prediction.</p>
			</div>
		</header>
		<section class="jm-almanac-page__reading" aria-label="Today’s cultural reflection">
			<div class="jm-almanac-page__card-wrap"><?php echo Jade_Myth_Almanac::card( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div class="jm-almanac-page__context">
				<p class="jm-almanac-page__eyebrow">How to read it</p>
				<h2>Calendar fact, then cultural context.</h2>
				<p>The date, lunar conversion, and solar term are calculated locally from a versioned calendar library. The daily focus and gentle prompt are editorial reflections, kept separate from the calculation.</p>
				<ul>
					<li>No fortune, fate, health, wealth, or relationship claims.</li>
					<li>No personal data is needed to view the free Almanac.</li>
					<li>Source links and the calculation version are included in the public response.</li>
				</ul>
				<p class="jm-almanac-page__sources"><a href="https://www.hko.gov.hk/en/gts/time/Calendar.htm" rel="noopener noreferrer" target="_blank">Chinese calendar reference</a><a href="https://www.hko.gov.hk/en/gts/time/24solarterms.htm" rel="noopener noreferrer" target="_blank">24 solar terms reference</a></p>
			</div>
		</section>
	</main>
	<?php
	return ob_get_clean();
}

add_filter( 'the_content', function ( $content ) {
	if ( is_front_page() && in_the_loop() && is_main_query() ) {
		return jade_myth_homepage();
	}
	if ( is_page( 'explore' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_explore_directory();
	}
	if ( is_page( 'daily-almanac' ) && in_the_loop() && is_main_query() ) {
		return jade_myth_daily_almanac_page();
	}
	if ( ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$content_type = get_post_meta( get_the_ID(), 'jm_content_type', true );
	$article_types = array(
		'cultural_reference',
		'archaeological_guide',
		'mythology_entity',
		'archaeology_entity',
	);
	if ( ! in_array( $content_type, $article_types, true ) ) {
		return $content;
	}

	$title          = get_the_title();
	$review_status  = get_post_meta( get_the_ID(), 'jm_review_status', true );
	$reviewed_by    = get_post_meta( get_the_ID(), 'jm_reviewed_by', true );
	$last_reviewed  = get_post_meta( get_the_ID(), 'jm_last_reviewed', true );
	$source_count   = absint( get_post_meta( get_the_ID(), 'jm_sources_count', true ) );
	$source_count   = $source_count ? $source_count : 1;
	$reading_minutes = max( 3, (int) ceil( str_word_count( wp_strip_all_tags( $content ) ) / 220 ) );
	$content         = preg_replace( '/<h1[^>]*>.*?<\\/h1>/is', '', $content, 1 );

	preg_match_all( '/<h2[^>]*>(.*?)<\\/h2>/is', $content, $matches );
	$toc = array();
	foreach ( $matches[1] as $index => $heading ) {
		$label = trim( wp_strip_all_tags( $heading ) );
		$id    = 'reading-' . ( $index + 1 );
		$content = preg_replace( '/<h2([^>]*)>' . preg_quote( $heading, '/' ) . '<\\/h2>/is', '<h2$1 id="' . esc_attr( $id ) . '">' . $heading . '</h2>', $content, 1 );
		$toc[] = array( 'id' => $id, 'label' => $label );
	}

	ob_start();
	?>
	<article class="jm-reading alignfull" data-content-type="<?php echo esc_attr( $content_type ); ?>">
		<header class="jm-reading__masthead">
			<div class="jm-reading__masthead-inner">
				<p class="jm-reading__kicker">Jade &amp; Myth / Research Archive</p>
				<h1><?php echo esc_html( $title ); ?></h1>
				<div class="jm-reading__ledger" aria-label="Article record">
					<span><b>Record</b><?php echo esc_html( ucwords( str_replace( '_', ' ', $content_type ) ) ); ?></span>
					<span><b>Reading</b><?php echo esc_html( $reading_minutes ); ?> min</span>
					<span><b>Sources</b><?php echo esc_html( $source_count ); ?> referenced</span>
					<span><b>Review</b><?php echo esc_html( $review_status ? str_replace( '_', ' ', $review_status ) : 'Editorial review' ); ?></span>
				</div>
			</div>
		</header>
		<div class="jm-reading__frame">
			<aside class="jm-reading__index" aria-label="On this page">
				<p>Contents</p>
				<ol>
					<?php foreach ( $toc as $item ) : ?>
						<li><a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ol>
			</aside>
			<div class="jm-reading__body">
				<div class="jm-reading__provenance"><span>Interpret with care</span><p>Primary text, later interpretation, and modern retelling are kept distinct throughout this archive.</p></div>
				<div class="jm-reading__content"><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<aside class="jm-reading__record" aria-label="Editorial record">
				<p>Editorial record</p>
				<dl>
					<div><dt>Reviewed by</dt><dd><?php echo esc_html( $reviewed_by ? $reviewed_by : 'Jade & Myth Editorial' ); ?></dd></div>
					<div><dt>Last reviewed</dt><dd><?php echo esc_html( $last_reviewed ? $last_reviewed : get_the_modified_date( 'F j, Y' ) ); ?></dd></div>
					<div><dt>Use</dt><dd>Cultural education and research.</dd></div>
				</dl>
			</aside>
		</div>
	</article>
	<?php
	return ob_get_clean();
}, 99 );

add_action( 'wp_body_open', function () {
	echo jade_myth_header();
}, 5 );

add_action( 'wp_footer', function () {
	$bottom = array(
		'Home'     => array( '/', 'home' ),
		'Explore'  => array( '/explore/', 'explore' ),
		'Almanac'  => array( '/daily-almanac/', 'calendar' ),
		'Saved'    => array( '/saved/', 'saved' ),
		'Account'  => array( '/account/', 'account' ),
	);
	?>
	<footer class="jm-footer">
		<div class="jm-shell jm-footer__inner">
			<div class="jm-footer__brand"><img src="<?php echo esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' ); ?>" width="42" height="42" alt=""><div><b>Jade &amp; Myth</b><span>Ancient myths. Living rituals.</span></div></div>
			<nav aria-label="Trust links">
				<a href="<?php echo esc_url( home_url( '/editorial-policy/' ) ); ?>">Editorial Policy</a>
				<a href="<?php echo esc_url( home_url( '/sources/' ) ); ?>">Sources</a>
				<a href="<?php echo esc_url( home_url( '/cultural-advisors/' ) ); ?>">Cultural Advisors</a>
				<a href="<?php echo esc_url( home_url( '/ai-disclosure/' ) ); ?>">AI Disclosure</a>
				<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy</a>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a>
			</nav>
			<small>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Aetheris Sun LLC. Cultural education, not medical or supernatural advice.</small>
		</div>
	</footer>
	<nav class="jm-bottom-nav" aria-label="Mobile primary navigation">
		<?php foreach ( $bottom as $label => $item ) : ?>
			<a href="<?php echo esc_url( home_url( $item[0] ) ); ?>"><?php echo jade_myth_icon( $item[1] ); ?><span><?php echo esc_html( $label ); ?></span></a>
		<?php endforeach; ?>
	</nav>
	<?php
}, 99 );

add_filter( 'get_custom_logo', function () {
	return sprintf(
		'<a href="%1$s" class="custom-logo-link" rel="home" aria-label="Jade &amp; Myth"><img src="%2$s" class="custom-logo" alt="Jade &amp; Myth" width="64" height="64"></a>',
		esc_url( home_url( '/' ) ),
		esc_url( JADE_MYTH_VISUAL_URL . 'jade-myth-mark.svg' )
	);
} );
