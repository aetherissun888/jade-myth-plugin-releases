/* Anatomical path rig. Material coordinates never receive a screen-space wave.
   Each vertex is attached to the two neighboring rigid frames on the spine. */
function createJadeDragonRig(canvas,fallback,diagnostics,isReduced,onReady) {
  'use strict';
  const gl=canvas.getContext('webgl',{alpha:true,premultipliedAlpha:false,antialias:true,powerPreference:'low-power'});
  let draw=()=>{};
  const fail=message=>{diagnostics.errors.push(message);canvas.hidden=true;fallback.style.display='block';};
  if(!gl){fail('WebGL unavailable; static fallback displayed');return draw;}
  try {
    // Anatomical centerline: skull -> upper neck -> lower neck -> belly ->
    // rising back -> rear curve -> tail root -> tapered tail fin.
    const W=2024,H=778;
    const spine=[
      [.215,.355],[.365,.285],[.463,.365],[.456,.535],
      [.395,.735],[.495,.825],[.600,.715],[.681,.535],
      [.747,.515],[.782,.652],[.818,.755],[.855,.650],
      [.852,.450],[.824,.300],[.910,.185]
    ].map(([x,y])=>[x*W,y*H]);
    const N=spine.length;
    const getFrame=Array.from({length:N},(_,i)=>`if(id<${i+.5})return bones[${i}];`).join('');
    const vertex=`precision highp float;
      attribute vec2 uv;attribute vec3 skin;uniform mat3 bones[${N}];varying vec2 tex;
      mat3 frame(float id){${getFrame}return bones[${N-1}];}
      void main(){tex=uv;vec3 p=vec3(uv*vec2(${W}.0,${H}.0),1.0);
        vec2 a=(frame(skin.x)*p).xy;vec2 b=(frame(skin.y)*p).xy;
        vec2 posed=mix(a,b,skin.z)/vec2(${W}.0,${H}.0);
        vec2 fitted=vec2(.07,.08)+posed*vec2(.86,.84);
        gl_Position=vec4(fitted.x*2.-1.,1.-fitted.y*2.,0.,1.);
      }`;
    const fragment=`precision mediump float;varying vec2 tex;uniform sampler2D picture;
      void main(){gl_FragColor=texture2D(picture,tex);}`;
    function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
    const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vertex));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
    function attachment(u,v){
      // The skull, eye, jaw, horns and forward whiskers share a rigid frame.
      if(u<.315&&v<.64)return [0,0,0];
      // Forelegs remain attached to the lower neck, rear feet to the belly.
      if(u<.325&&v>=.64)return [4,4,0];
      if(u>.565&&u<.72&&v>.81)return [6,6,0];
      // Tail plume follows the terminal frame, preserving individual brush strokes.
      if(u>.865&&v<.36)return [14,14,0];
      let best=Infinity,bone=0,weight=0;const x=u*W,y=v*H;
      for(let i=0;i<N-1;i++){
        const a=spine[i],b=spine[i+1],dx=b[0]-a[0],dy=b[1]-a[1];
        const t=Math.max(0,Math.min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)));
        const ex=x-a[0]-t*dx,ey=y-a[1]-t*dy,dist=ex*ex+ey*ey;
        if(dist<best){best=dist;bone=i;weight=t;}
      }
      return [bone,bone+1,weight];
    }
    const mobile=matchMedia('(max-width:760px)').matches;
    const cols=mobile?72:128,rows=mobile?30:54,vertices=[],weights=[];
    const add=(x,y)=>{const u=x/cols,v=y/rows;vertices.push(u,v);weights.push(...attachment(u,v));};
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){add(x,y);add(x+1,y);add(x,y+1);add(x+1,y);add(x+1,y+1);add(x,y+1);}
    function attribute(name,data,size){const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);const a=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,size,gl.FLOAT,false,0,0);}
    attribute('uv',vertices,2);attribute('skin',weights,3);
    const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
    for(const p of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T])gl.texParameteri(gl.TEXTURE_2D,p,gl.CLAMP_TO_EDGE);
    for(const p of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,p,gl.LINEAR);
    const location=gl.getUniformLocation(program,'bones[0]'),matrices=new Float32Array(N*9);
    const restAngle=spine.map((p,i)=>{const a=spine[Math.max(0,i-1)],b=spine[Math.min(N-1,i+1)];return Math.atan2(b[1]-a[1],b[0]-a[0]);});
    const image=new Image();image.onload=()=>{
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
      diagnostics.webgl=true;diagnostics.mesh=cols*rows*2;diagnostics.dragonRig='15 anatomical rigid frames, delayed head-to-tail flight path';
      draw=time=>{
        const t=isReduced()?0:time,phase=t*Math.PI*2/8.8;
        const posed=spine.map((p,i)=>{
          const lag=i*.31,amplitude=(28+1.6*i)*(mobile?.82:1);
          return [p[0]+5*Math.sin(phase-lag+.7),p[1]+amplitude*Math.sin(phase-lag)];
        });
        // Forward length constraint: joints follow the leading head without
        // stretching the spine or breathing the scales larger and smaller.
        for(let i=1;i<N;i++){
          const rx=spine[i][0]-spine[i-1][0],ry=spine[i][1]-spine[i-1][1],length=Math.hypot(rx,ry);
          const dx=posed[i][0]-posed[i-1][0],dy=posed[i][1]-posed[i-1][1],distance=Math.hypot(dx,dy);
          posed[i]=[posed[i-1][0]+dx/distance*length,posed[i-1][1]+dy/distance*length];
        }
        for(let i=0;i<N;i++){
          const a=posed[Math.max(0,i-1)],b=posed[Math.min(N-1,i+1)];
          const angle=i===0?.025*Math.cos(phase):Math.atan2(b[1]-a[1],b[0]-a[0])-restAngle[i];
          const c=Math.cos(angle),s=Math.sin(angle),r=spine[i],p=posed[i],offset=i*9;
          matrices.set([c,s,0,-s,c,0,p[0]-c*r[0]+s*r[1],p[1]-s*r[0]-c*r[1],1],offset);
        }
        const dpr=Math.min(devicePixelRatio,mobile?1.25:1.5),w=Math.round(canvas.clientWidth*dpr),h=Math.round(canvas.clientHeight*dpr);
        if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h);}
        gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.uniformMatrix3fv(location,false,matrices);gl.drawArrays(gl.TRIANGLES,0,vertices.length/2);
      };
      draw(0);onReady();
    };image.onerror=()=>fail('Dragon texture failed to load');image.src=fallback.currentSrc || fallback.src;
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();fail('WebGL context lost; static fallback displayed');});
  }catch(error){fail(error.message);}
  return time=>draw(time);
}
