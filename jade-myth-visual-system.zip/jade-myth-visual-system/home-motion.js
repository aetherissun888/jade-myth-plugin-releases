/* Approved local anatomical motion. No tracking, persistence or Oracle handlers. */
(() => {
  'use strict';
  const hero=document.querySelector('#motion-hero'), button=document.querySelector('#motion-toggle');
  if(!hero || !button)return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let manualPause=false, inView=true, active=true, renderDragon=()=>{}, raf=0, previous=0, elapsed=0;
  const diagnostics={errors:[],frames:0,webgl:false,reduced:reduced.matches,active:true,mesh:0};
  window.jadeMotionDiagnostics=diagnostics;
  addEventListener('error', e=>diagnostics.errors.push(e.message));
  const svgNS='http://www.w3.org/2000/svg';
  function el(tag,attrs,parent){const n=document.createElementNS(svgNS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,v);parent.append(n);return n;}
  function circle(parent,r,width=1){return el('circle',{r,'stroke-width':width},parent);}
  function radialLine(parent,angle,r1,r2,width=1){const a=angle*Math.PI/180;return el('path',{d:`M${Math.sin(a)*r1} ${-Math.cos(a)*r1}L${Math.sin(a)*r2} ${-Math.cos(a)*r2}`,'stroke-width':width},parent);}
  const second=document.querySelector('#ring-two');
  circle(second,203);circle(second,187);
  for(let i=0;i<120;i++)radialLine(second,i*3,i%5===0?189:196,202,i%5===0?1.25:.65);
  const third=document.querySelector('#ring-three');circle(third,182);circle(third,133);
  // Early-Heaven arrangement, clockwise from top; each triple is top-to-bottom.
  const trigrams=[['Qian',[1,1,1]],['Xun',[1,1,0]],['Kan',[0,1,0]],['Gen',[1,0,0]],['Kun',[0,0,0]],['Zhen',[0,0,1]],['Li',[1,0,1]],['Dui',[0,1,1]]];
  trigrams.forEach(([name,bits],i)=>{
    const g=el('g',{transform:`rotate(${i*45})`,'data-trigram':name,'data-lines':bits.join('')},third);
    bits.forEach((yang,j)=>{
      const y=-175+j*10;
      if(yang)el('rect',{x:-20,y,width:40,height:6.5,rx:.4,class:'trigram'},g);
      else for(const x of [-20,4.5])el('rect',{x,y,width:15.5,height:6.5,rx:.4,class:'trigram'},g);
    });
    radialLine(third,i*45+22.5,134,181,.7);
  });
  const fourth=document.querySelector('#ring-four');circle(fourth,128);circle(fourth,110);
  for(let i=0;i<64;i++){
    const g=el('g',{transform:`rotate(${i*360/64})`,class:'hexagram'},fourth);
    // Every binary six-line symbol occurs once; no invented pseudo-Chinese glyphs.
    for(let j=0;j<6;j++)el('path',{d:(i>>j&1)?`M-2.8 ${-126+j*2.5}h5.6`:`M-2.8 ${-126+j*2.5}h2 M.8 ${-126+j*2.5}h2`},g);
  }
  const dust=document.querySelector('#stardust');
  for(let i=0;i<22;i++){
    const a=i*2.39996,r=228+(i*17%27);
    el('circle',{cx:Math.cos(a)*r,cy:Math.sin(a)*r,r:i%4===0?1.15:.55,class:'dust',style:`--delay:-${i*.73}s`},dust);
  }
  function state(){
    const was=active;active=inView&&!document.hidden&&!manualPause&&!reduced.matches;
    hero.classList.toggle('motion-paused',!active);diagnostics.active=active;diagnostics.reduced=reduced.matches;
    button.textContent=reduced.matches?'Reduced motion':' '+(manualPause?'Play motion':'Pause motion');
    button.disabled=reduced.matches;button.setAttribute('aria-pressed',String(manualPause));
    if(!active){cancelAnimationFrame(raf);raf=0;previous=0;renderDragon(elapsed);}
    else if(!was||!raf)raf=requestAnimationFrame(frame);
  }
  function frame(now){
    if(!active)return;
    if(previous)elapsed+=Math.min((now-previous)/1000,.07);
    previous=now;renderDragon(elapsed);diagnostics.frames++;raf=requestAnimationFrame(frame);
  }
  new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;state();},{threshold:.015}).observe(hero);
  document.addEventListener('visibilitychange',state);reduced.addEventListener('change',state);
  button.addEventListener('click',()=>{manualPause=!manualPause;state();});
  renderDragon = createJadeDragonRig(document.querySelector('#dragon'), document.querySelector('#dragon-fallback'), diagnostics, () => reduced.matches, () => { renderDragon(elapsed); state(); });
  state();
})();
